# *********************************************************************
# * A script to set classpath and path on Linux/Unix System.
# * create by pengdy
# * run this script.
# ********************************************************************
Start_Watchdog()
{
	
	sh watchdog.sh >/dev/null 2>&1 &
	echo "watchdog.sh is started."
}

Stop_Watchdog()
{
	# kill $1 if it exists.
	PID_LIST=`ps -ef|grep "sh watchdog.sh"|grep -v grep|awk '{printf "%s ", $2}'`
	for PID in $PID_LIST
	do
	  if kill -9 $PID
		 then
			echo "Process $one($PID) was stopped at " `date`
			echo "watchdog.sh is stoped."
	  fi
	done
	
	PID_LIST=`pgrep -f "sh watchdog.sh"|awk '{printf "%s ", $1}'`
	for PID in $PID_LIST
	do
	  if kill -9 $PID
		 then
			echo "Process $one($PID) was stopped at " `date`
			echo "watchdog.sh is stoped."
	  fi
	done
}

Status_Watchdog()
{
	PID_NUM=`ps -ef|grep "sh watchdog.sh"|grep -v grep|wc -l`
	PID_NUM1=`pgrep -f "sh watchdog.sh"|wc -l`
	if [ $PID_NUM -gt 0 -o $PID_NUM1 -gt 0 ]
		then
		{
			echo "watchdog.sh is started."
		}
		else
		{
			echo "watchdog.sh is stoped."
		}
	fi
}


case "$1" in
'start')
	Start_Watchdog
	;;
'stop')
	Stop_Watchdog
	;;
'restart')
	Stop_Watchdog
	Start_Watchdog
	;;
'status')
	Status_Watchdog
	;;	
*)
	echo "Usage: $0 {start|stop|restart}"
	echo "	start : To start the watchdog.sh"
	echo "	stop  : To stop the watchdog.sh"
	echo "	restart  : To restart the watchdog.sh"
	echo "	status  : Show status the watchdog.sh"
	RETVAL=1
	;;
esac

exit 0
