# *********************************************************************
# * A script to set classpath and path on Linux/Unix System.
# * create by pengdy
# * run this script.
# *********************************************************************

#!/bin/bash
#set -x

check_server() {

	ServerName=$1
	ServerPort=$2
        WorkDir=$3
	
	Current_Time=`date +"%Y-%m-%d %H:%M:%S.%N"`
	TCPListeningnum=`netstat -an | grep ":$ServerPort" |   awk 'substr($1,0,3) =="tcp" && $NF == "LISTEN" {print $0}' | wc -l`
        echo "[${Current_Time}] monitor start...." >> ${WorkDir}/logs/${RunDogLogFile}
	echo "${ServerName} listenging port num:${TCPListeningnum}" >> ${WorkDir}/logs/${RunDogLogFile}
	if [ $TCPListeningnum = 1 ]
		then
		{
			#echo "The ${ServerName} ${ServerPort} port is listening"
			echo "[${Current_Time}] The ${ServerName} ${ServerPort} port is listening" >> ${WorkDir}/logs/${RunDogLogFile}
		}
		else
		{
			#echo "The ${ServerName} ${ServerPort} port is not listening"
			echo "[${Current_Time}] The ${ServerName} ${ServerPort} port is not listening" >> ${WorkDir}/logs/${RunDogLogFile}
			echo "[${Current_Time}] killall ${ServerName} ${ServerPort} port now !" >> ${WorkDir}/logs/${RunDogLogFile}
			# kill $1 if it exists.
			PID_LIST=`ps -ef|grep ${ServerName}|grep -v grep|awk '{printf "%s ", $2}'`
			for PID in $PID_LIST
			do
			  if kill -9 $PID
				 then
					echo "Process $one($PID) was stopped at " `date`  >> ${WorkDir}/logs/${RunDogLogFile}
					echo "${ServerName} Server is stoped."  >> ${WorkDir}/logs/${RunDogLogFile}
			  fi
			done
			#echo "check ${ServerName} quit, now restart ${ServerName} ..."
			echo "[${Current_Time}] check ${ServerName} quit, now restart ${ServerName} ..." >> ${WorkDir}/logs/${RunDogLogFile}
			
			sh ${WorkDir}/ctrl_server.sh restart ${WorkDir}
		}
	fi
	
	Current_Time=`date +"%Y-%m-%d %H:%M:%S.%N"`
	#用ps获取${ServerName}进程数量
	NUM=`ps aux | grep ${ServerName} | grep -v grep |wc -l`
	#echo "The ${ServerName} process:${NUM}"
	echo "[${Current_Time}] ${ServerName} Process:${NUM}" >> ${WorkDir}/logs/${RunDogLogFile}
	
	#少于1，重启进程
	if [ "${NUM}" -lt "1" ];then
		echo "[${Current_Time}] ${ServerName} was killed" >> ${WorkDir}/logs/${RunDogLogFile}
		sh ${WorkDir}/ctrl_server.sh restart ${WorkDir}
	#大于1，杀掉所有进程，重启
	elif [ "${NUM}" -gt "1" ];then
		echo "[${Current_Time}] ${ServerName} Process more than 1,killall ${ServerName}" >> ${WorkDir}/logs/${RunDogLogFile}
		killall -9 $ServerName
		sh ${WorkDir}/ctrl_server.sh restart ${WorkDir}
	fi
	#kill僵尸进程
	NUM_STAT=`ps aux | grep ${ServerName} | grep T | grep -v grep | wc -l`
	  
	if [ "${NUM_STAT}" -gt "0" ];then
		killall -9 ${ServerName}
		sh ${WorkDir}/ctrl_server.sh restart ${WorkDir}
	fi
	
}

WORK_DIR=./
Ctrl_Server=./ctrl_server.sh
RunDogLogFile=watchdog.log

while [ 1 ]
do
	check_server native-config 8888 /home/ap/suap/nativeConfig
	check_server native-registry 10000 /home/ap/suap/nativeRegistry
	sleep 60
done
