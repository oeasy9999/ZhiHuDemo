# *********************************************************************
# * A script to set classpath and path on Linux/Unix System.
# * create by pengdy
# * run this script.
# ********************************************************************
Start_Server()
{
	echo "begin start_server: $1"
        if [ $# -eq 1 ] 
                then
                {
			${JAVA_HOME}/bin/java -Dname=native-config -jar $1/ccb-suap-native-config.jar >/dev/null 2>&1 &
			echo "1.Server native-config is starting..."
		}
		else
                {
			${JAVA_HOME}/bin/java -Dname=native-config -jar ccb-suap-native-config.jar >/dev/null 2>&1 &
			echo "2.Server native-config is starting..."
		}
	fi
}

Stop_Server()
{
	# kill $1 if it exists.
	PID_LIST=`ps -ef|grep native-config|grep -v grep|awk '{printf "%s ", $2}'`
	echo "PID_LIST: ${PID_LIST}"
	for PID in $PID_LIST
	do
	  if kill -9 $PID
		 then
			echo "Process $one($PID) was stopped at " `date`
			echo "Server native-config is stoped."
	  fi
	done
}



####---- main ----####
#export JAVA_HOME=/opt/java6
#export CLASSPATH=.:$JAVA_HOME/lib:$JAVA_HOME/jre/lib
Server_ROOT=/home/ap/suap/nativeConfig
#export Server_ROOT
cd $Server_ROOT

case "$1" in
'start')
	Start_Server $2
	;;
'stop')
	Stop_Server
	;;
'restart')
	Stop_Server
	Start_Server $2
	;;
*)
	echo "Usage: $0 {start|stop|restart}"
	echo "	start : To start the application of Server"
	echo "	stop  : To stop the application of Server"
	echo "	restart  : To restart the application of Server"
	RETVAL=1
	;;
esac

exit 0
