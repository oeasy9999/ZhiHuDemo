# *********************************************************************
# * A script to set classpath and path on Linux/Unix System.
# * create by pengdy
# * run this script.
# ********************************************************************
Start_Server()
{
	
	${JAVA_HOME}/bin/java -Dname=native-business -jar ccb-suap-native-business-service.jar >/dev/null 2>&1 &
	echo "Server native-business is starting..."
}

Stop_Server()
{
	# kill $1 if it exists.
	PID_LIST=`ps -ef|grep native-business|grep -v grep|awk '{printf "%s ", $2}'`
	for PID in $PID_LIST
	do
	  if kill -9 $PID
		 then
			echo "Process $one($PID) was stopped at " `date`
			echo "Server native-business is stoped."
	  fi
	done
}



####---- main ----####
#export JAVA_HOME=/opt/java6
#export CLASSPATH=.:$JAVA_HOME/lib:$JAVA_HOME/jre/lib
Server_ROOT=/home/ap/suap/nativeBusiness
#export Server_ROOT
cd $Server_ROOT

case "$1" in
'start')
	Start_Server
	;;
'stop')
	Stop_Server
	;;
'restart')
	Stop_Server
	Start_Server
	;;
*)
	echo "Usage: $0 {start|stop|restart}"
	echo "	start : To start the application of Server"
	echo "	stop  : To stop the application of Server"
	echo "	restart  : To restart the application of Server"
	RETVAL=1
	;;
esac

exit 0
