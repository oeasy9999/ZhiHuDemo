# *********************************************************************
# * A script to set classpath and path on Linux/Unix System.
# * create by pengdy
# * run this script.
# *********************************************************************

#!/bin/bash
#set -x

check_server() {

	ServerName=$1
	ServerPort=$2
	
	Current_Time=`date +"%Y-%m-%d %H:%M:%S.%N"`
	TCPListeningnum=`netstat -an | grep ":$ServerPort" |   awk 'substr($1,0,3) =="tcp" && $NF == "LISTEN" {print $0}' | wc -l`
	echo "${ServerName} listenging port num:${TCPListeningnum}" >> ${WORK_DIR}/logs/${RunDogLogFile}
	if [ $TCPListeningnum = 1 ]
		then
		{
			echo "[${Current_Time}] The ${ServerName} ${ServerPort} port is listening" >> ${WORK_DIR}/logs/${RunDogLogFile}
		}
		else
		{
			echo "[${Current_Time}] The ${ServerName} ${ServerPort} port is not listening" >> ${WORK_DIR}/logs/${RunDogLogFile}
			echo "[${Current_Time}] killall ${ServerName} ${ServerPort} port now !" >> ${WORK_DIR}/logs/${RunDogLogFile}
			# kill $1 if it exists.
			PID_LIST=`ps -ef|grep ${ServerName}|grep -v grep|awk '{printf "%s ", $2}'`
			for PID in $PID_LIST
			do
			  if kill -9 $PID
				 then
					echo "Process $one($PID) was stopped at " `date`  >> ${WORK_DIR}/logs/${RunDogLogFile}
					echo "${ServerName} Server is stoped."  >> ${WORK_DIR}/logs/${RunDogLogFile}
			  fi
			done
			echo "[${Current_Time}] check ${ServerName} quit, now restart ${ServerName} ..." >> ${WORK_DIR}/logs/${RunDogLogFile}
			
			${Ctrl_Server} restart
		}
	fi
	
	Current_Time=`date +"%Y-%m-%d %H:%M:%S.%N"`
	#用ps获取${ServerName}进程数量
	NUM=`ps aux | grep ${ServerName} | grep -v grep |wc -l`
	echo "[${Current_Time}] ${ServerName} Process:${NUM}" >> ${WORK_DIR}/logs/${RunDogLogFile}
	
	#少于1，重启进程
	if [ "${NUM}" -lt "1" ];then
		echo "[${Current_Time}] ${ServerName} was killed" >> ${WORK_DIR}/logs/${RunDogLogFile}
		${Ctrl_Server} restart
	#大于1，杀掉所有进程，重启
	elif [ "${NUM}" -gt "1" ];then
		echo "[${Current_Time}] ${ServerName} Process more than 1,killall ${ServerName}" >> ${WORK_DIR}/logs/${RunDogLogFile}
		killall -9 $ServerName
		${Ctrl_Server} restart
	fi
	#kill僵尸进程
	NUM_STAT=`ps aux | grep ${ServerName} | grep T | grep -v grep | wc -l`
	  
	if [ "${NUM_STAT}" -gt "0" ];then
		killall -9 ${ServerName}
		${Ctrl_Server} restart
	fi
	
}

WORK_DIR=./
Ctrl_Server=./ctrl_server.sh
RunDogLogFile=watchdog.log

Current_Time=`date +"%Y-%m-%d %H:%M:%S.%N"`
echo "[${Current_Time}] monitor start...." >> ${WORK_DIR}/logs/${RunDogLogFile}

while [ 1 ]
do
	check_server native-facegpups 8085;
	sleep 60
done
