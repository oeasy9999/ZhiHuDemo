package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

import java.io.Serializable;

public class GroupDeleteFeatureOutVo implements Serializable {

	private static final long serialVersionUID = -1L;
	private String result;
	private String errorMessage;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "GroupDeleteOutVo [result=" + result + ", errorMessage=" + errorMessage + "]";
	}
	
}
