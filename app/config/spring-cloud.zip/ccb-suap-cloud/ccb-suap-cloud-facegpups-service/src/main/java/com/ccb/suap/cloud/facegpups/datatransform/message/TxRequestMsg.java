package com.ccb.suap.cloud.facegpups.datatransform.message;

import java.io.Serializable;

public class TxRequestMsg implements Serializable{

	private static final long serialVersionUID = 1L;
	private TxRequestMsgHead tx_header;
	private TxRequestMsgBody tx_body;
	
	public TxRequestMsgHead getTx_header() {
		return tx_header;
	}
	public void setTx_header(TxRequestMsgHead tx_header) {
		this.tx_header = tx_header;
	}
	public TxRequestMsgBody getTx_body() {
		return tx_body;
	}
	public void setTx_body(TxRequestMsgBody tx_body) {
		this.tx_body = tx_body;
	}
	@Override
	public String toString() {
		return "TxRequestMsg [getTx_header()=" + getTx_header()!=null?getTx_header().toString():null + ", getTx_body()=" + getTx_body()!=null?getTx_body().toString():null + "]";
	}
	
}
