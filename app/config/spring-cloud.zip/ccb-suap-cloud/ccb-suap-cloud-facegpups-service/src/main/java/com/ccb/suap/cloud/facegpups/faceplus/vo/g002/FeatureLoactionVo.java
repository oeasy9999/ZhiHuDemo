package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

public class FeatureLoactionVo {

    private Double lat;
    private Double lon;
    private Double distance;
    private int index;
    
    public FeatureLoactionVo() {
        // TODO Auto-generated constructor stub
    }
    
    public FeatureLoactionVo(Double lat, Double lon, Double distance,int index) {
        super();
        this.lat = lat;
        this.lon = lon;
        this.distance = distance;
        this.index = index;
    }
    public Double getLat() {
        return lat;
    }
    public void setLat(Double lat) {
        this.lat = lat;
    }
    public Double getLon() {
        return lon;
    }
    public void setLon(Double lon) {
        this.lon = lon;
    }
    public Double getDistance() {
        return distance;
    }
    public void setDistance(Double distance) {
        this.distance = distance;
    }

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
}
