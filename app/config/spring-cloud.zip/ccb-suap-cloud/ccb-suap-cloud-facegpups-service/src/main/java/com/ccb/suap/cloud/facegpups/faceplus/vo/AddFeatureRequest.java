package com.ccb.suap.cloud.facegpups.faceplus.vo;


public class AddFeatureRequest {

	private String ip;
	private String port1;
	private String port2;
	private String port3;
	private String traceid;
	private String groupname;
	private String featureid;
	private String feature;
	
	
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getPort1() {
		return port1;
	}
	public String getTraceid() {
		return traceid;
	}
	public void setTraceid(String traceid) {
		this.traceid = traceid;
	}
	public void setPort1(String port1) {
		this.port1 = port1;
	}
	public String getPort2() {
		return port2;
	}
	public void setPort2(String port2) {
		this.port2 = port2;
	}
	public String getPort3() {
		return port3;
	}
	public void setPort3(String port3) {
		this.port3 = port3;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public String getFeatureid() {
		return featureid;
	}
	public void setFeatureid(String featureid) {
		this.featureid = featureid;
	}
	public String getFeature() {
		return feature;
	}
	public void setFeature(String feature) {
		this.feature = feature;
	}
	@Override
	public String toString() {
		return "AddFeatureRequest [ip=" + ip + ", port1=" + port1 + ", port2=" + port2 + ", port3=" + port3
				+ ", groupname=" + groupname + ", featureid=" + featureid + ", feature=" + feature + ", traceid="
				+ traceid + "]";
	}
	

	
}
