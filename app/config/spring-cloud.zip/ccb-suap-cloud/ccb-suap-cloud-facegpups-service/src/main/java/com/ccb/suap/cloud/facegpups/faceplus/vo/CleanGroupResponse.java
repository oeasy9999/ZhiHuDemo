package com.ccb.suap.cloud.facegpups.faceplus.vo;


public class CleanGroupResponse {

	private boolean result;
	private String error;
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	@Override
	public String toString() {
		return "CleanGroupResponse [result=" + result + ", error=" + error + "]";
	}

	
}
