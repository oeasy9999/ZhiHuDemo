package com.ccb.suap.cloud.facegpups.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import com.ccb.suap.cloud.facegpups.model.GpumpFeatureModel;

@Mapper
@Component
public interface GpumpFeatureMapper {

	Integer count(@Param("logic_db_id")String logic_db_id,@Param("gpu_type_id")String gpu_type_id);
	
	GpumpFeatureModel select(@Param("logic_db_id")String logic_db_id,@Param("gpu_type_id")String gpu_type_id,@Param("cust_id")String cust_id);
	
	GpumpFeatureModel selectbyfeature(@Param("logic_db_id")String logic_db_id,@Param("gpu_type_id")String gpu_type_id,@Param("feature")String feature);
	
	List<GpumpFeatureModel> selectAll(@Param("logic_db_id")String logic_db_id,@Param("gpu_type_id")String gpu_type_id);
	
	Integer insert(GpumpFeatureModel model);
	
	int update(GpumpFeatureModel model);
	
	int delete(@Param("logic_db_id")String logic_db_id,@Param("gpu_type_id")String gpu_type_id,@Param("cust_id")String cust_id);
}
