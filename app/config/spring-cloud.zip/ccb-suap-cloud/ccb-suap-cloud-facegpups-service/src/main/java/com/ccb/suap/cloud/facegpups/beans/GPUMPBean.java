package com.ccb.suap.cloud.facegpups.beans;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.ccb.suap.cloud.facegpups.inf.TrxInterface;

import sun.misc.BASE64Encoder;

public abstract class GPUMPBean implements TrxInterface{

	public GPUMPBean(){
		super();
	}
	/**
	 * 删除文件方法
	 * @param path 文件绝对路径
	 * @return
	 */
	public boolean deleteImage(String path)
	{
		boolean flag=true;
		try {
			File f=new File(path);
			if(f.exists()&&f.isFile())
			{
				f.delete();
			}
		} catch (Exception e) {
			return false;
		}
		return flag;
	}
	/**
	 * 读取文件内容并且转为base64
	 * @param path
	 * @return
	 */
	public static String readFiletobase64(String path)
	{
		if(path==null)
		{
			System.err.println("imagefile param is null");
			return null;
		}
		File f=new File(path);
		String data=null;
		if(f.exists()){
			FileInputStream targetFile = null;
			try {
				targetFile=new FileInputStream(f);
				byte[] b = new byte[targetFile.available()];
				//System.out.println(targetFile.available());
				targetFile.read(b);
				BASE64Encoder encoder=new BASE64Encoder();
				data = encoder.encode(b);
				targetFile.close();
			} catch (FileNotFoundException e) {
				System.err.println("FileNotFoundException: "+e.getMessage());
			} catch (IOException e) {
				System.err.println("IOException: "+e.getMessage());
			}finally{
				if(targetFile!=null){
					try {
						targetFile.close();
					} catch (IOException e) {
						System.err.println("IOException: "+e.getMessage());
					}
				}
			}
		}else
		{
			System.err.println("filePath is not exist, "+path);
		}
		return data;
	}
}
