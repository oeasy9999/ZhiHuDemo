package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

public class Faceattr {

	private String age;
	private String gender;
	private String roll;
	private String pitch;
	private String yaw;
	private String quality;
	private String blurness;
	private String left_eye_status_type;
	private String left_eye_status;
	private String right_eye_status_type;
	private String right_eye_status;
	private String mouth_status_type;
	private String mouth_status;

	public String getQuality() {
		return quality;
	}
	public void setQuality(String quality) {
		this.quality = quality;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRoll() {
		return roll;
	}
	public void setRoll(String roll) {
		this.roll = roll;
	}
	public String getPitch() {
		return pitch;
	}
	public void setPitch(String pitch) {
		this.pitch = pitch;
	}
	public String getYaw() {
		return yaw;
	}
	public void setYaw(String yaw) {
		this.yaw = yaw;
	}
	public String getBlurness() {
		return blurness;
	}
	public void setBlurness(String blurness) {
		this.blurness = blurness;
	}
	public String getLeft_eye_status_type() {
		return left_eye_status_type;
	}
	public void setLeft_eye_status_type(String leftEyeStatusType) {
		left_eye_status_type = leftEyeStatusType;
	}
	public String getLeft_eye_status() {
		return left_eye_status;
	}
	public void setLeft_eye_status(String leftEyeStatus) {
		left_eye_status = leftEyeStatus;
	}
	public String getRight_eye_status_type() {
		return right_eye_status_type;
	}
	public void setRight_eye_status_type(String rightEyeStatusType) {
		right_eye_status_type = rightEyeStatusType;
	}
	public String getRight_eye_status() {
		return right_eye_status;
	}
	public void setRight_eye_status(String rightEyeStatus) {
		right_eye_status = rightEyeStatus;
	}
	public String getMouth_status_type() {
		return mouth_status_type;
	}
	public void setMouth_status_type(String mouthStatusType) {
		mouth_status_type = mouthStatusType;
	}
	public String getMouth_status() {
		return mouth_status;
	}
	public void setMouth_status(String mouthStatus) {
		mouth_status = mouthStatus;
	}
}
