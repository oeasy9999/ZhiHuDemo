package com.ccb.suap.cloud.facegpups.faceplus.vo;


public class DeleteFeatureResponse{

	private boolean result;
	private String error;
	private String featureid;
	
	public String getFeatureid() {
		return featureid;
	}
	public void setFeatureid(String featureid) {
		this.featureid = featureid;
	}
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	@Override
	public String toString() {
		return "DeleteFeatureResponse [result=" + result + ", error=" + error + ", featureid=" + featureid + "]";
	}
	
}
