package com.ccb.suap.cloud.facegpups.model;

/**
 * @author oeasy9999
 * @create 2020-05-30 16:42
 */
public class GpumpLogicCapModel {
  private String logicDbId;     //逻辑库主键
  private int totalCapacity; //最大容量
  private int capacity;      //当前容量

  public String getLogicDbId() {
    return logicDbId;
  }

  public void setLogicDbId(String logicDbId) {
    this.logicDbId = logicDbId;
  }

  public int getTotalCapacity() {
    return totalCapacity;
  }

  public void setTotalCapacity(int totalCapacity) {
    this.totalCapacity = totalCapacity;
  }

  public int getCapacity() {
    return capacity;
  }

  public void setCapacity(int capacity) {
    this.capacity = capacity;
  }

  @Override
  public String toString() {
    return "GpumpLogicCapModel [logicDbId=" + logicDbId + ", totalCapacity=" + totalCapacity + ", capacity=" + capacity + ']';
  }
}
