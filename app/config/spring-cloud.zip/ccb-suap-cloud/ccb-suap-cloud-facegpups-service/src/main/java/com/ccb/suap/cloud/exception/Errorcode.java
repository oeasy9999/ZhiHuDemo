//package com.ccb.suap.cloud.exception;
//
//public class Errorcode {
//
//	public static String NOERROR="000000000000"; 	 	//无错误
//
//	
//	public static String syscode="GPUPS";               //系统编码
//	
//	public static String mode="Z";						//主服务模块
//	public static String gpumpmode="G";                 //GPU模块
//	public static String databasemode="S";				//数据库模块
//	
//	
//	public static String errortype_FA="FA";                //业务报错（正常错误，由前端根据错误码进行相应逻辑处理）
//	public static String errortype_WA="WA"; 			   //交易报错（异常报错，交易级别错误）
//	public static String errortype_ER="ER";                //系统报错（异常报错，系统级别报错）
//	
//	
//	public static String NODATA=syscode+mode+errortype_FA+"0001";			  		//无数据
//	public static String DATABASEERROR=syscode+databasemode+errortype_FA+"0006";    //数据库错误
//	public static String DATABASEEDATARROR=syscode+databasemode+errortype_FA+"0007";    //数据库数据错误
//	public static String RELATEERROR=syscode+mode+errortype_FA+"0008";         		//注册失败
//	public static String TXCODEERROR=syscode+mode+errortype_FA+"0009";         		//交易码错误
//	public static String EXCEPTION=syscode+mode+errortype_ER+"0010";         		//内部异常
//	
//	public static String PARAMENOEXIST=syscode+mode+errortype_FA+"0011";       		    //系统参数不存在
//	public static String GPURESULTERROR=syscode+gpumpmode+errortype_WA+"0014"; 			//GPU返回失败，返回空
//	public static String GPUSEARCHERROR=syscode+gpumpmode+errortype_FA+"0015"; 			//GPU识别失败
//	public static String GPUDELETEUSERERROR=syscode+gpumpmode+errortype_FA+"0016"; 		//GPU删除用户
//	public static String GPUEXTRACTERERROR=syscode+gpumpmode+errortype_FA+"0017"; 		//GPU采集失败
//	public static String GPUGROUPERROR=syscode+mode+errortype_ER+"0018"; 				//GPU分组不存在
//	public static String DATABASEPRIMARYERROR=syscode+databasemode+errortype_ER+"0019"; //数据库唯一约束错误
//	
//	public static String DATABASEDELLETERROR=syscode+databasemode+errortype_FA+"0020";   //没有删除的数据
//	
//	public static String SYSPARAREFRESHERROR=syscode+mode+errortype_ER+"0021";   		//刷新配置参数错误
//	public static String LOGICFACEDBERROR=syscode+databasemode+errortype_FA+"0022";   	//逻辑库出错,不存在或类型不匹配
//	public static String LOGICFACEDBMOUNTGPUERROR=syscode+databasemode+errortype_FA+"0023";   	//逻辑库出错,挂载GPU错误
//	
//	public static String REALDBERROR=syscode+databasemode+errortype_FA+"0024";   		//物理库出错,不存在或类型不匹配
//	public static String GPUINFOERROR=syscode+databasemode+errortype_FA+"0025";   		//GPU信息不存在
//	public static String GPUTYPEERROR=syscode+databasemode+errortype_FA+"0026";   		//注册库没有快速库的的GPU类型
//}
