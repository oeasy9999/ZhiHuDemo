package com.ccb.suap.cloud.facegpups.faceplus.vo;


public class GetVersionResponse {

	private boolean result;
	private String error;
	private String version;

	public boolean getResult() {
		return result;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "GetVersionResponse [result=" + result + ", error=" + error + ", version=" + version + "]";
	}

}
