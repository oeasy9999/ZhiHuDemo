package com.ccb.suap.cloud.facegpups.faceplus.vo.g001;

public class VersionOutVo {

	private String result;
	private String error;
	private String version;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	@Override
	public String toString() {
		return "VersionOutVo [result=" + result + ", error=" + error + ", version=" + version + "]";
	}
}
