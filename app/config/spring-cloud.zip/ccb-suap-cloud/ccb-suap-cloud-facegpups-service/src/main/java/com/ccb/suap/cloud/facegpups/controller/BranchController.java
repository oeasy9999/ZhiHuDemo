package com.ccb.suap.cloud.facegpups.controller;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.facegpups.beans.GPUMPBean;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.faceplus.vo.AddFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.AddFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureResponse;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.mapper.TraceLogger;
import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFeatureModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFidcustMapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;
import com.ccb.suap.cloud.facegpups.service.GpumpCustInfoService;
import com.ccb.suap.cloud.facegpups.service.GpumpFeatureService;
import com.ccb.suap.cloud.facegpups.service.GpumpFidcustMapService;
import com.ccb.suap.cloud.facegpups.service.GpumpRealFacedbService;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpGpuInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.cloud.facegpups.vo.CopyRealFacedbServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.CopyRealFacedbServiceOutVo;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.log.TraceLog;

@Controller
public class BranchController {

	private GpumpFidcustMapService GpumpFidcustMapService=GpumpDaoFactory.getDaoManager().getGpumpFidcustMapService();
	private GpumpRealFacedbService GpumpRealFacedbService= GpumpDaoFactory.getDaoManager().getGpumpRealFacedbService();
	private GpumpCustInfoService GpumpCustInfoService=GpumpDaoFactory.getDaoManager().getGpumpCustInfoService();
	private GpumpFeatureService GpumpFeatureService=GpumpDaoFactory.getDaoManager().getGpumpFeatureService();
	private static final Logger LOGGER = LoggerFactory.getLogger(BranchController.class);
	@Autowired
    private TraceLogger traceLogger; 
	@RequestMapping(value = "/branchManage/query", produces = "text/json; charset=utf-8")
	@ResponseBody
	public String query() {
		Map<String, Object> result = new HashMap<String, Object>();
		
		result.put("success", true);
		result.put("message", "查询列表成功");
		result.put("list", null);
		
		return JSON.toJSONString(result);
	}
    @RequestMapping(value = "/testjson")
    public String testjson()
    {
    	System.out.println("---------------testjson------------");
    	return "/Test_index";
    }

    @RequestMapping(value = "/GpumpService_CopyRealFacedb",consumes="application/json",produces = "application/json; charset=utf-8")
    @ResponseBody
    public JSONObject GpumpService_CopyRealFacedb(@RequestBody JSONObject data)
    {
    	int sum_error=0;
    	int sum_success=0;
    	CopyRealFacedbServiceInVo invo=JSONObject.toJavaObject(data, CopyRealFacedbServiceInVo.class);
    	CopyRealFacedbServiceOutVo outvo=new CopyRealFacedbServiceOutVo();
    	if(invo==null)
		{
    		outvo.setErrorcode("-1");
    		outvo.setErrormessage("json param trans object error");
    		return (JSONObject) JSONObject.toJSON(outvo);
		}
		String real_db_id_source = invo.getReal_db_id_source();
		String real_db_id_order_list = invo.getReal_db_id_order();
		if(real_db_id_source==null||real_db_id_order_list==null)
		{
			outvo.setErrorcode("-1");
    		outvo.setErrormessage("real_db_id_source or real_db_id_order is null");
    		return (JSONObject) JSONObject.toJSON(outvo);
		}
		GpumpRealFacedbModel GpumpRealFacedbModel_source =GpumpRealFacedbService.select(real_db_id_source);
		String gpu_name_source = GpumpRealFacedbModel_source.getGpu_name();
		GpumpGpuInfoModel gpumpGpuInfoModel_source = GpumpGpuInfoParaUtil.getGpuInfoValue(gpu_name_source);
		if(gpumpGpuInfoModel_source==null)
		{
			outvo.setErrorcode("-1");
    		outvo.setErrormessage("gpumpGpuInfoModel_source is null");
    		return (JSONObject) JSONObject.toJSON(outvo);
		}
		String gpu_type_id_source = gpumpGpuInfoModel_source.getGpu_type_id();
		String[] read_id=real_db_id_order_list.split(":");
		for(String read_id_order:read_id)
		{
			LOGGER.debug("begin copy to "+read_id_order);
			GpumpRealFacedbModel GpumpRealFacedbModel_order = GpumpRealFacedbService.select(read_id_order);
			String gpu_name_order = GpumpRealFacedbModel_order.getGpu_name();
			String gpu_face_db_order = GpumpRealFacedbModel_order.getGpu_face_db();
			GpumpGpuInfoModel gpumpGpuInfoModel_order = GpumpGpuInfoParaUtil.getGpuInfoValue(gpu_name_order);
			if(gpumpGpuInfoModel_order==null)
			{
				outvo.setErrorcode("-1");
	    		outvo.setErrormessage("gpumpGpuInfoModel_order is null");
	    		LOGGER.error("gpumpGpuInfoModel_order is null");
	    		return (JSONObject) JSONObject.toJSON(outvo);
			}
			String gpu_type_id_order = gpumpGpuInfoModel_order.getGpu_type_id();
			String gpuclassname_order="com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gpu_type_id_order + "_Bean";
			GpuInterface gpuBean_order=(GpuInterface) Utils.getInstance(gpuclassname_order);
			if(gpuBean_order==null)
			{
				outvo.setErrorcode("-1");
	    		outvo.setErrormessage("gpuBean_order is null");
	    		LOGGER.error("gpuBean_order is null");
	    		return (JSONObject) JSONObject.toJSON(outvo);
			}
			int totalCount = GpumpFidcustMapService.getTotalCount(real_db_id_source);
			
			//List<GpumpFidcustMapModel> GpumpFidcustMapModel_list = GpumpFidcustMapService.selectAll(real_db_id_source);
			if(totalCount==0)
			{
				outvo.setErrorcode("-1");
	    		outvo.setErrormessage("source db have no data,read_id is : "+real_db_id_source);
	    		LOGGER.error("source db have no data,read_id is : "+real_db_id_source);
	    		return (JSONObject) JSONObject.toJSON(outvo);
			}
			int maxResults=100;//每次查询100条
			int page=totalCount/maxResults+1;//总页数
			for(int firstResult=0;firstResult<page;firstResult++)
			{
				List<GpumpFidcustMapModel> GpumpFidcustMapModel_list=GpumpFidcustMapService.selectByPage(real_db_id_source, firstResult*maxResults, maxResults);
				if(GpumpFidcustMapModel_list==null||GpumpFidcustMapModel_list.size()==0)
				{
					LOGGER.warn(firstResult*maxResults+" to "+firstResult*maxResults+maxResults+" no data for GpumpFidcustMap.");
					continue;
				}
				for(GpumpFidcustMapModel gpumpFidcustMapModel:GpumpFidcustMapModel_list)
				{
					String feature_id = gpumpFidcustMapModel.getFeature_id();
					String cust_id = gpumpFidcustMapModel.getCust_id();
					String logic_db_id = GpumpRealFacedbModel_order.getLogic_db_id();
					String feature_source=null;
					if(!gpu_type_id_order.equals(gpu_type_id_source))//型号不相同需要重新提取特征值,插入特征值表
					{
						GpumpCustInfoModel gpumpCustInfoModel = GpumpCustInfoService.select(logic_db_id, cust_id);
						String image_addr = gpumpCustInfoModel.getImage_addr();
						String face=GPUMPBean.readFiletobase64(image_addr);
						if(face==null||"".equals(face.trim()))
						{
							LOGGER.error("cust_id : "+cust_id+" image_addr error,"+image_addr);
							sum_error++;
							continue;
						}
						TraceLog traceLog=new TraceLog();
						traceLog.setMaxValueLength(Integer.parseInt(SysParaUtil.getStrValue("MaxValueLength:1","100")));
				    	traceLog.setLevel(SysParaUtil.getStrValue("LogLevel:1","DEBUG"));
						traceLog.setLogName("CopyRealFacedb");
						traceLog.setTraceId(read_id_order+"_"+cust_id);
						GetFeatureRequest req=new GetFeatureRequest();
						req.setImage(face);
						req.setIp(gpumpGpuInfoModel_order.getGpu_ip());
						req.setPort1(gpumpGpuInfoModel_order.getGpu_port1());
						req.setPort2(gpumpGpuInfoModel_order.getGpu_port2());
						req.setPort3(gpumpGpuInfoModel_order.getGpu_port3());
						GetFeatureResponse getfeature = gpuBean_order.getFeature(req, traceLog);
						if(!getfeature.getResult())
						{
							traceLogger.dispose(traceLog);
							sum_error++;
							LOGGER.error("cust_id "+cust_id+" getfeature error,"+getfeature.getError());
							continue;
						}else
						{
							feature_source = getfeature.getFeature();
							GpumpFeatureModel gpumpFeatureModel_order=new GpumpFeatureModel();
							gpumpFeatureModel_order.setCust_id(cust_id);
							gpumpFeatureModel_order.setFeature(feature_source);
							gpumpFeatureModel_order.setGpu_type_id(gpu_type_id_order);
							gpumpFeatureModel_order.setLogic_db_id(logic_db_id);
							gpumpFeatureModel_order.setCreate_time(new Date());
							try {
								GpumpFeatureService.insert(gpumpFeatureModel_order);
							} catch (Exception e) {
								e.printStackTrace();
								outvo.setErrorcode("-1");
								outvo.setSum_error(sum_error+"");
								outvo.setSum_success(sum_success+"");
					    		outvo.setErrormessage("GpumpFeatureService insert error"+e.getMessage());
					    		LOGGER.error("GpumpFeatureService insert error"+e.getMessage());
					    		return (JSONObject) JSONObject.toJSON(outvo);
							}
						}
					}else //型号相同不需要重新提取特征值,不需要插入特征值表
					{
						//直接获取获取特征值入库
						GpumpFeatureModel gpumpFeatureModel = GpumpFeatureService.select(logic_db_id, gpu_type_id_source, cust_id);
						feature_source = gpumpFeatureModel.getFeature();
					}
					AddFeatureRequest req=new AddFeatureRequest();
					req.setIp(gpumpGpuInfoModel_order.getGpu_ip());
					req.setPort1(gpumpGpuInfoModel_order.getGpu_port1());
					req.setPort2(gpumpGpuInfoModel_order.getGpu_port2());
					req.setPort3(gpumpGpuInfoModel_order.getGpu_port3());
					req.setFeature(feature_source);
					req.setFeatureid(feature_id);
					req.setGroupname(gpu_face_db_order);
					TraceLog traceLog=new TraceLog();
					traceLog.setTraceId(read_id_order+"_"+cust_id);
					traceLog.setMaxValueLength(Integer.parseInt(SysParaUtil.getStrValue("MaxValueLength:1","100")));
			    	traceLog.setLevel(SysParaUtil.getStrValue("LogLevel:1","DEBUG"));
					traceLog.setLogName("CopyRealFacedb");
					AddFeatureResponse addFeature = gpuBean_order.addFeature(req, traceLog);
					if(!addFeature.getResult())
					{
						traceLogger.dispose(traceLog);
						LOGGER.error("cust_id "+cust_id+" addFeature error,"+addFeature.getError());
						sum_error++;
						continue;
					}else
					{
						String featureid_return = addFeature.getFeatureid();
						gpumpFidcustMapModel.setReal_db_id(read_id_order);
						gpumpFidcustMapModel.setFeature_id(featureid_return);
						try {
							GpumpFidcustMapService.insert(gpumpFidcustMapModel);
							sum_success++;
						} catch (Exception e) {
							e.printStackTrace();
							outvo.setErrorcode("-1");
							outvo.setSum_error(sum_error+"");
							outvo.setSum_success(sum_success+"");
				    		outvo.setErrormessage("GpumpFidcustMapService insert error"+e.getMessage());
				    		LOGGER.error("GpumpFidcustMapService insert error"+e.getMessage());
				    		return (JSONObject) JSONObject.toJSON(outvo);
						}
					}
				}
			}
			LOGGER.debug("end copy to "+read_id_order);
		}
		outvo.setErrorcode("0");
		outvo.setSum_error(sum_error+"");
		outvo.setSum_success(sum_success+"");
    	return (JSONObject) JSONObject.toJSON(outvo);
    }
}
