//package com.ccb.suap.cloud.facegpups.gpubeans;
//
//import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareOutVo;
//import com.ccb.suap.cloud.facegpups.faceplus.vo.DetectOutVo;
//import com.ccb.suap.cloud.facegpups.faceplus.vo.ExtractWithDetectOutVo;
//import com.ccb.suap.cloud.facegpups.faceplus.vo.GroupAddOutVo;
//import com.ccb.suap.cloud.facegpups.faceplus.vo.GroupCleanOutVo;
//import com.ccb.suap.cloud.facegpups.faceplus.vo.GroupDeleteOutVo;
//import com.ccb.suap.cloud.facegpups.faceplus.vo.GroupGetSizeOutVo;
//import com.ccb.suap.cloud.facegpups.faceplus.vo.GroupSearchOutVo;
//import com.ccb.suap.cloud.facegpups.faceplus.vo.VerifyOutVo;
//import com.ccb.suap.cloud.facegpups.faceplus.vo.VersionOutVo;
//import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
//
//public abstract class  GPUBean implements GpuInterface {
//
//	public GPUBean(){
//		super();
//	}
//		//人脸采集
//		public abstract ExtractWithDetectOutVo extractWithDetect(String url,String img);
//		//人脸采集返回多张图片
//		public abstract ExtractWithDetectOutVo extractWithDetect2(String url,String img,String extractflag);
//		//GPU人脸注册
//		public abstract GroupAddOutVo register(String url,String groupname,String feature_id,String face_image,String face_refer_image);
//		
//		//GPU人脸识别,返回相似度
//		public abstract GroupSearchOutVo search(String url,String groupname,String feature_id,String face_image,String face_eigen,String hit_size,String threshold);
//		
//		//GPU人脸删除
//		public abstract GroupDeleteOutVo delete(String url,String groupname,String feature_id);
//		
//		//GPU 2个特征值对比
//		public abstract CompareOutVo compare(String url,String feature1,String feature2);
//		
//		//GPU 2张图片对比
//		public abstract VerifyOutVo verify(String url,String image_best,String image_idcard);
//		
//		//获取GPU人脸库中特征值数量
//		public abstract GroupGetSizeOutVo getsize(String url,String Groupname);
//		
//		//获取版本
//		public abstract VersionOutVo getVersion(String url);
//		
//		//图片资料检测
//		public abstract DetectOutVo detect(String url,String img,String attrs);
//		
//		//清空人脸库
//		public abstract GroupCleanOutVo clean(String url,String Groupname);
//}
