package com.ccb.suap.cloud.facegpups.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;

@Mapper
public interface GpumpGpuInfoMapper {
	
	int insert(GpumpGpuInfoModel gpumpGpuInfoModel);
	
	List<GpumpGpuInfoModel> selectAll();
	
	GpumpGpuInfoModel select(@Param("gpu_name")String gpu_name);
	
	int update(GpumpGpuInfoModel gpumpGpuInfoModel);
	
}
