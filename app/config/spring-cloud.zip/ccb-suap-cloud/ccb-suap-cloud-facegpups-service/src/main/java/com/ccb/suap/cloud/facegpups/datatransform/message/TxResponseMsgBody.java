package com.ccb.suap.cloud.facegpups.datatransform.message;

public class TxResponseMsgBody {
	

	private TxResponseMsgEntity entity;

	public TxResponseMsgEntity getEntity() {
		return entity;
	}

	public void setEntity(TxResponseMsgEntity entity) {
		this.entity = entity;
	}

	
	
}
