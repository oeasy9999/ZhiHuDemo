package com.ccb.suap.cloud.facegpups.datatransform.message;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;

public class TxResponseMsgHead {

	private String sys_tx_code;  //服务名
	private String sys_evt_trace_id;   //全局事件跟踪号
	private String sys_recv_time; //服务接收时间 格式为“yyyymmddhhmmssNNN”
	private String sys_resp_time; //服务响应时间 格式为“yyyymmddhhmmssNNN”
	private String sys_pkg_sts_type; //报文状态类型 01－应答报文
	private String sys_tx_status; //服务状态 00－成功，01－失败,02-不确定
	private String sys_resp_code; //服务响应码
	private String sys_resp_desc; //服务响应描述（UTF-8）
	/**
	 * 设置响应数据方法
	 * @param rspMsg 	响应类实例
	 * @param sys_tx_code	交易码 
	 * @param sys_resp_code	错误码
	 * @return
	 */
	public static TxResponseMsg setTxResponseMsgHead(TxResponseMsg rspMsg,String sys_tx_code,String sys_resp_code)
	{
		TxResponseMsgHead rspMsgHead=rspMsg.getTx_header();
		rspMsgHead.setSys_tx_code(sys_tx_code);
		if(rspMsgHead.getSys_evt_trace_id()==null)
		{
			rspMsgHead.setSys_evt_trace_id("000000000000");
		}
		
		rspMsgHead.setSys_resp_time(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()));
		rspMsgHead.setSys_pkg_sts_type("01");
		
		if(rspMsgHead.getSys_resp_code()==null)
		{
			rspMsgHead.setSys_resp_code(sys_resp_code);
			rspMsgHead.setSys_tx_status(sys_resp_code.equals("000000000000")?"00":"01");
		}else
		{
			rspMsgHead.setSys_tx_status(rspMsgHead.getSys_resp_code().equals("000000000000")?"00":"01");
		}
		if(rspMsgHead.getSys_resp_desc()==null)
		{
			rspMsgHead.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(sys_resp_code));
		}
		return rspMsg;
	}
	public String getSys_tx_code() {
		return sys_tx_code;
	}
	public void setSys_tx_code(String sys_tx_code) {
		this.sys_tx_code = sys_tx_code;
	}
	public String getSys_evt_trace_id() {
		return sys_evt_trace_id;
	}
	public void setSys_evt_trace_id(String sys_evt_trace_id) {
		this.sys_evt_trace_id = sys_evt_trace_id;
	}
	public String getSys_recv_time() {
		return sys_recv_time;
	}
	public void setSys_recv_time(String sys_recv_time) {
		this.sys_recv_time = sys_recv_time;
	}
	public String getSys_resp_time() {
		return sys_resp_time;
	}
	public void setSys_resp_time(String sys_resp_time) {
		this.sys_resp_time = sys_resp_time;
	}
	public String getSys_pkg_sts_type() {
		return sys_pkg_sts_type;
	}
	public void setSys_pkg_sts_type(String sys_pkg_sts_type) {
		this.sys_pkg_sts_type = sys_pkg_sts_type;
	}
	public String getSys_tx_status() {
		return sys_tx_status;
	}
	public void setSys_tx_status(String sys_tx_status) {
		this.sys_tx_status = sys_tx_status;
	}
	public String getSys_resp_code() {
		return sys_resp_code;
	}
	public void setSys_resp_code(String sys_resp_code) {
		this.sys_resp_code = sys_resp_code;
	}
	public String getSys_resp_desc() {
		return sys_resp_desc;
	}
	public void setSys_resp_desc(String sys_resp_desc) {
		this.sys_resp_desc = sys_resp_desc;
	}

	
}
