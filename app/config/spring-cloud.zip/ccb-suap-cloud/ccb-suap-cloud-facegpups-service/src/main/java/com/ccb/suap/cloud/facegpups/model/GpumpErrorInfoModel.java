package com.ccb.suap.cloud.facegpups.model;

public class GpumpErrorInfoModel {
	public static String syscode="GPUPS";               //系统编码
	public static String mode="Z";						//主服务模块
	public static String gpumpmode="G";                 //GPU模块
	public static String databasemode="S";				//数据库模块
	
	
	public static String errortype_FA="FA";                //业务报错（正常错误，由前端根据错误码进行相应逻辑处理）
	public static String errortype_WA="WA"; 			   //交易报错（异常报错，交易级别错误）
	public static String errortype_ER="ER";                //系统报错（异常报错，系统级别报错）

	public static String NOERROR="000000000000"; 	 									//无错误
	
	public static String EXCEPTION=syscode+mode+errortype_ER+"0001";         			//内部异常
	public static String SYSPARAREFRESHERROR=syscode+mode+errortype_ER+"0002";   		//刷新配置参数错误
	public static String DB_EXCEPTION=syscode+mode+errortype_ER+"0003";         			//服务不可用，数据库异常
	
	public static String MESSAGEFORMATERROR=syscode+mode+errortype_FA+"0010";       		    //报文格式错误,无法解析!
	public static String PARAMENOEXIST_CUSTID=syscode+mode+errortype_FA+"0011";       		    //客户号不能为空!
	public static String PARAMENOEXIST_GROUPNAME=syscode+mode+errortype_FA+"0012";       		//N库分组名称不能为空!
	public static String PARAMENOEXIST_SYSCHANNELID=syscode+mode+errortype_FA+"0013";       	//系统渠道编号不能为空!
	public static String PARAMENOEXIST_FACEIMAGE=syscode+mode+errortype_FA+"0014";       		//人脸图片不能为空!
	public static String PARAMENOEXIST_IDTYPE=syscode+mode+errortype_FA+"0015";       			//证件类型为空或超长
	public static String TXCODEERROR=syscode+mode+errortype_FA+"0016";         					//交易码错误
	public static String PARAMENOEXIST_REFERFACEIMAGE=syscode+mode+errortype_FA+"0017";       		//人脸对比图片不能为空!
	
	public static String LOGICFACEDBERROR=syscode+databasemode+errortype_FA+"1001";   			//逻辑库出错,不存在或类型不匹配
	public static String REALFACEDBERROR=syscode+databasemode+errortype_FA+"1002";   			//物理库出错,不存在或类型不匹配
	public static String LOGICFACEDBMOUNTGPUERROR=syscode+databasemode+errortype_FA+"1003";   	//逻辑库没有挂载GPU，不能识别
    public static String LOGICFACEDBCAPACITYERROR=syscode+databasemode+errortype_FA+"1004";   			//逻辑库出错,逻辑库容量超限
    public static String CUSTINFONOEXIT=syscode+databasemode+errortype_FA+"1005";               //客户信息不存在
    
	public static String NODATA=syscode+mode+errortype_FA+"2000";			  				//数据库无数据
	public static String DATABASEERROR_INSERT=syscode+databasemode+errortype_ER+"2001";    	//数据库插入错误
	public static String DATABASEERROR_UPDATE=syscode+databasemode+errortype_ER+"2002";    	//数据库更新错误
	public static String DATABASEERROR_DELETE=syscode+databasemode+errortype_ER+"2003";    	//数据库删除错误
	public static String DATABASEPRIMARYERROR=syscode+databasemode+errortype_ER+"2004";    //数据库唯一约束错误
	
	public static String GPURESULTERROR=syscode+gpumpmode+errortype_WA+"3001"; 			//GPU返回失败，返回空
	public static String GPUSEARCHERROR=syscode+gpumpmode+errortype_FA+"3002"; 			//GPU识别失败
	public static String GPUDELETEUSERERROR=syscode+gpumpmode+errortype_FA+"3003"; 		//GPU删除特征值失败
	public static String GPUEXTRACTERERROR=syscode+gpumpmode+errortype_FA+"3004"; 		//GPU采集失败
	public static String GPUGROUPERROR=syscode+mode+errortype_ER+"3005"; 				//GPU适配器不存在
	public static String GPURELATEERROR=syscode+mode+errortype_FA+"3006";         		//GPU注册失败
	public static String GPULISTERROR=syscode+gpumpmode+errortype_WA+"3007"; 			//GPU列表为空
	public static String GPUDETECTERROR_FACESNULL=syscode+gpumpmode+errortype_WA+"3008"; 			//GPU检查不到人脸
	public static String GPUDETECTERROR_FACESMORE=syscode+gpumpmode+errortype_WA+"3009"; 			//GPU检查到多个人脸
	public static String GPUDETECTERROR_CHECK=syscode+gpumpmode+errortype_WA+"3010";		     //GPU检查不通过
	public static String GPUEXTRACTERERROR_MOREFACE=syscode+gpumpmode+errortype_WA+"3011"; 		 //GPU采集失败,不能有多张人脸
	public static String GPUDETECTERROR_ROLL=syscode+gpumpmode+errortype_WA+"3012";		     //GPU人脸摇摆角度检查不通过
	public static String GPUDETECTERROR_PITCH=syscode+gpumpmode+errortype_WA+"3013";		 		//GPU人脸仰偏角度检查不通过
	public static String GPUDETECTERROR_YAW=syscode+gpumpmode+errortype_WA+"3014";				//GPU人脸左右偏角度检查不通过
	public static String GPUDETECTERROR_BLURNESS=syscode+gpumpmode+errortype_WA+"3015";		//GPU人脸模糊度检查不通过
	public static String FACEIMAGESAVEERROR=syscode+mode+errortype_ER+"4001";         	//人脸图片保存失败
	
	public static String GPURESULTERROR_JSON=syscode+gpumpmode+errortype_WA+"5000"; 	 //GPU返回不是json
	public static String GPURESULTERROR_ARGUMENT_ERROR=syscode+gpumpmode+errortype_WA+"5001"; 	 //GPU采集调用参数错误	
	public static String GPURESULTERROR_IMAGE_SIZE=syscode+gpumpmode+errortype_WA+"5002"; 	 //图片太大	
	public static String GPURESULTERROR_IMAGE_FORMAT=syscode+gpumpmode+errortype_WA+"5003"; 	 //不支持的图片格式
	public static String GPURESULTERROR_INTERNAL=syscode+gpumpmode+errortype_WA+"5004"; 	 //其他未分类的内部错误
	
	public static String GPURESULTERROR_BAD_PARAMETER=syscode+gpumpmode+errortype_WA+"5005"; 	 //GPU添加特征值调用参数出错
	public static String GPURESULTERROR_GROUP_NOT_EXIST=syscode+gpumpmode+errortype_WA+"5006"; 	 //GPU人脸库不存在
	public static String GPURESULTERROR_FEATURE_ID_EXIST=syscode+gpumpmode+errortype_WA+"5007"; 	 //GPU人脸特征值id已存在
	public static String GPURESULTERROR_FEATURE_ID_NO_EXIST=syscode+gpumpmode+errortype_WA+"5008"; 	 //GPU人脸特征值id不存在
	public static String GPURESULTERROR_FILENULL=syscode+gpumpmode+errortype_WA+"5009"; 	 //请求中没有文件
	public static String GPURESULTERROR_WEB=syscode+gpumpmode+errortype_WA+"5010";     //GPU Web服务器内部错误
	public static String GPURESULTERROR_DB=syscode+gpumpmode+errortype_WA+"5011";     //GPU 数据库内部错误
	public static String GPURESULTERROR_VERIFY=syscode+gpumpmode+errortype_WA+"5012";     //GPU 比对服务内部错误
	public static String GPURESULTERROR_VERIFY_CONNECTION=syscode+gpumpmode+errortype_WA+"5013";     //GPU 比对服务拒绝连接
	public static String GPURESULTERROR_IMG_NOT_FOUND=syscode+gpumpmode+errortype_WA+"5014";     //读取图片失败
	public static String GPURESULTERROR_CONVERT_FROM_BIN_FAILED=syscode+gpumpmode+errortype_WA+"5015";     //图片格式错误
	public static String GPURESULTERROR_TOO_SMALL=syscode+gpumpmode+errortype_WA+"5016";     //图片宽度太小
	public static String GPURESULTERROR_FACE_UNDER=syscode+gpumpmode+errortype_WA+"5017";     //图片人脸质量过低
	public static String GPURESULTERROR_FACE_RECT=syscode+gpumpmode+errortype_WA+"5018";     //图片人脸坐标偏差太大
	public static String GPURESULTERROR_DETECT_FAILED=syscode+gpumpmode+errortype_WA+"5019";     //GPU内部算法错误
	public static String GPURESULTERROR_GROUP_ALREADY_EXIST=syscode+gpumpmode+errortype_WA+"5020";     //有相同名称的人脸库已经存在
	
	
	private String errorcode;
	private String errortype;
	private String errormsg;
	private String isconv;
	public String getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	public String getErrortype() {
		return errortype;
	}
	public void setErrortype(String errortype) {
		this.errortype = errortype;
	}
	public String getErrormsg() {
		return errormsg;
	}
	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}
	public String getIsconv() {
		return isconv;
	}
	public void setIsconv(String isconv) {
		this.isconv = isconv;
	}
	
}
