package com.ccb.suap.cloud.facegpups.model;

import java.util.Date;
import java.util.List;

public class GpumpLogicFacedbModel {
	
	private String logic_db_id;						//逻辑库主键
	private String channel_id;						//渠道号
	private String logid_db_name;					//逻辑库名
	private String logid_db_desc;					//逻辑库描述
	private String type;							//库类型
	private String source_db_id;					//母库主键
	private String total_capacity;					//最大容量
	private String capacity;						//当前容量
	private String is_mount_pag;					//是否挂载页为库IS_MOUNT_PAG 
	private String pag_strategy;					//分页策略PAG_STRATEGY
	private String pag_count;  						//分页数量PAG_COUNT  
	private String is_mount_gpu;					//是否挂载GPU
	private String real_db_count;					//物理库数量
	private String is_save_featuer;					//是否存特征值
	private String verify_similarity;				//比对相似度
	private String verify_param1;					//比对参数1
	private String verify_param2;					//比对参数2
	private String verify_param3;					//比对参数3
	private String register_param1;					//注册参数1
	private String register_param2;					//注册参数2
	private String register_param3;					//注册参数3
	private String update_param1;					//更新参数1
	private String update_param2;					//更新参数2
	private String update_param3;					//更新参数3
	private Date create_time;						//创建时间
	private Date modify_time;						//修改时间
	private String work_version;					//工作版本
	private String work_state;						//工作状态
	private Date work_update_time;					//状态更新时间
	
	

	private Integer index;  						//分页库标签信息  

	private List<GpumpRealFacedbModel> gpumpRealFacedbModelList;			//物理库集合

	public String getLogic_db_id() {
		return logic_db_id;
	}

	public void setLogic_db_id(String logic_db_id) {
		this.logic_db_id = logic_db_id;
	}

	public String getChannel_id() {
		return channel_id;
	}

	public void setChannel_id(String channel_id) {
		this.channel_id = channel_id;
	}

	public String getLogid_db_name() {
		return logid_db_name;
	}

	public void setLogid_db_name(String logid_db_name) {
		this.logid_db_name = logid_db_name;
	}

	public String getLogid_db_desc() {
		return logid_db_desc;
	}

	public void setLogid_db_desc(String logid_db_desc) {
		this.logid_db_desc = logid_db_desc;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSource_db_id() {
		return source_db_id;
	}

	public void setSource_db_id(String source_db_id) {
		this.source_db_id = source_db_id;
	}

	public String getTotal_capacity() {
		return total_capacity;
	}

	public void setTotal_capacity(String total_capacity) {
		this.total_capacity = total_capacity;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public String getIs_mount_gpu() {
		return is_mount_gpu;
	}

	public void setIs_mount_gpu(String is_mount_gpu) {
		this.is_mount_gpu = is_mount_gpu;
	}

	public String getReal_db_count() {
		return real_db_count;
	}

	public void setReal_db_count(String real_db_count) {
		this.real_db_count = real_db_count;
	}

	public String getIs_save_featuer() {
		return is_save_featuer;
	}

	public void setIs_save_featuer(String is_save_featuer) {
		this.is_save_featuer = is_save_featuer;
	}

	public String getVerify_similarity() {
		return verify_similarity;
	}

	public void setVerify_similarity(String verify_similarity) {
		this.verify_similarity = verify_similarity;
	}

	public String getVerify_param1() {
		return verify_param1;
	}

	public void setVerify_param1(String verify_param1) {
		this.verify_param1 = verify_param1;
	}

	public String getVerify_param2() {
		return verify_param2;
	}

	public void setVerify_param2(String verify_param2) {
		this.verify_param2 = verify_param2;
	}

	public String getVerify_param3() {
		return verify_param3;
	}

	public void setVerify_param3(String verify_param3) {
		this.verify_param3 = verify_param3;
	}

	public String getRegister_param1() {
		return register_param1;
	}

	public void setRegister_param1(String register_param1) {
		this.register_param1 = register_param1;
	}

	public String getRegister_param2() {
		return register_param2;
	}

	public void setRegister_param2(String register_param2) {
		this.register_param2 = register_param2;
	}

	public String getRegister_param3() {
		return register_param3;
	}

	public void setRegister_param3(String register_param3) {
		this.register_param3 = register_param3;
	}

	public String getUpdate_param1() {
		return update_param1;
	}

	public void setUpdate_param1(String update_param1) {
		this.update_param1 = update_param1;
	}

	public String getUpdate_param2() {
		return update_param2;
	}

	public void setUpdate_param2(String update_param2) {
		this.update_param2 = update_param2;
	}

	public String getUpdate_param3() {
		return update_param3;
	}

	public void setUpdate_param3(String update_param3) {
		this.update_param3 = update_param3;
	}

	public Date getCreate_time() {
		return create_time;
	}

	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}

	public Date getModify_time() {
		return modify_time;
	}

	public void setModify_time(Date modify_time) {
		this.modify_time = modify_time;
	}

	public String getWork_version() {
		return work_version;
	}

	public void setWork_version(String work_version) {
		this.work_version = work_version;
	}

	public String getWork_state() {
		return work_state;
	}

	public void setWork_state(String work_state) {
		this.work_state = work_state;
	}

	public Date getWork_update_time() {
		return work_update_time;
	}

	public void setWork_update_time(Date work_update_time) {
		this.work_update_time = work_update_time;
	}

	
	public String getIs_mount_pag() {
		return is_mount_pag;
	}

	public void setIs_mount_pag(String is_mount_pag) {
		this.is_mount_pag = is_mount_pag;
	}

	public String getPag_strategy() {
		return pag_strategy;
	}

	public void setPag_strategy(String pag_strategy) {
		this.pag_strategy = pag_strategy;
	}

	public String getPag_count() {
		return pag_count;
	}

	public void setPag_count(String pag_count) {
		this.pag_count = pag_count;
	}

	public List<GpumpRealFacedbModel> getGpumpRealFacedbModelList() {
		return gpumpRealFacedbModelList;
	}

	public void setGpumpRealFacedbModelList(List<GpumpRealFacedbModel> gpumpRealFacedbModelList) {
		this.gpumpRealFacedbModelList = gpumpRealFacedbModelList;
	}
	

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}



	@Override
	public String toString() {
		return "GpumpLogicFacedbModel [logic_db_id=" + logic_db_id + ", channel_id=" + channel_id + ", logid_db_name="
				+ logid_db_name + ", logid_db_desc=" + logid_db_desc + ", type=" + type + ", source_db_id="
				+ source_db_id + ", total_capacity=" + total_capacity + ", capacity=" + capacity + ", is_mount_gpu="
				+ is_mount_gpu + ", real_db_count=" + real_db_count + ", is_save_featuer=" + is_save_featuer
				+ ", verify_similarity=" + verify_similarity + ", verify_param1=" + verify_param1 + ", verify_param2="
				+ verify_param2 + ", verify_param3=" + verify_param3 + ", register_param1=" + register_param1
				+ ", register_param2=" + register_param2 + ", register_param3=" + register_param3 + ", update_param1="
				+ update_param1 + ", update_param2=" + update_param2 + ", update_param3=" + update_param3
				+ ", create_time=" + create_time + ", modify_time=" + modify_time + ", work_version=" + work_version
				+ ", work_state=" + work_state + ", work_update_time=" + work_update_time+",is_mount_pag=" + is_mount_pag
				+",pag_strategy="+pag_strategy+",pag_count="+pag_count	+",index="+index
				+ ", gpumpRealFacedbModelList=" + gpumpRealFacedbModelList + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
