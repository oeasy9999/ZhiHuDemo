package com.ccb.suap.cloud.facegpups.faceplus.vo.g003;

public class FaceRect {
//	"FaceRect": {
//	"left": 63,
//	"top": 84,
//	"right": 121,
//	"bottom": 143
//},
	private String left;
	private String top;
	private String right;
	private String bottom;
	public String getLeft() {
		return left;
	}
	public void setLeft(String left) {
		this.left = left;
	}
	public String getTop() {
		return top;
	}
	public void setTop(String top) {
		this.top = top;
	}
	public String getRight() {
		return right;
	}
	public void setRight(String right) {
		this.right = right;
	}
	public String getBottom() {
		return bottom;
	}
	public void setBottom(String bottom) {
		this.bottom = bottom;
	}
}
