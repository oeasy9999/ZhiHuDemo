package com.ccb.suap.cloud.facegpups.mapper;

import com.ccb.suap.cloud.facegpups.model.GpumpLogicCapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface GpumpLogicFacedbMapper {
	
	int count();
	
	int insert(GpumpLogicFacedbModel gpumpLogicFacedbModel);
	
	List<GpumpLogicFacedbModel> selectAll();
	
	List<GpumpLogicFacedbModel> selectBySourceDbId(@Param("source_db_id")String source_db_id);
	
	GpumpLogicFacedbModel select(@Param("logic_db_id")String logic_db_id);
	
	int update(GpumpLogicFacedbModel model);

	int updateLogicCap(GpumpLogicCapModel model);

	int delete(@Param("logic_db_id")String logic_db_id);
}
