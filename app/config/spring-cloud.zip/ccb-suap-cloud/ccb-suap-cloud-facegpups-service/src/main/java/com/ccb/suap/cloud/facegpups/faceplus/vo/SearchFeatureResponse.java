package com.ccb.suap.cloud.facegpups.faceplus.vo;

import java.util.List;

public class SearchFeatureResponse {

	/**
	 * 
	 */
	private boolean result;
	private String error;
	private List<String> featureids;
	private List<String> scores;
	private List<String> tags;
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public List<String> getFeatureids() {
		return featureids;
	}
	public void setFeatureids(List<String> featureids) {
		this.featureids = featureids;
	}
	public List<String> getScores() {
		return scores;
	}
	public void setScores(List<String> scores) {
		this.scores = scores;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	@Override
	public String toString() {
		return "SearchFeatureResponse [result=" + result + ", error=" + error + ", featureids=" + featureids
				+ ", scores=" + scores + ", tags=" + tags + "]";
	}
	
	
}
