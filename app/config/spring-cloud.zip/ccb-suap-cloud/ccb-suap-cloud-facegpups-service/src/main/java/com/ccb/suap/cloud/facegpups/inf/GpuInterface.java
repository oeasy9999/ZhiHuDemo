package com.ccb.suap.cloud.facegpups.inf;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DetectImageRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DetectImageResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupListReponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupListRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.AddFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.AddFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CleanGroupRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CleanGroupResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteGroupRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteGroupResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupSizeRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupSizeResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.SearchFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.SearchFeatureResponse;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareImageRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareImageResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetVersionRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetVersionResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.InitGroupRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.InitGroupResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareFeatureResponse;

public interface GpuInterface {

	//GPU人脸采集返回特征值
	//public HashMap<String, Object> extractWithDetect(ExtractWithDetectInVo invo);
	/**
	 * GPU人脸采集返回特征值返回中心图片
	 * @param req 请求参数
	 * @param traceLog 日志报文缓存类
	 * @return GetFeatureResponse 提取特征值结果类
	 */
	public GetFeatureResponse getFeature(GetFeatureRequest req,TraceLog traceLog);
	
	/**
	 * GPU人脸注册,写入特征值
	 * @param req 请求参数
	 * @param traceLog 日志报文缓存类
	 * @return AddFeatureResponse 人脸添加结果类
	 */
	public AddFeatureResponse addFeature(AddFeatureRequest req,TraceLog traceLog);
	
	/**
	 * GPU人脸识别,返回相似度
	 * @param req 请求参数 
	 * @param traceLog 日志报文缓存类
	 * @return SearchFeatureResponse 人脸识别结果类
	 */
	public SearchFeatureResponse searchFeature(SearchFeatureRequest req,TraceLog traceLog); 
	
	/**
	 * GPU人脸删除
	 * @param req 请求参数 
	 * @param traceLog 日志报文缓存类
	 * @return DeleteFeatureResponse 人脸删除结果类
	 */
	public DeleteFeatureResponse deleteFeature(DeleteFeatureRequest req,TraceLog traceLog);
	
	/**
	 * GPU 2个特征值对比
	 * @param req
	 * @param traceLog
	 * @return CompareFeatureResponse 特征值比对结果类
	 */
	public CompareFeatureResponse compareFeature(CompareFeatureRequest req,TraceLog traceLog);
	
	/**
	 * GPU 2张图片对比
	 * @param req 请求参数
	 * @param traceLog 日志报文缓存类
	 * @return CompareImageResponse 比对结果实例
	 */
	public CompareImageResponse compareImage(CompareImageRequest req,TraceLog traceLog); 
	
	/**
	 * 获取GPU人脸库中特征值数量
	 * @param req 请求参数
	 * @return GetGroupSizeResponse 人脸库中特征值数量获取类
	 */
	public GetGroupSizeResponse getGroupSize(GetGroupSizeRequest req);  
	
	/**
	 * 获取版本
	 * @param req 请求参数
	 * @return GetVersionResponse  获取版本结果类
	 */
	public GetVersionResponse getVersion(GetVersionRequest req);
	
	/**
	 * 图片质量检测
	 * @param req 请求参数
	 * @param traceLog 日志报文缓存类
	 * @return DetectImageResponse 图片质量检测结果类
	 */
	public DetectImageResponse detectImage(DetectImageRequest req,TraceLog traceLog,String chanel_id);  
	
	/**
	 * 清空人脸库 
	 * @param req 请求参数
	 * @return CleanGroupResponse 清空人脸库结果类
	 */
	public CleanGroupResponse cleanGroup(CleanGroupRequest req);
	
    /**
	 * 初始化人脸库
	 * @param req 请求参数
	 * @return InitGroupResponse 初始化人脸库结果类
	 */
	public InitGroupResponse initGroup(InitGroupRequest req);
	
	/**
	 * 获取人脸库列表
	 * @param req 请求参数
	 * @return GetGroupListReponse  获取人脸库列表结果类
	 */
	public GetGroupListReponse getGroupList(GetGroupListRequest req);
	
	/**
	 * 删除人脸库
	 * @param req 请求参数
	 * @return  人脸库删除结果类
	 */
	public DeleteGroupResponse deleteGroup(DeleteGroupRequest req);
}
