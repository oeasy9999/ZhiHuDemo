package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

import java.io.Serializable;
import java.util.List;
/**
 * 图片检测返回实例
 * @author zhanzifeng
 *
 */
public class DetectOutVo implements Serializable {

	private static final long serialVersionUID = -2322422754329611651L;
	private String result;
	private String errorMessage;
	private List<DetectVo> data;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<DetectVo> getData() {
		return data;
	}
	public void setData(List<DetectVo> data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "DetectOutVo [result=" + result + ", errorMessage=" + errorMessage + ", data=" + data + "]";
	}
	

}
