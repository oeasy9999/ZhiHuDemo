package com.ccb.suap.cloud.facegpups.datatransform.message;

public class TxRequestMsgCom1 {

	private String sysChannelID;   //系统渠道编号
	private String dotNumber;   //网点号
	public String getSysChannelID() {
		return sysChannelID;
	}
	public void setSysChannelID(String sysChannelID) {
		this.sysChannelID = sysChannelID;
	}
	public String getDotNumber() {
		return dotNumber;
	}
	public void setDotNumber(String dotNumber) {
		this.dotNumber = dotNumber;
	}
	@Override
	public String toString() {
		return "TxRequestMsgCom1 [sysChannelID=" + sysChannelID + ", dotNumber=" + dotNumber + "]";
	}
	
	
	
}
