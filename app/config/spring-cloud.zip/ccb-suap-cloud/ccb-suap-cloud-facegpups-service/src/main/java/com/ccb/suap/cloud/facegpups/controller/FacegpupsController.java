package com.ccb.suap.cloud.facegpups.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.eureka.EurekaDiscoveryClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.inf.TrxInterface;
import com.ccb.suap.cloud.facegpups.mapper.TraceLogger;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFaceLogModel;
import com.ccb.suap.cloud.facegpups.service.GpumpFaceLogService;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpFaceLogUtil;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpFacePicANDLogUtil;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpGpuDispatchParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTaskThread;
import com.ccb.suap.cloud.facegpups.task.TraceLogThread;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1001ServiceOutVo;
import com.ccb.suap.util.LocalMessage;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.date.DateUtils;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.log.thread.MultithreadingLogExecutor;

@RefreshScope
@RestController
public class FacegpupsController {
	//private static final Logger LOGGER = LoggerBuilder.getLogger("./logs","facegpups-control","100MB","debug");
	private static final Logger LOGGER = LoggerFactory.getLogger(FacegpupsController.class);
	private  GpumpFaceLogService gpumpFaceLogService=GpumpDaoFactory.getDaoManager().getGpumpFaceLogService();
	private TraceLogger traceLogger = GpumpDaoFactory.getDaoManager().getTraceLogger();
	@Autowired
    EurekaDiscoveryClient discoveryClient;

    @Value("${msg:unknown}")
    private String msg;
    @Value("${apache.rocketmq.TOPIC_COMPLETE}")
	private String topic_complete;
    
    public static boolean Redisflag=true;//redis标识
    public static boolean dbflag=true;//数据库标识标识

    public static boolean isRedisflag() {
		return Redisflag;
	}

	public static void setRedisflag(boolean redisflag) {
		FacegpupsController.Redisflag = redisflag;
	}

	public static boolean isDbflag() {
		return dbflag;
	}

	public static void setDbflag(boolean dbflag) {
		FacegpupsController.dbflag = dbflag;
	}
    @RequestMapping(value = "/GpumpService_SysparaRefresh/{para}",consumes="application/json",produces = "application/json; charset=utf-8")
	@ResponseBody
	public JSONObject SysparaRefresh(@PathVariable("para")String para)
	{
    	Map<String, Object> result = new HashMap<String, Object>();
    	int ret=1;
		if(para.equals("systemPara"))
		{
			LOGGER.info("Refresh GpumpSysparaModel");
			ret=SysParaUtil.refresh();
		}else if(para.equals("gpuPara"))
		{
			LOGGER.info("Refresh GpuModel");
			ret=ServiceParaUtil.refreshAllGpuDBMsg();
		} else if ("gpuDispathPara".equals(para)) {
			LOGGER.info("Refresh GpumpDispathModel");
			ret = GpumpGpuDispatchParaUtil.refresh();
		} else if (para.equals("errorCode"))
		{
			LOGGER.info("Refresh GpumpErrorInfoModel");
			ret=GpumpErrorInfoParaUtil.refresh();
		}else if(para.equals("allPara"))
		{
			LOGGER.info("Refresh all para!");
			SysParaUtil.refresh();
			ServiceParaUtil.refreshAllGpuDBMsg();
			GpumpErrorInfoParaUtil.refresh();
		}else
		{
			LOGGER.error("paramer refresh error,para :"+para+" undefind!");
			result.put("errorCode", GpumpErrorInfoModel.SYSPARAREFRESHERROR);
			result.put("errorMsg",GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.SYSPARAREFRESHERROR));
			return (JSONObject) JSONObject.toJSON(result);
		}
		if(ret!=1)
		{
			LOGGER.error(para+" paramer refresh error! ");
			result.put("errorCode", GpumpErrorInfoModel.SYSPARAREFRESHERROR);
			result.put("errorMsg",GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.SYSPARAREFRESHERROR));
		}else
		{
			result.put("errorCode", GpumpErrorInfoModel.NOERROR);
			result.put("errorMsg", GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.NOERROR));
		}
		return (JSONObject) JSONObject.toJSON(result);
	}
    
    
    @RequestMapping(value = "/GpumpService/{txcode}",consumes="application/json",produces = "application/json; charset=utf-8")
    public JSONObject GpumpServer(@PathVariable("txcode")String txcode,@RequestBody JSONObject data)
    {
    	long start = System.currentTimeMillis();
    	LOGGER.debug("GpumpServer JSONObject data is : "+data.toJSONString());
    	
    	TraceLog traceLog = new TraceLog();
    	traceLog.setMaxValueLength(Integer.parseInt(SysParaUtil.getStrValue("MaxValueLength:1","100")));
    	traceLog.setLevel(SysParaUtil.getStrValue("LogLevel:1","DEBUG"));
    	traceLog.setRequestJsonString_client(data.toString());
    	
    	TxRequestMsg reqMsg=JSONObject.toJavaObject(data, TxRequestMsg.class);
    	TxResponseMsg rspMsg = new TxResponseMsg();
    	TxResponseMsgHead msghead=new TxResponseMsgHead();
    	msghead.setSys_tx_code(txcode);
    	msghead.setSys_recv_time(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()));
    	msghead.setSys_pkg_sts_type("01");
    	//String COSTTIMEINFO="";
    	String traceid=reqMsg.getTx_header().getSys_evt_trace_id();
		traceLog.setTraceId(traceid);
    	HashMap<String, Long> logtime=new HashMap<String, Long>();
    	if(reqMsg!=null&&reqMsg.getTx_header()!=null)
    	{
        	msghead.setSys_evt_trace_id(reqMsg.getTx_header().getSys_evt_trace_id());
        	rspMsg.setTx_header(msghead);
        	if(txcode==null)
    		{
        		traceLog.setErrormessage("txcode is null ! ");
        		msghead.setSys_resp_code(GpumpErrorInfoModel.TXCODEERROR);
        		msghead.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.TXCODEERROR));
        		//rspMsg.setTx_header(msghead);
        		LOGGER.error("txcode is null ! ");
    		}else
    		{
    			traceLog.setLogName(txcode);
    			String className = "com.ccb.suap.cloud.facegpups.beans." + txcode + "_Bean";
            	TrxInterface gpumpBean=null;
            	try {
					gpumpBean = (TrxInterface) Utils.getInstance(className);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					LOGGER.error("业务bean调用异常::" + e1.getMessage(),e1);
					rspMsg.getTx_header().setSys_tx_status("02");
					rspMsg.getTx_header().setSys_resp_code(GpumpErrorInfoModel.EXCEPTION);
					rspMsg.getTx_header().setSys_resp_desc("业务bean调用异常::" + e1.getMessage());
					traceLog.setErrormessage("cannot find the "+txcode+" server");
					return (JSONObject) JSONObject.toJSON(rspMsg);
				}
        		if(gpumpBean==null)
        		{
            		LOGGER.error("cannot find the "+txcode+" server");
            		traceLog.setErrormessage("cannot find the "+txcode+" server");
            		TxResponseMsgHead.setTxResponseMsgHead(rspMsg,txcode,GpumpErrorInfoModel.TXCODEERROR);
        		}else
        		{
        			try {
            			reqMsg=(TxRequestMsg) gpumpBean.transform(data);
            			rspMsg=gpumpBean.executeProcess(rspMsg,reqMsg,logtime,traceLog);
            			
            		}catch (CommonRuntimeException e) {
            			LOGGER.error("CommonRuntimeException "+e.getMessage(),e);
            			GPUMP1001ServiceOutVo outvo=new GPUMP1001ServiceOutVo();
            			TxResponseMsgBody MsgBody=new TxResponseMsgBody();
            			MsgBody.setEntity(outvo);
            			rspMsg.setTx_body(MsgBody);
            			traceLog.setErrormessage(e.getCode()+" : "+e.getMessage());
            			TxResponseMsgHead.setTxResponseMsgHead(rspMsg,txcode, e.getCode());
            			//List<GpuRegisterTask> gpuTask_list = gpumpBean.getGpuTask();
            			
            		}catch (Exception e) {
            			LOGGER.error("Exception "+e.getLocalizedMessage(),e);
            			LOGGER.error(e.getLocalizedMessage());
            			GPUMP1001ServiceOutVo outvo=new GPUMP1001ServiceOutVo();
            			TxResponseMsgBody MsgBody=new TxResponseMsgBody();
            			MsgBody.setEntity(outvo);
            			rspMsg.setTx_body(MsgBody);
            			if(e.toString().contains("PRIMARY"))
            			{
            				LOGGER.error("data primary error");
            				traceLog.setErrormessage("data primary error");
            				TxResponseMsgHead.setTxResponseMsgHead(rspMsg,txcode, GpumpErrorInfoModel.DATABASEPRIMARYERROR);
            			}else
            			{
            				LOGGER.error("Service invocation excepyion occurred!");
            				traceLog.setErrormessage("Service invocation excepyion occurred!");
            				TxResponseMsgHead.setTxResponseMsgHead(rspMsg,txcode, GpumpErrorInfoModel.EXCEPTION);
            			}
            			List<GpuRegisterTask> gpuTask_list = gpumpBean.getGpuTask();
            			GpuRegisterTaskThread GpuRegisterTaskThread=new GpuRegisterTaskThread(gpuTask_list,msghead.getSys_evt_trace_id());
            			MultithreadingLogExecutor.addLogTaskRoolback(GpuRegisterTaskThread);
            		} 
        			//COSTTIMEINFO=gpumpBean.getTime();
        		}
    		}
    	}else
    	{
    		rspMsg.setTx_header(msghead);
    		TxResponseMsgHead.setTxResponseMsgHead(rspMsg,txcode,GpumpErrorInfoModel.MESSAGEFORMATERROR);
    	}
    	
		LOGGER.debug("Sys_evt_trace_id is "+msghead.getSys_evt_trace_id()+" ,result json: "+JSONObject.toJSONString(rspMsg));
		long end = System.currentTimeMillis();
		logtime.put("costTime", end-start);
		traceLog.setResponseJsonString_client(JSONObject.toJSON(rspMsg).toString());
		if(traceLog.getLogName()!=null)
		{
			TraceLogThread TraceLogThread = new TraceLogThread(traceLog,traceLogger);
			MultithreadingLogExecutor.addLogTask(TraceLogThread);
		}
		GpumpFacePicANDLogUtil gpumpFacePicANDLogUtil = new GpumpFacePicANDLogUtil( reqMsg, rspMsg, logtime.toString(), traceLog,gpumpFaceLogService);
		MultithreadingLogExecutor.addLogTask(gpumpFacePicANDLogUtil);
		return (JSONObject) JSONObject.toJSON(rspMsg);
    }

    //异步记录日志到数据库
    public void insertlog(TxRequestMsg reqMsg,TxResponseMsg rspMsg,String time,TraceLog traceLog)
    {
    	String flag=SysParaUtil.getStrValue("LogFlag:1","0");
		if(!"0".equals(flag))//记录日志
		{
			if(traceLog.getLogName()!=null)
			{
				TraceLogThread TraceLogThread = new TraceLogThread(traceLog,traceLogger);
				MultithreadingLogExecutor.addLogTask(TraceLogThread);
			}
			LOGGER.debug(" log flag is open,bengin to insert log to database!");
	    	//TxRequestMsgHead tx_header =reqMsg.getTx_header();
			TxRequestMsgCom2 com2 = reqMsg.getTx_body().getCom2();
			//TxRequestMsgHead tx_header = reqMsg.getTx_header();
			TxResponseMsgHead tx_header2 = rspMsg.getTx_header();
			
			String errorcode=tx_header2.getSys_resp_code();
			if("2".equals(flag)&&"000000000000".equals(errorcode))
			{
				return ;
			}
			GpumpFaceLogModel facelogmodel=new GpumpFaceLogModel();
			if(com2!=null)
			{
				facelogmodel.setChannelid(com2.getSysChannelID());
				facelogmodel.setBranchid(com2.getDotNumber());
				facelogmodel.setVendorcode(com2.getVenderCode());
			}
			Date Recvtime=null;
			Date resptime=null;
			
			
			if(tx_header2!=null)
			{
				try {
					Recvtime = new SimpleDateFormat("yyyyMMddHHmmssSSS").parse(tx_header2.getSys_recv_time());
					resptime = new SimpleDateFormat("yyyyMMddHHmmssSSS").parse(tx_header2.getSys_resp_time());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					LOGGER.error(e.getMessage(),e);
					LOGGER.error("Recvtime or resptime  trans error!");
				}
				facelogmodel.setRecvtime(Recvtime);
				facelogmodel.setResptime(resptime);
				facelogmodel.setChanneltxcode(tx_header2.getSys_tx_code());
				facelogmodel.setTxcode(tx_header2.getSys_tx_code());
				facelogmodel.setTransret(tx_header2.getSys_tx_status());
				facelogmodel.setErrorcode(tx_header2.getSys_resp_code());
				facelogmodel.setErrormsg(tx_header2.getSys_resp_desc());
				facelogmodel.setRecvtimemillis(tx_header2.getSys_recv_time());
				facelogmodel.setResptimemillis(tx_header2.getSys_resp_time());
				facelogmodel.setTransflow(tx_header2.getSys_evt_trace_id());
				facelogmodel.setPhoto_path(traceLog.getLog_image_addr_nas());
			}
		
			facelogmodel.setHostname(LocalMessage.getHostName());
			String ip="";
			try {
				List<String> iplist = LocalMessage.getLocalIP();
				if(iplist!=null)
				{
					for(String str:iplist)
					{
						if(!"127.0.0.1".equals(str))
						{
							if(ip.equals(""))
							{
								ip=ip+str;
							}else
							{
								ip=ip+":"+str;
							}
						}
					}
				}
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				LOGGER.error(e.getMessage(),e);
				LOGGER.error("get ip error!");
			}
			facelogmodel.setServerip(ip);
			facelogmodel.setCosttimeinfo(time);

      String num = null;
  	  long  logid=gpumpFaceLogService.seq_logid_log();

      String patten = SysParaUtil.getStrPara("FACELOGPATTEN:1", "yyMM");
      try {
        String timeMills = facelogmodel.getTransflow().substring(9,19)+"000";
        num = DateUtils.getTimeInMillis(patten, Long.parseLong(timeMills));
       // num = new SimpleDateFormat(patten).format(new Date());
        LOGGER.info("FacegpupsController - insertlog - num:{}", num);
      } catch (Exception e1) {
        num = new SimpleDateFormat(patten).format(new Date());
        LOGGER.error("get table name fail, try to get table name by nowaday, table name = " + num + ", patten = " + patten,e1);
      }
  	  facelogmodel.setLogid(num+String.valueOf(logid));
      facelogmodel.setNum(num);
	  GpumpFaceLogUtil gpumpFaceLogUtil=new GpumpFaceLogUtil(facelogmodel,gpumpFaceLogService);
	  MultithreadingLogExecutor.addLogTask(gpumpFaceLogUtil);
		}
    }
}