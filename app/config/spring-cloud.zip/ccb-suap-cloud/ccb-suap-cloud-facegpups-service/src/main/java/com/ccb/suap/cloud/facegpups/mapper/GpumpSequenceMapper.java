package com.ccb.suap.cloud.facegpups.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.facegpups.model.GpumpSequenceModel;

@Mapper
@Component
public interface GpumpSequenceMapper {
		
	void currval(GpumpSequenceModel map);
	    
	void nextval(GpumpSequenceModel map);
		
	int update(@Param("seq_name")String seq_name,@Param("current_val")String current_val);
	
	int  select (@Param("seq_name")String seq_name);
}
