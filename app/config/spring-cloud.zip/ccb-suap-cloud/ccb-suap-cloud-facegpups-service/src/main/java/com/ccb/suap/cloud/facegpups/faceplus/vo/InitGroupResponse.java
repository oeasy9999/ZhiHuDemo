package com.ccb.suap.cloud.facegpups.faceplus.vo;

public class InitGroupResponse {

	private boolean result;
	private String error;
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	@Override
	public String toString() {
		return "InitGroupResponse [result=" + result + ", error=" + error + "]";
	}
	
}
