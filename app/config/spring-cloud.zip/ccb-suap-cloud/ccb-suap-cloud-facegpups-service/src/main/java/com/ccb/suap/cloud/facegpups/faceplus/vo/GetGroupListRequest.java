package com.ccb.suap.cloud.facegpups.faceplus.vo;

public class GetGroupListRequest {

	private String ip;
	private String port1;
	private String port2;
	private String port3;
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getPort1() {
		return port1;
	}
	public void setPort1(String port1) {
		this.port1 = port1;
	}
	public String getPort2() {
		return port2;
	}
	public void setPort2(String port2) {
		this.port2 = port2;
	}
	public String getPort3() {
		return port3;
	}
	public void setPort3(String port3) {
		this.port3 = port3;
	}
	@Override
	public String toString() {
		return "GetGroupListRequest [ip=" + ip + ", port1=" + port1 + ", port2=" + port2 + ", port3=" + port3 + "]";
	}
	
}
