package com.ccb.suap.cloud.facegpups.faceplus.vo;


public class AddFeatureResponse {

	private boolean result;
	private String error;
	private String featureid;
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getFeatureid() {
		return featureid;
	}
	public void setFeatureid(String featureid) {
		this.featureid = featureid;
	}
	@Override
	public String toString() {
		return "AddFeatureResponse [result=" + result + ", error=" + error + ", featureid=" + featureid + "]";
	}
	


	
}
