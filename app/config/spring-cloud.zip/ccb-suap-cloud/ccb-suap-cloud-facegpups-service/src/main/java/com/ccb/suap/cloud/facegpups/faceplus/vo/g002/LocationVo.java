package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

/**
 * 封装经纬度坐标类
 * @author Paiking
 *
 */
public class LocationVo {

    private double x;
    private double y;

    public LocationVo() {
    }

    public LocationVo(double x, double y) {
        this.x = x;
        this.y = y;
    }

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
}