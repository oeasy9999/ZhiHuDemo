package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

public class DetectVo {

	private String rect;
	private String quality_score;
	private String yaw;
	private String pitch;
	private String roll;
	private String saturation;
	public String getRect() {
		return rect;
	}
	public void setRect(String rect) {
		this.rect = rect;
	}
	public String getQuality_score() {
		return quality_score;
	}
	public void setQuality_score(String quality_score) {
		this.quality_score = quality_score;
	}
	public String getYaw() {
		return yaw;
	}
	public void setYaw(String yaw) {
		this.yaw = yaw;
	}
	public String getPitch() {
		return pitch;
	}
	public void setPitch(String pitch) {
		this.pitch = pitch;
	}
	public String getRoll() {
		return roll;
	}
	public void setRoll(String roll) {
		this.roll = roll;
	}
	public String getSaturation() {
		return saturation;
	}
	public void setSaturation(String saturation) {
		this.saturation = saturation;
	}
	@Override
	public String toString() {
		return "DetectVo [rect=" + rect + ", quality_score=" + quality_score + ", yaw=" + yaw + ", pitch=" + pitch
				+ ", roll=" + roll + ", saturation=" + saturation + "]";
	}
	
}
