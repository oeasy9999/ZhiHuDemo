package com.ccb.suap.cloud.facegpups.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import com.ccb.suap.cloud.facegpups.model.GpumpFidcustMapModel;

@Mapper
@Component
public interface GpumpFidCustMapMapper {

	int count(@Param("real_db_id")String real_db_id);
	
	GpumpFidcustMapModel select(@Param("real_db_id")String real_db_id,@Param("cust_id")String cust_id);
	
	GpumpFidcustMapModel selectbyfeatureid(@Param("real_db_id")String real_db_id,@Param("feature_id")String feature_id);
	
	List<GpumpFidcustMapModel> selectAll(@Param("real_db_id")String real_db_id);
	List<GpumpFidcustMapModel> selectByPage(@Param("real_db_id")String real_db_id,@Param("firstResult")int firstResult,@Param("maxResults")int maxResults);
	
	int insert(GpumpFidcustMapModel model);//seq_feature_id为SEQUENCE序列
	
	int update(GpumpFidcustMapModel model);
	
	int deleteAll(@Param("real_db_id")String real_db_id);
	
	int delete(@Param("real_db_id")String real_db_id,@Param("cust_id")String cust_id);
}
