package com.ccb.suap.cloud.facegpups.faceplus.vo;


public class CompareFeatureResponse {

	private boolean result;
	private String error;
	private String score;
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	@Override
	public String toString() {
		return "CompareFeatureResponse [result=" + result + ", error=" + error + ", score=" + score + "]";
	}
	
	
	
	
}
