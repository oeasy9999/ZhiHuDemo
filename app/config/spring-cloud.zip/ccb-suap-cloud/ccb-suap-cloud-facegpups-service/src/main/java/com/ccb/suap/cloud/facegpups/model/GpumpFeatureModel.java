package com.ccb.suap.cloud.facegpups.model;

import java.io.Serializable;
import java.util.Date;

public class GpumpFeatureModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String logic_db_id;
	private String gpu_type_id;
	private String cust_id;
	private String feature;
	private Date create_time;
	private Date modify_time;
	
	public String getLogic_db_id() {
		return logic_db_id;
	}
	public void setLogic_db_id(String logic_db_id) {
		this.logic_db_id = logic_db_id;
	}
	public String getGpu_type_id() {
		return gpu_type_id;
	}
	public void setGpu_type_id(String gpu_type_id) {
		this.gpu_type_id = gpu_type_id;
	}
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getFeature() {
		return feature;
	}
	public void setFeature(String feature) {
		this.feature = feature;
	}
	public Date getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}
	public Date getModify_time() {
		return modify_time;
	}
	public void setModify_time(Date modify_time) {
		this.modify_time = modify_time;
	}
	
	@Override
	public String toString() {
		return "GpumpFeatureModel [logic_db_id=" + logic_db_id + ", gpu_type_id=" + gpu_type_id + ", cust_id=" + cust_id
				+ ", feature=" + feature + ", create_time=" + create_time + ", modify_time=" + modify_time + "]";
	}
	
	
	
	
	
}
