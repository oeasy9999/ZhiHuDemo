package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

public class FaceVo {

	private String Confidence;
	private String FaceImg;
	private String Feature ;
	private FaceRect FaceRect;
	private Faceattr faceattr;
	public String getConfidence() {
		return Confidence;
	}
	public void setConfidence(String confidence) {
		Confidence = confidence;
	}
	public String getFaceImg() {
		return FaceImg;
	}
	public void setFaceImg(String faceImg) {
		FaceImg = faceImg;
	}
	public String getFeature() {
		return Feature;
	}
	public void setFeature(String feature) {
		Feature = feature;
	}
	public FaceRect getFaceRect() {
		return FaceRect;
	}
	public void setFaceRect(FaceRect faceRect) {
		FaceRect = faceRect;
	}
	public Faceattr getFaceattr() {
		return faceattr;
	}
	public void setFaceattr(Faceattr faceattr) {
		this.faceattr = faceattr;
	}
}
