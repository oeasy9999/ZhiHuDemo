package com.ccb.suap.cloud.facegpups.beans;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.controller.FacegpupsController;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureResponse;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFidcustMapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;
import com.ccb.suap.cloud.facegpups.service.Gpump1003RollbackService;
import com.ccb.suap.cloud.facegpups.service.GpumpCustInfoService;
import com.ccb.suap.cloud.facegpups.service.GpumpFidcustMapService;
import com.ccb.suap.cloud.facegpups.service.RockerMqService;
import com.ccb.suap.cloud.facegpups.service.GpumpFeatureService;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.task.entity.RealDbTask;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1003ServiceOutVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1003ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.ServiceInVoParam1003;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.log.TraceLog;
/*
 * 人脸1:N删除
 * */
public class GPUMP1003_Bean extends GPUMPBean{
	 private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");
	 private static final Logger LOGGER_TASK = LoggerFactory.getLogger("TASK");
	 private GpumpCustInfoService GpumpCustInfoService=GpumpDaoFactory.getDaoManager().getGpumpCustInfoService();
	 private GpumpFeatureService GpumpFeatureService=GpumpDaoFactory.getDaoManager().getGpumpFeatureService();
	 private GpumpFidcustMapService GpumpFidcustMapService=GpumpDaoFactory.getDaoManager().getGpumpFidcustMapService();
	 private RockerMqService RockerMqService=GpumpDaoFactory.getDaoManager().getRockerMqService();
	 private Gpump1003RollbackService Gpump1003RollbackService=GpumpDaoFactory.getDaoManager().getGpump1003RollbackService();
	 @Override
	public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		// TODO Auto-generated method stub
		 boolean flag=true;
		 TxResponseMsgHead rspHeader =rspMsg.getTx_header();
		 GPUMP1003ServiceInVo invo=(GPUMP1003ServiceInVo) reqMsg.getTx_body().getEntity();
		 TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		 if(invo.getCust_id()==null)
		 {
			 LOGGER.error("checkPara ---- Cust_id can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID);
			 flag= false;
		 }else if(Com2.getGroupName()==null)
		 {
			 LOGGER.error("checkPara ---- GroupName can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
			 flag= false;
		 }else if(Com2.getSysChannelID()==null)
		 {
			 LOGGER.error("checkPara ---- SysChannelID can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
			 flag= false;
		 }
		 rspMsg.setTx_header(rspHeader);
		return flag;
	}

	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg,TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("---------调用GPUMP1003_Bean服务---------");
		//LOGGER.debug("reqMsg: "+reqMsg.toString());
		if(!FacegpupsController.dbflag)
		{
			LOGGER.error("db error");
			throw new CommonRuntimeException(GpumpErrorInfoModel.DB_EXCEPTION,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.DB_EXCEPTION));
		}
		if(!checkPara(rspMsg,reqMsg))
		{
			TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1003", null);
			return rspMsg;
		}
		
		//设置交易流程参数
		ServiceInVoParam1003 param=new ServiceInVoParam1003();
		setparam(param, logtime, reqMsg);
		
		//获取逻辑库实例
		genLogicFaceModel(param);
		
		//获取同步参数，默认为异步
		String Synchronization_Flag=SysParaUtil.getStrValue("Synchronization_Flag:1", "1");
		if("0".equals(Synchronization_Flag))//同步
		{
			String is_mount_pag = param.getGpumpLogicFacedbModel().getIs_mount_pag();
			if("T".equals(is_mount_pag)){
				//如果挂载页位库，先查询当前的客户信息
				GpumpCustInfoModel custInfoModel=param.getGpumpCustInfoModel();
				String real_group_id=custInfoModel.getReal_group_id();
				//根据客户注册的页位库ID查找当前分页库
				GpumpLogicFacedbModel gpumpLogicFacedbModel = ServiceParaUtil.getAllGpuDBMsgByID(real_group_id);
				param.setGpumpLogicFacedbModel(gpumpLogicFacedbModel);
			}
			deleteFastBaseData(param,traceLog);
			GpumpLogicFacedbModel gpumpLogicFacedbModel_register=param.getGpumpLogicFacedbModel();
			String is_mount_gpu = gpumpLogicFacedbModel_register.getIs_mount_gpu();
			if("T".equals(is_mount_gpu))
			{
				//删除注册库物理库数据
				deleteRegisterBaseData(param,traceLog);
			}
			// TODO Auto-generated method stub
			//删除特征值表数据
			deleteFeatureData(param);
			deleteCustInfoData(param);
		}else //异步
		{
			//事务数据库事务删除  客户信息|特征值,返回redis任务到param
			List<String> redisTask_list=new ArrayList<String>();//记录到redis的任务
			param.setRedisTask_list(redisTask_list);
			//删除客户信息表和特征值表(事务)
			try {
				Gpump1003RollbackService.Gpump1003RollbackExRealDb(param,traceLog);
				//redis任务处理
				redisTask_list=param.getRedisTask_list();
				redisConduct(redisTask_list);
			} catch (CommonRuntimeException e) {
				LOGGER.error("Gpump1003RollbackExRealDb error,message is : "+e.getMessage(),e);
				throw e;
			}catch (Exception e) {
				// TODO Auto-generated catch block
				throw e;
			}
			String traceid = param.getTraceid();
			String cust_id=param.getCust_id();
			RealDbTask realDbTask=new RealDbTask();
			realDbTask.setTraceid(traceid);
			realDbTask.setCust_id(cust_id);
			realDbTask.setType("2");
			realDbTask.setParamMap(param);
			realDbTask.setTraceLog(traceLog);
			//RegisterTask.addTask(traceid+"_"+invo.getCust_id(), realDbTask);
			JSONObject json = (JSONObject)JSONObject.toJSON(realDbTask);
			RockerMqService.setMq("realDbTask", traceid+"_"+cust_id, json.toString());
			LOGGER_TASK.debug(traceid+"_"+cust_id+"||"+json.toString());
		}
		GPUMP1003ServiceOutVo outvo=new GPUMP1003ServiceOutVo();
		TxResponseMsgBody MsgBody=new TxResponseMsgBody();
		MsgBody.setEntity(outvo);
		rspMsg.setTx_body(MsgBody);
		
		TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1003", GpumpErrorInfoModel.NOERROR);
		LOGGER.debug("GPUMP1003_Bean end!");
		return rspMsg;
	}
	/**
	 * 设置服务流程参数方法
	 * @param param 流程数据类
	 * @param logtime 各环节耗时缓存
	 * @param reqMsg 请求数据
	 */
	void setparam(ServiceInVoParam1003 param,HashMap<String, Long> logtime,TxRequestMsg reqMsg)
	{

		TxRequestMsgHead reqMsgHead=reqMsg.getTx_header();
		String traceid=reqMsgHead.getSys_evt_trace_id();
		logtime.put("selectTime", (long) 0);
		logtime.put("deleteForGpuTime", (long) 0);
		logtime.put("deleteImageTime", (long) 0);
		logtime.put("deleteTime", (long) 0);
		GPUMP1003ServiceInVo invo=(GPUMP1003ServiceInVo)reqMsg.getTx_body().getEntity();
		TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		String GroupName=Com2.getGroupName();
		String sysChannelID=Com2.getSysChannelID();
		LOGGER.debug("GroupName is "+GroupName);
		LOGGER.debug("sysChannelID is "+sysChannelID);
		param.setSysChannelID(sysChannelID);
		param.setGroupName(GroupName);
		param.setLogtime(logtime);
		param.setTraceid(traceid);
		param.setCust_id(invo.getCust_id());
	}
	/**
	 * redis任务处理
	 * @param redisTask_list   redis任务缓存
	 */
	public void redisConduct(List<String> redisTask_list)
	{
		if(redisTask_list!=null&&redisTask_list.size()>0)
		{
			for(String task:redisTask_list)
			{
				String arg[]=task.split("\\|\\|");
				if(arg.length>=3)
				{
					String type=arg[0];
					String key=arg[1];
					String data=arg[2];
					RockerMqService.sendRedisOrMq(key, data, type);
				}else
				{
					LOGGER.warn("this task no 3 param, data is : "+task);
				}
			}
		}else
		{
			LOGGER.debug("redisTask_list is null");
		}
	}
	public void selectCustInfoData(ServiceInVoParam1003 param)
	{
		HashMap<String, Long> logtime=param.getLogtime();
		GpumpLogicFacedbModel gpumpLogicFacedbModel_register=param.getGpumpLogicFacedbModel();
		String Logic_db_id=gpumpLogicFacedbModel_register.getLogic_db_id();
	
		String cust_id=param.getCust_id();
		long start = System.currentTimeMillis();
		GpumpCustInfoModel gpumpcustinfomodel = GpumpCustInfoService.select(Logic_db_id,cust_id);
		long end = System.currentTimeMillis();
		logtime.put("selectTime", logtime.get("selectTime")+end-start);
		if(gpumpcustinfomodel==null)
		{
			LOGGER.warn("Cust_id is not exits for GpumpCustInfo,Cust_id is "+cust_id);
		}
		param.setGpumpCustInfoModel(gpumpcustinfomodel);
	}
	public void deleteCustInfoData(ServiceInVoParam1003 param)
	{
		HashMap<String, Long> logtime=param.getLogtime();
		GpumpLogicFacedbModel gpumpLogicFacedbModel_register=param.getGpumpLogicFacedbModel();
		String Logic_db_id = gpumpLogicFacedbModel_register.getLogic_db_id();;
		if("3".equals(gpumpLogicFacedbModel_register.getType())){//该库为页位库，查询母库ID
			Logic_db_id = gpumpLogicFacedbModel_register.getSource_db_id();
		}
		String cust_id=param.getCust_id();
		GpumpCustInfoModel gpumpcustinfomodel = param.getGpumpCustInfoModel();

		if(gpumpcustinfomodel!=null)
		{
			String image_addr = gpumpcustinfomodel.getImage_addr();
			LOGGER.debug("begin to delete for GpumpCustInfo,Cust_id is "+cust_id);
			//String default_url=new ApplicationHome(getClass()).getSource().getParent()+File.separator+"image";
			//String image_addr=SysParaUtil.getStrValue("image_addr:1",default_url)+File.separator+sysChannelID+File.separator+invo.getCust_id()+".jpg";
			LOGGER.debug("file path is "+image_addr);
			if(!deleteFaceImage(image_addr,logtime))//删除图片
			{
				LOGGER.error("delete face image error,file path is "+image_addr);
			}
			long start = System.currentTimeMillis();
			int ret=GpumpCustInfoService.delete(Logic_db_id,cust_id);
			long end = System.currentTimeMillis();
			logtime.put("deleteTime", logtime.get("deleteTime")+end-start);
			if(ret!=1)
			{
				LOGGER.error("GpumpCustInfoService  delete error! Cust_id is "+cust_id);
			}
			LOGGER.debug("end to delete for GpumpCustInfo.");
		}else
		{
			LOGGER.warn("Cust_id is not exits for GpumpCustInfo,Cust_id is "+cust_id);
		}
	}
	public void deleteFeatureData(ServiceInVoParam1003 param)
	{
		GpumpLogicFacedbModel gpumpLogicFacedbModel_register=param.getGpumpLogicFacedbModel();
		String is_mount_gpu = gpumpLogicFacedbModel_register.getIs_mount_gpu();
		String Logic_db_id=gpumpLogicFacedbModel_register.getLogic_db_id();
		String cust_id=param.getCust_id();
		HashMap<String, Long> logtime=param.getLogtime();
		HashMap<String, Boolean> Featuremap=new HashMap<>();//缓存已经删除的GPU类型,避免重复删除
		if("T".equals(is_mount_gpu))
		{
			LOGGER.debug("this gpumpLogicFacedb is mount gpu.");
			
			List<GpumpRealFacedbModel> gpumpRealFacedbModel_list=gpumpLogicFacedbModel_register.getGpumpRealFacedbModelList();
			if(gpumpRealFacedbModel_list==null||gpumpRealFacedbModel_list.size()==0)
			{
				LOGGER.error("gpumpRealFacedb is null");
				throw new CommonRuntimeException(GpumpErrorInfoModel.REALFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR));
			}
			
			for(GpumpRealFacedbModel gpumpRealFacedbModel:gpumpRealFacedbModel_list)
			{
				GpumpGpuInfoModel gpumpGpuInfoModel=gpumpRealFacedbModel.getGpumpGpuInfo();
				if(gpumpGpuInfoModel==null)
				{
					LOGGER.error("gpumpGpuInfo is null,continue this gpu!");
					continue;
				}
				String gpu_type_id=gpumpGpuInfoModel.getGpu_type_id();
				LOGGER.debug("begin to delete for GpumpFeature,Cust_id is "+cust_id);
				Boolean flag=Featuremap.get(gpu_type_id);//缓存已经删除的GPU类型,避免重复删除
				if(flag==null||!flag)
				{
					long start = System.currentTimeMillis();
					int ret=GpumpFeatureService.delete(Logic_db_id, gpu_type_id,cust_id);
					long end = System.currentTimeMillis();
					logtime.put("deleteForGpuTime", logtime.get("deleteForGpuTime")+end-start);
					if(ret!=1)
					{
						LOGGER.error("GpumpFeatureService delete error! Cust_id is "+cust_id);
					}
					Featuremap.put(gpu_type_id, true);
				}
				LOGGER.debug("end to delete for GpumpFeature.");
				RockerMqService.sendRedisOrMq(cust_id+"_"+Logic_db_id+"_"+gpu_type_id, null, "delRedis");
			}
		}else
		{
			LOGGER.debug("this gpumpLogicFacedb is unmount gpu.");
			Hashtable<String, List<GpumpGpuInfoModel>> gpuinfoByType = ServiceParaUtil.getGpuinfoByType();
			if(gpuinfoByType==null||gpuinfoByType.size()==0)
			{
				LOGGER.error("gpuinfo is null!");
				throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
			}
			Set<String> keySet = gpuinfoByType.keySet();
			for(String gputype:keySet)//gputype不会重复，所以不需要使用featurelist
			{
				long start = System.currentTimeMillis();
				int ret=GpumpFeatureService.delete(Logic_db_id, gputype,  cust_id);
				long end = System.currentTimeMillis();
				logtime.put("deleteForGpuTime", logtime.get("deleteForGpuTime")+end-start);
				if(ret!=1)
				{
					LOGGER.error("GpumpFeatureService delete error! Cust_id is : "+cust_id+" ,gputype is : "+gputype);
				}else
				{
					RockerMqService.sendRedisOrMq(cust_id+"_"+Logic_db_id+"_"+gputype, null, "delRedis");
				}
			}
		}
		
	}
	public void deleteFastBaseData(ServiceInVoParam1003 param,TraceLog traceLog)
	{
		GpumpLogicFacedbModel gpumpLogicFacedbModel_register=param.getGpumpLogicFacedbModel();
		String Logic_db_id=gpumpLogicFacedbModel_register.getLogic_db_id();
		String cust_id=param.getCust_id();
		String traceid=param.getTraceid();
		HashMap<String, Long> logtime=param.getLogtime();
		List<GpumpLogicFacedbModel> GpumpLogicFacedbModel_list = ServiceParaUtil.getLogicFacedbValueBySourceDbId(Logic_db_id);
		if(GpumpLogicFacedbModel_list==null||GpumpLogicFacedbModel_list.size()==0)
		{
			LOGGER.debug("this register base have no fast base!");
		}else
		{
			for(GpumpLogicFacedbModel gpumpLogicFacedbModel:GpumpLogicFacedbModel_list)
			{
				List<GpumpRealFacedbModel> gpumpRealFacedbModelList = gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
				if(gpumpRealFacedbModelList==null)
				{
					LOGGER.debug("gpumpRealFacedbModelList_fast is null!");
				}else 
				{
					for(GpumpRealFacedbModel gpumpRealFacedbModel:gpumpRealFacedbModelList)
					{
						String real_db_id = gpumpRealFacedbModel.getReal_db_id();
						String gpu_face_db = gpumpRealFacedbModel.getGpu_face_db();
						GpumpGpuInfoModel gpumpGpuInfo = gpumpRealFacedbModel.getGpumpGpuInfo();
						if(gpumpGpuInfo!=null)
						{
							String gpu_type_id=gpumpGpuInfo.getGpu_type_id();
							String gpuclassname="com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gpu_type_id + "_Bean";
							GpuInterface gpuBean=(GpuInterface) Utils.getInstance(gpuclassname);
							if(gpuBean==null)
							{
								LOGGER.error("GPUMP "+gpu_type_id+" service is no exist!");
								continue;
							}
							long start = System.currentTimeMillis();
							GpumpFidcustMapModel gpumpFidcustMapModel = GpumpFidcustMapService.select(real_db_id, cust_id);
							long end = System.currentTimeMillis();
							logtime.put("selectTime", logtime.get("selectTime")+end-start);
							if(gpumpFidcustMapModel!=null&&gpumpFidcustMapModel.getFeature_id()!=null)
							{
								String feature_id=gpumpFidcustMapModel.getFeature_id();
								DeleteFeatureRequest groupdeleteinvo=new DeleteFeatureRequest();
								groupdeleteinvo.setIp(gpumpGpuInfo.getGpu_ip());
								groupdeleteinvo.setPort1(gpumpGpuInfo.getGpu_port1());
								groupdeleteinvo.setPort2(gpumpGpuInfo.getGpu_port2());
								groupdeleteinvo.setPort3(gpumpGpuInfo.getGpu_port3());
								groupdeleteinvo.setTraceid(traceid);
								groupdeleteinvo.setGroupname(gpu_face_db);
								groupdeleteinvo.setFeatureid(feature_id);
								LOGGER.debug("begin to delete_fast for gpu,feature_id is "+feature_id);
								start = System.currentTimeMillis();
								DeleteFeatureResponse deletefeatureresponse = gpuBean.deleteFeature(groupdeleteinvo,traceLog);
								end = System.currentTimeMillis();
								logtime.put("deleteForGpuTime", logtime.get("deleteForGpuTime")+end-start);
								traceLog.setDeleteFeatureTime(traceLog.getDeleteFeatureTime()+end-start);
								if(!deletefeatureresponse.getResult()&&deletefeatureresponse.getError().equals(GpumpErrorInfoModel.GPURESULTERROR_FEATURE_ID_NO_EXIST))
								{
									LOGGER.warn("gpu user delete_fast error! feature_id is "+feature_id+" is not exist!");
								}else if(!deletefeatureresponse.getResult())
								{
									LOGGER.error("delete_fast user error,message is "+deletefeatureresponse.getError()+" : "+GpumpErrorInfoParaUtil.getErrorMsg(deletefeatureresponse.getError()));
									throw new CommonRuntimeException(deletefeatureresponse.getError(),GpumpErrorInfoParaUtil.getErrorMsg(deletefeatureresponse.getError()));
								}
								LOGGER.debug("end to delete for gpu.");
								
								LOGGER.debug("begin to delete for GpumpFidcustMap_fast,Cust_id is "+cust_id);
								start = System.currentTimeMillis();
								int ret=GpumpFidcustMapService.delete(real_db_id, cust_id);
								end = System.currentTimeMillis();
								logtime.put("deleteTime", logtime.get("deleteTime")+end-start);
								if(ret!=1)
								{
									LOGGER.error("GpumpFidcustMapService_fast delete error! Cust_id is "+cust_id);
								}
								LOGGER.debug("end to delete for GpumpFidcustMap_fast.");
							}
						}else
						{
							LOGGER.warn("gpumpGpuInfoModel is null,real_db_id is : "+gpumpRealFacedbModel.getReal_db_id());
						}
					}
				}
			}
		}
	}
	public boolean deleteFaceImage(String filePath,HashMap<String, Long> logtime)
	{
		long start = System.currentTimeMillis();
		boolean flag=true;
		File f=new File(filePath);
		if(!f.exists())
		{
			LOGGER.warn(filePath+" is not exist");
			flag=false;
		}else if(!f.isFile())
		{
			LOGGER.warn(filePath+" is not file");
			flag=false;
		}else
		{
			f.delete();
		}
		long end = System.currentTimeMillis();
		//deleteImageTime=deleteImageTime+end-start;
		logtime.put("deleteImageTime", logtime.get("deleteImageTime")+end-start);
		return flag;
	}
	
	
	public void deleteRegisterBaseData(ServiceInVoParam1003 param,TraceLog traceLog)
	{
		LOGGER.debug("this gpumpLogicFacedb is mount gpu.");
		GpumpLogicFacedbModel gpumpLogicFacedbModel_register=param.getGpumpLogicFacedbModel();
		List<GpumpRealFacedbModel> gpumpRealFacedbModel_list=gpumpLogicFacedbModel_register.getGpumpRealFacedbModelList();
		if(gpumpRealFacedbModel_list==null||gpumpRealFacedbModel_list.size()==0)
		{
			LOGGER.error("gpumpRealFacedb is null");
			throw new CommonRuntimeException(GpumpErrorInfoModel.REALFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR));
		}
		String cust_id=param.getCust_id();
		String traceid=param.getTraceid();
		HashMap<String, Long> logtime=param.getLogtime();
		for(GpumpRealFacedbModel gpumpRealFacedbModel:gpumpRealFacedbModel_list)
		{
			String Real_db_id=gpumpRealFacedbModel.getReal_db_id();
			String Gpu_face_db=gpumpRealFacedbModel.getGpu_face_db();
			GpumpGpuInfoModel gpumpGpuInfoModel=gpumpRealFacedbModel.getGpumpGpuInfo();
			if(gpumpGpuInfoModel==null)
			{
				LOGGER.error("gpumpGpuInfo is null,continue this gpu!");
				continue;
			}
			String gpu_type_id=gpumpGpuInfoModel.getGpu_type_id();
			String gpuclassname="com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gpu_type_id + "_Bean";
			GpuInterface gpuBean=(GpuInterface) Utils.getInstance(gpuclassname);
			if(gpuBean==null)
			{
				LOGGER.error("GPUMP "+gpu_type_id+" service is no exist!");
				continue;
			}
			//删除FidcustMap表记录，同时从gpu删除特征值
			deleteFidcustMapAndDeleteforGpu(gpumpGpuInfoModel, gpuBean, Real_db_id, Gpu_face_db,cust_id,traceid,logtime,traceLog);
			
		}
	
	}
	public void deleteFidcustMapAndDeleteforGpu(GpumpGpuInfoModel gpumpGpuInfoModel,GpuInterface gpuBean,String Real_db_id,String Gpu_face_db,String Cust_id,String traceid,HashMap<String, Long> logtime,TraceLog traceLog)
	{
		long start = System.currentTimeMillis();
		GpumpFidcustMapModel gpumpFidcustMapModel=GpumpFidcustMapService.select(Real_db_id, Cust_id);
		long end = System.currentTimeMillis();
		logtime.put("selectTime", logtime.get("selectTime")+end-start);
		if(gpumpFidcustMapModel==null)
		{
			LOGGER.error("delete user error,Cust_id: "+Cust_id+" is no exist");
		}else
		{
			LOGGER.debug("find the Cust_id : "+Cust_id+" for gpumpFidcustMap.");
			String feature_id=gpumpFidcustMapModel.getFeature_id();
			DeleteFeatureRequest groupdeleteinvo=new DeleteFeatureRequest();
			groupdeleteinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
			groupdeleteinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
			groupdeleteinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
			groupdeleteinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
			groupdeleteinvo.setGroupname(Gpu_face_db);
			groupdeleteinvo.setFeatureid(feature_id);
			groupdeleteinvo.setTraceid(traceid);
			//此处调用GPU删除
			LOGGER.debug("begin to delete for gpu,feature_id is "+feature_id);
			start = System.currentTimeMillis();
			DeleteFeatureResponse deletefeatureresponse= gpuBean.deleteFeature(groupdeleteinvo,traceLog);
			end = System.currentTimeMillis();
			logtime.put("deleteForGpuTime", logtime.get("deleteForGpuTime")+end-start);
			traceLog.setDeleteFeatureTime(traceLog.getDeleteFeatureTime()+end-start);
			if(!deletefeatureresponse.getResult()&&deletefeatureresponse.getError().equals(GpumpErrorInfoModel.GPURESULTERROR_FEATURE_ID_NO_EXIST))
			{
				LOGGER.warn("gpu user delete_fast error! feature_id is "+feature_id+" is not exist!");
			}else if(!deletefeatureresponse.getResult())
			{
				LOGGER.error("delete_fast user error,message is "+deletefeatureresponse.getError()+" : "+GpumpErrorInfoParaUtil.getErrorMsg(deletefeatureresponse.getError()));
				throw new CommonRuntimeException(deletefeatureresponse.getError(),GpumpErrorInfoParaUtil.getErrorMsg(deletefeatureresponse.getError()));
			}
			LOGGER.debug("end to delete for gpu.");
			
			LOGGER.debug("begin to delete for GpumpFidcustMap,Cust_id is "+Cust_id);
			start = System.currentTimeMillis();
			int ret=GpumpFidcustMapService.delete(Real_db_id,Cust_id);
			end = System.currentTimeMillis();
			logtime.put("deleteTime", logtime.get("deleteTime")+end-start);
			if(ret!=1)
			{
				LOGGER.error("GpumpFidcustMapService delete error! Cust_id is "+Cust_id);
			}
			LOGGER.debug("end to delete for GpumpFidcustMap.");
		}
	}
	
	@Override
    public Object transform(JSONObject indata) throws Exception {
		// TODO Auto-generated method stub
		JSONObject tx_body=indata.getJSONObject("tx_body");
		if(tx_body==null)
		{
			LOGGER.error("tx_body is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject entity=tx_body.getJSONObject("entity");
		if(entity==null)
		{
			LOGGER.error("entity is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject com2=tx_body.getJSONObject("com2");
		if(com2==null)
		{
			LOGGER.error("com2 is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		TxRequestMsg reqMsg=(TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
		GPUMP1003ServiceInVo invo=(GPUMP1003ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1003ServiceInVo.class);
		TxRequestMsgCom2 com=JSON.parseObject(JSON.toJSONString(com2),TxRequestMsgCom2.class);
		TxRequestMsgBody MsgBody=reqMsg.getTx_body();
		MsgBody.setEntity(invo);
		MsgBody.setCom2(com);
		reqMsg.setTx_body(MsgBody);
		return reqMsg;
	}
	@Override
	public List<GpuRegisterTask> getGpuTask() {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * 获取逻辑库实例
	 * @param param		交易流程数据类
	 */
	public void genLogicFaceModel(ServiceInVoParam1003 param)
	{
		String sysChannelID=param.getSysChannelID();
		String GroupName=param.getGroupName();
		String custId = param.getCust_id();
		GpumpLogicFacedbModel gpumpLogicFacedbModel=ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID+":"+GroupName);
		if(gpumpLogicFacedbModel==null)
		{
			LOGGER.error(GroupName+" is not exist!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
		}else if(!"1".equals(gpumpLogicFacedbModel.getType()) )
		{
			LOGGER.error(GroupName+" is not register base or page!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
		}
	
		//param.put("gpumpLogicFacedbModel", gpumpLogicFacedbModel);
		param.setGpumpLogicFacedbModel(gpumpLogicFacedbModel);
	}

	

}
