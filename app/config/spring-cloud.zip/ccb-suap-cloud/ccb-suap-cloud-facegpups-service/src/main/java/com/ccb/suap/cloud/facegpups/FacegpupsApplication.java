package com.ccb.suap.cloud.facegpups;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.amqp.RabbitAutoConfiguration;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.cloud.bus.BusAutoConfiguration;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
@EnableDiscoveryClient
//@EnableFeignClients
@SpringBootApplication(exclude={SecurityAutoConfiguration.class,RabbitAutoConfiguration.class,BusAutoConfiguration.class})
@EnableCircuitBreaker
//@EnableOAuth2Client
@MapperScan("com.ccb.suap.cloud.facegpups.mapper")
public class FacegpupsApplication
{
  public static void main(String[] args)
  {
    SpringApplication.run(FacegpupsApplication.class, args);
  }
}