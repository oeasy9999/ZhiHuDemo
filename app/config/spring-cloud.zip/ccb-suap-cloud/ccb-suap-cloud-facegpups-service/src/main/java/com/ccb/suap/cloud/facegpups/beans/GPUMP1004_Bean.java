package com.ccb.suap.cloud.facegpups.beans;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sun.misc.BASE64Encoder;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFidcustMapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;
import com.ccb.suap.cloud.facegpups.service.RedisService;
import com.ccb.suap.cloud.facegpups.service.utils.Constants;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1004ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1004ServiceOutVo;
import com.ccb.suap.util.file.FileCipherUtils;
import com.ccb.suap.util.log.TraceLog;

/*
 *人脸信息查询
 * */
public class GPUMP1004_Bean extends GPUMPBean{
	private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");
	private RedisService redisService=GpumpDaoFactory.getDaoManager().getRedisService();
	@Override
	public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		// TODO Auto-generated method stub
		 boolean flag=true;
		 TxResponseMsgHead rspHeader =rspMsg.getTx_header();
		 GPUMP1004ServiceInVo invo=(GPUMP1004ServiceInVo) reqMsg.getTx_body().getEntity();
		 TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		 if(invo.getCust_id()==null)
		 {
			 LOGGER.error("checkPara ---- Cust_id can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID);
			 flag= false;
		 }else if(Com2.getGroupName()==null)
		 {
			 LOGGER.error("checkPara ---- GroupName can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
			 flag= false;
		 }else if(Com2.getSysChannelID()==null)
		 {
			 LOGGER.error("checkPara ---- SysChannelID can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
			 flag= false;
		 }
		 rspMsg.setTx_header(rspHeader);
		return flag;
	}

	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg,TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("---------调用GPUMP1004_Bean服务---------");
		//LOGGER.debug("reqMsg: "+reqMsg.toString());
		TxResponseMsgBody rspMsgBody=new TxResponseMsgBody();
		GPUMP1004ServiceOutVo outvo=new GPUMP1004ServiceOutVo();
		//TxRequestMsgHead reqMsgHead=reqMsg.getTx_header();
		if(!checkPara(rspMsg,reqMsg))
		{
			TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1004", null);
			return rspMsg;
		}
		logtime.put("selectTime", (long) 0);
		logtime.put("readfileTime", (long) 0);
		GPUMP1004ServiceInVo invo=(GPUMP1004ServiceInVo)reqMsg.getTx_body().getEntity();
		TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		String GroupName=Com2.getGroupName();
		String sysChannelID=Com2.getSysChannelID();
		LOGGER.debug("GroupName is "+GroupName);
		LOGGER.debug("sysChannelID is "+sysChannelID);

		String Logic_db_id=null;
		GpumpLogicFacedbModel gpumpLogicFacedbModel=ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID+":"+GroupName);
		if(gpumpLogicFacedbModel==null)
		{
			LOGGER.error("gpumpLogicFacedb is not exist!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
		}
		if("1".equals(gpumpLogicFacedbModel.getType()))
		{
			Logic_db_id=gpumpLogicFacedbModel.getLogic_db_id();
			LOGGER.debug("this is a register base,Logic_db_id is "+Logic_db_id);
		}else
		{
			List<GpumpRealFacedbModel> gpumpRealFacedbModelList = gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
			if(gpumpRealFacedbModelList==null)
			{
				LOGGER.error(" gpumpRealFacedbModelList is null!");
				throw new CommonRuntimeException(GpumpErrorInfoModel.REALFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR));
			}
			boolean flag=false;
			for(GpumpRealFacedbModel gpumpRealFacedbModel:gpumpRealFacedbModelList)
			{
				String Real_db_id=gpumpRealFacedbModel.getReal_db_id();
				LOGGER.debug("Real_db_id is : "+Real_db_id);
				GpumpFidcustMapModel gpumpFidcustMapModel=redisService.selectFidcustMapModel(Real_db_id, invo.getCust_id());
				if(gpumpFidcustMapModel!=null)
				{
					LOGGER.debug(invo.getCust_id()+" is exist from GpumpFidcustMapModel");
					flag=true;
					break;
				}else
				{
					LOGGER.debug(invo.getCust_id()+" is not exist from GpumpFidcustMapModel");
				}
			}
			if(!flag)
			{
				LOGGER.error(" GpumpFidcustMapModel is null,cust_id is : "+invo.getCust_id());
				throw new CommonRuntimeException(GpumpErrorInfoModel.CUSTINFONOEXIT,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.CUSTINFONOEXIT));
			}
			
			gpumpLogicFacedbModel=ServiceParaUtil.getAllGpuDBMsgByID(gpumpLogicFacedbModel.getSource_db_id());
			if(gpumpLogicFacedbModel==null)
			{
				LOGGER.error("gpumpLogicFacedb register base is not exist");
				throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
			}
			Logic_db_id=gpumpLogicFacedbModel.getLogic_db_id();
			LOGGER.debug("this is a fast base,Logic_db_id is "+gpumpLogicFacedbModel.getLogic_db_id());
			LOGGER.debug("register base Logic_db_id is "+Logic_db_id);
		}
		long start = System.currentTimeMillis();
		GpumpCustInfoModel gpumpCustInfoModel=redisService.selectCustInfo(Logic_db_id, invo.getCust_id());
		long end = System.currentTimeMillis();
		//selectTime=selectTime+end-start;
		logtime.put("selectTime", logtime.get("selectTime")+end-start);
		if(gpumpCustInfoModel==null)
		{
			LOGGER.error("cust_id "+invo.getCust_id()+" is no exist");
			TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1004", GpumpErrorInfoModel.CUSTINFONOEXIT);
			rspMsg.setTx_body(rspMsgBody);
			return rspMsg;
		}
		
		String face_image_path=gpumpCustInfoModel.getImage_addr();
		String face_image=null;
		if(face_image_path!=null)
		{
			File face_file=new File(face_image_path);
			LOGGER.debug("file path is "+face_image_path);
			start = System.currentTimeMillis();
			if(face_file.exists())
			{
				LOGGER.debug("file is exist.");
				try {
					  byte[] picturebyte= FileCipherUtils.DecFileBuffer(Constants.DEFAULT_FILE_KEY, face_image_path);
					  BASE64Encoder encoder = new BASE64Encoder();
					  face_image = encoder.encode(picturebyte) ;
					  face_image = face_image.replaceAll("\r", "");
					  face_image = face_image.replaceAll("\n", "");
					  face_image = face_image.replaceAll(" ", "");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					LOGGER.error("readfile error,path is : "+face_image_path,e);
				}
		        LOGGER.debug("file transform to base64string success.");
			}else
			{
				LOGGER.warn("file is not exist!");
			}
			end = System.currentTimeMillis();
			//readfileTime=readfileTime+end-start;
			logtime.put("readfileTime", logtime.get("readfileTime")+end-start);
		}else
		{
			LOGGER.warn("face_image_path is null!");
		}
		outvo.setCust_id(invo.getCust_id());
		outvo.setId_no(gpumpCustInfoModel.getId_no());
		outvo.setId_type(gpumpCustInfoModel.getId_type());
		outvo.setName(gpumpCustInfoModel.getName());
		outvo.setMobile_no(gpumpCustInfoModel.getMobile_no());
		outvo.setFace_collecttime(gpumpCustInfoModel.getModify_time()==null?null:new SimpleDateFormat("yyyyMMddHHmmssSSS").format(gpumpCustInfoModel.getModify_time()));
		outvo.setFace_recognitiontime(gpumpCustInfoModel.getRecognition_time()==null?null:new SimpleDateFormat("yyyyMMddHHmmssSSS").format(gpumpCustInfoModel.getRecognition_time()));
		outvo.setFace_image(face_image);
		rspMsgBody.setEntity(outvo);

		TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1004", GpumpErrorInfoModel.NOERROR);
		rspMsg.setTx_body(rspMsgBody);
		LOGGER.debug("GPUMP1004_Bean end!");
		return rspMsg;
	}

	@Override
    public Object transform(JSONObject indata) throws Exception {
		// TODO Auto-generated method stub
		JSONObject tx_body=indata.getJSONObject("tx_body");
		if(tx_body==null)
		{
			LOGGER.error("tx_body is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject entity=tx_body.getJSONObject("entity");
		if(entity==null)
		{
			LOGGER.error("entity is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject com2=tx_body.getJSONObject("com2");
		if(com2==null)
		{
			LOGGER.error("com2 is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		TxRequestMsg reqMsg=(TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
		GPUMP1004ServiceInVo invo=(GPUMP1004ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1004ServiceInVo.class);;
		TxRequestMsgCom2 com=JSON.parseObject(JSON.toJSONString(com2),TxRequestMsgCom2.class);
		TxRequestMsgBody MsgBody=reqMsg.getTx_body();
		MsgBody.setEntity(invo);
		MsgBody.setCom2(com);
		reqMsg.setTx_body(MsgBody);
		return reqMsg;
	}

	@Override
	public List<GpuRegisterTask> getGpuTask(){
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public String getTime() {
//		StringBuffer cmmpLog = new StringBuffer();
//		cmmpLog.append("selectTime<").append(selectTime).append("> ");
//		cmmpLog.append("readfileTime<").append(readfileTime).append("> ");
//		return cmmpLog.toString();
//	}
}
