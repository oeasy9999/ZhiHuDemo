package com.ccb.suap.cloud.facegpups.faceplus.vo.g003;

public class GroupSearchVo {

	private String imageId;
	private String score;
	private String dbId;
	private String pid;
	private String extra;
	private String payload;
	private String filename;
	
	public String getExtra() {
		return extra;
	}
	public void setExtra(String extra) {
		this.extra = extra;
	}
	public String getImageId() {
		return imageId;
	}
	public void setImageId(String imageId) {
		this.imageId = imageId;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getDbId() {
		return dbId;
	}
	public void setDbId(String dbId) {
		this.dbId = dbId;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	@Override
	public String toString() {
		return "GroupSearchVo [imageId=" + imageId + ", score=" + score + ", dbId=" + dbId + ", pid=" + pid
				+ ", payload=" + payload + ", filename=" + filename + "]";
	}
	
}
