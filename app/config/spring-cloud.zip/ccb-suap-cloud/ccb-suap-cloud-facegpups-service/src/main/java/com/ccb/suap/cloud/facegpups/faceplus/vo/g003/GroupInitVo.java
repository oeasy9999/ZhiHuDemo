package com.ccb.suap.cloud.facegpups.faceplus.vo.g003;

public class GroupInitVo implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1L;
	private String dbName;
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	
}
