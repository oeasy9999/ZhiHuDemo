package com.ccb.suap.cloud.facegpups.model;

import java.util.Date;

public class GpumpGpuInfoModel {
	
	private String gpu_name;				//GPU主机名
	private String gpu_type_id;				//GPU类型标识
	private String gpu_ip;					//IP地址
	private String gpu_port1;				//端口1
	private String gpu_port2;				//端口2
	private String gpu_port3;				//端口3
	private String gpu_factory;				//厂商
	private String gpu_version;				//版本
	private String adapter;					//适配器
	private String total_capacity;			//总容量
	private String single_capacity;			//单库容量
	private String work_version;			//工作版本
	private String work_state;				//工作状态
	private Date work_update_time;			//状态更新时间
	
	public String getGpu_name() {
		return gpu_name;
	}
	public void setGpu_name(String gpu_name) {
		this.gpu_name = gpu_name;
	}
	public String getGpu_type_id() {
		return gpu_type_id;
	}
	public void setGpu_type_id(String gpu_type_id) {
		this.gpu_type_id = gpu_type_id;
	}
	public String getGpu_ip() {
		return gpu_ip;
	}
	public void setGpu_ip(String gpu_ip) {
		this.gpu_ip = gpu_ip;
	}
	public String getGpu_port1() {
		return gpu_port1;
	}
	public void setGpu_port1(String gpu_port1) {
		this.gpu_port1 = gpu_port1;
	}
	public String getGpu_port2() {
		return gpu_port2;
	}
	public void setGpu_port2(String gpu_port2) {
		this.gpu_port2 = gpu_port2;
	}
	public String getGpu_port3() {
		return gpu_port3;
	}
	public void setGpu_port3(String gpu_port3) {
		this.gpu_port3 = gpu_port3;
	}
	public String getGpu_factory() {
		return gpu_factory;
	}
	public void setGpu_factory(String gpu_factory) {
		this.gpu_factory = gpu_factory;
	}
	public String getGpu_version() {
		return gpu_version;
	}
	public void setGpu_version(String gpu_version) {
		this.gpu_version = gpu_version;
	}
	public String getAdapter() {
		return adapter;
	}
	public void setAdapter(String adapter) {
		this.adapter = adapter;
	}
	public String getTotal_capacity() {
		return total_capacity;
	}
	public void setTotal_capacity(String total_capacity) {
		this.total_capacity = total_capacity;
	}
	public String getSingle_capacity() {
		return single_capacity;
	}
	public void setSingle_capacity(String single_capacity) {
		this.single_capacity = single_capacity;
	}
	public String getWork_version() {
		return work_version;
	}
	public void setWork_version(String work_version) {
		this.work_version = work_version;
	}
	public String getWork_state() {
		return work_state;
	}
	public void setWork_state(String work_state) {
		this.work_state = work_state;
	}
	public Date getWork_update_time() {
		return work_update_time;
	}
	public void setWork_update_time(Date work_update_time) {
		this.work_update_time = work_update_time;
	}
	
	@Override
	public String toString() {
		return "GpumpGpuInfoModel [gpu_name=" + gpu_name + ", gpu_type_id=" + gpu_type_id + ", gpu_ip=" + gpu_ip
				+ ", gpu_port1=" + gpu_port1 + ", gpu_port2=" + gpu_port2 + ", gpu_port3=" + gpu_port3
				+ ", gpu_factory=" + gpu_factory + ", gpu_version=" + gpu_version + ", adapter=" + adapter
				+ ", total_capacity=" + total_capacity + ", single_capacity=" + single_capacity + ", work_version="
				+ work_version + ", work_state=" + work_state + ", work_update_time=" + work_update_time + "]";
	}
	
	
	
	
	
	
	
	
	
	
}
