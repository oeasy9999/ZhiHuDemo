package com.ccb.suap.cloud.facegpups.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;

@Mapper
@Component
public interface GpumpCustInfoMapper {

    int count(@Param("logic_db_id")String logic_db_id);
	
	GpumpCustInfoModel select(@Param("logic_db_id")String logic_db_id,@Param("cust_id")String cust_id);
	
	List<GpumpCustInfoModel> selectAll(@Param("logic_db_id")String logic_db_id);
	
	int insert(GpumpCustInfoModel model);
	
	int update(GpumpCustInfoModel model);
	
	int delete(@Param("logic_db_id")String logic_db_id,@Param("cust_id")String cust_id);
}
