package com.ccb.suap.cloud.facegpups.faceplus.vo.g003;


public class GroupCleanOutVo {

	private String result;
	private String errorMessage;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "GroupCleanOutVo [result=" + result + ", errorMessage=" + errorMessage + "]";
	}

	
}
