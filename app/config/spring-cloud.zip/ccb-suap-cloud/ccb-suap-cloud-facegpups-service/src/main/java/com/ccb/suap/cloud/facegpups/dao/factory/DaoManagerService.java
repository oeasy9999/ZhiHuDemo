package com.ccb.suap.cloud.facegpups.dao.factory;


import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ccb.suap.cloud.facegpups.mapper.JmsConfig;
import com.ccb.suap.cloud.facegpups.mapper.TraceLogger;
import com.ccb.suap.cloud.facegpups.redis.RedisUtil;
import com.ccb.suap.cloud.facegpups.rocketmq.PayProducer;
import com.ccb.suap.cloud.facegpups.service.Gpump1001RollbackService;
import com.ccb.suap.cloud.facegpups.service.Gpump1003RollbackService;
import com.ccb.suap.cloud.facegpups.service.GpumpCustInfoService;
import com.ccb.suap.cloud.facegpups.service.GpumpFaceLogService;
import com.ccb.suap.cloud.facegpups.service.GpumpFeatureService;
import com.ccb.suap.cloud.facegpups.service.GpumpFidcustMapService;
import com.ccb.suap.cloud.facegpups.service.GpumpGpuInfoService;
import com.ccb.suap.cloud.facegpups.service.GpumpLogicFacedbService;
import com.ccb.suap.cloud.facegpups.service.GpumpRealFacedbService;
import com.ccb.suap.cloud.facegpups.service.GpumpSysParaService;
import com.ccb.suap.cloud.facegpups.service.RealDbTaskService;
import com.ccb.suap.cloud.facegpups.service.RedisService;
import com.ccb.suap.cloud.facegpups.service.RockerMqService;
import com.ccb.suap.cloud.facegpups.service.SequenceService;

@Service(value="daoManager")
@Transactional
public class DaoManagerService {

	@Resource
	private GpumpCustInfoService gpumpCustInfoService;
	@Resource
	private GpumpFeatureService gpumpFeatureService;
	@Resource
	private GpumpFidcustMapService gpumpFidcustMapService;
	@Resource
	private SequenceService sequenceService;
	@Resource 
	private GpumpFaceLogService gpumpFaceLogService;
	@Resource
	private GpumpRealFacedbService gpumpRealFacedbService;
	@Resource
	private GpumpLogicFacedbService gpumpLogicFacedbService;
	@Resource
	private GpumpGpuInfoService gpumpGpuInfoService;
	@Resource
	private Gpump1001RollbackService gpump1001RollbackService;
	@Resource
	private Gpump1003RollbackService gpump1003RollbackService;
	@Resource
	private RedisUtil redisUtil;
	@Resource
	private PayProducer payProducer;
	@Resource
	private RedisService redisService;
	@Resource
	private RockerMqService rockerMqService;
	@Resource
	private RealDbTaskService realDbTaskService;
	@Resource
	private GpumpSysParaService gpumpSysParaService;
	@Resource
	private JmsConfig JmsConfig;
	@Resource
	private TraceLogger traceLogger;
	
	public JmsConfig getJmsConfig() {
		return JmsConfig;
	}
	public void setJmsConfig(JmsConfig jmsConfig) {
		JmsConfig = jmsConfig;
	}
	public GpumpSysParaService getGpumpSysParaService() {
		return gpumpSysParaService;
	}
	public void setGpumpSysParaService(GpumpSysParaService gpumpSysParaService) {
		this.gpumpSysParaService = gpumpSysParaService;
	}
	public RealDbTaskService getRealDbTaskService() {
		return realDbTaskService;
	}
	public void setRealDbTaskService(RealDbTaskService realDbTaskService) {
		this.realDbTaskService = realDbTaskService;
	}
	public RockerMqService getRockerMqService() {
		return rockerMqService;
	}
	public void setRockerMqService(RockerMqService rockerMqService) {
		this.rockerMqService = rockerMqService;
	}
	public RedisService getRedisService() {
		return redisService;
	}
	public void setRedisService(RedisService redisService) {
		this.redisService = redisService;
	}
	public RedisUtil getRedisUtil() {
		return redisUtil;
	}
	public void setRedisUtil(RedisUtil redisUtil) {
		this.redisUtil = redisUtil;
	}
	
	public PayProducer getPayProducer() {
		return payProducer;
	}
	public void setPayProducer(PayProducer payProducer) {
		this.payProducer = payProducer;
	}
	public Gpump1001RollbackService getGpump1001RollbackService() {
		return gpump1001RollbackService;
	}
	public void setGpump1001RollbackService(Gpump1001RollbackService gpump1001RollbackService) {
		this.gpump1001RollbackService = gpump1001RollbackService;
	}
	public Gpump1003RollbackService getGpump1003RollbackService() {
		return gpump1003RollbackService;
	}
	public void setGpump1003RollbackService(Gpump1003RollbackService gpump1003RollbackService) {
		this.gpump1003RollbackService = gpump1003RollbackService;
	}
	public GpumpGpuInfoService getGpumpGpuInfoService() {
		return gpumpGpuInfoService;
	}
	public void setGpumpGpuInfoService(GpumpGpuInfoService gpumpGpuInfoService) {
		this.gpumpGpuInfoService = gpumpGpuInfoService;
	}
	public GpumpRealFacedbService getGpumpRealFacedbService() {
		return gpumpRealFacedbService;
	}
	public void setGpumpRealFacedbService(GpumpRealFacedbService gpumpRealFacedbService) {
		this.gpumpRealFacedbService = gpumpRealFacedbService;
	}
	public GpumpLogicFacedbService getGpumpLogicFacedbService() {
		return gpumpLogicFacedbService;
	}
	public void setGpumpLogicFacedbService(GpumpLogicFacedbService gpumpLogicFacedbService) {
		this.gpumpLogicFacedbService = gpumpLogicFacedbService;
	}
	public GpumpFaceLogService getGpumpFaceLogService() {
		return gpumpFaceLogService;
	}
	public void setGpumpFaceLogService(GpumpFaceLogService gpumpFaceLogService) {
		this.gpumpFaceLogService = gpumpFaceLogService;
	}
	public GpumpCustInfoService getGpumpCustInfoService() {
		return gpumpCustInfoService;
	}
	public void setGpumpCustInfoService(GpumpCustInfoService gpumpCustInfoService) {
		this.gpumpCustInfoService = gpumpCustInfoService;
	}
	public GpumpFeatureService getGpumpFeatureService() {
		return gpumpFeatureService;
	}
	public void setGpumpFeatureService(GpumpFeatureService gpumpFeatureService) {
		this.gpumpFeatureService = gpumpFeatureService;
	}

	public GpumpFidcustMapService getGpumpFidcustMapService() {
		return gpumpFidcustMapService;
	}
	public void setGpumpFidcustMapService(GpumpFidcustMapService gpumpFidcustMapService) {
		this.gpumpFidcustMapService = gpumpFidcustMapService;
	}
	public SequenceService getSequenceService() {
		return sequenceService;
	}
	public void setSequenceService(SequenceService sequenceService) {
		this.sequenceService = sequenceService;
	}
	public TraceLogger getTraceLogger() {
		return traceLogger;
	}
	public void setTraceLogger(TraceLogger traceLogger) {
		this.traceLogger = traceLogger;
	}
	
	
}
