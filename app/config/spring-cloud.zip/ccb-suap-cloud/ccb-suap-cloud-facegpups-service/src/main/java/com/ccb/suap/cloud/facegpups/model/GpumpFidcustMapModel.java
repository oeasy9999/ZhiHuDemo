package com.ccb.suap.cloud.facegpups.model;

import java.io.Serializable;
import java.util.Date;

public class GpumpFidcustMapModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String real_db_id;
	private String cust_id;
	private String feature_id;
	private Date create_time;
	private Date modify_time;
	

	public String getReal_db_id() {
		return real_db_id;
	}
	public void setReal_db_id(String read_db_id) {
		this.real_db_id = read_db_id;
	}
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getFeature_id() {
		return feature_id;
	}
	public void setFeature_id(String feature_id) {
		this.feature_id = feature_id;
	}
	public Date getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}
	public Date getModify_time() {
		return modify_time;
	}
	public void setModify_time(Date modify_time) {
		this.modify_time = modify_time;
	}
	
	
	
}
