package com.ccb.suap.cloud.facegpups.faceplus.vo.g001;

import java.io.Serializable;

public class GroupDeleteFeatureOutVo implements Serializable {

	private static final long serialVersionUID = -1L;
	private String result;
	private String error;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	@Override
	public String toString() {
		return "GroupDeleteOutVo [result=" + result + ", error=" + error + "]";
	}
	
}
