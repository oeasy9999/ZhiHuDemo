package com.ccb.suap.cloud.facegpups.beans;

import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareFeatureResponse;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFeatureModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFidcustMapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;
import com.ccb.suap.cloud.facegpups.service.GpumpCustInfoService;
import com.ccb.suap.cloud.facegpups.service.GpumpFeatureService;
import com.ccb.suap.cloud.facegpups.service.RedisService;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.PhotoUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1008ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1008ServiceOutVo;
import com.ccb.suap.cloud.facegpups.vo.ServiceInVoParam1002;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.log.TraceLog;

/**
 * 传入图片和客户号比对
 *
 * @author zhanzifeng
 */
public class GPUMP1008_Bean extends GPUMPBean {

  private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");
  private GpumpFeatureService GpumpFeatureService =
      GpumpDaoFactory.getDaoManager().getGpumpFeatureService();
  private GpumpCustInfoService gpumpCustInfoService =
      GpumpDaoFactory.getDaoManager().getGpumpCustInfoService();
  private RedisService redisService = GpumpDaoFactory.getDaoManager().getRedisService();

  @Override
  public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,
      HashMap<String, Long> logtime, TraceLog traceLog) throws Exception {
    LOGGER.debug("---------调用GPUMP1008_Bean服务---------");
    if (!checkPara(rspMsg, reqMsg)) {
      TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1008", null);
      return rspMsg;
    }
    TxRequestMsgHead tx_header = reqMsg.getTx_header();
    String traceid = tx_header.getSys_evt_trace_id();
    logtime.put("extractForGpuTime", (long) 0);
    logtime.put("compareTime", (long) 0);
    logtime.put("selectTime", (long) 0);
    logtime.put("saveFileTime", (long) 0);
    GPUMP1008ServiceInVo invo = (GPUMP1008ServiceInVo) reqMsg.getTx_body().getEntity();
    String cust_id = invo.getCust_id();
    String face_image = invo.getFace_image();
    TxRequestMsgCom2 Com2 = reqMsg.getTx_body().getCom2();
    String sysChannelID = Com2.getSysChannelID();
    String GroupName = Com2.getGroupName();
    LOGGER.debug("sysChannelID : " + sysChannelID);
    LOGGER.debug("GroupName : " + GroupName);
    saveFaceImageByUrl(reqMsg,logtime,traceLog);
    
    GpumpLogicFacedbModel gpumpLogicFacedbModel =
        ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID + ":" + GroupName);
    if (gpumpLogicFacedbModel == null) {
      LOGGER.error("gpumpLogicFacedbModel is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
    }
    String logic_db_id = gpumpLogicFacedbModel.getLogic_db_id();
    GpumpCustInfoModel gpumpCustInfoModel1 =
        redisService.selectCustInfo(logic_db_id, invo.getCust_id());
    if (gpumpCustInfoModel1 == null) {
      LOGGER.error("cust_id " + invo.getCust_id() + " is no exist");
      throw new CommonRuntimeException(GpumpErrorInfoModel.CUSTINFONOEXIT,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.CUSTINFONOEXIT));
    }
    String extractflag = gpumpLogicFacedbModel.getVerify_param1();
    String similarity = null;
    boolean flag = false;
    boolean FidExits = false;
    if (("1".equals(gpumpLogicFacedbModel.getType()) && "T".equals(gpumpLogicFacedbModel.getIs_mount_gpu()))
        || "2".equals(gpumpLogicFacedbModel.getType())) {//注册库有挂载gpu

      if ("2".equals(gpumpLogicFacedbModel.getType())) { //如果是快速库，先查找特征值对照表是否存在该客户
        List<GpumpRealFacedbModel> gpumpRealFacedbModellist_fast =
            gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
        if (gpumpRealFacedbModellist_fast == null) {
          LOGGER.warn("this register base have no RealFacedb!");
          throw new CommonRuntimeException(GpumpErrorInfoModel.REALFACEDBERROR,
              GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR));
        }
        for (int i = 0; i < gpumpRealFacedbModellist_fast.size(); i++) {//
          GpumpRealFacedbModel realFacedbModel_fast = gpumpRealFacedbModellist_fast.get(i);
          String REAL_DB_ID_fast = realFacedbModel_fast.getReal_db_id();
          //查询客户特征值对照表
          long start = System.currentTimeMillis();
          GpumpFidcustMapModel gpumpFidcustMapModel =
              redisService.selectFidcustMapModel(REAL_DB_ID_fast, cust_id);
          long end = System.currentTimeMillis();
          //selectTime=selectTime+end-start;
          logtime.put("selectTime", logtime.get("selectTime") + end - start);
          if (gpumpFidcustMapModel != null) {
            LOGGER.debug(invo.getCust_id() + " is exist from GpumpFidcustMapModel");
            FidExits = true;
            break;
          }
        }
        //如果是快速库，查询不到特征值对照表直接返回错误
        if (!FidExits) {
          LOGGER.error(" GpumpFidcustMapModel is null,cust_id is : " + invo.getCust_id());
          throw new CommonRuntimeException(GpumpErrorInfoModel.CUSTINFONOEXIT,
              GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.CUSTINFONOEXIT));
        }
        logic_db_id = gpumpLogicFacedbModel.getSource_db_id();
        gpumpLogicFacedbModel = ServiceParaUtil.getAllGpuDBMsgByID(logic_db_id);
      }

      if ("T".equals(gpumpLogicFacedbModel.getIs_mount_pag()) && "1".equals(
          gpumpLogicFacedbModel.getType())) {
        //注册库挂挂有分页库
        GpumpCustInfoModel gpumpCustInfoModel =
            getGpumpCustInfoModel(gpumpLogicFacedbModel, cust_id);
        logic_db_id = gpumpCustInfoModel.getReal_group_id();
        gpumpLogicFacedbModel = ServiceParaUtil.getAllGpuDBMsgByID(logic_db_id);
      }
      extractflag = gpumpLogicFacedbModel.getVerify_param1();
      List<GpumpRealFacedbModel> gpumpRealFacedbModelList =
          gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
      if (gpumpRealFacedbModelList != null) {
        GpumpRealFacedbModel gpumpRealFacedbModel =
            gpumpRealFacedbModelList.get((int) (Math.random() * gpumpRealFacedbModelList.size()));
        GpumpGpuInfoModel gpumpGpuInfo = gpumpRealFacedbModel.getGpumpGpuInfo();
        if (gpumpGpuInfo != null) {
          long start = System.currentTimeMillis();
          GpumpFeatureModel gpumpFeatureModel =
              GpumpFeatureService.select(logic_db_id, gpumpGpuInfo.getGpu_type_id(), cust_id);
          long end = System.currentTimeMillis();
          //selectTime=selectTime+end-start;
          logtime.put("selectTime", logtime.get("selectTime") + end - start);
          if (gpumpFeatureModel != null) {
            String feature = gpumpFeatureModel.getFeature();
            String feature2 =
                getFeature(face_image, gpumpGpuInfo, extractflag, traceid, logtime, traceLog);
            similarity =
                compareForTwoFeature(feature2, feature, gpumpGpuInfo, traceid, logtime, traceLog);
            flag = true;
          } else {
            LOGGER.error("FeatureModel is null,gputype is : "
                + gpumpGpuInfo.getGpu_type_id()
                + " ,logic_db_id is : "
                + logic_db_id);
            throw new CommonRuntimeException(GpumpErrorInfoModel.CUSTINFONOEXIT,
                GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.CUSTINFONOEXIT));
          }
        } else {
          LOGGER.warn("this RealFacedb base have no GpuInfo!");
          throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,
              GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
        }
      } else {
        LOGGER.warn("this register base have no RealFacedb!");
        throw new CommonRuntimeException(GpumpErrorInfoModel.REALFACEDBERROR,
            GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR));
      }
    } else {
      LOGGER.debug(logic_db_id + " is a register base.");
      LOGGER.debug(logic_db_id + " have no mount gpu.");
      //注册库并且没有挂载GPU,向下找有没有快速库
      List<GpumpLogicFacedbModel> gpumpLogicFacedbModel_list =
          ServiceParaUtil.getLogicFacedbValueBySourceDbId(logic_db_id);
      if (gpumpLogicFacedbModel_list != null && !gpumpLogicFacedbModel_list.isEmpty()) {
        //随机获取一个注册库
        gpumpLogicFacedbModel = gpumpLogicFacedbModel_list.get(
            (int) (Math.random() * gpumpLogicFacedbModel_list.size()));
        extractflag = gpumpLogicFacedbModel.getVerify_param1();
        List<GpumpRealFacedbModel> gpumpRealFacedbModelList =
            gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
        if (gpumpRealFacedbModelList != null) {
          GpumpRealFacedbModel gpumpRealFacedbModel =
              gpumpRealFacedbModelList.get((int) (Math.random() * gpumpRealFacedbModelList.size()));
          GpumpGpuInfoModel gpumpGpuInfo = gpumpRealFacedbModel.getGpumpGpuInfo();
          if (gpumpGpuInfo != null) {
            long start = System.currentTimeMillis();
            GpumpFeatureModel gpumpFeatureModel =
                GpumpFeatureService.select(logic_db_id, gpumpGpuInfo.getGpu_type_id(), cust_id);
            long end = System.currentTimeMillis();
            //selectTime=selectTime+end-start;
            logtime.put("selectTime", logtime.get("selectTime") + end - start);
            if (gpumpFeatureModel != null) {
              String feature = gpumpFeatureModel.getFeature();
              String feature2 =
                  getFeature(face_image, gpumpGpuInfo, extractflag, traceid, logtime, traceLog);
              similarity =
                  compareForTwoFeature(feature2, feature, gpumpGpuInfo, traceid, logtime, traceLog);
              flag = true;
            }
          } else {
            LOGGER.warn("this RealFacedb base have no GpuInfo!");
            throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,
                GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
          }
        } else {
          LOGGER.warn("this register base have no RealFacedb!");
          throw new CommonRuntimeException(GpumpErrorInfoModel.REALFACEDBERROR,
              GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR));
        }
      } else {
        LOGGER.warn("this register base have no fast base,must be random acquistion a gpu!");
        Hashtable<String, List<GpumpGpuInfoModel>> gpuinfoByType =
            ServiceParaUtil.getGpuinfoByType();
        if (gpuinfoByType == null || gpuinfoByType.size() == 0) {
          LOGGER.error("gpuinfo is null!");
          throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,
              GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
        }
        Set<String> keySet = gpuinfoByType.keySet();
        for (String gputype : keySet)//gputype不会重复，所以不需要使用featurelist
        {
          if (flag) {
            break;
          }
          List<GpumpGpuInfoModel> GpumpGpuInfoModellist = gpuinfoByType.get(gputype);
          GpumpGpuInfoModel gpumpGpuInfoModel =
              GpumpGpuInfoModellist.get((int) (Math.random() * GpumpGpuInfoModellist.size()));

          long start = System.currentTimeMillis();
          GpumpFeatureModel gpumpFeatureModel =
              GpumpFeatureService.select(logic_db_id, gputype, cust_id);
          long end = System.currentTimeMillis();
          //selectTime=selectTime+end-start;
          logtime.put("selectTime", logtime.get("selectTime") + end - start);
          if (gpumpFeatureModel == null) {
            LOGGER.error(cust_id + " is not exist for GpumpFeatureModel,gputype is : " + gputype);
            continue;
          }
          String feature1 = gpumpFeatureModel.getFeature();
          if (feature1 == null) {
            LOGGER.error(cust_id + " feature is null for GpumpFeatureModel!");
            continue;
          }
          //采集特征值
          String feature2 =
              getFeature(face_image, gpumpGpuInfoModel, "0", traceid, logtime, traceLog);
          similarity = compareForTwoFeature(feature1, feature2, gpumpGpuInfoModel, traceid, logtime,
              traceLog);
          flag = true;
        }
      }
    }
    if (!flag) {
      LOGGER.error("flag is false,no resource to compare!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
    }
    GPUMP1008ServiceOutVo outvo = new GPUMP1008ServiceOutVo();
    outvo.setSimilarity(similarity);
    
    TxResponseMsgBody MsgBody = new TxResponseMsgBody();
    MsgBody.setEntity(outvo);
    rspMsg.setTx_body(MsgBody);
    TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1008", GpumpErrorInfoModel.NOERROR);
    return rspMsg;
  }

  @Override
  public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
    boolean flag = true;
    TxResponseMsgHead rspHeader = rspMsg.getTx_header();
    GPUMP1008ServiceInVo invo = (GPUMP1008ServiceInVo) reqMsg.getTx_body().getEntity();
    TxRequestMsgCom2 Com2 = reqMsg.getTx_body().getCom2();
    if (invo.getCust_id() == null) {
      LOGGER.error("checkPara ---- cust_id can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID);
      flag = false;
    } else if (invo.getFace_image() == null) {
      LOGGER.error("checkPara ---- Face_image can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE);
      flag = false;
    } else if (Com2.getGroupName() == null) {
      LOGGER.error("checkPara ---- GroupName can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
      flag = false;
    } else if (Com2.getSysChannelID() == null) {
      LOGGER.error("checkPara ---- SysChannelID can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
      flag = false;
    }
    rspMsg.setTx_header(rspHeader);
    return flag;
  }

  public GpumpCustInfoModel getGpumpCustInfoModel(GpumpLogicFacedbModel gpumpLogicFacedbModel,
      String cust_id) {
    GpumpCustInfoModel gpumpCustInfoModel = null;
    String source_db_id = null;
    if ("1".equals(gpumpLogicFacedbModel.getType())) {
      source_db_id = gpumpLogicFacedbModel.getLogic_db_id();
    } else {
      //快速库客户信息
      source_db_id = gpumpLogicFacedbModel.getSource_db_id();
    }
    gpumpCustInfoModel = gpumpCustInfoService.select(source_db_id, cust_id);
    if (gpumpCustInfoModel == null) {
      LOGGER.error(
          " gpumpCustInfoModel is null,LOGIC_DB_ID: " + source_db_id + ", cust_id is : " + cust_id);
      throw new CommonRuntimeException(GpumpErrorInfoModel.CUSTINFONOEXIT,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.CUSTINFONOEXIT));
    }
    return gpumpCustInfoModel;
  }

  @Override
  public Object transform(JSONObject indata) throws Exception {
    JSONObject tx_body = indata.getJSONObject("tx_body");
    if (tx_body == null) {
      LOGGER.error("tx_body is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
    }
    JSONObject entity = tx_body.getJSONObject("entity");
    if (entity == null) {
      LOGGER.error("entity is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
    }
    JSONObject com2 = tx_body.getJSONObject("com2");
    if (com2 == null) {
      LOGGER.error("com2 is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
    }
    TxRequestMsg reqMsg = (TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
    GPUMP1008ServiceInVo invo =
        (GPUMP1008ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1008ServiceInVo.class);
    TxRequestMsgCom2 com = JSON.parseObject(JSON.toJSONString(com2), TxRequestMsgCom2.class);

    TxRequestMsgBody MsgBody = reqMsg.getTx_body();
    MsgBody.setEntity(invo);
    MsgBody.setCom2(com);
    reqMsg.setTx_body(MsgBody);
    return reqMsg;
  }

  @Override
  public List<GpuRegisterTask> getGpuTask() {
    // TODO Auto-generated method stub
    return null;
  }

  //	@Override
  //	public String getTime() {
  //		StringBuffer cmmpLog = new StringBuffer();
  //		cmmpLog.append("extractForGpuTime<").append(extractForGpuTime).append("> ");
  //		cmmpLog.append("compareTime<").append(compareTime).append("> ");
  //		cmmpLog.append("selectTime<").append(selectTime).append("> ");
  //		return cmmpLog.toString();
  //	}

  public String getFeature(String faceImage, GpumpGpuInfoModel gpumpGpuInfoModel,
      String extractflag, String traceid, HashMap<String, Long> logtime, TraceLog traceLog) {
    String gpu_type_id = gpumpGpuInfoModel.getGpu_type_id();
    String gpuclassname = "com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gpu_type_id + "_Bean";
    //GpuInterface gpuBean=GpuMeth.getBeanClass(gpuclassname);
    GpuInterface gpuBean = (GpuInterface) Utils.getInstance(gpuclassname);
    if (gpuBean == null) {
      LOGGER.error("GPUMP " + gpu_type_id + " service is no exist!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPUGROUPERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUGROUPERROR));
    }
    GetFeatureRequest gpuinvo = new GetFeatureRequest();
    gpuinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
    gpuinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
    gpuinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
    gpuinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
    gpuinvo.setImage(faceImage);
    gpuinvo.setTraceid(traceid);
    gpuinvo.setExtractflag(extractflag);
    LOGGER.debug("begin to extract for gpu.");
    long start = System.currentTimeMillis();
    GetFeatureResponse getfeatureresponse = gpuBean.getFeature(gpuinvo, traceLog);
    long end = System.currentTimeMillis();
    //extractForGpuTime=extractForGpuTime+end-start;
    traceLog.setGetFeatureTime(traceLog.getGetFeatureTime() + end - start);
    logtime.put("extractForGpuTime", logtime.get("extractForGpuTime") + end - start);
    LOGGER.debug(getfeatureresponse.toString());
    if (!getfeatureresponse.getResult()) {
      LOGGER.error("extract user error, " + getfeatureresponse.getError());
      throw new CommonRuntimeException(getfeatureresponse.getError(),
          GpumpErrorInfoParaUtil.getErrorMsg(getfeatureresponse.getError()));
    }
    String feature = getfeatureresponse.getFeature();
    if (feature == null) {
      LOGGER.error("extract user error,feature is null.");
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPUEXTRACTERERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUEXTRACTERERROR));
    }
    LOGGER.debug("end to extract for gpu.");
    return feature;
  }

  /**
   * 保存图片到nas目录，目录 yyyyMMddHHmm，每10分钟一个目录 文件名 客户号_yyyyMMddHHmmss.jpg
   *
   * @param param 交易流程数据类
 * @throws IOException 
   */
  public void saveFaceImageByUrl(TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws IOException {
	  String logImgCof=SysParaUtil.getStrPara("LOGIMGCOF:1","1");
	  if("1".equals(logImgCof)){
		GPUMP1008ServiceInVo invo = (GPUMP1008ServiceInVo) reqMsg.getTx_body().getEntity();
	    String sysChannelID = reqMsg.getTx_body().getCom2().getSysChannelID();
	    String face_image = invo.getFace_image();
	    String transflow = reqMsg.getTx_header().getSys_evt_trace_id();
		String log_mage_addr_nas = PhotoUtil.getPath("image_addr:1", "/"+sysChannelID+"/faceComplmage", invo.getCust_id()+"_"+transflow);
		traceLog.setFace_image(face_image);
	    traceLog.setLog_image_addr_nas(log_mage_addr_nas);
    }
  }
  
  /**
   * 2各特征值比对，返回相似度
   *
   * @param feature1 特征值1
   * @param feature2 特征值2
   * @param gpumpGpuInfoModel GPU实例
   * @param traceid 全集交易流水号
   * @param logtime 各环节交易耗时缓存
   * @param traceLog 报文日志缓存类
   * @return 相似度
   */
  public String compareForTwoFeature(String feature1, String feature2,
      GpumpGpuInfoModel gpumpGpuInfoModel, String traceid, HashMap<String, Long> logtime,
      TraceLog traceLog) {

    String gpu_type_id = gpumpGpuInfoModel.getGpu_type_id();
    String gpuclassname = "com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gpu_type_id + "_Bean";
    //GpuInterface gpuBean=GpuMeth.getBeanClass(gpuclassname);
    GpuInterface gpuBean = (GpuInterface) Utils.getInstance(gpuclassname);
    if (gpuBean == null) {
      LOGGER.error("GPUMP " + gpu_type_id + " service is no exist!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPUGROUPERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUGROUPERROR));
    }
    CompareFeatureRequest compareinvo = new CompareFeatureRequest();
    compareinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
    compareinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
    compareinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
    compareinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
    compareinvo.setTraceid(traceid);
    compareinvo.setFeature1(feature1);
    compareinvo.setFeature2(feature2);
    long start = System.currentTimeMillis();
    CompareFeatureResponse verifyOutVo = gpuBean.compareFeature(compareinvo, traceLog);
    long end = System.currentTimeMillis();
    //compareTime=compareTime+end-start;
    logtime.put("compareTime", logtime.get("compareTime") + end - start);
    traceLog.setCompareFeatureTime(traceLog.getCompareFeatureTime() + end - start);
    if (!verifyOutVo.getResult()) {
      LOGGER.error(
          "compare user error!message is " + verifyOutVo.getError() + " : " + GpumpErrorInfoParaUtil
              .getErrorMsg(verifyOutVo.getError()));
      throw new CommonRuntimeException(verifyOutVo.getError(),
          GpumpErrorInfoParaUtil.getErrorMsg(verifyOutVo.getError()));
    }
    String similarity = verifyOutVo.getScore();
    LOGGER.debug("similarity is " + similarity);
    if (similarity == null) {
      LOGGER.error("compare return Confidence is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPURESULTERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPURESULTERROR));
    }
    LOGGER.info("compare return Confidence is " + similarity);
    return similarity;
  }
}
