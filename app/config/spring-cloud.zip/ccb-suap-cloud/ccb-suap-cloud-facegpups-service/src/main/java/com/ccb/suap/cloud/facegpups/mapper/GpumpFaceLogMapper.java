package com.ccb.suap.cloud.facegpups.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.facegpups.model.GpumpFaceLogModel;

@Mapper
@Component
public interface GpumpFaceLogMapper {
	int count();
	
	GpumpFaceLogModel select(@Param("begintime")String begintime,@Param("endtime")String endtime);
	
	List<GpumpFaceLogModel> selectAll();
	
	int insert(GpumpFaceLogModel model);
	
	int update(GpumpFaceLogModel model);
	
	int delete(@Param("logid")String logid);

	long seq_logid_log();
}
