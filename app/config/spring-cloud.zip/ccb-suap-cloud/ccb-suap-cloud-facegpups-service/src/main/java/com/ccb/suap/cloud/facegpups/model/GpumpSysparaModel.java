package com.ccb.suap.cloud.facegpups.model;

public class GpumpSysparaModel {

	private String paracode;
	private String paraname;
	private String paravalue;
	private String paratype;
	private String remark;
	public String getParacode() {
		return paracode;
	}
	public void setParacode(String paracode) {
		this.paracode = paracode;
	}
	public String getParaname() {
		return paraname;
	}
	public void setParaname(String paraname) {
		this.paraname = paraname;
	}
	public String getParavalue() {
		return paravalue;
	}
	public void setParavalue(String paravalue) {
		this.paravalue = paravalue;
	}
	public String getParatype() {
		return paratype;
	}
	public void setParatype(String paratype) {
		this.paratype = paratype;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
}
