package com.ccb.suap.cloud.facegpups.beans;

import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DetectImageRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DetectImageResponse;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;
//import com.ccb.suap.cloud.facegpups.service.utils.GpuMeth;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpGpuInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.PhotoUtil;
import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1008ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1010ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1010ServiceOutVo;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.log.TraceLog;
/**
 * 人脸图片质量检测
 * @author zhanzifeng
 *
 */
public class GPUMP1010_Bean extends GPUMPBean{
	private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");

	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws Exception {
		LOGGER.debug("---------调用GPUMP1010_Bean服务---------");
		LOGGER.debug("reqMsg: "+reqMsg.toString());
		if(!checkPara(rspMsg,reqMsg))
		{
			TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1010", null);
			return rspMsg; 
		}
		TxRequestMsgHead tx_header = reqMsg.getTx_header();
		String traceid=tx_header.getSys_evt_trace_id();
		logtime.put("detectForGpuTime", (long) 0);
		logtime.put("saveFileTime", (long) 0);
	    saveFaceImageByUrl(reqMsg,logtime,traceLog);
		GPUMP1010ServiceInVo invo=(GPUMP1010ServiceInVo) reqMsg.getTx_body().getEntity();
		String face_image = invo.getFace_image();
		Hashtable<String, List<GpumpGpuInfoModel>> gpuinfoByType_list = GpumpGpuInfoParaUtil.getParaByType();
		if(gpuinfoByType_list==null||gpuinfoByType_list.size()==0)
		{
			LOGGER.error("gpuinfoByType_list is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
		}
		Set<String> keySet = gpuinfoByType_list.keySet();

		//boolean flag=true;
		for(String gputype:keySet)//gputype不会重复，所以不需要使用featurelist
		{


			List<GpumpGpuInfoModel> GpumpGpuInfoModellist = gpuinfoByType_list.get(gputype);
		
			GpumpGpuInfoModel gpumpGpuInfoModel=GpumpGpuInfoModellist.get((int)(Math.random()*GpumpGpuInfoModellist.size()));
		
			String gpuclassname="com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gputype + "_Bean";
			//GpuInterface gpuBean=GpuMeth.getBeanClass(gpuclassname);
			GpuInterface gpuBean=(GpuInterface) Utils.getInstance(gpuclassname);
			if(gpuBean==null)
			{
				LOGGER.error("GPUMP "+gputype+" service is no exist!");
				continue;
			}
			DetectImageRequest detectinvo=new DetectImageRequest();
			detectinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
			detectinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
			detectinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
			detectinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
			detectinvo.setImage(face_image);
			detectinvo.setTraceid(traceid);
			long start = System.currentTimeMillis();
			DetectImageResponse detectimageresponse = gpuBean.detectImage(detectinvo,traceLog,reqMsg.getTx_body().getCom2().getSysChannelID());
			long end = System.currentTimeMillis();
			//detectForGpuTime=detectForGpuTime+end-start;
			logtime.put("detectForGpuTime", logtime.get("detectForGpuTime")+end-start);
			traceLog.setDetectImageTime(traceLog.getDetectImageTime()+end-start);
			if(!detectimageresponse.getResult())
			{
				LOGGER.error("detectOutVo return error,errormessage is : "+detectimageresponse.getError()+" "+GpumpErrorInfoParaUtil.getErrorMsg(detectimageresponse.getError()));
				throw new CommonRuntimeException(detectimageresponse.getError(),GpumpErrorInfoParaUtil.getErrorMsg(detectimageresponse.getError()));
			}
			/*double quality = Double.parseDouble(detectimageresponse.getQuality()==null?"0":detectimageresponse.getQuality().trim());
		
			LOGGER.debug("quality is : "+quality);
			String face_quality=SysParaUtil.getStrValue("Face_quality:1","80");

			LOGGER.debug("face_quality is : "+face_quality);
			double sum=Double.parseDouble(face_quality);
			if(sum>quality)
			{
				LOGGER.warn("image quality "+quality+" less than face_quality"+sum +" for gputype is : "+gputype);
				flag=false;
				break;
			}*/
		}
		/*if(!flag)
		{
			LOGGER.error("image check error!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.GPUDETECTERROR_CHECK,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUDETECTERROR_CHECK));
		}*/
		TxResponseMsgBody rspMsgBody=new TxResponseMsgBody();
		GPUMP1010ServiceOutVo GPUMP1010ServiceOutVo=new GPUMP1010ServiceOutVo();
		rspMsgBody.setEntity(GPUMP1010ServiceOutVo);
		rspMsg.setTx_body(rspMsgBody);
		TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1010", GpumpErrorInfoModel.NOERROR);
		LOGGER.debug("GPUMP1010_Bean end!");
		return rspMsg;
	}

	

	@Override
	public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		boolean flag=true;
		 TxResponseMsgHead rspHeader =rspMsg.getTx_header();
		 GPUMP1010ServiceInVo invo=(GPUMP1010ServiceInVo) reqMsg.getTx_body().getEntity();
		 TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		 if(invo.getFace_image()==null)
		 {
			 LOGGER.error("checkPara ---- Face_image can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE);
			 flag= false;
		 }else if(Com2.getGroupName()==null)
		 {
			 LOGGER.error("checkPara ---- GroupName can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
			 flag= false;
		 }else if(Com2.getSysChannelID()==null)
		 {
			 LOGGER.error("checkPara ---- SysChannelID can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
			 flag= false;
		 }
		rspMsg.setTx_header(rspHeader);
		return flag;
	}

	@Override
	public Object transform(JSONObject indata) throws Exception {
		JSONObject tx_body=indata.getJSONObject("tx_body");
		if(tx_body==null)
		{
			LOGGER.error("tx_body is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject entity=tx_body.getJSONObject("entity");
		if(entity==null)
		{
			LOGGER.error("entity is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject com2=tx_body.getJSONObject("com2");
		if(com2==null)
		{
			LOGGER.error("com2 is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		TxRequestMsg reqMsg=(TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
		GPUMP1010ServiceInVo invo=(GPUMP1010ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1010ServiceInVo.class);
		TxRequestMsgCom2 com=JSON.parseObject(JSON.toJSONString(com2),TxRequestMsgCom2.class);
		
		TxRequestMsgBody MsgBody=reqMsg.getTx_body();
		MsgBody.setEntity(invo);
		MsgBody.setCom2(com);
		reqMsg.setTx_body(MsgBody);
		return reqMsg;
	}

	@Override
	public List<GpuRegisterTask> getGpuTask() {
		// TODO Auto-generated method stub
		return null;
	}

	  /**
	   * 保存图片到nas目录，目录 yyyyMMddHHmm，每10分钟一个目录 文件名 客户号_yyyyMMddHHmmss.jpg
	   *
	   * @param param 交易流程数据类
	 * @throws IOException 
	   */
	  public void saveFaceImageByUrl(TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws IOException {
		  String logImgCof=SysParaUtil.getStrPara("LOGIMGCOF:1","1");
		  if("1".equals(logImgCof)){
			GPUMP1010ServiceInVo invo = (GPUMP1010ServiceInVo) reqMsg.getTx_body().getEntity();
		    String sysChannelID = reqMsg.getTx_body().getCom2().getSysChannelID();
		    String face_image = invo.getFace_image();
		    String transflow = reqMsg.getTx_header().getSys_evt_trace_id();
			String log_mage_addr_nas = PhotoUtil.getPath("image_addr:1", "/"+sysChannelID+"/faceComplmage", "GPUMP1010_"+transflow);
			traceLog.setFace_image(face_image);
		    traceLog.setLog_image_addr_nas(log_mage_addr_nas);
	    }
	  }

}
