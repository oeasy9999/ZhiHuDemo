package com.ccb.suap.cloud.facegpups.datatransform.message;

import java.io.Serializable;

public class TxRequestMsgHead implements Serializable{

	 private static final long serialVersionUID = 1L;

	private String sys_pkg_vrsn;  //协议版本号
	private String sys_tx_code;   //服务名
	private String sys_channel_id; //渠道编号（预留）
	private String sys_evt_trace_id; //全局事件跟踪号
	private String sys_req_time; //请求时间格式为“yyyymmddhhmmssNNN”
	private String sys_pkg_sts_type; //报文状态类型
	public String getSys_pkg_vrsn() {
		return sys_pkg_vrsn;
	}
	public void setSys_pkg_vrsn(String sys_pkg_vrsn) {
		this.sys_pkg_vrsn = sys_pkg_vrsn;
	}
	public String getSys_tx_code() {
		return sys_tx_code;
	}
	public void setSys_tx_code(String sys_tx_code) {
		this.sys_tx_code = sys_tx_code;
	}
	public String getSys_channel_id() {
		return sys_channel_id;
	}
	public void setSys_channel_id(String sys_channel_id) {
		this.sys_channel_id = sys_channel_id;
	}
	public String getSys_evt_trace_id() {
		return sys_evt_trace_id;
	}
	public void setSys_evt_trace_id(String sys_evt_trace_id) {
		this.sys_evt_trace_id = sys_evt_trace_id;
	}
	public String getSys_req_time() {
		return sys_req_time;
	}
	public void setSys_req_time(String sys_req_time) {
		this.sys_req_time = sys_req_time;
	}
	public String getSys_pkg_sts_type() {
		return sys_pkg_sts_type;
	}
	public void setSys_pkg_sts_type(String sys_pkg_sts_type) {
		this.sys_pkg_sts_type = sys_pkg_sts_type;
	}
	@Override
	public String toString() {
		return "TxRequestMsgHead [sys_pkg_vrsn=" + sys_pkg_vrsn + ", sys_tx_code=" + sys_tx_code + ", sys_channel_id="
				+ sys_channel_id + ", sys_evt_trace_id=" + sys_evt_trace_id + ", sys_req_time=" + sys_req_time
				+ ", sys_pkg_sts_type=" + sys_pkg_sts_type + "]";
	}
	
	
}
