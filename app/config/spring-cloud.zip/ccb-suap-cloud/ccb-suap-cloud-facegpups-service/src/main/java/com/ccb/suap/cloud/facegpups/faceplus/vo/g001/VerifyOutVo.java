package com.ccb.suap.cloud.facegpups.faceplus.vo.g001;

public class VerifyOutVo {

	private String time_used;
	private String reqid;
	private String delta_validation;
	private String confidence;
	private String error;
	public String getTime_used() {
		return time_used;
	}
	public void setTime_used(String timeUsed) {
		time_used = timeUsed;
	}
	public String getReqid() {
		return reqid;
	}
	public void setReqid(String reqid) {
		this.reqid = reqid;
	}
	public String getDelta_validation() {
		return delta_validation;
	}
	public void setDelta_validation(String deltaValidation) {
		delta_validation = deltaValidation;
	}
	public String getConfidence() {
		return confidence;
	}
	public void setConfidence(String confidence) {
		this.confidence = confidence;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	@Override
	public String toString() {
		return "VerifyOutVo [time_used=" + time_used + ", reqid=" + reqid + ", delta_validation=" + delta_validation
				+ ", confidence=" + confidence + ", error=" + error + "]";
	}
	
}
