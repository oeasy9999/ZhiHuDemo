package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

import java.io.Serializable;

public class GroupAddOutVo implements Serializable {

	private static final long serialVersionUID = -1L;
	private String result;
	private String errorMessage;
	private String featureId;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getFeatureId() {
		return featureId;
	}
	public void setFeatureId(String featureId) {
		this.featureId = featureId;
	}
	@Override
	public String toString() {
		return "GroupAddOutVo [result=" + result + ", errorMessage=" + errorMessage + ", featureId=" + featureId + "]";
	}

}
