package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

import java.util.List;

public class GroupSearchOutVo implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1L;
	private String result;
	private List<GroupSearchVo> data;
	private String errorMessage;
	private String time_used;
	
	public String getTime_used() {
		return time_used;
	}
	public void setTime_used(String time_used) {
		this.time_used = time_used;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
	public List<GroupSearchVo> getData() {
		return data;
	}
	public void setData(List<GroupSearchVo> data) {
		this.data = data;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "GroupSearchOutVo [result=" + result + ", data=" + data + ", errorMessage=" + errorMessage + "]";
	}
	
}
