package com.ccb.suap.cloud.facegpups.faceplus.vo.g003;

public class VersionOutVo {

	private String result;
	private String errorMessage;
	private String version;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	@Override
	public String toString() {
		return "VersionOutVo [result=" + result + ", errorMessage=" + errorMessage + ", version=" + version + "]";
	}
	
	
}
