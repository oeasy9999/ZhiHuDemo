package com.ccb.suap.cloud.facegpups.gpubeans.tranerrorcode;

import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;

public class GpuCodeUtil_G001 {

	public static String tranCode(String errorcode)
	{
		String result;
		if(errorcode.contains("ARGUMENT_ERROR")||errorcode.contains("ARGUMENTS_ERROR"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_ARGUMENT_ERROR;
		}else if(errorcode.contains("TOO_LARGE_IMAGE_SIZE_ERROR"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_IMAGE_SIZE;
		}else if(errorcode.contains("UNSUPPORTED_FORMAT_IMAGE_ERROR"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_IMAGE_FORMAT;
		}else if(errorcode.contains("BAD_PARAMETER"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_BAD_PARAMETER;
		}else if(errorcode.contains("GROUP_NOT_EXIST"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_GROUP_NOT_EXIST;
		}else if(errorcode.contains("FEATURE_ID_ALREADY_EXIST"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_FEATURE_ID_EXIST;
		}else if(errorcode.contains("FEATURE_ID_NOT_EXIST"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_FEATURE_ID_NO_EXIST;
		}else if(errorcode.contains("NO_FACE_FOUND"))
		{
			result=GpumpErrorInfoModel.GPUDETECTERROR_FACESNULL;
		}else if(errorcode.contains("GROUP_ALREADY_EXIST"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_GROUP_ALREADY_EXIST;
		}
		else
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_INTERNAL;
		}
		return result;
	}
}
