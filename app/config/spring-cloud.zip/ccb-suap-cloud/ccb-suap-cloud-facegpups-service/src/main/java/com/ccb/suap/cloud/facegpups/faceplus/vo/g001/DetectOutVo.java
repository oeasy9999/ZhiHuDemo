package com.ccb.suap.cloud.facegpups.faceplus.vo.g001;

import java.io.Serializable;
import java.util.List;
/**
 * 图片检测返回实例
 * @author zhanzifeng
 *
 */
public class DetectOutVo implements Serializable {

	private static final long serialVersionUID = -2322422754329611651L;
	private String time_used;
	private String reqid;
	private String delta_validation;
	private List<FaceVo> faces;
	private String error;
	public String getTime_used() {
		return time_used;
	}
	public void setTime_used(String time_used) {
		this.time_used = time_used;
	}
	public String getReqid() {
		return reqid;
	}
	public void setReqid(String reqid) {
		this.reqid = reqid;
	}
	public String getDelta_validation() {
		return delta_validation;
	}
	public void setDelta_validation(String delta_validation) {
		this.delta_validation = delta_validation;
	}
	public List<FaceVo> getFaces() {
		return faces;
	}
	public void setFaces(List<FaceVo> faces) {
		this.faces = faces;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "DetectOutVo [time_used=" + time_used + ", reqid=" + reqid + ", delta_validation=" + delta_validation
				+ ", faces=" + faces + ", error=" + error + "]";
	}
	

}
