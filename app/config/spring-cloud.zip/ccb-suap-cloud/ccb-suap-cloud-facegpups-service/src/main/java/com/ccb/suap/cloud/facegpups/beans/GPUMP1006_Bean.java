package com.ccb.suap.cloud.facegpups.beans;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.faceplus.vo.AddFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.AddFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureResponse;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpFidcustMapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFeatureModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;
import com.ccb.suap.cloud.facegpups.service.GpumpFidcustMapService;
import com.ccb.suap.cloud.facegpups.service.RedisService;
import com.ccb.suap.cloud.facegpups.service.RockerMqService;
import com.ccb.suap.cloud.facegpups.service.GpumpCustInfoService;
import com.ccb.suap.cloud.facegpups.service.SequenceService;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1006ServiceOutVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1006ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.ServiceInVoParam1001;
import com.ccb.suap.cloud.facegpups.vo.ServiceInVoParam1006;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.log.TraceLog;

/*
 * 快速库入库
 * */
public class GPUMP1006_Bean extends GPUMPBean{
	private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");
	private SequenceService sequenceService=GpumpDaoFactory.getDaoManager().getSequenceService();
	private GpumpFidcustMapService GpumpFidcustMapService=GpumpDaoFactory.getDaoManager().getGpumpFidcustMapService();
	private GpumpCustInfoService GpumpCustInfoService=GpumpDaoFactory.getDaoManager().getGpumpCustInfoService();
	private RockerMqService RockerMqService=GpumpDaoFactory.getDaoManager().getRockerMqService();
	private RedisService redisService=GpumpDaoFactory.getDaoManager().getRedisService();
	@Override
	public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		boolean flag=true;
		TxResponseMsgHead rspHeader =rspMsg.getTx_header();
		GPUMP1006ServiceInVo invo=(GPUMP1006ServiceInVo) reqMsg.getTx_body().getEntity();
		TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		 if(invo.getCust_id()==null)
		 {
			 LOGGER.error("checkPara ---- Cust_id can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID);
			 flag= false;
		 }else if(Com2.getGroupName()==null)
		 {
			 LOGGER.error("checkPara ---- GroupName can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
			 flag= false;
		 }else if(Com2.getSysChannelID()==null)
		 {
			 LOGGER.error("checkPara ---- SysChannelID can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
			 flag= false;
		 }
		rspMsg.setTx_header(rspHeader);
		return flag;
	}

	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws Exception {
		LOGGER.debug("---------调用GPUMP1006_Bean服务---------");
		LOGGER.debug("reqMsg: "+reqMsg.toString());
		
		if(!checkPara(rspMsg,reqMsg))
		{
			TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1006", null);
			return rspMsg;
		}
		//设置服务交易参数
		ServiceInVoParam1006 param=new ServiceInVoParam1006();
		setparam(param, logtime, reqMsg);
		//获取逻辑库
		genLogicFaceModel(param);
		
		//获取数据库的特征值map，key为GPU类型value为特征值
		getfeaturemap(param);
		//快速库处理
		fastDbHandle(param,traceLog);
		
		//redis数据处理
		redisConduct(param);
		
		GPUMP1006ServiceOutVo outvo=new GPUMP1006ServiceOutVo();
		TxResponseMsgBody MsgBody=new TxResponseMsgBody();
		MsgBody.setEntity(outvo);
		rspMsg.setTx_body(MsgBody);
		TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1006", GpumpErrorInfoModel.NOERROR);
		LOGGER.debug("GPUMP1006_Bean end!");
		return rspMsg;
	}
	/**
	 * 设置服务流程参数方法
	 * @param param 流程数据类
	 * @param logtime 各环节耗时缓存
	 * @param reqMsg 请求数据
	 */
	void setparam(ServiceInVoParam1006 param,HashMap<String, Long> logtime,TxRequestMsg reqMsg)
	{
		logtime.put("insertTime", (long) 0);
		logtime.put("updateTime", (long) 0);
		logtime.put("selectTime", (long) 0);
		logtime.put("registerForGpuTime", (long) 0);
		logtime.put("deleteForGpuTime", (long) 0);
		GPUMP1006ServiceInVo invo=(GPUMP1006ServiceInVo)reqMsg.getTx_body().getEntity();
		TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		TxRequestMsgHead reqMsgHead=reqMsg.getTx_header();
		String traceid=reqMsgHead.getSys_evt_trace_id();
		String GroupName=Com2.getGroupName();
		String sysChannelID=Com2.getSysChannelID();
		List<String> redisTask_list=new ArrayList<String>();
		param.setRedisTask_list(redisTask_list);
		param.setSysChannelID(sysChannelID);
		param.setGroupName(GroupName);
		param.setCust_id(invo.getCust_id());
		param.setLogtime(logtime);
		param.setTraceid(traceid);
	}
	/**
	 * redis数据处理
	 * @param paramMap
	 */
	public void redisConduct(ServiceInVoParam1006 paramMap)
	{
		List<String> redisTask_list = paramMap.getRedisTask_list();
		if(redisTask_list!=null&&redisTask_list.size()>0)
		{
			for(String task:redisTask_list)
			{
				String arg[]=task.split("\\|\\|");
				if(arg.length>=3)
				{
					String type=arg[0];
					String key=arg[1];
					String data=arg[2];
					RockerMqService.sendRedisOrMq(key, data, type);
				}else
				{
					LOGGER.warn("this task no 3 param, data is : "+task);
				}
			}
		}else
		{
			LOGGER.debug("redisTask_list is null");
		}
	}
	/**
	 * 快速库处理
	 * @param param
	 * @param traceLog
	 */
	public void fastDbHandle(ServiceInVoParam1006 param,TraceLog traceLog)
	{
		GpumpLogicFacedbModel gpumpLogicFacedbModel_fast = param.getGpumpLogicFacedbModel_fast();
		HashMap<String, String> featuremap = param.getFeaturemap();
		//快速库处理
		String feature_id=null;
		List<GpumpRealFacedbModel> gpumpRealFacedbModellist_fast=gpumpLogicFacedbModel_fast.getGpumpRealFacedbModelList();
		if(gpumpRealFacedbModellist_fast==null||gpumpRealFacedbModellist_fast.size()==0)
		{
			LOGGER.error("gpumpRealFacedb database or pagbase is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.REALFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR));
		}
		//循环所有物理库
		for(GpumpRealFacedbModel gpumpRealFacedbModel_fast:gpumpRealFacedbModellist_fast)
		{
			String GPU_FACE_DB=gpumpRealFacedbModel_fast.getGpu_face_db();
			String REAL_DB_ID_fast=gpumpRealFacedbModel_fast.getReal_db_id();
			LOGGER.debug("GPU_FACE_DB is "+GPU_FACE_DB);
			GpumpGpuInfoModel gpumpGpuInfoModel=gpumpRealFacedbModel_fast.getGpumpGpuInfo();
			if(gpumpGpuInfoModel==null)
			{
				LOGGER.warn("gpumpGpuInfoModel is null,real_db_id is : "+gpumpRealFacedbModel_fast.getReal_db_id());
				continue;
			}
			String gpu_type_id=gpumpGpuInfoModel.getGpu_type_id();
			String gpuclassname="com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gpu_type_id + "_Bean";
			//GpuInterface gpuBean=GpuMeth.getBeanClass(gpuclassname);
			GpuInterface gpuBean=(GpuInterface) Utils.getInstance(gpuclassname);
			if(gpuBean==null)
			{
				LOGGER.error("GPUMP "+gpu_type_id+" service is no exist!");
				continue;
			}
			String feature=featuremap.get(gpu_type_id);
			
			param.setGpumpGpuInfoModel(gpumpGpuInfoModel);
			param.setGpuBean(gpuBean);
			param.setFeature(feature);
			param.setFeature_id(feature_id);
			param.setGpu_face_db(GPU_FACE_DB);
			//注册特征值到gpu,特征值为空，跳过
			feature_id=registerForGpu(param,traceLog);
			if(feature_id!=null)
			{
				//插入或更新特征值客户信息对照表,如果存在记录先到GPU删除数据再更新数据库
				param.setReal_db_id_fast(REAL_DB_ID_fast);
				insertFidcustMapAndDeleteforGpu(param,traceLog);
			}
		}
	}
	/**
	 * 获取逻辑库实例方法，设置到流程数据实例内
	 * @param param  交易流程参数类
	 */
	public void genLogicFaceModel(ServiceInVoParam1006 param)
	{
		String sysChannelID = param.getSysChannelID();
		String GroupName = param.getGroupName();
		String cust_id = param.getCust_id();
		GpumpLogicFacedbModel gpumpLogicFacedbModel_fast=ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID+":"+GroupName);
		
		if(gpumpLogicFacedbModel_fast==null)
		{
			LOGGER.error("GpumpLogicFacedb is not exist!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
		}else if(!"2".equals(gpumpLogicFacedbModel_fast.getType()))
		{
			LOGGER.error("Logic_db_id : "+gpumpLogicFacedbModel_fast.getLogic_db_id()+" is not fast base!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
		}
		String LOGIC_DB_ID_fast=gpumpLogicFacedbModel_fast.getLogic_db_id();
		LOGGER.debug(" fast base LOGIC_DB_ID is "+LOGIC_DB_ID_fast);
		
		String SOURCE_DB_ID=gpumpLogicFacedbModel_fast.getSource_db_id();
		LOGGER.debug("find register base SOURCE_DB_ID is "+SOURCE_DB_ID);
		GpumpLogicFacedbModel gpumpLogicFacedbModel_register=ServiceParaUtil.getAllGpuDBMsgByID(SOURCE_DB_ID);//注册库
		if(gpumpLogicFacedbModel_register==null)
		{
			LOGGER.error("register base is not exist,for fast base id is "+LOGIC_DB_ID_fast);
			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
		}
		GpumpCustInfoModel gpumpCustInfoModel = GpumpCustInfoService.select(SOURCE_DB_ID, cust_id);
		if(gpumpCustInfoModel==null)
		{
			LOGGER.error(" gpumpCustInfoModel is null,LOGIC_DB_ID: "+SOURCE_DB_ID+", cust_id is : "+cust_id);
			throw new CommonRuntimeException(GpumpErrorInfoModel.NODATA,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.NODATA));
		}
		param.setGpumpLogicFacedbModel_fast(gpumpLogicFacedbModel_fast);
		param.setGpumpLogicFacedbModel_register(gpumpLogicFacedbModel_register);
		param.setGpumpCustInfoModel(gpumpCustInfoModel);
	}
	/**
	 * 插入或更新特征值客户信息对照表,如果存在记录先到GPU删除数据再更新数据库，同时记录redis删除和更新任务
	 * @param param			交易流程参数
	 * @param traceLog		报文日志缓存类
	 * @return
	 */
	public String insertFidcustMapAndDeleteforGpu(ServiceInVoParam1006 param,TraceLog traceLog)
	{
		String real_db_id_fast = param.getReal_db_id_fast();
		LOGGER.error("real_db_id_fast"+real_db_id_fast);
		String cust_id = param.getCust_id();
		HashMap<String, Long> logtime = param.getLogtime();
		String feature_id = param.getFeature_id();
		String traceid = param.getTraceid();
		String gpu_face_db = param.getGpu_face_db();
		GpuInterface gpuBean = param.getGpuBean();
		GpumpGpuInfoModel gpumpGpuInfoModel = param.getGpumpGpuInfoModel();
		//插入客户特征值对照表
		GpumpFidcustMapModel gpumpFidcustMapModel=redisService.selectFidcustMapModel(real_db_id_fast,cust_id);

		if(gpumpFidcustMapModel==null)
		{
			LOGGER.debug("Cust_id: "+cust_id+" is not exist for GpumpFidcustMap,must be insert it!");
			gpumpFidcustMapModel=new GpumpFidcustMapModel();
			gpumpFidcustMapModel.setCust_id(cust_id);
			gpumpFidcustMapModel.setReal_db_id(real_db_id_fast);
			gpumpFidcustMapModel.setCreate_time(new Date());
			gpumpFidcustMapModel.setModify_time(new Date());
			gpumpFidcustMapModel.setFeature_id(feature_id);
			long start = System.currentTimeMillis();
			int ret=GpumpFidcustMapService.insert(gpumpFidcustMapModel);
			long end = System.currentTimeMillis();
			//insertTime=insertTime+end-start;
			logtime.put("insertTime", logtime.get("insertTime")+end-start);
			if(ret!=1)
			{
				LOGGER.error("gpumpFidcustMap database error! Cust_id is "+cust_id);
				throw new CommonRuntimeException(GpumpErrorInfoModel.DATABASEERROR_INSERT,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.DATABASEERROR_INSERT));
			}else
			{
				JSONObject json = (JSONObject)JSONObject.toJSON(gpumpFidcustMapModel);
				List<String> redisTask_list = param.getRedisTask_list();
				redisTask_list.add("setRedis||"+feature_id+"_"+real_db_id_fast+"||"+cust_id);
				redisTask_list.add("setRedis||"+cust_id+"_"+real_db_id_fast+"||"+json.toString());
				param.setRedisTask_list(redisTask_list);
			}
		}else
		{
	
			List<String> redisTask_list = param.getRedisTask_list();
			String feature_id_old=gpumpFidcustMapModel.getFeature_id();
			LOGGER.error("feature_old is :" + feature_id_old);
			if(feature_id!=null)
			{
				LOGGER.warn("Cust_id: "+cust_id+" is exist for FidcustMap, Real_db_id is "+gpumpFidcustMapModel.getReal_db_id());
				DeleteFeatureRequest groupdeleteinvo=new DeleteFeatureRequest();
				groupdeleteinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
				groupdeleteinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
				groupdeleteinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
				groupdeleteinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
				groupdeleteinvo.setTraceid(traceid);
				groupdeleteinvo.setGroupname(gpu_face_db);
				groupdeleteinvo.setFeatureid(feature_id_old);
				LOGGER.warn("begin to delete feature_id for gpu,feature_id is "+feature_id);
				long start = System.currentTimeMillis();
				DeleteFeatureResponse deletefeatureresponse= gpuBean.deleteFeature(groupdeleteinvo,traceLog);
				long end = System.currentTimeMillis();
				//deleteForGpuTime=deleteForGpuTime+end-start;
				logtime.put("deleteForGpuTime", logtime.get("deleteForGpuTime")+end-start);
				traceLog.setDeleteFeatureTime(traceLog.getDeleteFeatureTime()+end-start);
				//LOGGER.debug(deletefeatureresponse.toString());
				if(!deletefeatureresponse.getResult()&&deletefeatureresponse.getError().equals(GpumpErrorInfoModel.GPURESULTERROR_FEATURE_ID_NO_EXIST))
				{
					LOGGER.warn("gpu user delete_fast error! feature_id is "+feature_id+" is not exist!");
				}else if(!deletefeatureresponse.getResult())
				{
					LOGGER.error("delete_fast user error,message is "+deletefeatureresponse.getError()+" : "+GpumpErrorInfoParaUtil.getErrorMsg(deletefeatureresponse.getError()));
					throw new CommonRuntimeException(deletefeatureresponse.getError(),GpumpErrorInfoParaUtil.getErrorMsg(deletefeatureresponse.getError()));
				}
				redisTask_list.add("delRedis||"+feature_id_old+"_"+real_db_id_fast+"||null");
				LOGGER.debug("delete for gpu funish,feature_id is "+feature_id);
			}

			LOGGER.debug("Cust_id: "+cust_id+"  is exist for GpumpFidcustMap,must be update it!");
			gpumpFidcustMapModel.setModify_time(new Date());
			gpumpFidcustMapModel.setFeature_id(feature_id);
			long start = System.currentTimeMillis();
			int ret=GpumpFidcustMapService.update(gpumpFidcustMapModel);
			long end = System.currentTimeMillis();
			//updateTime=updateTime+end-start;
			logtime.put("updateTime", logtime.get("updateTime")+end-start);
			if(ret!=1)
			{
				LOGGER.error(" update GpumpFidcustMap error!");
				throw new CommonRuntimeException(GpumpErrorInfoModel.DATABASEERROR_UPDATE,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.DATABASEERROR_UPDATE));
			}else
			{
				JSONObject json = (JSONObject)JSONObject.toJSON(gpumpFidcustMapModel);
				redisTask_list.add("setRedis||"+feature_id+"_"+real_db_id_fast+"||"+cust_id);
				redisTask_list.add("setRedis||"+cust_id+"_"+real_db_id_fast+"||"+json.toString());
				param.setRedisTask_list(redisTask_list);
			}
			LOGGER.debug("Cust_id: "+cust_id+" update funish for GpumpFidcustMap.");
		}
		return feature_id;
	}
	/**
	 * 注册特征值到gpu,特征值为空，跳过
	 * @param param			交易流程参数类
	 * @param traceLog		报文日志缓存类
	 * @return
	 */
	public String registerForGpu(ServiceInVoParam1006 param,TraceLog traceLog)
	{
		GpumpGpuInfoModel gpumpGpuInfoModel = param.getGpumpGpuInfoModel();
		String feature = param.getFeature();
		String feature_id = param.getFeature_id();
		HashMap<String, Long> logtime = param.getLogtime();
		String gpu_face_db = param.getGpu_face_db();
		String traceid = param.getTraceid();
		GpuInterface gpuBean = param.getGpuBean();
		GpumpLogicFacedbModel gpumpLogicFacedbModel_fast = param.getGpumpLogicFacedbModel_fast();
		String logic_db_id_fast = gpumpLogicFacedbModel_fast.getLogic_db_id();
		LOGGER.debug("begin to register for gpu.");
		String gpu_type_id=gpumpGpuInfoModel.getGpu_type_id();
		if(feature==null)
		{
			LOGGER.error("gpu_type_id "+gpu_type_id+" have no feature for GpumpFeature!");
			return null;
			//TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1006", Errorcode.GPUTYPEERROR, "gpu_type_id "+gpu_type_id+" have no feature for GpumpFeature!");
		}else
		{
			if(feature_id==null)
			{
				long start = System.currentTimeMillis();
				SimpleDateFormat sdf= new SimpleDateFormat("yyyyMMdd");
				String date= sdf.format(new Date());
				feature_id=date+sequenceService.select("SEQ_"+logic_db_id_fast)+"";
				long end = System.currentTimeMillis();
				//selectTime=selectTime+end-start;
				logtime.put("selectTime", logtime.get("selectTime")+end-start);
				LOGGER.debug("create nextval feature_id is "+feature_id);
			}
			AddFeatureRequest invo=new AddFeatureRequest();
			invo.setIp(gpumpGpuInfoModel.getGpu_ip());
			invo.setPort1(gpumpGpuInfoModel.getGpu_port1());
			invo.setPort2(gpumpGpuInfoModel.getGpu_port2());
			invo.setPort3(gpumpGpuInfoModel.getGpu_port3());
			invo.setGroupname(gpu_face_db);
			invo.setFeatureid(feature_id);
			invo.setFeature(feature);
			invo.setTraceid(traceid);
			long start = System.currentTimeMillis();
			AddFeatureResponse gpuoutvo=gpuBean.addFeature(invo,traceLog);
			long end = System.currentTimeMillis();
			//registerForGpuTime=registerForGpuTime+end-start;
			logtime.put("registerForGpuTime", logtime.get("registerForGpuTime")+end-start);
			traceLog.setAddFeatureTime(traceLog.getAddFeatureTime()+end-start);
			if(!gpuoutvo.getResult())
			{
				LOGGER.debug(gpuoutvo.toString());
				LOGGER.error("addFeature user error for fast base,GPU_FACE_DB is "+gpu_face_db+" ,feature_id is "+feature_id+" ,ErrorMessage "+gpuoutvo.getError()+" : "+GpumpErrorInfoParaUtil.getErrorMsg(gpuoutvo.getError()));
				throw new CommonRuntimeException(gpuoutvo.getError(),GpumpErrorInfoParaUtil.getErrorMsg(gpuoutvo.getError()));
			}
			//把特征值id更新，
			feature_id=gpuoutvo.getFeatureid();
			param.setFeature_id(feature_id);
		}
		LOGGER.debug("end to register for gpu.");
		return feature_id;
	}
	/**
	 * 获取数据库的特征值map，key为GPU类型value为特征值
	 * @param param
	 */
	public void getfeaturemap(ServiceInVoParam1006 param)
	{
		GpumpLogicFacedbModel gpumpLogicFacedbModel_register = param.getGpumpLogicFacedbModel_register();
		HashMap<String, Long> logtime = param.getLogtime();
		String cust_id = param.getCust_id();
		String gpu_type_id=null;
		HashMap<String, String> featuremap=new HashMap<>();
		
		String Is_mount_pag = gpumpLogicFacedbModel_register.getIs_mount_pag();
		if("T".equals(Is_mount_pag)){
			//查找出该客户挂载的页位库
			GpumpCustInfoModel gpumpCustInfoModel= param.getGpumpCustInfoModel();
			String real_groud_id = gpumpCustInfoModel.getReal_group_id();
			gpumpLogicFacedbModel_register=ServiceParaUtil.getAllGpuDBMsgByID(real_groud_id);//注册库下的页位库
			if(gpumpLogicFacedbModel_register==null){
				LOGGER.error("GpumpLogicFacedb is not exist!");
				throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
			}
		}
		String Is_mount_gpu=gpumpLogicFacedbModel_register.getIs_mount_gpu();
		String LOGIC_DB_ID_register=gpumpLogicFacedbModel_register.getLogic_db_id();//注册库分组标识
		LOGGER.debug(" register base or reister page db LOGIC_DB_ID is "+LOGIC_DB_ID_register);
		if("T".equals(Is_mount_gpu))//母库挂或页位库载了GPU，通过物理库获取GPU类型，查询出所有的特征值对应GPU的map
		{
			List<GpumpRealFacedbModel> gpumpRealFacedbModellist_register=gpumpLogicFacedbModel_register.getGpumpRealFacedbModelList();
			if(gpumpRealFacedbModellist_register==null)
			{
				LOGGER.error("gpumpRealFacedb is null,for fast LOGIC_DB_ID is "+LOGIC_DB_ID_register);
				throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
			}
			for(GpumpRealFacedbModel gpumpRealFacedbModel_register:gpumpRealFacedbModellist_register)
			{
				GpumpGpuInfoModel gpumpGpuInfoModel=gpumpRealFacedbModel_register.getGpumpGpuInfo();
				gpu_type_id=gpumpGpuInfoModel.getGpu_type_id();
				//String GPU_NAME=gpumpGpuInfoModel.getGpu_name();
				LOGGER.debug("register base or page base gpu_type_id is "+gpu_type_id);
				long start = System.currentTimeMillis();
				GpumpFeatureModel gpumpFeatureModel=redisService.selectFeatureModel(LOGIC_DB_ID_register, gpu_type_id, cust_id);
				long end = System.currentTimeMillis();
				//selectTime=selectTime+end-start;
				logtime.put("selectTime", logtime.get("selectTime")+end-start);
				if(gpumpFeatureModel==null)
				{
					LOGGER.error("cust_id "+cust_id+" is no exist,");
				}else
				{
					if(gpumpFeatureModel.getFeature()!=null)
					{
						featuremap.put(gpu_type_id, gpumpFeatureModel.getFeature());
					}else
					{
						LOGGER.error("feature is null for gpu_type_id : "+gpu_type_id);
					}
				}
			}
		}else
		{//母库或者分页库没有挂载GPU，通过获取所有GPU类型，查询出所有的特征值对应GPU的map
			List<String> allGpuTypelist = ServiceParaUtil.getAllGpuType();
			if(allGpuTypelist==null||allGpuTypelist.size()==0)
			{
				LOGGER.error("can not find gpu type list!");
				throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
			}
			for(String gputype:allGpuTypelist)
			{
				LOGGER.debug("register base gpu_type_id is "+gputype);
				long start = System.currentTimeMillis();
				GpumpFeatureModel gpumpFeatureModel=redisService.selectFeatureModel(LOGIC_DB_ID_register, gputype, cust_id);
				long end = System.currentTimeMillis();
				//selectTime=selectTime+end-start;
				logtime.put("selectTime", logtime.get("selectTime")+end-start);
				if(gpumpFeatureModel==null)
				{
					LOGGER.error("cust_id "+cust_id+" is no exist,");
				}else
				{
					if(gpumpFeatureModel.getFeature()!=null)
					{
						featuremap.put(gputype, gpumpFeatureModel.getFeature());
					}else
					{
						LOGGER.error("feature is null for gpu_type_id : "+gpu_type_id);
					}
				}
			}
		}
		if(featuremap.size()==0)
		{
			LOGGER.error("featuremap is null,cust_id "+cust_id);
			throw new CommonRuntimeException(GpumpErrorInfoModel.NODATA,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.NODATA));
		}
		param.setFeaturemap(featuremap);
	}

	@Override
	public Object transform(JSONObject indata) throws Exception {
		JSONObject tx_body=indata.getJSONObject("tx_body");
		if(tx_body==null)
		{
			LOGGER.error("tx_body is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject entity=tx_body.getJSONObject("entity");
		if(entity==null)
		{
			LOGGER.error("entity is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject com2=tx_body.getJSONObject("com2");
		if(com2==null)
		{
			LOGGER.error("com2 is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		TxRequestMsg reqMsg=(TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
		GPUMP1006ServiceInVo invo=(GPUMP1006ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1006ServiceInVo.class);;
		TxRequestMsgCom2 com=JSON.parseObject(JSON.toJSONString(com2),TxRequestMsgCom2.class);
		TxRequestMsgBody MsgBody=reqMsg.getTx_body();
		MsgBody.setEntity(invo);
		MsgBody.setCom2(com);
		reqMsg.setTx_body(MsgBody);
		return reqMsg;
	}
	

	@Override
	public List<GpuRegisterTask> getGpuTask(){
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public String getTime() {
//		StringBuffer cmmpLog = new StringBuffer();
//		cmmpLog.append("insertTime<").append(insertTime).append("> ");
//		cmmpLog.append("updateTime<").append(updateTime).append("> ");
//		cmmpLog.append("selectTime<").append(selectTime).append("> ");
//		cmmpLog.append("registerForGpuTime<").append(registerForGpuTime).append("> ");
//		cmmpLog.append("deleteForGpuTime<").append(deleteForGpuTime).append("> ");
//		return cmmpLog.toString();
//	}
}
