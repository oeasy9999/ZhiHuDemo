package com.ccb.suap.cloud.facegpups.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.facegpups.model.GpumpChannelInfoModel;

@Mapper
@Component
public interface GpumpChannelInfoMapper {
	
	List<GpumpChannelInfoModel> selectAll();
}
