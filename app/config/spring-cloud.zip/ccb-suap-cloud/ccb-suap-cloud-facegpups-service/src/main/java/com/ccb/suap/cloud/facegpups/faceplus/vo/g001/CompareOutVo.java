package com.ccb.suap.cloud.facegpups.faceplus.vo.g001;

public class CompareOutVo {

	private String time_used;
	private String reqid;
	private String confidence;
	private String error;
	public String getTime_used() {
		return time_used;
	}
	public void setTime_used(String timeUsed) {
		time_used = timeUsed;
	}
	public String getReqid() {
		return reqid;
	}
	public void setReqid(String reqid) {
		this.reqid = reqid;
	}
	public String getConfidence() {
		return confidence;
	}
	public void setConfidence(String confidence) {
		this.confidence = confidence;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
}
