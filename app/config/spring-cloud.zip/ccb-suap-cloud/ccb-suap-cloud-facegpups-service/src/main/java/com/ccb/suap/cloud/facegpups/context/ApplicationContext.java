package com.ccb.suap.cloud.facegpups.context;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 应用系统全局内存缓存
 */
public  class ApplicationContext extends Context{
	
	private static final long serialVersionUID = 1L;
	
	private static ApplicationContext AppContext = null;
	
	private    List<SessionContext>  sessionList;
	
	public ApplicationContext()
	{
		sessionList = new CopyOnWriteArrayList<SessionContext>();
	}
	
	public static ApplicationContext getAppContext()
	{
		
		if (AppContext == null)
			AppContext = new ApplicationContext();
		
		return AppContext;
	}
	
	/**
	 * 判断是否已经缓存当前健值对象
	 * @param key 缓存健值
	 * @return 已缓存为true,未缓存为false
	 * @throws Exception
	 */
	public static boolean appContainsKey (String key)
	{
		return getAppContext().containsKey(key.toLowerCase());
	}
	
	/**
	 * 装载缓存对象
	 * @param key 缓存健值
	 * @param entry 缓存对象	 
	 * @throws Exception 
	 */
	public static void appPut (String key,Object entry)
	{
		getAppContext().put(key.toLowerCase(),entry);
	}
	
	/**
	 * 获取缓存对象
	 * @param key 缓存健值
	 * @return 缓存对象或null
	 */
	public static Object appGet(String key)
	{
		if (appContainsKey(key))
		{
			return getAppContext().get(key.toLowerCase());
		}else
			return null;
	}
	
	/**
	 * 根据缓存健值清除缓存对象
	 * @param key 缓存健值
	 */
	public static void  appRemove(String key)
	{
		
		if (appContainsKey(key))
		{
			getAppContext().remove(key.toLowerCase());
		}
	}
	
	/**
	 * 添加Session级缓存
	 * @param sessionContext
	 */
	public void addSessionContext(SessionContext sessionContext)
	{
		removeSession(sessionContext.getID());
		
		sessionList.add(sessionContext);
	}
	
	/**
	 * 获取Session级缓存数量
	 * @return
	 */
	public int getSessionSize()
	{
		return sessionList.size();
	}
	public  List<SessionContext> getSessionList()
	{
		return sessionList;
	}
	/**
	 * 获取某个Session级缓存
	 * @param sessionID
	 * @return
	 */
	public SessionContext getSession(String sessionID)
	{
		SessionContext fContext = null;
		
		for(int i=0; i<sessionList.size();i++)
		{
			if (sessionList.get(i).getID().equals(sessionID))
			{
				fContext = sessionList.get(i);
				break;
			}
		}		
		return fContext;
	}
	/**
	 * 获取某个Session级缓存
	 * @param sessionID
	 * @return
	 */
	public SessionContext getSession(int inedex)
	{
		SessionContext fContext = null;
		if (inedex >-1 && inedex < sessionList.size())
			fContext = sessionList.get(inedex);
		return fContext;
	}
	
	/**
	 * 移除某个Session级缓存
	 * @param sessionID
	 */
	public void removeSession(String sessionID)
	{
		for(int i=sessionList.size()-1; i>-1;i--)
		{
			if (sessionList.get(i).getID().equals(sessionID))
			{
				sessionList.get(i).clear(0);
			}
		}
	}
	
	public void free()
	{
		for(int i=0; i<sessionList.size();i++)
		{
			sessionList.get(i).clear(0);
		}
		sessionList.clear();
		this.clear(0);
	}
	
}