package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

public class GroupListVo {

	private String dbName;
	private String count;
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "GroupGetSizeVo [dbName=" + dbName + ", count=" + count + "]";
	}
	
}
