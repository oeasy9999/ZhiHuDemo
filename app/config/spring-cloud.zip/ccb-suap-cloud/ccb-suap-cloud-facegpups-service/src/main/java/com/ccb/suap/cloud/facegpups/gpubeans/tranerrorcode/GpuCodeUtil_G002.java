package com.ccb.suap.cloud.facegpups.gpubeans.tranerrorcode;

import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;

public class GpuCodeUtil_G002 {

	public static String tranCode(String errorcode)
	{
		String result;
		if(errorcode.contains("INVALID_ARGUMENTS"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_ARGUMENT_ERROR;
		}else if(errorcode.contains("DB_NOT_EXISTS"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_GROUP_NOT_EXIST;
		}else if(errorcode.contains("WITHOUT_FILE"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_FILENULL;
		}else if(errorcode.contains("WEB_SERVER_ERROR"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_WEB;
		}else if(errorcode.contains("DATABASE_ERROR"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_DB;
		}else if(errorcode.contains("VERIFY_SERVER_ERROR"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_VERIFY;
		}else if(errorcode.contains("VERIFY_SERVER_CONNECTION_REFUSE"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_VERIFY_CONNECTION;
		}else if(errorcode.contains("IMG_NOT_FOUND"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_IMG_NOT_FOUND;
		}else if(errorcode.contains("CONVERT_FROM_BIN_FAILED"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_CONVERT_FROM_BIN_FAILED;
		}else if(errorcode.contains("TOO_SMALL_IMAGE_WIDTH_AND_HEIGHT"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_TOO_SMALL;
		}else if(errorcode.contains("ALL_FACE_UNDER_QUALITY_STANDARD"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_FACE_UNDER;
		}else if(errorcode.contains("INVALID_FACE_RECT"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_FACE_RECT;
		}else if(errorcode.contains("NO_FACE_DETECTED"))
		{
			result=GpumpErrorInfoModel.GPUDETECTERROR_FACESNULL;
		}else if(errorcode.contains("DETECT_FAILED"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_DETECT_FAILED;
		}else if(errorcode.contains("ALIGNMENT_FAILED"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_DETECT_FAILED;
		}else if(errorcode.contains("EXTRACT_FAILED"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_DETECT_FAILED;
		}else if(errorcode.contains("ATTR_DETECT_FAILED"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_DETECT_FAILED;
		}else if(errorcode.contains("COMPARE_FEATURE_FAILED"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_DETECT_FAILED;
		}else if(errorcode.contains("UUID_NOT_FOUND"))
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_FEATURE_ID_NO_EXIST;
		}else
		{
			result=GpumpErrorInfoModel.GPURESULTERROR_INTERNAL;
		}
		return result;
	}
}
