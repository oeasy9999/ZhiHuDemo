package com.ccb.suap.cloud.facegpups.faceplus.vo;


public class CompareFeatureRequest {

	private String ip;
	private String port1;
	private String port2;
	private String port3;
	private String traceid;
	private String feature1;
	private String feature2;
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getPort1() {
		return port1;
	}
	public void setPort1(String port1) {
		this.port1 = port1;
	}
	public String getPort2() {
		return port2;
	}
	public void setPort2(String port2) {
		this.port2 = port2;
	}
	public String getPort3() {
		return port3;
	}
	public void setPort3(String port3) {
		this.port3 = port3;
	}
	public String getTraceid() {
		return traceid;
	}
	public void setTraceid(String traceid) {
		this.traceid = traceid;
	}
	public String getFeature1() {
		return feature1;
	}
	public void setFeature1(String feature1) {
		this.feature1 = feature1;
	}
	public String getFeature2() {
		return feature2;
	}
	public void setFeature2(String feature2) {
		this.feature2 = feature2;
	}
	@Override
	public String toString() {
		return "CompareFeatureRequest [ip=" + ip + ", port1=" + port1 + ", port2=" + port2 + ", port3=" + port3
				+ ", traceid=" + traceid + ", feature1=" + feature1 + ", feature2=" + feature2 + "]";
	}
	

}
