package com.ccb.suap.cloud.facegpups.context;
import java.util.Vector;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.ccb.suap.cloud.facegpups.controller.FacegpupsController;
import com.ccb.suap.cloud.facegpups.resource.httpresource.HttpCommPoolService;
import com.ccb.suap.cloud.facegpups.resource.httpresource.HttpCommService;
import com.ccb.suap.cloud.facegpups.resource.httpresource.HttpResouceGroup;
import com.ccb.suap.util.log.LogUtil;
import com.ccb.suap.util.string.StringUtils;
import com.ccb.suap.util.xml.XmlReadView;
import com.ccb.suap.util.xml.XmlReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.ResourceUtils;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ccb.suap.cloud.facegpups.dao.factory.DaoManagerService;

import java.io.File;

public class mylistener implements ServletContextListener{

	private static final Logger LOGGER = LoggerFactory.getLogger(FacegpupsController.class);
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		System.out.println("-------------mylistener.contextInitialized--------------------");
		DaoManagerService daoManager = (DaoManagerService) WebApplicationContextUtils.getWebApplicationContext(sce.getServletContext()).getBean("daoManager");
    	
    	ApplicationContext.appPut("daoManager", daoManager);

		initHttpCommPool();
	}

	private void initHttpCommPool() {
		System.out.println("-------------begin initHttpCommPool...");
		HttpCommPoolService httpCommPool = HttpCommPoolService.HTTPCommPool;
		if (httpCommPool == null) {
			System.out.println("get HTTPCommPool is null, new HttpCommPoolService!");
			httpCommPool = new HttpCommPoolService();
		}
//		XmlReader xmlReader = null;
		try {
			System.out.println("*******************http资源分组设置*******************");
			System.out.println("***********系统自动从配置文件serviceapp.xml获取***********");
			String fileDir= new File(ResourceUtils.getURL("classpath:").getPath()).getParentFile().getParentFile().getParent();
			fileDir=fileDir.substring(5);
			if(!new File(fileDir + "/serviceapp.xml").exists()){
				fileDir=new ClassPathResource("").getFile().getAbsolutePath();
			}
			System.out.println("*******************路径*******************"+fileDir);
			XmlReader xmlReader = new XmlReader(fileDir + "/serviceapp.xml");
			XmlReadView httpCommPoolNode = xmlReader.getReadView("HttpCommPool");
			while (httpCommPoolNode.next()) {
				XmlReadView httpResouceGroupNode = httpCommPoolNode.getReadView("HttpResouceGroup");
				while (httpResouceGroupNode.next()) {
					String id = httpResouceGroupNode.getAttrValue("id");
					String reqMethod = httpResouceGroupNode.getAttrValue("reqMethod");
					String connectTimeout = httpResouceGroupNode.getAttrValue("connectTimeout");
					String soTimeout = httpResouceGroupNode.getAttrValue("soTimeout");
					String size = httpResouceGroupNode.getAttrValue("size");
					String heartInteval = httpResouceGroupNode.getAttrValue("heartInteval");
					String balance = httpResouceGroupNode.getAttrValue("balance");
					String useProxyAuthor = httpResouceGroupNode.getAttrValue("useProxyAuthor");
					String reqProxyIP = httpResouceGroupNode.getAttrValue("reqProxyIP");
					String reqProxyPort = httpResouceGroupNode.getAttrValue("reqProxyPort");
					String proxyUserName = httpResouceGroupNode.getAttrValue("proxyUserName");
					String proxyUserPass = httpResouceGroupNode.getAttrValue("proxyUserPass");
					HttpResouceGroup group = new HttpResouceGroup();
					group.setGroupID(id);
					group.setReqMethod(reqMethod);
					group.setConnectTimeout(Integer.parseInt(connectTimeout));
					group.setSoTimeout(Integer.parseInt(soTimeout));
					group.setMAX_REQ(Integer.parseInt(size));
					group.setHeartInteval(Integer.parseInt(heartInteval));
					group.setBalance(Boolean.parseBoolean(balance));
					group.setUseProxyAuthor(useProxyAuthor);
					group.setReqProxyIP(reqProxyIP);
					if(StringUtils.isNotBlack(reqProxyPort)) {
						try {
							group.setReqProxyPort(Integer.parseInt(reqProxyPort));
						} catch(NumberFormatException e) {
							e.printStackTrace();
						}
					}
					group.setProxyUserName(proxyUserName);
					group.setProxyUserPass(proxyUserPass);
					String contentType = httpResouceGroupNode.getAttrValue("contentType");
					if(StringUtils.hasText(contentType)) {
						group.setContentType(contentType);
					}
					XmlReadView httpResourceNode = httpResouceGroupNode.getReadView("HttpResource");
					if (httpResourceNode.getElementCount() == 0) {
						throw new Exception("errcode=SE05;serviceapp.xml 文件中:" + id + " 通讯标示下没定义通讯信息！");
					}
					while (httpResourceNode.next()) {
						HttpCommService http = new HttpCommService();
						http.setHttpURL(httpResourceNode.getAttrValue("dest"));
						group.addHttpCommService(http);
						System.out.println(id + ":setHttpURL=" + http.getHttpURL());
					}
					httpCommPool.addResoureGroup(id, group);
				}
			}
			System.out.println("end initHttpCommPool...");
		} catch (Exception e) {
			System.out.println("*******************初始化Http连接池失败************************");
			System.out.println("*														 *");
			System.out.println(e.getMessage());
			System.out.println("*														 *");
			System.out.println("*******************初始化Http连接池失败************************");
			e.printStackTrace();
		}
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		
	}

}
