package com.ccb.suap.cloud.facegpups.faceplus.vo.g001;

import java.util.List;

public class GroupSearchOutVo implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1L;
	private String result;
	private List<String> ids;
	private List<String> scores;
	private List<String> tags;
	private List<String> exprs;
	private String error;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public List<String> getIds() {
		return ids;
	}
	public void setIds(List<String> ids) {
		this.ids = ids;
	}
	public List<String> getScores() {
		return scores;
	}
	public void setScores(List<String> scores) {
		this.scores = scores;
	}
	public List<String> getTags() {
		return tags;
	}
	public void setTags(List<String> tags) {
		this.tags = tags;
	}
	public List<String> getExprs() {
		return exprs;
	}
	public void setExprs(List<String> exprs) {
		this.exprs = exprs;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	@Override
	public String toString() {
		return "GroupSearchOutVo [result=" + result + ", ids=" + ids + ", scores=" + scores + ", tags=" + tags
				+ ", exprs=" + exprs + ", error=" + error + "]";
	}
	
}
