package com.ccb.suap.cloud.facegpups.faceplus.vo.g003;

public class GroupInitOutVo implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1L;
	private String result;
	private String errorMessage;
	private GroupInitVo data;
	
	public GroupInitVo getData() {
		return data;
	}
	public void setData(GroupInitVo data) {
		this.data = data;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String error) {
		this.errorMessage = error;
	}
	@Override
	public String toString() {
		return "GroupInitOutVo [result=" + result + ", error=" + errorMessage + "]";
	}
	
}
