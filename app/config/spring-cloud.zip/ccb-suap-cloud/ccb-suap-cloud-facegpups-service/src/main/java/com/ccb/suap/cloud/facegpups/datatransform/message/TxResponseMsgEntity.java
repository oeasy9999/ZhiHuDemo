package com.ccb.suap.cloud.facegpups.datatransform.message;

public abstract interface TxResponseMsgEntity {

}
