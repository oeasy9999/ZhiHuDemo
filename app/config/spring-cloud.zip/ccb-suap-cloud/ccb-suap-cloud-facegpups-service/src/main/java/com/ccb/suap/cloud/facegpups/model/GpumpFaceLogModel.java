package com.ccb.suap.cloud.facegpups.model;

import java.util.Date;

public class GpumpFaceLogModel {

	private String logid;
	private String channelid;
	private String channeltxcode;
	private String branchid;
	private String transflow;
	private Date recvtime;
	private Date resptime;
	private String txcode;
	private String transret;
	private String hostname;
	private String serverip;
	private String errorcode;
	private String vendorcode;
	private String vendorerrcode;
	private String errormsg;
	private String recvtimemillis;
	private String resptimemillis;
	private String costtimeinfo;
	private String num;
	private String photo_path;
	

	public String getLogid() {
		return logid;
	}
	public void setLogid(String logid) {
		this.logid = logid;
	}
	public String getChannelid() {
		return channelid;
	}
	public void setChannelid(String channelid) {
		this.channelid = channelid;
	}
	public String getChanneltxcode() {
		return channeltxcode;
	}
	public void setChanneltxcode(String channeltxcode) {
		this.channeltxcode = channeltxcode;
	}
	public String getBranchid() {
		return branchid;
	}
	public void setBranchid(String branchid) {
		this.branchid = branchid;
	}
	public String getTransflow() {
		return transflow;
	}
	public void setTransflow(String transflow) {
		this.transflow = transflow;
	}
	public Date getRecvtime() {
		return recvtime;
	}
	public void setRecvtime(Date recvtime) {
		this.recvtime = recvtime;
	}
	public Date getResptime() {
		return resptime;
	}
	public void setResptime(Date resptime) {
		this.resptime = resptime;
	}
	public String getTxcode() {
		return txcode;
	}
	public void setTxcode(String txcode) {
		this.txcode = txcode;
	}
	public String getTransret() {
		return transret;
	}
	public void setTransret(String transret) {
		this.transret = transret;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getServerip() {
		return serverip;
	}
	public void setServerip(String serverip) {
		this.serverip = serverip;
	}
	public String getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	public String getVendorcode() {
		return vendorcode;
	}
	public void setVendorcode(String vendorcode) {
		this.vendorcode = vendorcode;
	}
	public String getVendorerrcode() {
		return vendorerrcode;
	}
	public void setVendorerrcode(String vendorerrcode) {
		this.vendorerrcode = vendorerrcode;
	}
	public String getErrormsg() {
		return errormsg;
	}
	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}
	public String getRecvtimemillis() {
		return recvtimemillis;
	}
	public void setRecvtimemillis(String recvtimemillis) {
		this.recvtimemillis = recvtimemillis;
	}
	public String getResptimemillis() {
		return resptimemillis;
	}
	public void setResptimemillis(String resptimemillis) {
		this.resptimemillis = resptimemillis;
	}
	public String getCosttimeinfo() {
		return costtimeinfo;
	}
	public void setCosttimeinfo(String costtimeinfo) {
		this.costtimeinfo = costtimeinfo;
	}

  public String getNum() {
    return num;
  }

  public void setNum(String num) {
    this.num = num;
  }
  public String getPhoto_path() {
	return photo_path;
  }
  public void setPhoto_path(String photo_path) {
	this.photo_path = photo_path;
  }
@Override
	public String toString() {
		return "GpumpFaceLogModel [logid=" + logid + ", channelid=" + channelid + ", channeltxcode=" + channeltxcode
				+ ", branchid=" + branchid + ", transflow=" + transflow + ", recvtime=" + recvtime + ", resptime="
				+ resptime + ", txcode=" + txcode + ", transret=" + transret + ", hostname=" + hostname + ", serverip="
				+ serverip + ", errorcode=" + errorcode + ", vendorcode=" + vendorcode + ", vendorerrcode="
				+ vendorerrcode + ", errormsg=" + errormsg + ", recvtimemillis=" + recvtimemillis + ", resptimemillis="
				+ resptimemillis + ", costtimeinfo=" + costtimeinfo + ", num=" + num + "]";
	}
	
}
