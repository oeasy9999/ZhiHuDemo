package com.ccb.suap.cloud.facegpups.mapper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
//@Order(1)
//public class JmsConfig implements CommandLineRunner{
public class JmsConfig{
	 @Value("${apache.rocketmq.namesrvAddr}")
	 public  String NAME_SERVER;
	 @Value("${apache.rocketmq.producer.producerGroup}")
	 public  String producerGroup;
	 @Value("${apache.rocketmq.consumer.PushConsumer}")
	 public  String consumerGroup;
	 @Value("${apache.rocketmq.TOPIC_COMPLETE}")
	 public  String TOPIC_COMPLETE;
	 //public static String TOPIC_NO_COMPLETE;
	public String getNAME_SERVER() {
		return NAME_SERVER;
	}
	public void setNAME_SERVER(String nAME_SERVER) {
		NAME_SERVER = nAME_SERVER;
	}
	public String getProducerGroup() {
		return producerGroup;
	}
	public void setProducerGroup(String producerGroup) {
		this.producerGroup = producerGroup;
	}
	public String getConsumerGroup() {
		return consumerGroup;
	}
	public void setConsumerGroup(String consumerGroup) {
		this.consumerGroup = consumerGroup;
	}
	public String getTOPIC_COMPLETE() {
		return TOPIC_COMPLETE;
	}
	public void setTOPIC_COMPLETE(String tOPIC_COMPLETE) {
		TOPIC_COMPLETE = tOPIC_COMPLETE;
	}

//	@Value("${apache.rocketmq.namesrvAddr}")
//	public void setNAME_SERVER(String namesrvAddr) {
//		JmsConfig.NAME_SERVER = namesrvAddr;
//	}
//	@Value("${apache.rocketmq.producer.producerGroup}")
//	public void setProducerGroup(String producerGroup) {
//		JmsConfig.producerGroup = producerGroup;
//	}
//	@Value("${apache.rocketmq.consumer.PushConsumer}")
//	public void setConsumerGroup(String PushConsumer) {
//		JmsConfig.consumerGroup = PushConsumer;
//	}
//	@Value("${apache.rocketmq.TOPIC_COMPLETE}")
//	public void setTOPIC_COMPLETE(String TOPIC_COMPLETE) {
//		 JmsConfig.TOPIC_COMPLETE = TOPIC_COMPLETE;
//	}
//	@Value("${apache.rocketmq.TOPIC_COMPLETE}")
//	public void setTOPIC_NO_COMPLETE(String TOPIC_NO_COMPLETE) {
//		JmsConfig.TOPIC_NO_COMPLETE = TOPIC_NO_COMPLETE;
//	}
	
//	@Override
//	public void run(String... args) throws Exception {
//		System.out.println("producerGroup= "+producerGroup);
//		System.out.println("NAME_SERVER= "+NAME_SERVER);
//		System.out.println("***************init JmsConfig***************");
//		
//	}

	 
}
