package com.ccb.suap.cloud.facegpups.dao.factory;

import com.ccb.suap.cloud.facegpups.context.ApplicationContext;

public class GpumpDaoFactory {

	//静态工厂
//	public static final IFactoryDao getStaticFactoryDaoImpl() {
//		return new StaticFactoryDaoImpl();
//	}
	
	public static DaoManagerService getDaoManager() {

		return (DaoManagerService) ApplicationContext.getAppContext().get("daoManager");
		
	}
}
