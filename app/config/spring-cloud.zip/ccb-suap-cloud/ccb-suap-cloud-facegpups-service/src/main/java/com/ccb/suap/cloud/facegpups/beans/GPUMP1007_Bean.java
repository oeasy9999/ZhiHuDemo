package com.ccb.suap.cloud.facegpups.beans;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureResponse;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFidcustMapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;
import com.ccb.suap.cloud.facegpups.service.GpumpCustInfoService;
import com.ccb.suap.cloud.facegpups.service.GpumpFidcustMapService;
import com.ccb.suap.cloud.facegpups.service.RedisService;
import com.ccb.suap.cloud.facegpups.service.RockerMqService;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1007ServiceOutVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1007ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.ServiceInVoParam1007;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.log.TraceLog;

/*
 * 快速库出库
 * */
public class GPUMP1007_Bean extends GPUMPBean{
	private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");
	private GpumpFidcustMapService GpumpFidcustMapService=GpumpDaoFactory.getDaoManager().getGpumpFidcustMapService();
	private RedisService redisService=GpumpDaoFactory.getDaoManager().getRedisService();
	private RockerMqService RockerMqService=GpumpDaoFactory.getDaoManager().getRockerMqService();

	@Override
	public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		boolean flag=true;
		TxResponseMsgHead rspHeader =rspMsg.getTx_header();
		GPUMP1007ServiceInVo invo=(GPUMP1007ServiceInVo) reqMsg.getTx_body().getEntity();
		TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		 if(invo.getCust_id()==null)
		 {
			 LOGGER.error("checkPara ---- Cust_id can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID);
			 flag= false;
		 }else if(Com2.getGroupName()==null)
		 {
			 LOGGER.error("checkPara ---- GroupName can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
			 flag= false;
		 }else if(Com2.getSysChannelID()==null)
		 {
			 LOGGER.error("checkPara ---- SysChannelID can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
			 flag= false;
		 }
		rspMsg.setTx_header(rspHeader);
		return flag;
	}

	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws Exception {
		LOGGER.debug("---------调用GPUMP1007_Bean服务---------");
		//LOGGER.debug("reqMsg: "+reqMsg.toString());
		
		if(!checkPara(rspMsg,reqMsg))
		{
			TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1007", null);
			return rspMsg;
		}
		
		//设置交易流程参数
		ServiceInVoParam1007 paramMap=new ServiceInVoParam1007();
		setparam(paramMap, logtime, reqMsg);
		
		//获取逻辑库
		genLogicFaceModel(paramMap);
		
		//快速库出库处理
		fastDbHandle(paramMap,traceLog);
		
		//redis任务处理
		redisConduct(paramMap);
		
		GPUMP1007ServiceOutVo outvo=new GPUMP1007ServiceOutVo();
		TxResponseMsgBody MsgBody=new TxResponseMsgBody();
		MsgBody.setEntity(outvo);
		rspMsg.setTx_body(MsgBody);
		
		TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1007", GpumpErrorInfoModel.NOERROR);
		LOGGER.debug("GPUMP1007_Bean end!");
		return rspMsg;
	}
	/**
	 * 设置服务流程参数方法
	 * @param param 流程数据类
	 * @param logtime 各环节耗时缓存
	 * @param reqMsg 请求数据
	 */
	void setparam(ServiceInVoParam1007 paramMap,HashMap<String, Long> logtime,TxRequestMsg reqMsg)
	{
		TxRequestMsgHead reqMsgHead=reqMsg.getTx_header();
		String traceid=reqMsgHead.getSys_evt_trace_id();
		logtime.put("selectTime", (long) 0);
		logtime.put("deleteForGpuTime", (long) 0);
		logtime.put("deleteTime", (long) 0);
		logtime.put("updateTime", (long) 0);
		GPUMP1007ServiceInVo invo=(GPUMP1007ServiceInVo)reqMsg.getTx_body().getEntity();
		TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		String GroupName=Com2.getGroupName();
		String sysChannelID=Com2.getSysChannelID();
		List<String> redisTask_list=new ArrayList<String>();
		paramMap.setRedisTask_list(redisTask_list);
		paramMap.setSysChannelID(sysChannelID);
		paramMap.setGroupName(GroupName);
		paramMap.setLogtime(logtime);
		paramMap.setCust_id(invo.getCust_id());
		paramMap.setTraceid(traceid);
	}
	/**
	 * redis任务处理
	 * @param paramMap
	 */
	public void redisConduct(ServiceInVoParam1007 paramMap)
	{
		List<String> redisTask_list = paramMap.getRedisTask_list();
		if(redisTask_list!=null&&redisTask_list.size()>0)
		{
			for(String task:redisTask_list)
			{
				String arg[]=task.split("\\|\\|");
				if(arg.length>=3)
				{
					String type=arg[0];
					String key=arg[1];
					String data=arg[2];
					RockerMqService.sendRedisOrMq(key, data, type);
				}else
				{
					LOGGER.warn("this task no 3 param, data is : "+task);
				}
			}
		}else
		{
			LOGGER.debug("redisTask_list is null");
		}
	}
	/**
	 * 快速库出库处理，记录redis删除任务
	 * @param param 		交易流程参数类
	 * @param traceLog		报文日志缓存类
	 */
	public void fastDbHandle(ServiceInVoParam1007 param,TraceLog traceLog)
	{
		String feature_id=null;
		GpumpLogicFacedbModel gpumpLogicFacedbModel_fast = param.getGpumpLogicFacedbModel_fast();
		String logic_db_id_fast=gpumpLogicFacedbModel_fast.getLogic_db_id();
		HashMap<String, Long> logtime = param.getLogtime();
		String traceid = param.getTraceid();
		String cust_id = param.getCust_id();
		List<GpumpRealFacedbModel> gpumpRealFacedbModellist_fast=gpumpLogicFacedbModel_fast.getGpumpRealFacedbModelList();
		if(gpumpRealFacedbModellist_fast==null||gpumpRealFacedbModellist_fast.size()==0)
		{
			LOGGER.error("gpumpRealFacedb database is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.REALFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR));
		}
		for(GpumpRealFacedbModel gpumpRealFacedbModel_fast:gpumpRealFacedbModellist_fast)
		{
			String REAL_DB_ID_fast=gpumpRealFacedbModel_fast.getReal_db_id();
			String GPU_FACE_DB=gpumpRealFacedbModel_fast.getGpu_face_db();
			LOGGER.debug("GPU_FACE_DB is "+GPU_FACE_DB);
			//查询客户特征值对照表
			long start = System.currentTimeMillis();
			GpumpFidcustMapModel gpumpFidcustMapModel=redisService.selectFidcustMapModel(REAL_DB_ID_fast, cust_id);
			long end = System.currentTimeMillis();
			//selectTime=selectTime+end-start;
			logtime.put("selectTime", logtime.get("selectTime")+end-start);
			GpumpGpuInfoModel gpumpGpuInfoModel=gpumpRealFacedbModel_fast.getGpumpGpuInfo();
			if(gpumpGpuInfoModel==null)
			{
				LOGGER.warn("gpumpGpuInfoModel is null,real_db_id is : "+gpumpRealFacedbModel_fast.getReal_db_id());
				continue;
			}
			String gpu_type_id=gpumpGpuInfoModel.getGpu_type_id();
			String gpuclassname="com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gpu_type_id + "_Bean";
			//GpuInterface gpuBean=GpuMeth.getBeanClass(gpuclassname);
			GpuInterface gpuBean=(GpuInterface) Utils.getInstance(gpuclassname);
			if(gpuBean==null)
			{
				LOGGER.error("GPUMP "+gpu_type_id+" service is no exist!");
				continue;
			}
			
			if(gpumpFidcustMapModel!=null)
			{
				feature_id=gpumpFidcustMapModel.getFeature_id();
				String real_db_id = gpumpFidcustMapModel.getReal_db_id();
				List<String> redisTask_list = param.getRedisTask_list();
				if(feature_id!=null)
				{
					DeleteFeatureRequest groupdeleteinvo=new DeleteFeatureRequest();
					groupdeleteinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
					groupdeleteinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
					groupdeleteinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
					groupdeleteinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
					groupdeleteinvo.setGroupname(GPU_FACE_DB);
					groupdeleteinvo.setFeatureid(feature_id);
					groupdeleteinvo.setTraceid(traceid);
					LOGGER.warn("begin to delete feature_id for gpu,feature_id is "+feature_id);
					start = System.currentTimeMillis();
					DeleteFeatureResponse deletefeatureresponse= gpuBean.deleteFeature(groupdeleteinvo,traceLog);
					end = System.currentTimeMillis();
					//deleteForGpuTime=deleteForGpuTime+end-start;
					logtime.put("deleteForGpuTime", logtime.get("deleteForGpuTime")+end-start);
					traceLog.setDeleteFeatureTime(traceLog.getDeleteFeatureTime()+end-start);
					//LOGGER.debug(deletefeatureresponse.toString());
					if(!deletefeatureresponse.getResult()&&deletefeatureresponse.getError().equals(GpumpErrorInfoModel.GPURESULTERROR_FEATURE_ID_NO_EXIST))
					{
						LOGGER.warn("gpu user delete_fast error! feature_id is "+feature_id+" is not exist!");
					}else if(!deletefeatureresponse.getResult())
					{
						LOGGER.error("delete_fast user error,message is "+deletefeatureresponse.getError()+" : "+GpumpErrorInfoParaUtil.getErrorMsg(deletefeatureresponse.getError()));
						throw new CommonRuntimeException(deletefeatureresponse.getError(),GpumpErrorInfoParaUtil.getErrorMsg(deletefeatureresponse.getError()));
					}
					redisTask_list.add("delRedis||"+feature_id+"_"+real_db_id+"||null");
					LOGGER.debug("delete for gpu funish,feature_id is "+feature_id);
				}
				start = System.currentTimeMillis();
				int ret=GpumpFidcustMapService.delete(real_db_id, cust_id);
				end = System.currentTimeMillis();
				//deleteTime=deleteTime+end-start;
				logtime.put("deleteTime", logtime.get("deleteTime")+end-start);
				if(ret!=1)
				{
					LOGGER.error(" delete GpumpFidcustMap error,LOGIC_DB_ID: "+logic_db_id_fast+" gpu_type_id: "+gpu_type_id+" custid: "+cust_id);
					throw new CommonRuntimeException(GpumpErrorInfoModel.DATABASEERROR_DELETE,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.DATABASEERROR_DELETE));
				}else
				{	
					redisTask_list.add("delRedis||"+cust_id+"_"+real_db_id+"||null");
					param.setRedisTask_list(redisTask_list);
				}
			}else
			{
				LOGGER.warn("gpumpFidcustMap is null,continue!");
			}
		}
	
		
	}

	
	/**
	 * 获取逻辑库实例方法，设置到流程数据实例内
	 * @param param  交易流程参数类
	 */
	public void genLogicFaceModel(ServiceInVoParam1007 param)
	{
		String sysChannelID=param.getSysChannelID();
		String groupName = param.getGroupName();
		//输入GroupName获取快速库对象
		GpumpLogicFacedbModel gpumpLogicFacedbModel_fast=ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID+":"+groupName);
		
		if(gpumpLogicFacedbModel_fast==null)
		{
			LOGGER.error(groupName+" is not exist!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
		}else if(!"2".equals(gpumpLogicFacedbModel_fast.getType()))
		{
			LOGGER.error(groupName+" is register base!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
		}

		String LOGIC_DB_ID_fast=gpumpLogicFacedbModel_fast.getLogic_db_id();
		param.setGpumpLogicFacedbModel_fast(gpumpLogicFacedbModel_fast);
		
		LOGGER.debug(" fast base LOGIC_DB_ID is "+LOGIC_DB_ID_fast);
	}
	

	@Override
	public Object transform(JSONObject indata) throws Exception {
		JSONObject tx_body=indata.getJSONObject("tx_body");
		if(tx_body==null)
		{
			LOGGER.error("tx_body is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject entity=tx_body.getJSONObject("entity");
		if(entity==null)
		{
			LOGGER.error("entity is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject com2=tx_body.getJSONObject("com2");
		if(com2==null)
		{
			LOGGER.error("com2 is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		TxRequestMsg reqMsg=(TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
		GPUMP1007ServiceInVo invo=(GPUMP1007ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1007ServiceInVo.class);;
		TxRequestMsgCom2 com=JSON.parseObject(JSON.toJSONString(com2),TxRequestMsgCom2.class);
		TxRequestMsgBody MsgBody=reqMsg.getTx_body();
		MsgBody.setEntity(invo);
		MsgBody.setCom2(com);
		reqMsg.setTx_body(MsgBody);
		return reqMsg;
	}

	@Override
	public List<GpuRegisterTask> getGpuTask() {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public String getTime() {
//		StringBuffer cmmpLog = new StringBuffer();
//		cmmpLog.append("selectTime<").append(selectTime).append("> ");
//		cmmpLog.append("deleteTime<").append(deleteTime).append("> ");
//		cmmpLog.append("deleteForGpuTime<").append(deleteForGpuTime).append("> ");
//		return cmmpLog.toString();
//	}

}
