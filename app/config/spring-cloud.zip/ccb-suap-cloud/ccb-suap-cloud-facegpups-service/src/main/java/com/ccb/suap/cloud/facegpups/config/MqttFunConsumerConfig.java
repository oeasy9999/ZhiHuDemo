//package com.ccb.suap.cloud.facegpups.config;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.integration.annotation.ServiceActivator;
//import org.springframework.integration.channel.DirectChannel;
//import org.springframework.integration.core.MessageProducer;
//import org.springframework.integration.mqtt.core.DefaultMqttPahoClientFactory;
//import org.springframework.integration.mqtt.core.MqttPahoClientFactory;
//import org.springframework.integration.mqtt.inbound.MqttPahoMessageDrivenChannelAdapter;
//import org.springframework.integration.mqtt.support.DefaultPahoMessageConverter;
//import org.springframework.messaging.Message;
//import org.springframework.messaging.MessageChannel;
//import org.springframework.messaging.MessageHandler;
//import org.springframework.messaging.MessagingException;
//import org.springframework.stereotype.Component;
//
//import com.alibaba.fastjson.JSON;
//import com.ccb.suap.cloud.facegpups.controller.FacegpupsController;
//
//@Component
//@Configuration
//public class MqttFunConsumerConfig {
//	private static final Logger LOGGER = LoggerFactory.getLogger(MqttFunConsumerConfig.class);
//	 @Value("${spring.mqtt.username}")
//	    private String username;
//	 
//	    @Value("${spring.mqtt.password}")
//	    private String password;
//	 
//	    @Value("${spring.mqtt.url}")
//	    private String hostUrl;
//	 
//	    @Value("${spring.mqtt.client.id}")
//	    private String clientId;
//	 
//	    @Value("${spring.mqtt.default.topic}")
//	    private String defaultTopic;
//	    @Value("${spring.mqtt.completionTimeout}")
//	    private int completionTimeout ; 
//
//	@Bean
//	public MqttPahoClientFactory mqttClientFactory() {
//		DefaultMqttPahoClientFactory factory = new DefaultMqttPahoClientFactory();
//		factory.setServerURIs(hostUrl);
//		return factory;
//	}
//
//	@Bean
//	public MessageChannel mqttTestInputChannel() {
//		return new DirectChannel();
//	}
//
//	@Bean
//	public MessageProducer inbound() {
//		MqttPahoMessageDrivenChannelAdapter adapter = new MqttPahoMessageDrivenChannelAdapter(clientId, mqttClientFactory(), defaultTopic);
//		adapter.setCompletionTimeout(completionTimeout);
//		adapter.setConverter(new DefaultPahoMessageConverter());
//		adapter.setQos(1);
//		adapter.setOutputChannel(mqttTestInputChannel());
//		return adapter;
//	}
//
//	@Bean
//	@ServiceActivator(inputChannel = "mqttTestInputChannel")
//	public MessageHandler handlerTest() {
//		return new MessageHandler() {
//
//			@Override
//			public void handleMessage(Message<?> message) throws MessagingException {
//				try {
//					//这里拿到发布的消息内容，做具体的业务逻辑处理
//					String string = message.getPayload().toString();
//					System.out.println("---handleMessage--"+string);
//					JSON.toJSON(string);
//					//JsonParser jsonParser = new JsonParser();
//					//JsonObject object = jsonParser.parse(string).getAsJsonObject();
//					//String asString = object.get("game").getAsString();
//				} catch (MessagingException ex) {
//					LOGGER.info(ex.getMessage());
//				}
//			}
//		};
//	}
//}