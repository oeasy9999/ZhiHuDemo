package com.ccb.suap.cloud.facegpups.faceplus.vo;


public class CompareImageRequest {

	private String ip;
	private String port1;
	private String port2;
	private String port3;
	private String traceid;
	private String image1;
	private String image2;
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getPort1() {
		return port1;
	}
	public void setPort1(String port1) {
		this.port1 = port1;
	}
	public String getPort2() {
		return port2;
	}
	public void setPort2(String port2) {
		this.port2 = port2;
	}
	public String getPort3() {
		return port3;
	}
	public void setPort3(String port3) {
		this.port3 = port3;
	}
	public String getTraceid() {
		return traceid;
	}
	public void setTraceid(String traceid) {
		this.traceid = traceid;
	}
	public String getImage1() {
		return image1;
	}
	public void setImage1(String image1) {
		this.image1 = image1;
	}
	public String getImage2() {
		return image2;
	}
	public void setImage2(String image2) {
		this.image2 = image2;
	}
	@Override
	public String toString() {
		String image1_length="0";
		if(image1!=null)
		{
			image1_length=image1.length()+"";
		}
		String image2_length="0";
		if(image2!=null)
		{
			image1_length=image2.length()+"";
		}
		return "CompareImageRequest [ip=" + ip + ", port1=" + port1 + ", port2=" + port2 + ", port3=" + port3
				+ ", traceid=" + traceid + ", image1_length=" + image1_length + ", image2_length=" + image2_length + "]";
	}
	
	
}
