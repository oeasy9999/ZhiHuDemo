package com.ccb.suap.cloud.facegpups.inf;

import java.util.HashMap;
import java.util.List;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.util.log.TraceLog;

/**
 * 交易处理接口
 * @author zhanzifeng
 *
 */
public interface TrxInterface {

	/**
	 * 服务bean执行方法
	 * @param rspMsg   响应数据
	 * @param reqMsg   请求数据
	 * @param logtime  各步骤耗时信息缓存
	 * @param traceLog 日志缓存类
	 * @return rspMsg   响应数据
	 * @throws Exception
	 */
	public  TxResponseMsg executeProcess(TxResponseMsg rspMsg,TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog)throws Exception;

	/**
	 * 参数校验方法
	 * @param TxResponseMsg rspMsg
	 * @param TxRequestMsg reqMsg
	 * @return boolean  检验失败返回false，错误信息在rspMsg内封装
	 * @throws Exception
	 */
	boolean checkPara(TxResponseMsg rspMsg,TxRequestMsg reqMsg) throws Exception;
	/**
	 * 接收传入json数据转化为对应bean实例的处理参数类
	 * @param indata
	 * @return
	 * @throws Exception
	 */
	public  Object transform(JSONObject indata)throws Exception;

	public List<GpuRegisterTask> getGpuTask();
	
	//public String getTime();
}
