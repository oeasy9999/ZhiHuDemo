package com.ccb.suap.cloud.facegpups.faceplus.vo;


public class GetGroupSizeResponse {

	/**
	 * 
	 */
	private boolean result;
	private String error;
	private String size;
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String string) {
		this.size = string;
	}
	@Override
	public String toString() {
		return "GetGroupSizeResponse [result=" + result + ", error=" + error + ", size=" + size + "]";
	}
	
}
