package com.ccb.suap.cloud.facegpups.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;

@Mapper
@Component
public interface GpumpErrorInfoMapper {
	
	int count();
	
	GpumpErrorInfoModel select(@Param("errorcode")String errorcode);
	
	List<GpumpErrorInfoModel> selectAll();
	
	int insert(GpumpErrorInfoModel model);
	
	int update(GpumpErrorInfoModel model);
	
	int delete(@Param("errorcode")String errorcode);
	
}
