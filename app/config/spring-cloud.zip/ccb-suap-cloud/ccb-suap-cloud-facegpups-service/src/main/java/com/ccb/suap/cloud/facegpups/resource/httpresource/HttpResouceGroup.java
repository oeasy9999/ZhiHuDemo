package com.ccb.suap.cloud.facegpups.resource.httpresource;

import com.ccb.suap.util.log.LogUtil;

import java.util.Vector;


public class HttpResouceGroup{
	
	private String groupID = null;
	
	public Vector vResouce = new Vector(1);

	public String reqProxyIP = null;

	public int reqProxyPort = -1;

	public String reqMethod = "POST";
	
	public String contentType = "application/json;charset=UTF-8";
	
	public String path = "";

	public String useProxyAuthor = null;

	public String proxyUserName = null;

	public String proxyUserPass = null;

	//private boolean usingProxy = true;

	public int connectTimeout = 4000;

	public int soTimeout = 3000;
	
	public String lb_strategy = "1";

	public boolean soNodelay = true;

	Vector headParam = null;

	//轮询链接资源
	public int count = 0;

	public int heartInteval = 300000;

	Thread heartThread = null;

	int MAX_REQ = 20;
	
	public boolean balance = true;

	public class HeartTest implements Runnable {
		int checkInteval = 300000;

		HttpResouceGroup group = null;

		/**
		 *  
		 */
		public HeartTest(HttpResouceGroup group1, int inteval) {
			super();
			group = group1;
			checkInteval = inteval;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			while (true) {
				try {
					Thread.sleep(checkInteval);
					if (group.heartCheck()) {
						break;
					}
				} catch (Exception ee) {
				}
			}
			try{
				heartThread.interrupt();
				heartThread = null;
			}catch(Exception ee){}
			
		}

	}

	/**
	 *  
	 */
	public HttpResouceGroup() {
		super();
	}
	
	public HttpResouceGroup(String groupID){
		this.groupID = groupID;
	}
	
	public HttpResouceGroup getHttpResouceGroup() {
		return this;
	}
	
	public Vector<HttpCommService> getAllResource() {
		return this.vResouce;
	}
	
	public void addHttpCommService(HttpCommService httpCommService){
		if(httpCommService!=null){
			this.vResouce.addElement(httpCommService);
		}
	}
	public Vector getResources() {
		return vResouce;
	}

	/**
	 * 获取http连接资源
	 * @return
	 * @throws Exception
	 */
	public synchronized HttpCommService getResouce() throws Exception {
		//负载均衡策略 1-轮询 2-权重轮询 3-权重随机
		if("2".equals(lb_strategy)) {
			WeightedRoundRobinScheduling wrrs = new WeightedRoundRobinScheduling(vResouce);
			return wrrs.getResouce(this.MAX_REQ);
		} else if ("3".equals(lb_strategy)) {
			WeightedRandomRobinScheduling wrrs = new WeightedRandomRobinScheduling(vResouce);
			return wrrs.getResouce(this.MAX_REQ);
		}
		int cnt = 0;
		int rLen = vResouce.size();
		//System.out.println("vResouce.size()==="+rLen);
		while (true) {
			//System.out.println("count===1"+count);
			if(count >= rLen){//重新轮询
				count = 0;
			}
			HttpCommService srv = (HttpCommService) vResouce.elementAt(count++);
			cnt++;
			//System.out.println("count===2"+count);
			if (srv.isRight) {
				if (srv.curConn < this.MAX_REQ) {
					srv.curConn++;
					LogUtil.debug("Service Url:" + count+"==="+srv.httpURL);
					return srv;
				}
			}
			if (rLen == cnt) {//轮询了所有资源
				break;
			}

		}
		throw new HttpResouceException("Http comm service in group all not available!,please check network!");
	}

	public String sendAndWait(String path, String msg, int connectTimeout1, int soTimeout1,
			Object dataColl) throws Exception {
		if (connectTimeout1 == -1) {
			connectTimeout1 = this.connectTimeout;
		}
		if (soTimeout1 == -1) {
			soTimeout1 = this.soTimeout;
		}
		String outdata = null;
		
		try{
			outdata = getResouce().sendAndWait(this, path, msg, connectTimeout1, soTimeout1, dataColl);
		}catch(Exception e){
			if(e instanceof HttpResouceException){
				return outdata;
			}
		}
				
		int cnt = 0;
		//System.out.println("outdata:"+outdata + " cnt:"+cnt);
		//判断当前连接是否正常返回,否继续轮询
		while(outdata==null || outdata.length()<4){
			//System.out.println("count:"+count + " cnt:"+cnt);
			try{
				cnt++;
				if(cnt >= vResouce.size()){
					break;
				}
				outdata = getResouce().sendAndWait(this, path, msg, connectTimeout1, soTimeout1,
					dataColl);
			}catch(Exception e){
				LogUtil.error("sendAndWait:", e);
				if (cnt >= vResouce.size()) {
					throw e;
				}
			}
			
			if (cnt >= vResouce.size()) {
				break;
			}
		}
		return outdata;
	}

	public Vector getHeadParams() {
		return headParam;
	}


	public boolean heartCheck() {
		boolean isGoog = true;
		if (vResouce != null) {
			int cnt = 0;
			for (int i = 0; i < vResouce.size(); i++) {
				HttpCommService srv = (HttpCommService) vResouce.elementAt(i);
				if (!srv.isRight) {
					cnt++;
					try {
						String checkdata = srv.sendAndWait(this, "", "{\"heartCheckMsg\":\"########heartCheck########\"}", -1, -1, null);
						LogUtil.debug("heartCheck return Msg:" + checkdata);
						if(checkdata==null){
							srv.isRight = false;
						}else{
							srv.isRight = true;
						}
					} catch (Exception ee) {
						isGoog = false;
						srv.isRight = false;
						//ee.printStackTrace();
					}
				}
			}
			if(cnt>0){//还有坏的资源，继续探针
				isGoog = false;
			}
		}
		return isGoog;
	}

	public void start() {
		if (heartThread == null) {
			heartThread = new Thread(new HeartTest(this, heartInteval));
			heartThread.setName("Heart check thread for HttpResouceGroup ");
			heartThread.start();
		}
	}
	
	public void terminate() throws Exception {
	    if (this.heartThread != null)
	      try {
	        this.heartThread.interrupt();
	        this.heartThread = null;
	      }
	      catch (Exception ee)
	      {
	      }
	  }

	public String getReqProxyIP() {
		return reqProxyIP;
	}

	public void setReqProxyIP(String reqProxyIP) {
		this.reqProxyIP = reqProxyIP;
	}

	public int getReqProxyPort() {
		return reqProxyPort;
	}

	public void setReqProxyPort(int reqProxyPort) {
		this.reqProxyPort = reqProxyPort;
	}

	public String getReqMethod() {
		return reqMethod;
	}

	public void setReqMethod(String reqMethod) {
		this.reqMethod = reqMethod;
	}

	public String getUseProxyAuthor() {
		return useProxyAuthor;
	}

	public void setUseProxyAuthor(String useProxyAuthor) {
		this.useProxyAuthor = useProxyAuthor;
	}

	public String getProxyUserName() {
		return proxyUserName;
	}

	public void setProxyUserName(String proxyUserName) {
		this.proxyUserName = proxyUserName;
	}

	public String getProxyUserPass() {
		return proxyUserPass;
	}

	public void setProxyUserPass(String proxyUserPass) {
		this.proxyUserPass = proxyUserPass;
	}

	public int getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public int getSoTimeout() {
		return soTimeout;
	}

	public void setSoTimeout(int soTimeout) {
		this.soTimeout = soTimeout;
	}

	public boolean isSoNodelay() {
		return soNodelay;
	}

	public void setSoNodelay(boolean soNodelay) {
		this.soNodelay = soNodelay;
	}

	public Vector getHeadParam() {
		return headParam;
	}

	public void setHeadParam(Vector headParam) {
		this.headParam = headParam;
	}

	public int getHeartInteval() {
		return heartInteval;
	}

	public void setHeartInteval(int heartInteval) {
		this.heartInteval = heartInteval;
	}

	public Thread getHeartThread() {
		return heartThread;
	}

	public void setHeartThread(Thread heartThread) {
		this.heartThread = heartThread;
	}

	public int getMAX_REQ() {
		return MAX_REQ;
	}

	public void setMAX_REQ(int mAX_REQ) {
		MAX_REQ = mAX_REQ;
	}

	public boolean isBalance() {
		return balance;
	}

	public void setBalance(boolean balance) {
		this.balance = balance;
	}

	public String getGroupID() {
		return groupID;
	}

	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
}