package com.ccb.suap.cloud.facegpups.gpubeans;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ccb.suap.cloud.facegpups.resource.httpresource.HttpCommPoolService;
import com.ccb.suap.cloud.facegpups.resource.httpresource.HtttpUtil;
import com.ccb.suap.cloud.facegpups.resource.httpresource.MultipartFormDataParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ResourceUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.facegpups.controller.FacegpupsController;
import com.ccb.suap.cloud.facegpups.faceplus.vo.AddFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.AddFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CleanGroupRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CleanGroupResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareImageRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareImageResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteGroupRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteGroupResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DetectImageRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DetectImageResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupListReponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupListRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupSizeRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupSizeResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetVersionRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetVersionResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.InitGroupRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.InitGroupResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.SearchFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.SearchFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.GroupDeleteOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.GroupListOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.GroupInitOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.GroupCleanOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.DetectOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.DetectVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.VersionOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.GroupGetSizeOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.GroupListVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.VerifyOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.CompareOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.GroupDeleteFeatureOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.GroupSearchOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.GroupSearchVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.GroupAddOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g003.ExtractWithDetectOutVo;
import com.ccb.suap.cloud.facegpups.gpubeans.tranerrorcode.GpuCodeUtil_G003;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.util.JSONUtils;
import com.ccb.suap.util.file.FileUtils;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

public class GPUTYPE_G003_Bean implements GpuInterface{

	private static final Logger LOGGER = LoggerFactory.getLogger(FacegpupsController.class);
	public String dump(String appname)
	{
		String filename;
		String data = null;
		try {
			String dumpfile_path=new File(ResourceUtils.getURL("classpath:").getPath()).getParentFile().getParentFile().getParent()+File.separator+"baffle";
			dumpfile_path=dumpfile_path.substring(5);
			
			filename=appname+"_G003.rsp";
			dumpfile_path=dumpfile_path+File.separator+filename;
			File F=new File(dumpfile_path);
			LOGGER.debug(dumpfile_path);
			if(F.exists()){
				LOGGER.debug(appname+"baffle begin");
				data = FileUtils.readFile(dumpfile_path);
				LOGGER.debug("file data is : "+JSONUtils.formatJson(data,100));
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}
	@Override
	public GetFeatureResponse getFeature(GetFeatureRequest req, TraceLog traceLog) {
		String url="http://"+req.getIp()+":"+req.getPort1()+"/engine/static-api-wrapper/verify/feature/gets";
		traceLog.setUrl(url);
		Map<String, String> fileMap = new HashMap<String, String>();
		fileMap.put("imageData", req.getImage());
		traceLog.setRequestJsonString_getFeature(JSONObject.toJSON(fileMap).toString());
		String result=dump("getFeature");

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.addFileParams("imageData", req.getImage());
		if (result == null) {
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G003_PORT1", "/engine/static-api-wrapper/verify/feature/gets", params);
			} catch (Exception e) {
				LOGGER.error("send /engine/static-api-wrapper/verify/feature/gets error:" + e.getMessage());
			}
		}

//		if(result==null)
//		{
//			result = HtttpUtil.httpPostFrom(url, null, fileMap);
//		}
		traceLog.setResponseJsonString_getFeature(result);
		GetFeatureResponse rsp=new GetFeatureResponse();
		rsp.setResult(true);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		ExtractWithDetectOutVo extractwithdetectoutvo=(ExtractWithDetectOutVo)JSONObject.toJavaObject(jsonObject, ExtractWithDetectOutVo.class);
		if(extractwithdetectoutvo!=null)
		{
			String error=extractwithdetectoutvo.getErrorMessage();
			String result_gpu=extractwithdetectoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		rsp.setFeature(extractwithdetectoutvo.getFeature());
		return rsp;
	}

	@Override
	public AddFeatureResponse addFeature(AddFeatureRequest req, TraceLog traceLog) {
		String url="http://"+req.getIp()+":"+req.getPort1()+"/engine/static-api-wrapper/verify/feature/synAdd";
		traceLog.setUrl(url);
		Map<String, String> textMap = new HashMap<String, String>();
		AddFeatureResponse rsp=new AddFeatureResponse();
		rsp.setResult(true);
		textMap.put("dbName", req.getGroupname());
		textMap.put("feature", req.getFeature());
		traceLog.setRequestJsonString_addFeature(JSONObject.toJSON(textMap).toString());
		String result=dump("addFeature");

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.setTextMap(textMap);
		if (result == null) {
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G003_PORT1", "/engine/static-api-wrapper/verify/feature/synAdd", params);
			} catch (Exception e) {
				LOGGER.error("send /engine/static-api-wrapper/verify/feature/synAdd error:" + e.getMessage());
			}
		}

//		if(result==null)
//		{
//			result=HtttpUtil.httpPostFrom(url, textMap, null);
//		}
		traceLog.setResponseJsonString_addFeature(result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		GroupAddOutVo groupaddoutvo=(GroupAddOutVo)JSONObject.toJavaObject(jsonObject, GroupAddOutVo.class);
		if(groupaddoutvo!=null)
		{
			String error=groupaddoutvo.getErrorMessage();
			String result_gpu=groupaddoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		rsp.setFeatureid(groupaddoutvo.getFeatureId());
		return rsp;
	}

	@Override
	public SearchFeatureResponse searchFeature(SearchFeatureRequest req, TraceLog traceLog) {
		Map<String, String> textMap = new HashMap<String, String>();
		SearchFeatureResponse rsp=new SearchFeatureResponse();
		rsp.setResult(true);
		String url="http://"+req.getIp()+":"+req.getPort1()+"/engine/static-api-wrapper/verify/feature/search";
		traceLog.setUrl(url);
		textMap.put("dbName", req.getGroupname());
		textMap.put("feature", req.getFeature());
		textMap.put("topNum", req.getHitsize());
		Double score=Double.parseDouble(req.getThreshold())/100;
		textMap.put("score", score+"");
		traceLog.setRequestJsonString_searchFeature(JSONObject.toJSON(textMap).toString());
		String result=dump("searchFeature");

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.setTextMap(textMap);
		if (result == null) {
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G003_PORT1", "/engine/static-api-wrapper/verify/feature/search", params);
			} catch (Exception e) {
				LOGGER.error("send /engine/static-api-wrapper/verify/feature/search error:" + e.getMessage());
			}
		}

//		if(result==null)
//		{
//			result=HtttpUtil.httpPostFrom(url, textMap, null);
//		}
		traceLog.setResponseJsonString_searchFeature(result);
		//LOGGER.debug("search GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		List<String> featureids = new ArrayList<String>();
		List<String> scores = null;
		GroupSearchOutVo groupsearchoutvo = (GroupSearchOutVo)JSONObject.toJavaObject(jsonObject, GroupSearchOutVo.class);
		if(groupsearchoutvo!=null)
		{
			String error=groupsearchoutvo.getErrorMessage();
			String result_gpu=groupsearchoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONArray userInfos = jsonObject.getJSONArray("data");
		if(userInfos!=null&&userInfos.size()>0)
		{
			scores = new ArrayList<String>();
			for(int i=0;i<userInfos.size();i++)
			{
				JSONObject userinfoobject =(JSONObject) userInfos.get(i);
				GroupSearchVo userbean = (GroupSearchVo) JSONObject.parseObject(JSON.toJSONString(userinfoobject), GroupSearchVo.class);
				//featureids.add(userbean.getImageId());
				featureids.add(userbean.getExtra());
				score=(double) 0;
				try {
					score = Double.parseDouble(userbean.getScore())*100;
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					LOGGER.debug("score is error,value is "+userbean.getScore());
				}
				if(score!=0)
				{
					scores.add(score+"");	
				}
				
			}
		}else
		{
			LOGGER.debug("userInfos is null or size is 0 !");
		}
		rsp.setFeatureids(featureids);
		rsp.setScores(scores);
		return rsp;
	}

	@Override
	public DeleteFeatureResponse deleteFeature(DeleteFeatureRequest req, TraceLog traceLog) {
		Map<String, String> textMap = new HashMap<String, String>();
		DeleteFeatureResponse rsp=new DeleteFeatureResponse();
		rsp.setResult(true);
		String url="http://"+req.getIp()+":"+req.getPort1()+"/engine/static-api-wrapper/verify/feature/deletes";
		traceLog.setUrl(url);
		textMap.put("dbName", req.getGroupname());
		textMap.put("featureId",req.getFeatureid() );
		traceLog.setRequestJsonString_deleteFeature(JSONObject.toJSON(textMap).toString());
		String result=dump("deleteFeature");

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.setTextMap(textMap);
		if (result == null) {
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G003_PORT1", "/engine/static-api-wrapper/verify/feature/deletes", params);
			} catch (Exception e) {
				LOGGER.error("send /engine/static-api-wrapper/verify/feature/deletes error:" + e.getMessage());
			}
		}

//		if(result==null)
//		{
//			result=HtttpUtil.httpPostFrom(url, textMap, null);
//		}
		traceLog.setResponseJsonString_deleteFeature(result);
		//LOGGER.debug("deleteFeature GPU result: "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		
		GroupDeleteFeatureOutVo groupdeleteoutvo= (GroupDeleteFeatureOutVo)JSONObject.toJavaObject(jsonObject, GroupDeleteFeatureOutVo.class);
		if(groupdeleteoutvo!=null)
		{
			String error=groupdeleteoutvo.getErrorMessage();
			String result_gpu=groupdeleteoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		return rsp;
	}

	@Override
	public CompareFeatureResponse compareFeature(CompareFeatureRequest req, TraceLog traceLog) {
		Map<String, String> textMap = new HashMap<String, String>();
		CompareFeatureResponse rsp=new CompareFeatureResponse();
		rsp.setResult(true);
		String url="http://"+req.getIp()+":"+req.getPort2()+"/engine/static-api-wrapper/verify/feature/compare";
		traceLog.setUrl(url);
		textMap.put("feature1", req.getFeature1());
		textMap.put("feature2", req.getFeature2());
		JSONObject json = (JSONObject) JSONObject.toJSON(textMap);
		traceLog.setRequestJsonString_compareFeature(json.toString());
		String result=dump("compareFeature");

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.setTextMap(textMap);
		if (result == null) {
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G003_PORT2", "/engine/static-api-wrapper/verify/feature/compare", params);
			} catch (Exception e) {
				LOGGER.error("send /engine/static-api-wrapper/verify/feature/compare error:" + e.getMessage());
			}
		}

//		if(result==null)
//		{
//			//result=HtttpUtil.postJson(url, json.toJSONString());
//			result=HtttpUtil.httpPostFrom(url, textMap, null);
//		}
		traceLog.setResponseJsonString_compareFeature(result);
		//LOGGER.debug("compare GPU result: "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
			
		CompareOutVo compareOutVo=(CompareOutVo)JSONObject.toJavaObject(jsonObject, CompareOutVo.class);
		if(compareOutVo!=null)
		{
			String error=compareOutVo.getErrorMessage();
			String result_gpu=compareOutVo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		double score=(double) 0;
		try {
			score = Double.parseDouble(compareOutVo.getScore())*100;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			LOGGER.debug("score is error,value is "+compareOutVo.getScore());
		}
		rsp.setScore(score+"");
		return rsp;
	}

	@Override
	public CompareImageResponse compareImage(CompareImageRequest req, TraceLog traceLog) {
		Map<String, String> fileMap = new HashMap<String, String>();
		CompareImageResponse rsp=new CompareImageResponse();
		rsp.setResult(true);
		String url="http://"+req.getIp()+":"+req.getPort2()+"/engine/static-api-wrapper/verify/face/verification";
		traceLog.setUrl(url);
		fileMap.put("imageOne", req.getImage1());
		fileMap.put("imageTwo", req.getImage2());
		traceLog.setRequestJsonString_compareImage(JSONObject.toJSON(fileMap).toString());

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.addFileParams("imageOne", req.getImage1());
		params.addFileParams("imageTwo", req.getImage2());
		String result = null;
		try {
			result = HttpCommPoolService.HTTPCommPool.sendAndWait("G003_PORT2", "/engine/static-api-wrapper/verify/face/verification", params);
		} catch (Exception e) {
			LOGGER.error("send /engine/static-api-wrapper/verify/face/verification error:" + e.getMessage());
		}

//		String result = HtttpUtil.httpPostFrom(url, null, fileMap);
		traceLog.setResponseJsonString_compareImage(result);
		//LOGGER.debug("verify GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		VerifyOutVo verifyoutvo = JSONObject.toJavaObject(jsonObject, VerifyOutVo.class);
		if(verifyoutvo!=null)
		{
			String error=verifyoutvo.getErrorMessage();
			String result_gpu=verifyoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		double score=(double) 0;
		try {
			score = Double.parseDouble(verifyoutvo.getScore())*100;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			LOGGER.debug("score is error,value is "+verifyoutvo.getScore());
		}
		rsp.setScore(score+"");
		return rsp;
	}

	@Override
	public GetGroupSizeResponse getGroupSize(GetGroupSizeRequest req) {
		LOGGER.debug("getGroupSize "+req.toString());
		GetGroupSizeResponse rsp=new GetGroupSizeResponse();
		rsp.setResult(true);
		String url="http://"+req.getIp()+":"+req.getPort1()+"/engine/static-api-wrapper/verify/target/gets";
		String result = HtttpUtil.getCurlData(url);
		LOGGER.debug("getsize GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		
		GroupGetSizeOutVo groupgetsizeoutvo=JSONObject.toJavaObject(jsonObject, GroupGetSizeOutVo.class);
		if(groupgetsizeoutvo!=null)
		{
			String error=groupgetsizeoutvo.getErrorMessage();
			String result_gpu=groupgetsizeoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		
		JSONArray userInfos = jsonObject.getJSONArray("data");
		String size=null;
		if(userInfos!=null&&userInfos.size()>0)
		{
			for(int i=0;i<userInfos.size();i++)
			{
				JSONObject userinfoobject =(JSONObject) userInfos.get(i);
				GroupListVo userbean = (GroupListVo) JSONObject.parseObject(JSON.toJSONString(userinfoobject), GroupListVo.class);
				if(userbean!=null&&(req.getGroupname()).equals(userbean.getDbName()))
				{
					size=userbean.getCount();
					break;
				}
			}
		}else
		{
			LOGGER.debug("userInfos is null or size is 0 !");
		}
		if(size==null)
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_GROUP_NOT_EXIST);
		}else
		{
			rsp.setSize(size);
		}
		return rsp;
	}

	@Override
	public GetVersionResponse getVersion(GetVersionRequest req) {
		LOGGER.debug("getVersion "+req.toString());
		GetVersionResponse rsp=new GetVersionResponse();
		rsp.setResult(true);
		String url="http://"+req.getIp()+":"+req.getPort2()+"/engine/static-api-wrapper/verify/version";
		String result = HtttpUtil.getCurlData(url);
		LOGGER.debug("getVersion GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		VersionOutVo versionoutvo=JSONObject.toJavaObject(jsonObject, VersionOutVo.class);
		if(versionoutvo!=null)
		{
			String error=versionoutvo.getErrorMessage();
			String result_gpu=versionoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		rsp.setVersion(versionoutvo.getVersion());
		return rsp;
	}

	@Override
	public DetectImageResponse detectImage(DetectImageRequest req, TraceLog traceLog,String chanel_id) {
		String url="http://"+req.getIp()+":"+req.getPort1()+"/engine/static-api-wrapper/verify/face/detectAndQuality";
		traceLog.setUrl(url);
		Map<String, String> textMap = new HashMap<String, String>();
		DetectImageResponse rsp=new DetectImageResponse();
		rsp.setResult(true);
		Map<String, String> fileMap = new HashMap<String, String>();
		fileMap.put("imageData", req.getImage());
		traceLog.setRequestJsonString_detectImage(JSONObject.toJSON(fileMap).toString());
		String result=dump("detectImage");

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.addFileParams("imageData", req.getImage());
		if (result == null) {
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G003_PORT1", "/engine/static-api-wrapper/verify/face/detectAndQuality", params);
			} catch (Exception e) {
				LOGGER.error("send /engine/static-api-wrapper/verify/face/detectAndQuality error:" + e.getMessage());
			}
		}

//		if(result==null)
//		{
//			result = HtttpUtil.httpPostFrom(url, textMap, fileMap);
//		}
		traceLog.setResponseJsonString_detectImage(result);
		
		//LOGGER.debug("Detect GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		JSONArray userInfos = jsonObject.getJSONArray("data");
		DetectOutVo detectoutvo = (DetectOutVo)JSONObject.toJavaObject(jsonObject, DetectOutVo.class);
		if(detectoutvo!=null)
		{
			String error=detectoutvo.getErrorMessage();
			String result_gpu=detectoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		Double quality = null;
		if(userInfos!=null&&userInfos.size()>1)
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPUDETECTERROR_FACESMORE);
			return rsp;
		}else if(userInfos!=null&&userInfos.size()==0)
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPUDETECTERROR_FACESNULL);
			return rsp;
		}
		JSONObject userinfoobject =(JSONObject) userInfos.get(0);
		DetectVo detectvo=(DetectVo) JSONObject.parseObject(JSON.toJSONString(userinfoobject), DetectVo.class);
		if(detectvo.getQuality_score()!=null)
		{
			quality=Double.parseDouble(detectvo.getQuality_score())*100;
		}
		rsp.setQuality(quality+"");
		return rsp;
	}

	@Override
	public CleanGroupResponse cleanGroup(CleanGroupRequest req) {
		LOGGER.debug("cleanGroup "+req.toString());
		String url="http://"+req.getIp()+":"+req.getPort1()+"/engine/static-api-wrapper/verify/target/clear";
		CleanGroupResponse rsp=new CleanGroupResponse();
		rsp.setResult(true);
		Map<String, String> textMap = new HashMap<String, String>();
		textMap.put("dbName", req.getGroupname());
		String result = HtttpUtil.httpPostFrom(url, textMap,null);
		LOGGER.debug("cleanGroup GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		
		GroupCleanOutVo groupcleanoutvo=JSONObject.toJavaObject(jsonObject, GroupCleanOutVo.class);
		if(groupcleanoutvo!=null)
		{
			String error=groupcleanoutvo.getErrorMessage();
			String result_gpu=groupcleanoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		return rsp;
	}

	@Override
	public InitGroupResponse initGroup(InitGroupRequest req) {
		LOGGER.debug("initGroup "+req.toString());
		Map<String, String> textMap = new HashMap<String, String>();
		InitGroupResponse rsp=new InitGroupResponse();
		rsp.setResult(true);
		textMap.put("dbName", req.getGroupname());
		//textMap.put("fastSearch", 1);
		String url="http://"+req.getIp()+":"+req.getPort1()+"/engine/static-api-wrapper/verify/target/add";
		JSONObject jsonObject;
		try {
			String result = HtttpUtil.httpPostFrom_data(url, textMap,null);
			if(StringUtils.checkEmpty(result))
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
				return rsp;
			}
			LOGGER.debug("initGroup GPU result ------ "+result);
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		GroupInitOutVo groupinitoutvo=JSONObject.toJavaObject(jsonObject, GroupInitOutVo.class);
		if(groupinitoutvo!=null)
		{
			String error=groupinitoutvo.getErrorMessage();
			String result_gpu=groupinitoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		return rsp;
	}

	@Override
	public GetGroupListReponse getGroupList(GetGroupListRequest req) {
		LOGGER.debug("getGroupList "+req.toString());
		String url="http://"+req.getIp()+":"+req.getPort1()+"/engine/static-api-wrapper/verify/target/gets";
		GetGroupListReponse rsp=new GetGroupListReponse();
		rsp.setResult(true);
		JSONObject jsonObject;
		try {
			String result = HtttpUtil.getCurlData(url);
			if(StringUtils.checkEmpty(result))
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
				return rsp;
			}
			LOGGER.debug("getGroupList GPU result ------ "+result);
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		List<String> groups=new ArrayList<String>();
		GroupListOutVo grouplistoutvo=JSONObject.toJavaObject(jsonObject, GroupListOutVo.class);
		if(grouplistoutvo!=null)
		{
			String error=grouplistoutvo.getErrorMessage();
			String result_gpu=grouplistoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONArray userInfos = jsonObject.getJSONArray("data");
		if(userInfos!=null&&userInfos.size()>0)
		{
			for(int i=0;i<userInfos.size();i++)
			{
				JSONObject userinfoobject =(JSONObject) userInfos.get(i);
				GroupListVo userbean = (GroupListVo) JSONObject.parseObject(JSON.toJSONString(userinfoobject), GroupListVo.class);
				groups.add(userbean.getDbName());
			}
		}else
		{
			LOGGER.debug("userInfos is null or size is 0 !");
		}
		rsp.setGroups(groups);
		return rsp;
	}

	@Override
	public DeleteGroupResponse deleteGroup(DeleteGroupRequest req) {
		LOGGER.debug("deleteGroup "+req.toString());
		Map<String, String> textMap = new HashMap<String, String>();
		DeleteGroupResponse rsp=new DeleteGroupResponse();
		rsp.setResult(true);
		textMap.put("dbName", req.getGroupname());
		//textMap.put("fastSearch", 1);
		String url="http://"+req.getIp()+":"+req.getPort1()+"/engine/static-api-wrapper/verify/target/deletes";
		JSONObject jsonObject;
		try {
			String result = HtttpUtil.httpPostFrom_data(url, textMap,null);
			if(StringUtils.checkEmpty(result))
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
				return rsp;
			}
			LOGGER.debug("initGroup GPU result ------ "+result);
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		GroupDeleteOutVo groupdeleteoutvo=JSONObject.toJavaObject(jsonObject, GroupDeleteOutVo.class);
		if(groupdeleteoutvo!=null)
		{
			String error=groupdeleteoutvo.getErrorMessage();
			String result_gpu=groupdeleteoutvo.getResult();
			if(!"success".equals(result_gpu))
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G003.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		return rsp;
	}

}
