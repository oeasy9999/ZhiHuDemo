package com.ccb.suap.cloud.facegpups.model;

import java.util.Date;
public class GpumpRealFacedbModel {
	
	private String real_db_id;					//物理库主键
	private String gpu_name;					//GPU主机名
	private String gpu_face_db;					//GPU库名
	private String total_capacity;				//最大容量
	private String capacity;					//当前容量
	private String logic_db_id;					//逻辑库主键
	private String sequence_id;					//库序号
	private String work_version;				//工作版本
	private String work_state;					//工作状态
	private Date work_update_time;			//状态更新时间
	private GpumpGpuInfoModel gpumpGpuInfo;				//GPU信息列表
	
	public String getReal_db_id() {
		return real_db_id;
	}
	public void setReal_db_id(String real_db_id) {
		this.real_db_id = real_db_id;
	}
	public String getGpu_name() {
		return gpu_name;
	}
	public void setGpu_name(String gpu_name) {
		this.gpu_name = gpu_name;
	}
	public String getGpu_face_db() {
		return gpu_face_db;
	}
	public void setGpu_face_db(String gpu_face_db) {
		this.gpu_face_db = gpu_face_db;
	}
	public String getTotal_capacity() {
		return total_capacity;
	}
	public void setTotal_capacity(String total_capacity) {
		this.total_capacity = total_capacity;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	public String getLogic_db_id() {
		return logic_db_id;
	}
	public void setLogic_db_id(String logic_db_id) {
		this.logic_db_id = logic_db_id;
	}
	public String getSequence_id() {
		return sequence_id;
	}
	public void setSequence_id(String sequence_id) {
		this.sequence_id = sequence_id;
	}
	public String getWork_version() {
		return work_version;
	}
	public void setWork_version(String work_version) {
		this.work_version = work_version;
	}
	public String getWork_state() {
		return work_state;
	}
	public void setWork_state(String work_state) {
		this.work_state = work_state;
	}

	public Date getWork_update_time() {
		return work_update_time;
	}
	public void setWork_update_time(Date work_update_time) {
		this.work_update_time = work_update_time;
	}
	public GpumpGpuInfoModel getGpumpGpuInfo() {
		return gpumpGpuInfo;
	}
	public void setGpumpGpuInfo(GpumpGpuInfoModel gpumpGpuInfo) {
		this.gpumpGpuInfo = gpumpGpuInfo;
	}
	
	@Override
	public String toString() {
		return "GpumpRealFacedbModel [real_db_id=" + real_db_id + ", gpu_name=" + gpu_name + ", gpu_face_db="
				+ gpu_face_db + ", total_capacity=" + total_capacity + ", capacity=" + capacity + ", logic_db_id="
				+ logic_db_id + ", sequence_id=" + sequence_id + ", work_version=" + work_version + ", work_state="
				+ work_state + ", work_update_time=" + work_update_time + ", gpumpGpuInfo=" + gpumpGpuInfo + "]";
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
}
