package com.ccb.suap.cloud.facegpups.faceplus.vo.g001;

import java.io.Serializable;
import java.util.List;

public class ExtractWithDetectOutVo implements Serializable {

	private static final long serialVersionUID = -6322422754329611651L;
	private String time_used;
	private String reqid;
	private String delta_validation;
	private List<FaceVo> faces;
	private String error;
	private String Confidence;
	private String Feature;;
	public String getConfidence() {
		return Confidence;
	}
	public void setConfidence(String confidence) {
		Confidence = confidence;
	}
	public String getFeature() {
		return Feature;
	}
	public void setFeature(String feature) {
		Feature = feature;
	}
	public String getTime_used() {
		return time_used;
	}
	public void setTime_used(String timeUsed) {
		time_used = timeUsed;
	}
	public String getReqid() {
		return reqid;
	}
	public void setReqid(String reqid) {
		this.reqid = reqid;
	}
	public String getDelta_validation() {
		return delta_validation;
	}
	public void setDelta_validation(String deltaValidation) {
		delta_validation = deltaValidation;
	}
	public List<FaceVo> getFaces() {
		return faces;
	}
	public void setFaces(List<FaceVo> faces) {
		this.faces = faces;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	@Override
	public String toString() {
		return "ExtractWithDetectOutVo [time_used=" + time_used + ", reqid=" + reqid + ", delta_validation="
				+ delta_validation + ", faces=" + faces + ", error=" + error + ", Confidence=" + Confidence
				+ ", Feature=" + Feature + "]";
	}
	
}
