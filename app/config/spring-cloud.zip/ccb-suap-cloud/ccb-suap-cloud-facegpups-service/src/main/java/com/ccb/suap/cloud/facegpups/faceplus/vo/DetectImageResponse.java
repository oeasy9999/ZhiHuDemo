package com.ccb.suap.cloud.facegpups.faceplus.vo;

/**
 * 图片检测返回实例
 * @author zhanzifeng
 *
 */

public class DetectImageResponse {

	private String error;
	private boolean result;
	private String quality;
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getQuality() {
		return quality;
	}
	public void setQuality(String quality) {
		this.quality = quality;
	}
	@Override
	public String toString() {
		return "DetectImageResponse [error=" + error + ", result=" + result + ", quality=" + quality + "]";
	}
	
	

}
