package com.ccb.suap.cloud.facegpups.model;

/**
 * @author oeasy9999
 * @create 2020-05-28 10:44
 */
public class GpumpGpuDispatchModel {
  private String id;
  private String type;
  private String gpuName;
  private String stationId;
  private String stationName;
  private String deviceId;
  private String deviceName;
  private String state;
  private String remark;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getGpuName() {
    return gpuName;
  }

  public void setGpuName(String gpuName) {
    this.gpuName = gpuName;
  }

  public String getStationId() {
    return stationId;
  }

  public void setStationId(String stationId) {
    this.stationId = stationId;
  }

  public String getStationName() {
    return stationName;
  }

  public void setStationName(String stationName) {
    this.stationName = stationName;
  }

  public String getDeviceId() {
    return deviceId;
  }

  public void setDeviceId(String deviceId) {
    this.deviceId = deviceId;
  }

  public String getDeviceName() {
    return deviceName;
  }

  public void setDeviceName(String deviceName) {
    this.deviceName = deviceName;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getRemark() {
    return remark;
  }

  public void setRemark(String remark) {
    this.remark = remark;
  }

  @Override
  public String toString() {
    return "GpumpGpuDispatchModel{"
        + "id='" + id + '\''
        + ", type='" + type + '\''
        + ", gpuName='" + gpuName + '\''
        + ", stationId='" + stationId + '\''
        + ", stationName='" + stationName + '\''
        + ", deviceId='" + deviceId + '\''
        + ", deviceName='" + deviceName + '\''
        + ", state='" + state + '\''
        + ", remark='" + remark + '\''
        + '}';
  }
}
