package com.ccb.suap.cloud.facegpups.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;

@Mapper
public interface GpumpRealFacedbMapper {
	
	int count();
	
	GpumpRealFacedbModel select(@Param("real_db_id")String real_db_id);
	
	List<GpumpRealFacedbModel> selectBylogic_db_id(@Param("logic_db_id")String logic_db_id);
	
	List<GpumpRealFacedbModel> selectAll();
	
	int insert(GpumpRealFacedbModel model);
	
	int update(GpumpRealFacedbModel model);
	
	int delete(@Param("real_db_id")String real_db_id);
	
	int deleteByLogicDbId(@Param("logic_db_id")String logic_db_id);
}
