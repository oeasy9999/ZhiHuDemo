package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

public class VersionOutVo {

	private String result;
	private String errorMessage;
	private String verify_server;
	private String sdk;
	private String model;
	private String verify_algo_master;
	private String verify_algo_worker;
	private String verify_server_search;
	private String verify_server_http;
	private String batch_insert_tool;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getVerify_server() {
		return verify_server;
	}
	public void setVerify_server(String verify_server) {
		this.verify_server = verify_server;
	}
	public String getSdk() {
		return sdk;
	}
	public void setSdk(String sdk) {
		this.sdk = sdk;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getVerify_algo_master() {
		return verify_algo_master;
	}
	public void setVerify_algo_master(String verify_algo_master) {
		this.verify_algo_master = verify_algo_master;
	}
	public String getVerify_algo_worker() {
		return verify_algo_worker;
	}
	public void setVerify_algo_worker(String verify_algo_worker) {
		this.verify_algo_worker = verify_algo_worker;
	}
	public String getVerify_server_search() {
		return verify_server_search;
	}
	public void setVerify_server_search(String verify_server_search) {
		this.verify_server_search = verify_server_search;
	}
	public String getVerify_server_http() {
		return verify_server_http;
	}
	public void setVerify_server_http(String verify_server_http) {
		this.verify_server_http = verify_server_http;
	}
	public String getBatch_insert_tool() {
		return batch_insert_tool;
	}
	public void setBatch_insert_tool(String batch_insert_tool) {
		this.batch_insert_tool = batch_insert_tool;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "VersionOutVo [verify_server=" + verify_server + ", sdk=" + sdk + ", model=" + model
				+ ", verify_algo_master=" + verify_algo_master + ", verify_algo_worker=" + verify_algo_worker
				+ ", verify_server_search=" + verify_server_search + ", verify_server_http=" + verify_server_http
				+ ", batch_insert_tool=" + batch_insert_tool + "]";
	}
	
}
