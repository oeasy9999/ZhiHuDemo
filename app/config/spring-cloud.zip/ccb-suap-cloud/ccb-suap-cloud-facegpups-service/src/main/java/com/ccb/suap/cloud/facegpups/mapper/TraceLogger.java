package com.ccb.suap.cloud.facegpups.mapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.util.log.MyFileLogger;
import com.ccb.suap.util.log.TraceLog;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class TraceLogger {
	protected static final Logger common_logger = LoggerFactory.getLogger(TraceLogger.class);
	private static Map<String,Logger> loggerMap = new HashMap<String,Logger>();
	private static Object lock1 = new Object();
	/**
	 * 打印缓存日志方法
	 * @param traceLog  报文日志缓存类
	 * @return
	 */
	public boolean dispose(TraceLog traceLog) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		traceLog.setEndTime(System.currentTimeMillis());

		//1.总开关判定----------------------------------------
		boolean logFlag = true;
		if(traceLog == null || !logFlag)
			return false;


		//3.计算日志名----------------------------------------
		String logName = traceLog.getLogName();
		if(logName.startsWith("/")){
			logName = logName.substring(1);
		}
		logName = logName.replaceAll("/", "_");

		//4.计算各种耗时----------------------------------------
		long startTime = traceLog.getStartTime();
		long endTime = traceLog.getEndTime();
		long httpcost = traceLog.getHttpcost();

		long totalcost = endTime - startTime;

		long codecost = totalcost - httpcost;

		String logPath=SysParaUtil.getStrValue("LogPath:1","./logs");
		String maxFileSize=SysParaUtil.getStrValue("MaxFileSize:1","100mb");
		String totalSizeCap=SysParaUtil.getStrValue("TotalSizeCap:1","100gb");
		String maxHistorySize=SysParaUtil.getStrValue("MaxHistorySize:1","168");
		//获取日志logger对象----------------------------------------
		Logger logger = null;
		synchronized(lock1) {
			logger = loggerMap.get(logName);
			if(logger == null) {
				logger = MyFileLogger.getLogger(logName,logPath,maxFileSize,totalSizeCap,maxHistorySize);
				loggerMap.put(logName, logger);
			}
		}

		//7logger写入日志----------------------------------------
		synchronized(logger) {
			logger.info("============ [  summary  ] ============");
			logger.info("CCB-Trace-Id     : " + traceLog.getTraceId());
			logger.info("Request-url      : " + traceLog.getUrl());
			logger.info("Start Time       : " + sdf.format(new Date(startTime)));
			logger.info("End Rime         : " + sdf.format(new Date(endTime)));
			logger.info("============ [  request_client  ] ============");
			logger.info("HttpRequestBody_client  : ");
			logger.info(traceLog.getRequestJsonString_client());
			
			if(traceLog.getRequestJsonString_detectImage()!=null&&!"".equals(traceLog.getRequestJsonString_detectImage()))
			{
				logger.info("============ [  request_detectImage  ] ============");
				logger.info("HttpRequestBody  : ");
				logger.info(traceLog.getRequestJsonString_detectImage());
			}
			if(traceLog.getResponseJsonString_detectImage()!=null&&!"".equals(traceLog.getResponseJsonString_detectImage()))
			{
				logger.info("============ [ response_detectImage  ] ============");
				logger.info("HttpResponseBody : ");
				logger.info(traceLog.getResponseJsonString_detectImage());
				logger.info("DetectImage Use Time : "+traceLog.getDetectImageTime());
			}
			
			if(traceLog.getRequestJsonString_getFeature()!=null&&!"".equals(traceLog.getRequestJsonString_getFeature()))
			{
				logger.info("============ [  request_getFeature  ] ============");
				logger.info("HttpRequestBody  : ");
				logger.info(traceLog.getRequestJsonString_getFeature());
			}
			if(traceLog.getResponseJsonString_getFeature()!=null&&!"".equals(traceLog.getResponseJsonString_getFeature()))
			{
				logger.info("============ [ response_getFeature  ] ============");
				logger.info("HttpResponseBody : ");
				logger.info(traceLog.getResponseJsonString_getFeature());
				logger.info("GetFeature Use Time : "+traceLog.getGetFeatureTime());
			}
			
			if(traceLog.getRequestJsonString_compareFeature()!=null&&!"".equals(traceLog.getRequestJsonString_compareFeature()))
			{
				logger.info("============ [  request_compareFeature  ] ============");
				logger.info("HttpRequestBody  : ");
				logger.info(traceLog.getRequestJsonString_compareFeature());
			}
			if(traceLog.getResponseJsonString_compareFeature()!=null&&!"".equals(traceLog.getResponseJsonString_compareFeature()))
			{
				logger.info("============ [ response_compareFeature  ] ============");
				logger.info("HttpResponseBody : ");
				logger.info(traceLog.getResponseJsonString_compareFeature());
				logger.info("CompareFeature Use Time : "+traceLog.getCompareFeatureTime());
			}
			
			if(traceLog.getRequestJsonString_compareImage()!=null&&!"".equals(traceLog.getRequestJsonString_compareImage()))
			{
				logger.info("============ [  request_compareImage  ] ============");
				logger.info("HttpRequestBody  : ");
				logger.info(traceLog.getRequestJsonString_compareImage());
			}
			if(traceLog.getResponseJsonString_compareImage()!=null&&!"".equals(traceLog.getResponseJsonString_compareImage()))
			{
				logger.info("============ [ response_compareImage  ] ============");
				logger.info("HttpResponseBody : ");
				logger.info(traceLog.getResponseJsonString_compareImage());
				logger.info("CompareImage Use Time : "+traceLog.getCompareImageTime());
			}
			
			if(traceLog.getRequestJsonString_addFeature()!=null&&!"".equals(traceLog.getRequestJsonString_addFeature()))
			{
				logger.info("============ [  request_addFeature  ] ============");
				logger.info("HttpRequestBody  : ");
				logger.info(traceLog.getRequestJsonString_addFeature());
			}
			if(traceLog.getResponseJsonString_addFeature()!=null&&!"".equals(traceLog.getResponseJsonString_addFeature()))
			{
				logger.info("============ [ response_addFeature  ] ============");
				logger.info("HttpResponseBody : ");
				logger.info(traceLog.getResponseJsonString_addFeature());
				logger.info("AddFeature Use Time : "+traceLog.getAddFeatureTime());
			}
			
			if(traceLog.getRequestJsonString_searchFeature()!=null&&!"".equals(traceLog.getRequestJsonString_searchFeature()))
			{
				logger.info("============ [  request_searchFeature  ] ============");
				logger.info("HttpRequestBody  : ");
				logger.info(traceLog.getRequestJsonString_searchFeature());
			}
//			logger.info("============ [  detail   ] ============");
//			for(String str:traceLog.getLogDetailStrList()){
//				logger.info(str);
//			}
			if(traceLog.getResponseJsonString_searchFeature()!=null&&!"".equals(traceLog.getResponseJsonString_searchFeature()))
			{
				logger.info("============ [ response_searchFeature  ] ============");
				logger.info("HttpResponseBody : ");
				logger.info(traceLog.getResponseJsonString_searchFeature());
				logger.info("SearchFeature Use Time : "+traceLog.getSearchFeatureTime());
			}
			
			if(traceLog.getRequestJsonString_deleteFeature()!=null&&!"".equals(traceLog.getRequestJsonString_deleteFeature()))
			{
				logger.info("============ [  request_deleteFeature  ] ============");
				logger.info("HttpRequestBody  : ");
				logger.info(traceLog.getRequestJsonString_deleteFeature());
			}
			if(traceLog.getResponseJsonString_deleteFeature()!=null&&!"".equals(traceLog.getResponseJsonString_deleteFeature()))
			{
				logger.info("============ [ response_deleteFeature  ] ============");
				logger.info("HttpResponseBody : ");
				logger.info(traceLog.getResponseJsonString_deleteFeature());
				logger.info("DeleteFeature Use Time : "+traceLog.getDeleteFeatureTime());
			}
			
			logger.info("============ [ response_client  ] ============");
			logger.info("HttpResponseBody_client : ");
			logger.info(traceLog.getResponseJsonString_client());
			if(traceLog.getErrormessage()!=null)
			{
				logger.info("============ [ Errormessage  ] ============");
				logger.info(traceLog.getErrormessage());
			}
			logger.info("============ [ time cost ] ============");
			logger.info("Total Use Time   : " + totalcost);
			logger.info("Http Use Time    : " + httpcost);
			logger.info("Code Cost        : " + codecost);
			logger.info("#################################################################");
			logger.info("");
			traceLog=null;
		}

		return true;
	}

	
}
