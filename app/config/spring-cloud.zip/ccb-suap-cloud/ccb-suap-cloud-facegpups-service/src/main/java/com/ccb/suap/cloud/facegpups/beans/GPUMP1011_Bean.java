package com.ccb.suap.cloud.facegpups.beans;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.SearchFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.SearchFeatureResponse;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFidcustMapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;
import com.ccb.suap.cloud.facegpups.service.GpumpCustInfoService;
import com.ccb.suap.cloud.facegpups.service.RedisService;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.PhotoUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1011ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1011ServiceOutVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1011ServiceOutVo_Group;
import com.ccb.suap.cloud.facegpups.vo.ServiceInVoParam1002;
import com.ccb.suap.cloud.facegpups.vo.ServiceInVoParam1011;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.log.TraceLog;

/*
 * 人脸1:N识别，多库识别
 * */
public class GPUMP1011_Bean extends GPUMPBean{
	private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");
	private GpumpCustInfoService GpumpCustInfoService=GpumpDaoFactory.getDaoManager().getGpumpCustInfoService();
	private RedisService redisService=GpumpDaoFactory.getDaoManager().getRedisService();
	@Override
	public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {

		 boolean flag=true;
		 TxResponseMsgHead rspHeader =rspMsg.getTx_header();
		 GPUMP1011ServiceInVo invo=(GPUMP1011ServiceInVo) reqMsg.getTx_body().getEntity();
		 TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		 if(Com2.getGroupName()==null)
		 {
			 LOGGER.error("checkPara ---- GroupName can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
			 flag= false;
		 }else if(invo.getFace_image()==null)
		 {
			 LOGGER.error("checkPara ---- Face_image can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE);
			 flag= false;
		 }else if(Com2.getSysChannelID()==null)
		 {
			 LOGGER.error("checkPara ---- SysChannelID can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
			 flag= false;
		 }
		 if(invo.getHit_size()==null)
		 {
			 LOGGER.warn("checkPara ---- Hit_size is null,set Hit_size is 1");
			 invo.setHit_size("1");
		 }
		 if(invo.getThreshold()==null)
		 {
			 invo.setThreshold("95");
			 LOGGER.warn("checkPara ---- Threshold is null,set Threshold 95");
		 }
		 rspMsg.setTx_header(rspHeader);
		 return flag;
	}
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg,TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("---------调用GPUMP1011_Bean服务---------");
		LOGGER.debug("reqMsg: "+reqMsg.toString());
		TxResponseMsgBody rspMsgBody=new TxResponseMsgBody();

		if(!checkPara(rspMsg,reqMsg))
		{
			TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1011", null);
			return rspMsg;
		}
	
		//设置交易流程参数
		ServiceInVoParam1011 param=new ServiceInVoParam1011();
		setparam(param, logtime, reqMsg);
		saveFaceImageByUrl(param,traceLog);
		String GroupName=param.getGroupName();
		String[] groupname_list=GroupName.split(",");
		for(int k=0;k<groupname_list.length;k++)
		{
			String groupname=groupname_list[k];
 			param.setGroupName(groupname);
			//获取逻辑库
			genLogicFaceModel(param);
	
		/*	List<GpumpRealFacedbModel> gpumpRealFacedbModel_list=gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
			if(gpumpRealFacedbModel_list!=null)
			{
				param.setGpumpRealFacedbModel_list(gpumpRealFacedbModel_list);
				//获取gpu实例
				genGpuBean(param);
				//计算特征值
				getFeature(param,traceLog);	
				//比对人脸
				searchFeature(param,traceLog);
				
				List<String> similarity=param.getSimilarity();
				List<String> list=param.getList();
				GPUMP1011ServiceOutVo outvo=new GPUMP1011ServiceOutVo();
				*/
				GpumpLogicFacedbModel gpumpLogicFacedbModel = param.getGpumpLogicFacedbModel();
				GPUMP1011ServiceOutVo outvo=new GPUMP1011ServiceOutVo();
				List<GPUMP1011ServiceOutVo_Group> outvogrouplistAll = getAlloutVoList(gpumpLogicFacedbModel,param,traceLog);
		
				if(outvogrouplistAll == null || outvogrouplistAll.isEmpty())
				{
					//继续识别下一个库
					LOGGER.debug("check use is null!");
					outvo.setResult_list_size("0");
					outvo.setResult_list(new ArrayList<>());
					rspMsgBody.setEntity(outvo);
					rspMsg.setTx_body(rspMsgBody);
					continue;
				}else
				{
					LOGGER.debug("end to query user.");
					
					if(outvogrouplistAll!=null&&outvogrouplistAll.size()>0)
					{				
						List<GPUMP1011ServiceOutVo_Group> outvogrouplist = sort(outvogrouplistAll, Integer.valueOf(param.getHit_size()));
						outvo.setResult_list(outvogrouplist);
						outvo.setResult_list_size(outvogrouplist.size()+"");
						outvo.setGroupName(groupname);
						rspMsgBody.setEntity(outvo);
						break; //匹配到用户后结束循环
					}else
					{
						outvo.setResult_list_size("0");
						outvo.setResult_list(new ArrayList<>());
						rspMsgBody.setEntity(outvo);
					}
				}
		
		}
		
		
		TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1011",GpumpErrorInfoModel.NOERROR);
		rspMsg.setTx_body(rspMsgBody);
		//outvo.setCust_id(cust_id);
		LOGGER.debug("GPUMP1011_Bean end!");
		return rspMsg;
	}
	
	
	
	
	/**
	 * 获取客户信息
	 * @param param  交易流程参数
	 * @return
	 */
	public List<GPUMP1011ServiceOutVo_Group> genCustInfo(ServiceInVoParam1011 param)
	{
		List<String> list=param.getList();
		HashMap<String, Long> logtime = param.getLogtime();
		List<String> similarity = param.getSimilarity();
		String logic_db_id=param.getLogic_db_id();
		String real_db_id=param.getReal_db_id();
		
		List<GPUMP1011ServiceOutVo_Group> outvogrouplist=new ArrayList<GPUMP1011ServiceOutVo_Group>();
		for(int i=0;i<list.size();i++)//特征值id列表
		{
			String feature_id=list.get(i)+"";
			Long start = System.currentTimeMillis();
			GpumpFidcustMapModel gpumpFidcustMapModel=redisService.selectFidcustMapModelbyfeatureid(real_db_id, feature_id);			
			Long end = System.currentTimeMillis();
			//selectTime=selectTime+end-start;
			logtime.put("selectTime", logtime.get("selectTime")+end-start);
			if(gpumpFidcustMapModel!=null)
			{
				LOGGER.warn("feature_id : "+feature_id+" is exist for GpumpFidcustMap,Real_db_id is "+real_db_id);
				String cust_id=gpumpFidcustMapModel.getCust_id();
				start = System.currentTimeMillis();
				GpumpCustInfoModel gpumpCustInfoModel=redisService.selectCustInfo(logic_db_id, cust_id);
				end = System.currentTimeMillis();
				//selectTime=selectTime+end-start;
				logtime.put("selectTime", logtime.get("selectTime")+end-start);
				if(gpumpCustInfoModel!=null)
				{
					LOGGER.warn("cust_id : "+cust_id+" is exist for gpumpCustInfo.");
					gpumpCustInfoModel.setRecognition_time(new Date());
					start = System.currentTimeMillis();
					int ret=GpumpCustInfoService.update(gpumpCustInfoModel);
					end = System.currentTimeMillis();
					//updateTime=updateTime+end-start;
					logtime.put("updateTime", logtime.get("updateTime")+end-start);
					if(ret!=0)
					{
						LOGGER.error("cust_id : "+cust_id+" update error for gpumpCustInfo!");
					}
					GPUMP1011ServiceOutVo_Group outvogroup=new GPUMP1011ServiceOutVo_Group();
					outvogroup.setCust_id(gpumpFidcustMapModel.getCust_id());
					outvogroup.setId_no(gpumpCustInfoModel.getId_no());
					outvogroup.setId_type(gpumpCustInfoModel.getId_type());
					outvogroup.setName(gpumpCustInfoModel.getName());
					outvogroup.setMobile_no(gpumpCustInfoModel.getMobile_no());
					outvogroup.setFace_collecttime(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(gpumpCustInfoModel.getModify_time()));
					outvogroup.setSimilarity(similarity.get(i));
					outvogrouplist.add(outvogroup);
				}else
				{
					LOGGER.warn("cust_id "+cust_id+" is not exist for gpumpCustInfo.");
				}
			}else
			{
				LOGGER.warn("feature_id "+feature_id+" is not exist for gpumpFidcustMap.");
			}
		}
		return outvogrouplist;
	}
	
	public List<GPUMP1011ServiceOutVo_Group> getAlloutVoList(GpumpLogicFacedbModel gpumpLogicFacedbModel,ServiceInVoParam1011 param,TraceLog traceLog){
		List<GPUMP1011ServiceOutVo_Group> outvogrouplistAll = new 	ArrayList<GPUMP1011ServiceOutVo_Group>();
		if("T".equals(gpumpLogicFacedbModel.getIs_mount_pag())){//挂载页位库
			//查询属于该逻辑库的分页库
			List<GpumpLogicFacedbModel> gpumpLogicFacedbModelList= ServiceParaUtil.getLogicFacedbValueBySourceDbId(gpumpLogicFacedbModel.getLogic_db_id(),"3");
			if(gpumpLogicFacedbModelList==null){
				LOGGER.error("page gpumpLogicFacedbModelList is null!");
				throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
			}
			for(int i=0; i<gpumpLogicFacedbModelList.size();i++){
		    	GpumpLogicFacedbModel gpumpLogicFacedbModel1 = gpumpLogicFacedbModelList.get(i);
		    	param.setGpumpLogicFacedbModel(gpumpLogicFacedbModel1);
	    		List<GpumpRealFacedbModel> gpumpRealFacedbModel_list=gpumpLogicFacedbModel1.getGpumpRealFacedbModelList();
	    		if(gpumpRealFacedbModel_list==null)
				{
	    			LOGGER.error("gpumpRealFacedbModel_list is null!");
	    			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR)); 
				}
	        
				//获取gpu实例
	    	   	genGpuBean(param);
			
	        	try {
	        	 	 ThreadDemo mc=new ThreadDemo(param,traceLog);
	            	 FutureTask<List<GPUMP1011ServiceOutVo_Group>> ft=new FutureTask<List<GPUMP1011ServiceOutVo_Group>>(mc);
	            	 new Thread(ft).start();
	         	   	 List<GPUMP1011ServiceOutVo_Group> outListAll = ft.get();
	         	   	 LOGGER.error("比对信息"+outListAll);
	         	     outvogrouplistAll.addAll(outListAll);
				} catch (Exception e) {
					LOGGER.error("searchFeature error!");
					throw new CommonRuntimeException(GpumpErrorInfoModel.GPUSEARCHERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUSEARCHERROR));
				} 
			
			}
		
		}else{
			List<GpumpRealFacedbModel> gpumpRealFacedbModel_list=gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
			if(gpumpRealFacedbModel_list!=null)
			{
				param.setGpumpRealFacedbModel_list(gpumpRealFacedbModel_list);
				//获取gpu实例
				genGpuBean(param);
				//计算特征值
				String feature=getFeature(param,traceLog);	
				//比对人脸
				searchFeature(param,feature,traceLog);
				List<String> list=param.getList();
				List<String> similarity = param.getSimilarity();
				if(list==null||similarity==null)
				{
					//继续识别下一个库
					return null;
				}
				outvogrouplistAll = genCustInfo(param);
			}else{
    			LOGGER.error("gpumpRealFacedbModel_list is null!");
    			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR)); 
			}

		}
		return outvogrouplistAll;
}
	

	class ThreadDemo implements Callable<List<GPUMP1011ServiceOutVo_Group>>{
		   ServiceInVoParam1011 param = null;
		   TraceLog traceLog = null;
		
		   public ThreadDemo(ServiceInVoParam1011 param,TraceLog traceLog) {  
		        this.param = param;  
		        this.traceLog=traceLog;
		       
		    }  
			@Override
			public List<GPUMP1011ServiceOutVo_Group> call() throws Exception {
				//计算特征值
            	String feature=getFeature(param,traceLog);
				ServiceInVoParam1011 paramlast2 = searchFeature(param,feature,traceLog);
				List<GPUMP1011ServiceOutVo_Group> outvogrouplist = new ArrayList<>();
				List<String> similarity=param.getSimilarity();
				List<String> list=param.getList();
				if(list!=null||similarity!=null){
    					outvogrouplist = genCustInfo(paramlast2);
    					LOGGER.error("分组比对信息："+outvogrouplist);
    				}
				return outvogrouplist;
			}
    }
	
	
	/**
	 * 计算特征值
	 * @param param 		交易流程数据类
	 * @param traceLog 		报文日志缓存类
	 */
	public String  getFeature(ServiceInVoParam1011 param,TraceLog traceLog)
	{
		LOGGER.debug("begin to extract for gpu.");
		GpumpGpuInfoModel gpumpGpuInfoModel = param.getGpumpGpuInfoModel();
		String face_image=param.getFace_image();
		String extractflag=param.getExtractflag();
		String traceid=param.getTraceid();
		GpuInterface gpuBean = param.getGpuBean();
		HashMap<String, Long> logtime = param.getLogtime();
		GetFeatureRequest gpuinvo=new GetFeatureRequest();
		gpuinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
		gpuinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
		gpuinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
		gpuinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
		gpuinvo.setImage(face_image);
		gpuinvo.setExtractflag(extractflag);
		gpuinvo.setTraceid(traceid);
		long start = System.currentTimeMillis();
		GetFeatureResponse getfeatureresponse = gpuBean.getFeature(gpuinvo,traceLog);
		long end = System.currentTimeMillis();
		//extractForGpuTime=extractForGpuTime+end-start;
		traceLog.setGetFeatureTime(traceLog.getGetFeatureTime()+end-start);
		logtime.put("extractForGpuTime", logtime.get("extractForGpuTime")+end-start);
		LOGGER.debug(getfeatureresponse.toString());
		
		if(!getfeatureresponse.getResult())
		{
			LOGGER.error("getfeature error,errormessage is : "+getfeatureresponse.getError());
			throw new CommonRuntimeException(getfeatureresponse.getError(),GpumpErrorInfoParaUtil.getErrorMsg(getfeatureresponse.getError()));
		}
		
		String feature=getfeatureresponse.getFeature();
		if(feature==null)
		{
			LOGGER.error("extract user error,feature is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.GPUDETECTERROR_FACESNULL,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUDETECTERROR_FACESNULL));	
		}
		param.setFeature(feature);
		LOGGER.debug("end to extract for gpu,feature is : "+feature);
		return feature;
	}
	/**
	 * 比对人脸，比对失败抛出异常
	 * @param param 		交易流程数据类
	 * @param traceLog		报文日志缓存类
	 */
	public ServiceInVoParam1011  searchFeature(ServiceInVoParam1011 param,String feature,TraceLog traceLog)
	{
		GpumpGpuInfoModel gpumpGpuInfoModel = param.getGpumpGpuInfoModel();
		HashMap<String, Long> logtime = param.getLogtime();
		String gpu_face_db=param.getGpu_face_db();
		String hit_size=param.getHit_size();
		String threshold=param.getThreshold();
		String traceid=param.getTraceid();
		GpuInterface gpuBean = param.getGpuBean();
		SearchFeatureRequest groupsearchinvo=new SearchFeatureRequest();
		groupsearchinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
		groupsearchinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
		groupsearchinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
		groupsearchinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
		groupsearchinvo.setGroupname(gpu_face_db);
		groupsearchinvo.setFeature(feature);
		groupsearchinvo.setHitsize(hit_size);
		groupsearchinvo.setThreshold(threshold);
		groupsearchinvo.setTraceid(traceid);
		Long start = System.currentTimeMillis();
		SearchFeatureResponse searchfeatureresponse = gpuBean.searchFeature(groupsearchinvo,traceLog);
		Long end = System.currentTimeMillis();
		//searchForGpuTime=searchForGpuTime+end-start;
		logtime.put("searchForGpuTime", logtime.get("searchForGpuTime")+end-start);
		traceLog.setSearchFeatureTime(traceLog.getSearchFeatureTime()+end-start);
		LOGGER.debug(searchfeatureresponse.toString());
		if(!searchfeatureresponse.getResult())
		{
			LOGGER.error("searchFeature user error!message is "+searchfeatureresponse.getError()+" : "+GpumpErrorInfoParaUtil.getErrorMsg(searchfeatureresponse.getError()));
			throw new CommonRuntimeException(searchfeatureresponse.getError(),GpumpErrorInfoParaUtil.getErrorMsg(searchfeatureresponse.getError()));
		}
		
		List<String> similarity=searchfeatureresponse.getScores();
		List<String> list=searchfeatureresponse.getFeatureids();
		param.setList(list);
		param.setSimilarity(similarity);
		int num;
		if(list==null)
		{
			num=0;
		}else
		{
			num=list.size();
		}
		LOGGER.debug("end to search for gpu,find "+num+" use");
		return param;
	}
	/**
	 * 获取gpu实例
	 * @param param 交易流程参数
	 */
	public void genGpuBean(ServiceInVoParam1011 param)
	{
		GpumpLogicFacedbModel gpumpLogicFacedbModel = param.getGpumpLogicFacedbModel();
		List<GpumpRealFacedbModel> gpumpRealFacedbModel_list = gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
		GpumpRealFacedbModel gpumpRealFacedbModel=gpumpRealFacedbModel_list.get((int)(Math.random()*gpumpRealFacedbModel_list.size()));//随机获取一个物理库
		
		GpumpGpuInfoModel gpumpGpuInfoModel=gpumpRealFacedbModel.getGpumpGpuInfo();
		if(gpumpGpuInfoModel==null)
		{
			LOGGER.error("gpumpGpuInfoModel is null,real_db_id is : "+gpumpRealFacedbModel.getReal_db_id());
			throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
		}
		String gpu_type_id=gpumpGpuInfoModel.getGpu_type_id();
		String Real_db_id=gpumpRealFacedbModel.getReal_db_id();
		String Gpu_face_db=gpumpRealFacedbModel.getGpu_face_db();
		String gpuclassname="com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gpu_type_id + "_Bean";
		GpuInterface gpuBean=(GpuInterface) Utils.getInstance(gpuclassname);
		if(gpuBean==null)
		{
			LOGGER.error("GPUMP "+gpu_type_id+" service is no exist!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.GPUGROUPERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUGROUPERROR));
		}
		param.setGpumpGpuInfoModel(gpumpGpuInfoModel);
		param.setGpu_face_db(Gpu_face_db);
		param.setReal_db_id(Real_db_id);
		param.setGpuBean(gpuBean);
	
	}
	/**
	 * 获取逻辑库实例方法，设置到流程数据实例内
	 * @param param 交易流程数据类
	 */
	public void genLogicFaceModel(ServiceInVoParam1011 param)
	{
		String sysChannelID = param.getSysChannelID();
		String groupName = param.getGroupName();
		GpumpLogicFacedbModel gpumpLogicFacedbModel=ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID+":"+groupName);
		if(gpumpLogicFacedbModel==null)
		{
			LOGGER.error("gpumpLogicFacedbModel is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
		}
		String Logic_db_id=null;//注册库逻辑库id
		String extractflag=null;
		if(gpumpLogicFacedbModel.getType().equals("1"))
		{
			Logic_db_id=gpumpLogicFacedbModel.getLogic_db_id();
			String Is_mount_gpu=gpumpLogicFacedbModel.getIs_mount_gpu();
			extractflag=gpumpLogicFacedbModel.getVerify_param1();
			if(Is_mount_gpu==null||!Is_mount_gpu.equals("T")) //如果是注册库且没有挂载GPU
			{
				LOGGER.error("register Logic_db_id "+Logic_db_id+" have no mount gpu");
				throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBMOUNTGPUERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBMOUNTGPUERROR));
			}
		}else
		{
			GpumpLogicFacedbModel gpumpLogicFacedbModel_register=ServiceParaUtil.getAllGpuDBMsgByID(gpumpLogicFacedbModel.getSource_db_id());
			Logic_db_id=gpumpLogicFacedbModel_register.getLogic_db_id();
			extractflag=gpumpLogicFacedbModel.getVerify_param1();
		}
		param.setGpumpLogicFacedbModel(gpumpLogicFacedbModel);
		param.setLogic_db_id(Logic_db_id);
		param.setExtractflag(extractflag);
	}
	/**
	 * 设置服务流程参数方法
	 * @param param 流程数据类
	 * @param logtime 各环节耗时缓存
	 * @param reqMsg 请求数据
	 */
	void setparam(ServiceInVoParam1011 param,HashMap<String, Long> logtime,TxRequestMsg reqMsg)
	{
		TxRequestMsgHead reqMsgHead=reqMsg.getTx_header();
		String traceid=reqMsgHead.getSys_evt_trace_id();
		logtime.put("updateTime", (long) 0);
		logtime.put("selectTime", (long) 0);
		logtime.put("extractForGpuTime", (long) 0);
		logtime.put("searchForGpuTime", (long) 0);
		logtime.put("saveFileTime", (long) 0);
		GPUMP1011ServiceInVo invo=(GPUMP1011ServiceInVo)reqMsg.getTx_body().getEntity();
		TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		String GroupName=Com2.getGroupName();
		String sysChannelID=Com2.getSysChannelID();
		param.setTraceid(traceid);
		param.setLogtime(logtime);
		param.setHit_size(invo.getHit_size());
		param.setThreshold(invo.getThreshold());
		param.setSysChannelID(sysChannelID);
		param.setGroupName(GroupName);
		param.setFace_image(invo.getFace_image());
	}
	@Override
    public Object transform(JSONObject indata) throws Exception {
		// TODO Auto-generated method stub
		JSONObject tx_body=indata.getJSONObject("tx_body");
		if(tx_body==null)
		{
			LOGGER.error("tx_body is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject entity=tx_body.getJSONObject("entity");
		if(entity==null)
		{
			LOGGER.error("entity is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject com2=tx_body.getJSONObject("com2");
		if(com2==null)
		{
			LOGGER.error("com2 is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		TxRequestMsg reqMsg=(TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
		GPUMP1011ServiceInVo invo=(GPUMP1011ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1011ServiceInVo.class);;
		TxRequestMsgCom2 com=JSON.parseObject(JSON.toJSONString(com2),TxRequestMsgCom2.class);
		TxRequestMsgBody MsgBody=reqMsg.getTx_body();
		MsgBody.setEntity(invo);
		MsgBody.setCom2(com);
		reqMsg.setTx_body(MsgBody);
		return reqMsg;
	}

	@Override
	public List<GpuRegisterTask> getGpuTask(){
		// TODO Auto-generated method stub
		return null;
	}

	public static List<GPUMP1011ServiceOutVo_Group> sort(List<GPUMP1011ServiceOutVo_Group> list,Integer num){
		list.sort(Comparator.comparing(GPUMP1011ServiceOutVo_Group::getSimilarity).reversed());
		List<GPUMP1011ServiceOutVo_Group> gPUMP1011ServiceOutVo_GroupList= new ArrayList<GPUMP1011ServiceOutVo_Group>();
		if(list.size()<num){
			num = list.size();
		}
		for(int i=0; i<num;i++){
			GPUMP1011ServiceOutVo_Group group = list.get(i);
			gPUMP1011ServiceOutVo_GroupList.add(group);
		}
		return gPUMP1011ServiceOutVo_GroupList;
	}
	
	public static List<Double> StringtoDouble(List<String> similarity ){
		List<Double> doubleList = new ArrayList<Double>();
		for(int i=0;i<similarity.size();i++){
			Double similari=Double.parseDouble(similarity.get(i));
			doubleList.add(similari);
		}
		return doubleList;
	}
	 /**
	   * 保存图片到nas目录，目录 yyyyMMddHHmm，每10分钟一个目录 文件名 客户号_yyyyMMddHHmmss.jpg
	   *
	   * @param param 交易流程数据类
	 * @throws IOException 
	   */
	  public void saveFaceImageByUrl(ServiceInVoParam1011 param,TraceLog traceLog) throws IOException {
		  String logImgCof=SysParaUtil.getStrPara("LOGIMGCOF:1","1");
		  if("1".equals(logImgCof)){
		    String sysChannelID = param.getSysChannelID();
		    String face_image = param.getFace_image();
		    HashMap<String, Long> logtime = param.getLogtime();
			String log_mage_addr_nas = PhotoUtil.getPath("image_addr:1", "/"+sysChannelID+"/faceComplmage", "GPUMP1011_"+param.getTraceid());
			traceLog.setFace_image(face_image);
		    traceLog.setLog_image_addr_nas(log_mage_addr_nas);
	    }
	  }
}
