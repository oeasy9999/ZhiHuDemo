package com.ccb.suap.cloud.facegpups.model;

public class GpumpChannelInfoModel {
	
	private String channel_id;				//渠道号
	private String channel_desc;			//渠道描述
	private String channel_state;			//状态
	
	public String getChannel_id() {
		return channel_id;
	}
	public void setChannel_id(String channel_id) {
		this.channel_id = channel_id;
	}
	public String getChannel_desc() {
		return channel_desc;
	}
	public void setChannel_desc(String channel_desc) {
		this.channel_desc = channel_desc;
	}
	public String getChannel_state() {
		return channel_state;
	}
	public void setChannel_state(String channel_state) {
		this.channel_state = channel_state;
	}
	
	@Override
	public String toString() {
		return "GpumpChannelInfoModel [channel_id=" + channel_id + ", channel_desc=" + channel_desc + ", channel_state="
				+ channel_state + "]";
	}
	
	
	
	
	
	
	
	
}
