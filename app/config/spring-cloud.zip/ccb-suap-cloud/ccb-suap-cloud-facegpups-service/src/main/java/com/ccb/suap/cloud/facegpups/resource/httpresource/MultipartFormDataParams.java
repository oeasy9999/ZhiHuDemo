package com.ccb.suap.cloud.facegpups.resource.httpresource;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * HTTP请求 以 multipart/form-data方式发送请求参数类
 * @author pengdy
 *
 */
public class MultipartFormDataParams {

	private Map<String, String> textMap = new HashMap<String, String>();
	private Map<String, MultipartFile> fileMap = new HashMap<String, MultipartFile>();
	
	public void addTextParams(String name, String value) {
		this.textMap.put(name, value);
	}
	/**
	 * 默认image/jpeg 文件类型
	 * @param name 文件参数名
	 * @param value 文件MultipartFile Base64字符串内容
	 */
	public void addFileParams(String name, String value) {
		MultipartFile multipartFile = new MultipartFile();
		multipartFile.setExt(MultipartFile.jpeg_ext);
		multipartFile.setFileBase64(value);
		this.fileMap.put(name, multipartFile);
	}
	
	public String toParams() {
		StringBuffer sb = new StringBuffer();
		for(Iterator<String> it=textMap.keySet().iterator();it.hasNext();) {
			String key = (String) it.next();
			Object value = textMap.get(key);
			sb.append(key).append("=").append(value).append("&");
		}
		return sb.toString();
	}
	
	public void addFileParams(String name, MultipartFile value) {
		this.fileMap.put(name, value);
	}
	public Map<String, String> getTextMap() {
		return textMap;
	}
	public void setTextMap(Map<String, String> textMap) {
		this.textMap = textMap;
	}
	public Map<String, MultipartFile> getFileMap() {
		return fileMap;
	}
	public void setFileMap(Map<String, MultipartFile> fileMap) {
		this.fileMap = fileMap;
	}
	
}
