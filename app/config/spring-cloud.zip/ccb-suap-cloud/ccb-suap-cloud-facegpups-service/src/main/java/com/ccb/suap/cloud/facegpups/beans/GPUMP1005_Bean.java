package com.ccb.suap.cloud.facegpups.beans;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFidcustMapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;
import com.ccb.suap.cloud.facegpups.service.RedisService;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1005ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1005ServiceOutVo;
import com.ccb.suap.util.log.TraceLog;
/*
 *人脸信息查询是否存在
 * */
public class GPUMP1005_Bean extends GPUMPBean{
	private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");
	private RedisService redisService=GpumpDaoFactory.getDaoManager().getRedisService();
	@Override
	public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		// TODO Auto-generated method stub
		 boolean flag=true;
		 TxResponseMsgHead rspHeader =rspMsg.getTx_header();
		 GPUMP1005ServiceInVo invo=(GPUMP1005ServiceInVo) reqMsg.getTx_body().getEntity();
		 TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		 if(invo.getCust_id()==null)
		 {
			 LOGGER.error("checkPara ---- Cust_id can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID);
			 flag= false;
		 }else if(Com2.getGroupName()==null)
		 {
			 LOGGER.error("checkPara ---- GroupName can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
			 flag= false;
		 }else if(Com2.getSysChannelID()==null)
		 {
			 LOGGER.error("checkPara ---- SysChannelID can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
			 flag= false;
		 }
		 rspMsg.setTx_header(rspHeader);
		return flag;
	}

	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg,TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws Exception {
		// TODO Auto-generated method stub
		LOGGER.debug("---------调用GPUMP1005_Bean服务---------");
		//LOGGER.debug("reqMsg: "+reqMsg.toString());
		TxResponseMsgBody rspMsgBody=new TxResponseMsgBody();
		GPUMP1005ServiceOutVo outvo=new GPUMP1005ServiceOutVo();
		//TxRequestMsgHead reqMsgHead=reqMsg.getTx_header();
		if(!checkPara(rspMsg,reqMsg))
		{
			TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1005", null);
			return rspMsg;
		}
		logtime.put("selectTime", (long) 0);
		GPUMP1005ServiceInVo invo=(GPUMP1005ServiceInVo)reqMsg.getTx_body().getEntity();
		TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		String GroupName=Com2.getGroupName();
		String sysChannelID=Com2.getSysChannelID();
		LOGGER.debug("GroupName is "+GroupName);
		LOGGER.debug("sysChannelID is "+sysChannelID);
		String Logic_db_id=null;
		GpumpLogicFacedbModel gpumpLogicFacedbModel=ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID+":"+GroupName);
	
		if( gpumpLogicFacedbModel==null)
		{
			LOGGER.error("gpumpLogicFacedb is not exist!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
		}
		String is_mount_pag = gpumpLogicFacedbModel.getIs_mount_pag();
		Logic_db_id=gpumpLogicFacedbModel.getLogic_db_id();
		LOGGER.debug("Logic_db_id is "+Logic_db_id+",type is : "+gpumpLogicFacedbModel.getType());
		if("1".equals(gpumpLogicFacedbModel.getType())&&!"T".equals(is_mount_pag))//注册库并且没有挂载分页库
		{
			Logic_db_id=gpumpLogicFacedbModel.getLogic_db_id();
			LOGGER.debug("this is a register base,Logic_db_id is "+Logic_db_id);
			long start = System.currentTimeMillis();
			GpumpCustInfoModel gpumpCustInfoModel=redisService.selectCustInfo(Logic_db_id, invo.getCust_id());
			long end = System.currentTimeMillis();
			//selectTime=selectTime+end-start;
			logtime.put("selectTime", logtime.get("selectTime")+end-start);
			if(gpumpCustInfoModel==null)
			{
				LOGGER.debug("cust_id "+invo.getCust_id()+" is no exist");
				outvo.setIsexist("0");
			}else
			{
				LOGGER.debug("cust_id "+invo.getCust_id()+" is exist.");
				outvo.setIsexist("1");
			}
		}else{
			List<GpumpRealFacedbModel> gpumpRealFacedbModelList = gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
			if(gpumpRealFacedbModelList==null)
			{
				LOGGER.debug("cust_id "+invo.getCust_id()+" is no exist");
				outvo.setIsexist("0");
			}else
			{
				boolean flag=false;
				for(GpumpRealFacedbModel gpumpRealFacedbModel:gpumpRealFacedbModelList)
				{
					String real_db_id=gpumpRealFacedbModel.getReal_db_id();
					GpumpFidcustMapModel gpumpFidcustMapModel =redisService.selectFidcustMapModel(real_db_id, invo.getCust_id());
					if(gpumpFidcustMapModel!=null)
					{
						LOGGER.debug("cust_id "+invo.getCust_id()+" is exist.");
						outvo.setIsexist("1");
						flag=true;
						break;//找到一个就行
					}
				}
				if(flag)
				{
					LOGGER.debug("cust_id "+invo.getCust_id()+" is exist.");
					outvo.setIsexist("1");
				}else
				{
					LOGGER.debug("cust_id "+invo.getCust_id()+" is no exist");
					outvo.setIsexist("0");
				}
			}
			Logic_db_id=gpumpLogicFacedbModel.getLogic_db_id();
			LOGGER.debug("this is a fast base,Logic_db_id is "+gpumpLogicFacedbModel.getLogic_db_id());
			LOGGER.debug("register base Logic_db_id is "+Logic_db_id);
		}
		TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1005", GpumpErrorInfoModel.NOERROR);
		rspMsgBody.setEntity(outvo);
		rspMsg.setTx_body(rspMsgBody);
		LOGGER.debug("GPUMP1005_Bean end!");
		return rspMsg;
	}

	@Override
    public Object transform(JSONObject indata) throws Exception {
		// TODO Auto-generated method stub
		JSONObject tx_body=indata.getJSONObject("tx_body");
		if(tx_body==null)
		{
			LOGGER.error("tx_body is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject entity=tx_body.getJSONObject("entity");
		if(entity==null)
		{
			LOGGER.error("entity is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject com2=tx_body.getJSONObject("com2");
		if(com2==null)
		{
			LOGGER.error("com2 is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		TxRequestMsg reqMsg=(TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
		GPUMP1005ServiceInVo invo=(GPUMP1005ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1005ServiceInVo.class);;
		TxRequestMsgCom2 com=JSON.parseObject(JSON.toJSONString(com2),TxRequestMsgCom2.class);
		TxRequestMsgBody MsgBody=reqMsg.getTx_body();
		MsgBody.setEntity(invo);
		MsgBody.setCom2(com);
		reqMsg.setTx_body(MsgBody);
		return reqMsg;
	}

	@Override
	public List<GpuRegisterTask> getGpuTask(){
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public String getTime() {
//		StringBuffer cmmpLog = new StringBuffer();
//		cmmpLog.append("selectTime<").append(selectTime).append("> ");
//		return cmmpLog.toString();
//	}
}
