package com.ccb.suap.cloud.facegpups.faceplus.vo.g001;

import java.util.List;

public class GroupListOutVo implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1L;
	private String result;
	private List<String>groups;
	private String error;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public List<String> getGroups() {
		return groups;
	}
	public void setGroups(List<String> groups) {
		this.groups = groups;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
}
