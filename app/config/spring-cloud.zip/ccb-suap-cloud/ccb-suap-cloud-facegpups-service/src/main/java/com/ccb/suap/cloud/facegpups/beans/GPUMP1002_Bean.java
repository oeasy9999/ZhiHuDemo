package com.ccb.suap.cloud.facegpups.beans;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.SearchFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.SearchFeatureResponse;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpFidcustMapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuDispatchModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;
import com.ccb.suap.cloud.facegpups.service.RedisService;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpGpuDispatchParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.PhotoUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1002ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1002ServiceOutVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1002ServiceOutVo_Group;
import com.ccb.suap.cloud.facegpups.vo.ServiceInVoParam1001;
import com.ccb.suap.cloud.facegpups.vo.ServiceInVoParam1002;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.log.TraceLog;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

/*
 * 人脸1:N识别
 * */
public class GPUMP1002_Bean extends GPUMPBean {
  private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");
  private RedisService redisService = GpumpDaoFactory.getDaoManager().getRedisService();

  @Override
  public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {

    boolean flag = true;
    TxResponseMsgHead rspHeader = rspMsg.getTx_header();
    GPUMP1002ServiceInVo invo = (GPUMP1002ServiceInVo) reqMsg.getTx_body().getEntity();
    TxRequestMsgCom2 Com2 = reqMsg.getTx_body().getCom2();
    if (Com2.getGroupName() == null) {
      LOGGER.error("checkPara ---- GroupName can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
      flag = false;
    } else if (invo.getFace_image() == null) {
      LOGGER.error("checkPara ---- Face_image can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE);
      flag = false;
    } else if (Com2.getSysChannelID() == null) {
      LOGGER.error("checkPara ---- SysChannelID can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
      flag = false;
    }
    if (invo.getHit_size() == null) {
      LOGGER.warn("checkPara ---- Hit_size is null,set Hit_size is 1");
      invo.setHit_size("1");
    }
    if (invo.getThreshold() == null) {
      invo.setThreshold("95");
      LOGGER.warn("checkPara ---- Threshold is null,set Threshold 95");
    }
    rspMsg.setTx_header(rspHeader);
    return flag;
  }

  @Override
  public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,
      HashMap<String, Long> logtime, TraceLog traceLog) throws Exception {
    // TODO Auto-generated method stub
    LOGGER.debug("---------调用GPUMP1002_Bean服务---------");
    TxResponseMsgBody rspMsgBody = new TxResponseMsgBody();

    if (!checkPara(rspMsg, reqMsg)) {
      TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1002", null);
      return rspMsg;
    }

    //设置交易流程参数
    ServiceInVoParam1002 param = new ServiceInVoParam1002();
    setparam(param, logtime, reqMsg);

    //获取逻辑库信息
    genLogicFaceModel(param);
    //保存图片
    saveFaceImageByUrl(param,traceLog);
    
    GpumpLogicFacedbModel gpumpLogicFacedbModel = param.getGpumpLogicFacedbModel();

    if ("T".equals(gpumpLogicFacedbModel.getIs_mount_pag())) {
      //查询属于该逻辑库的分页库
      List<GpumpLogicFacedbModel> gpumpLogicFacedbModelList =
          ServiceParaUtil.getLogicFacedbValueBySourceDbId(gpumpLogicFacedbModel.getLogic_db_id(),
              "3");
      if (gpumpLogicFacedbModelList == null || gpumpLogicFacedbModelList.size() == 0) {
        LOGGER.error("page gpumpLogicFacedbModel is null!");
        throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,
            GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
      }

      List<GPUMP1002ServiceOutVo_Group> outvogrouplistAll =
          getAlloutVoList(gpumpLogicFacedbModelList, param, traceLog);

      LOGGER.error("汇总比对信息：" + outvogrouplistAll);
      GPUMP1002ServiceOutVo outvo = new GPUMP1002ServiceOutVo();

      if (outvogrouplistAll == null) {
        LOGGER.debug("check use is null!");
        outvo.setResult_list_size("0");
        outvo.setResult_list(new ArrayList<>());
        rspMsgBody.setEntity(outvo);
        rspMsg.setTx_body(rspMsgBody);
        TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1002", GpumpErrorInfoModel.NOERROR);
        return rspMsg;
      }
      List<GPUMP1002ServiceOutVo_Group> outvogrouplist =
          sort(outvogrouplistAll, Integer.valueOf(param.getHit_size()));
      LOGGER.debug("end to query user.");
      outvo.setResult_list(outvogrouplist);
      outvo.setResult_list_size(outvogrouplist.size() + "");
      rspMsgBody.setEntity(outvo);

      TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1002", GpumpErrorInfoModel.NOERROR);
      rspMsg.setTx_body(rspMsgBody);
      //outvo.setCust_id(cust_id);
      LOGGER.debug("GPUMP1002_Bean end!");
      return rspMsg;
    }

    List<GpumpRealFacedbModel> gpumpRealFacedbModel_list =
        gpumpLogicFacedbModel.getGpumpRealFacedbModelList();

    if (gpumpRealFacedbModel_list != null) {

      //获取gpu实例
      genGpuBean(param, gpumpRealFacedbModel_list);
      //计算特征值
      String feature = getFeature(param, traceLog);

      //比对人脸
      searchFeature(param, feature, traceLog);

      List<String> similarity = param.getSimilarity();
      List<String> list = param.getList();
      GPUMP1002ServiceOutVo outvo = new GPUMP1002ServiceOutVo();
      if (list == null || similarity == null) {
        LOGGER.debug("check use is null!");
        outvo.setResult_list_size("0");
        outvo.setResult_list(new ArrayList<>());
        rspMsgBody.setEntity(outvo);
        rspMsg.setTx_body(rspMsgBody);
        TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1002", GpumpErrorInfoModel.NOERROR);
        return rspMsg;
      }
      LOGGER.debug("end to search for gpu,find " + list == null ? "0" : list.size() + " use");

      LOGGER.debug("begin to query user.");
      List<GPUMP1002ServiceOutVo_Group> outvogrouplist = genCustInfo(param);

      LOGGER.debug("end to query user.");
      outvo.setResult_list(outvogrouplist);
      outvo.setResult_list_size(outvogrouplist.size() + "");
      rspMsgBody.setEntity(outvo);
    } else {
      LOGGER.error("gpumpRealFacedbModel_list is null!");
      TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1002",
          GpumpErrorInfoModel.REALFACEDBERROR);
      return rspMsg;
    }
    TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1002", GpumpErrorInfoModel.NOERROR);
    rspMsg.setTx_body(rspMsgBody);
    //outvo.setCust_id(cust_id);
    LOGGER.debug("GPUMP1002_Bean end!");
    return rspMsg;
  }

  //多线程获取特征值列表
  public List<GPUMP1002ServiceOutVo_Group> getAlloutVoList(
      List<GpumpLogicFacedbModel> gpumpLogicFacedbModelList, ServiceInVoParam1002 param,
      TraceLog traceLog) {

    List<GPUMP1002ServiceOutVo_Group> outvogrouplistAll =
        new ArrayList<GPUMP1002ServiceOutVo_Group>();

    for (int i = 0; i < gpumpLogicFacedbModelList.size(); i++) {
      GpumpLogicFacedbModel gpumpLogicFacedbModel1 = gpumpLogicFacedbModelList.get(i);
      List<GpumpRealFacedbModel> gpumpRealFacedbModel_list =
          gpumpLogicFacedbModel1.getGpumpRealFacedbModelList();
      if (gpumpRealFacedbModel_list == null) {
        LOGGER.error("gpumpRealFacedbModel_list is null!");
        throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,
            GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR));
      }

      //获取gpu实例
      genGpuBean(param, gpumpRealFacedbModel_list);

      List<GPUMP1002ServiceOutVo_Group> outvogrouplist = null;

      try {
        ThreadDemo mc = new ThreadDemo(param, traceLog);
        FutureTask<List<GPUMP1002ServiceOutVo_Group>> ft =
            new FutureTask<List<GPUMP1002ServiceOutVo_Group>>(mc);
        new Thread(ft).start();
        outvogrouplist = ft.get();
        outvogrouplistAll.addAll(outvogrouplist);
      } catch (Exception e) {
        LOGGER.error("searchFeature error!");
        throw new CommonRuntimeException(GpumpErrorInfoModel.GPUSEARCHERROR,
            GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUSEARCHERROR));
      }
    }
    return outvogrouplistAll;
  }

  class ThreadDemo implements Callable<List<GPUMP1002ServiceOutVo_Group>> {
    ServiceInVoParam1002 param = null;
    TraceLog traceLog = null;

    public ThreadDemo(ServiceInVoParam1002 param, TraceLog traceLog) {
      this.param = param;
      this.traceLog = traceLog;
    }

    @Override
    public List<GPUMP1002ServiceOutVo_Group> call() throws Exception {
      //计算特征值
      String feature = getFeature(param, traceLog);
      ServiceInVoParam1002 paramlast2 = searchFeature(param, feature, traceLog);
      List<GPUMP1002ServiceOutVo_Group> outvogrouplist = null;
      List<String> similarity = param.getSimilarity();
      List<String> list = param.getList();
      if (list != null || similarity != null) {
        outvogrouplist = genCustInfo(paramlast2);
        LOGGER.error("分组比对信息：" + outvogrouplist);
      }
      return outvogrouplist;
    }
  }

  /**
   * 设置服务流程参数方法
   *
   * @param param 流程数据类
   * @param logtime 各环节耗时缓存
   * @param reqMsg 请求数据
   */
  void setparam(ServiceInVoParam1002 param, HashMap<String, Long> logtime, TxRequestMsg reqMsg) {
    TxRequestMsgHead reqMsgHead = reqMsg.getTx_header();
    String traceid = reqMsgHead.getSys_evt_trace_id();
    logtime.put("updateTime", (long) 0);
    logtime.put("selectTime", (long) 0);
    logtime.put("extractForGpuTime", (long) 0);
    logtime.put("searchForGpuTime", (long) 0);
    logtime.put("saveFileTime", (long) 0);
    GPUMP1002ServiceInVo invo = (GPUMP1002ServiceInVo) reqMsg.getTx_body().getEntity();
    TxRequestMsgCom2 Com2 = reqMsg.getTx_body().getCom2();
    String GroupName = Com2.getGroupName();
    String sysChannelID = Com2.getSysChannelID();
    String dotNumber = Com2.getDotNumber();
    String venderCode = Com2.getVenderCode();
    LOGGER.debug("GroupName is " + GroupName);
    LOGGER.debug("sysChannelID is " + sysChannelID);
    LOGGER.debug("StationId is " + dotNumber);
    LOGGER.debug("DeviceId is " + venderCode);
    param.setTraceid(traceid);
    param.setLogtime(logtime);
    param.setHit_size(invo.getHit_size());
    param.setThreshold(invo.getThreshold());
    param.setSysChannelID(sysChannelID);
    param.setGroupName(GroupName);
    param.setFace_image(invo.getFace_image());
    param.setDeviceId(venderCode);
    param.setStationId(dotNumber);
    param.setTransflow(reqMsg.getTx_header().getSys_evt_trace_id());
  }

  /**
   * 获取逻辑库信息
   *
   * @param param 交易流程数据类
   */
  public void genLogicFaceModel(ServiceInVoParam1002 param) {
    String sysChannelID = param.getSysChannelID();
    String groupName = param.getGroupName();
    GpumpLogicFacedbModel gpumpLogicFacedbModel =
        ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID + ":" + groupName);
    if (gpumpLogicFacedbModel == null) {
      LOGGER.error("gpumpLogicFacedbModel is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
    }

    gpumpLogicFacedbModel = filterGpuByStationOrDevice(gpumpLogicFacedbModel, param);

    String Logic_db_id = null;//注册库逻辑库id
    String extractflag = null;
    if (gpumpLogicFacedbModel.getType().equals("1")) {
      Logic_db_id = gpumpLogicFacedbModel.getLogic_db_id();
      String Is_mount_gpu = gpumpLogicFacedbModel.getIs_mount_gpu();
      extractflag = gpumpLogicFacedbModel.getVerify_param1();
      if (Is_mount_gpu == null || !Is_mount_gpu.equals("T")) //如果是注册库且没有挂载GPU
      {
        LOGGER.error("register Logic_db_id " + Logic_db_id + " have no mount gpu");
        throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBMOUNTGPUERROR,
            GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBMOUNTGPUERROR));
      }
    } else {
      GpumpLogicFacedbModel gpumpLogicFacedbModel_register =
          ServiceParaUtil.getAllGpuDBMsgByID(gpumpLogicFacedbModel.getSource_db_id());
      Logic_db_id = gpumpLogicFacedbModel_register.getLogic_db_id();
      extractflag = gpumpLogicFacedbModel.getVerify_param1();
    }
    param.setGpumpLogicFacedbModel(gpumpLogicFacedbModel);
    param.setLogic_db_id(Logic_db_id);
    param.setExtractflag(extractflag);
  }

  private GpumpLogicFacedbModel filterGpuByStationOrDevice(GpumpLogicFacedbModel gpumpLogicFacedbModel, ServiceInVoParam1002 param) {
    List<GpumpRealFacedbModel> gpumpRealFacedbModelList = gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
    if (null == gpumpRealFacedbModelList) {
      return gpumpLogicFacedbModel;
    }
    gpumpRealFacedbModelList.stream().forEach(model -> LOGGER.info("before filter GpumpRealFacedbModel:" + model.getReal_db_id() + ", gpuName:" + model.getGpu_name()));
    Hashtable<String, List<GpumpGpuDispatchModel>> deviceGpuDispatchMap =
        GpumpGpuDispatchParaUtil.getDeviceGpuDispatchMap();
    LOGGER.debug("deviceGpuDispatchMap size:" + deviceGpuDispatchMap.size());
    Hashtable<String, List<GpumpGpuDispatchModel>> stationGpuDispatchMap =
        GpumpGpuDispatchParaUtil.getStationGpuDispatchMap();
    LOGGER.debug("stationGpuDispatchMap size:" + stationGpuDispatchMap.size());
    List<GpumpRealFacedbModel> filterList = new ArrayList<>();

    String stationId = param.getStationId();
    String deviceId = param.getDeviceId();
    for (GpumpRealFacedbModel realFacedbModel : gpumpRealFacedbModelList) {
      String gpu_name = realFacedbModel.getGpu_name();

      if (null != deviceId && deviceGpuDispatchMap.containsKey(deviceId)) {
        LOGGER.debug("filterGpuByStationOrDevice containsKey deviceId");
        List<GpumpGpuDispatchModel> gpumpGpuDispatchModels = deviceGpuDispatchMap.get(deviceId);
        if (null != gpumpGpuDispatchModels) {
          for (GpumpGpuDispatchModel dispatchModel : gpumpGpuDispatchModels) {
            if (gpu_name.equals(dispatchModel.getGpuName())) {
              filterList.add(realFacedbModel);
            }
          }
        }

      } else if (null != stationId && stationGpuDispatchMap.containsKey(stationId)) {
        LOGGER.debug("filterGpuByStationOrDevice containsKey stationId");
        List<GpumpGpuDispatchModel> gpumpGpuDispatchModels = stationGpuDispatchMap.get(stationId);
        if (null != gpumpGpuDispatchModels) {
          for (GpumpGpuDispatchModel dispatchModel : gpumpGpuDispatchModels) {
            if (gpu_name.equals(dispatchModel.getGpuName())) {
              filterList.add(realFacedbModel);
            }
          }
        }

      } else {
        LOGGER.debug("filterGpuByStationOrDevice not containsKey deviceId or stationId");
        List<GpumpGpuDispatchModel> gpumpGpuDispatchModels = new ArrayList<>();
        Set<String> deviceKeySet = deviceGpuDispatchMap.keySet();
        for (String id : deviceKeySet) {
          List<GpumpGpuDispatchModel> deviceDispatchModelList = deviceGpuDispatchMap.get(id);
          if (null != deviceDispatchModelList) {
            gpumpGpuDispatchModels.addAll(deviceDispatchModelList);
          }
        }
        Set<String> stationKeySet = stationGpuDispatchMap.keySet();
        for (String id : stationKeySet) {
          List<GpumpGpuDispatchModel> stationDispatchModelList = stationGpuDispatchMap.get(id);
          if (null != stationDispatchModelList) {
            gpumpGpuDispatchModels.addAll(stationDispatchModelList);
          }
        }
        LOGGER.debug("gpumpGpuDispatchModels: size:" + gpumpGpuDispatchModels.size());
        boolean flag = true;
        for (GpumpGpuDispatchModel dispatchModel : gpumpGpuDispatchModels) {
          LOGGER.debug("dispatchModel gpufacedb:" + dispatchModel.getGpuName());
          if (gpu_name.equals(dispatchModel.getGpuName())) {
            flag = false;
            break;
          }
        }
        LOGGER.debug("flag :" + flag);
        if (flag) {
          filterList.add(realFacedbModel);
        }
      }
    }
    if (filterList.size() == 0) {
      throw new CommonRuntimeException(GpumpErrorInfoModel.REALFACEDBERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.REALFACEDBERROR));
    }
    filterList.stream().forEach(model -> LOGGER.info("after filter GpumpRealFacedbModel:" + model.getReal_db_id() + ", gpuName:" + model.getGpu_name()));
    gpumpLogicFacedbModel.setGpumpRealFacedbModelList(filterList);
    return gpumpLogicFacedbModel;
  }

  /**
   * 获取gpu实例
   *
   * @param param 交易流程参数
   */
  public static ServiceInVoParam1002 genGpuBean(ServiceInVoParam1002 param,
      List<GpumpRealFacedbModel> gpumpRealFacedbModel_list) {
    ServiceInVoParam1002 param1 = new ServiceInVoParam1002();
    GpumpRealFacedbModel gpumpRealFacedbModel = gpumpRealFacedbModel_list.get(
        (int) (Math.random() * gpumpRealFacedbModel_list.size()));//随机获取一个物理库

    GpumpGpuInfoModel gpumpGpuInfoModel = gpumpRealFacedbModel.getGpumpGpuInfo();
    LOGGER.info("send GPU info ----- realId:{}, gpuName:{}, gpuType:{}, gpuIP:{}", gpumpRealFacedbModel.getReal_db_id(), gpumpRealFacedbModel.getGpu_name(), gpumpGpuInfoModel.getGpu_type_id(), gpumpGpuInfoModel.getGpu_ip());
    if (gpumpGpuInfoModel == null) {
      LOGGER.error(
          "gpumpGpuInfoModel is null,real_db_id is : " + gpumpRealFacedbModel.getReal_db_id());
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
    }
    String gpu_type_id = gpumpGpuInfoModel.getGpu_type_id();
    String Real_db_id = gpumpRealFacedbModel.getReal_db_id();
    String Gpu_face_db = gpumpRealFacedbModel.getGpu_face_db();
    String gpuclassname = "com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gpu_type_id + "_Bean";
    GpuInterface gpuBean = (GpuInterface) Utils.getInstance(gpuclassname);
    if (gpuBean == null) {
      LOGGER.error("GPUMP " + gpu_type_id + " service is no exist!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPUGROUPERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUGROUPERROR));
    }
    param.setGpumpGpuInfoModel(gpumpGpuInfoModel);
    param.setGpu_face_db(Gpu_face_db);
    param.setReal_db_id(Real_db_id);
    param.setGpuBean(gpuBean);

    return param;
  }

  /**
   * 计算特征值
   *
   * @param param 交易流程数据类
   * @param traceLog 报文日志缓存类
   */
  public static String getFeature(ServiceInVoParam1002 param, TraceLog traceLog) {
    LOGGER.debug("begin to extract for gpu.");
    GpumpGpuInfoModel gpumpGpuInfoModel = param.getGpumpGpuInfoModel();
    String face_image = param.getFace_image();
    String extractflag = param.getExtractflag();
    String traceid = param.getTraceid();
    GpuInterface gpuBean = param.getGpuBean();
    HashMap<String, Long> logtime = param.getLogtime();
    GetFeatureRequest gpuinvo = new GetFeatureRequest();
    gpuinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
    gpuinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
    gpuinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
    gpuinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
    gpuinvo.setImage(face_image);
    gpuinvo.setExtractflag(extractflag);
    gpuinvo.setTraceid(traceid);
    long start = System.currentTimeMillis();
    GetFeatureResponse getfeatureresponse = gpuBean.getFeature(gpuinvo, traceLog);
    long end = System.currentTimeMillis();
    //extractForGpuTime=extractForGpuTime+end-start;
    traceLog.setGetFeatureTime(traceLog.getGetFeatureTime() + end - start);
    logtime.put("extractForGpuTime", logtime.get("extractForGpuTime") + end - start);
    //LOGGER.debug(getfeatureresponse.toString());

    if (!getfeatureresponse.getResult()) {
      LOGGER.error("getfeature error,errormessage is : " + getfeatureresponse.getError());
      throw new CommonRuntimeException(getfeatureresponse.getError(),
          GpumpErrorInfoParaUtil.getErrorMsg(getfeatureresponse.getError()));
    }

    String feature = getfeatureresponse.getFeature();
    if (feature == null) {
      LOGGER.error("extract user error,feature is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPUDETECTERROR_FACESNULL,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUDETECTERROR_FACESNULL));
    }
    LOGGER.debug("end to extract for gpu,feature is : " + feature);
    return feature;
  }

  /**
   * 比对人脸，比对失败抛出异常
   *
   * @param param 交易流程数据类
   * @param traceLog 报文日志缓存类
   */
  public static ServiceInVoParam1002 searchFeature(ServiceInVoParam1002 param, String feature,
      TraceLog traceLog) {
    GpumpGpuInfoModel gpumpGpuInfoModel = param.getGpumpGpuInfoModel();
    HashMap<String, Long> logtime = param.getLogtime();
    String gpu_face_db = param.getGpu_face_db();
    LOGGER.error("逻辑库组名：" + gpu_face_db);
    String hit_size = param.getHit_size();
    String threshold = param.getThreshold();
    String traceid = param.getTraceid();
    GpuInterface gpuBean = param.getGpuBean();
    SearchFeatureRequest groupsearchinvo = new SearchFeatureRequest();
    groupsearchinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
    groupsearchinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
    groupsearchinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
    groupsearchinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
    groupsearchinvo.setGroupname(gpu_face_db);
    groupsearchinvo.setFeature(feature);
    groupsearchinvo.setHitsize(hit_size);
    groupsearchinvo.setThreshold(threshold);
    groupsearchinvo.setTraceid(traceid);
    Long start = System.currentTimeMillis();
    //LOGGER.error("groupsearchinvo信息"+groupsearchinvo);
    SearchFeatureResponse searchfeatureresponse = gpuBean.searchFeature(groupsearchinvo, traceLog);
    Long end = System.currentTimeMillis();
    //searchForGpuTime=searchForGpuTime+end-start;
    logtime.put("searchForGpuTime", logtime.get("searchForGpuTime") + end - start);
    traceLog.setSearchFeatureTime(traceLog.getSearchFeatureTime() + end - start);
    //LOGGER.debug(searchfeatureresponse.toString());
    if (!searchfeatureresponse.getResult()) {
      LOGGER.error("searchFeature user error!message is "
          + searchfeatureresponse.getError()
          + " : "
          + GpumpErrorInfoParaUtil.getErrorMsg(searchfeatureresponse.getError()));
      throw new CommonRuntimeException(searchfeatureresponse.getError(),
          GpumpErrorInfoParaUtil.getErrorMsg(searchfeatureresponse.getError()));
    }

    List<String> similarity = searchfeatureresponse.getScores();
    List<String> list = searchfeatureresponse.getFeatureids();
    param.setList(list);
    param.setSimilarity(similarity);
    return param;
  }

  public List<GPUMP1002ServiceOutVo_Group> genCustInfo(ServiceInVoParam1002 param) {
    List<String> list = param.getList();
    HashMap<String, Long> logtime = param.getLogtime();
    List<String> similarity = param.getSimilarity();
    String logic_db_id = param.getLogic_db_id();
    String real_db_id = param.getReal_db_id();

    List<GPUMP1002ServiceOutVo_Group> outvogrouplist = new ArrayList<GPUMP1002ServiceOutVo_Group>();
    for (int i = 0; i < list.size(); i++)//特征值id列表
    {
      String feature_id = list.get(i) + "";
      Long start = System.currentTimeMillis();
      GpumpFidcustMapModel gpumpFidcustMapModel =
          redisService.selectFidcustMapModelbyfeatureid(real_db_id, feature_id);
      Long end = System.currentTimeMillis();
      //selectTime=selectTime+end-start;
      logtime.put("selectTime", logtime.get("selectTime") + end - start);
      if (gpumpFidcustMapModel != null) {
        LOGGER.warn("feature_id : "
            + feature_id
            + " is exist for GpumpFidcustMap,Real_db_id is "
            + real_db_id);
        String cust_id = gpumpFidcustMapModel.getCust_id();
        start = System.currentTimeMillis();
        GpumpCustInfoModel gpumpCustInfoModel = redisService.selectCustInfo(logic_db_id, cust_id);
        end = System.currentTimeMillis();
        //selectTime=selectTime+end-start;
        logtime.put("selectTime", logtime.get("selectTime") + end - start);
        if (gpumpCustInfoModel != null) {
          LOGGER.warn("cust_id : " + cust_id + " is exist for gpumpCustInfo.");
          gpumpCustInfoModel.setRecognition_time(new Date());
          start = System.currentTimeMillis();
          int ret = 1;
          try {
            // ret=GpumpCustInfoService.update(gpumpCustInfoModel);
          } catch (Exception e) {
            LOGGER.error("cust_id : " + cust_id + " update error for gpumpCustInfo!");
          }
          end = System.currentTimeMillis();
          //updateTime=updateTime+end-start;
          logtime.put("updateTime", logtime.get("updateTime") + end - start);
          if (ret != 0) {
            LOGGER.error("cust_id : " + cust_id + " update error for gpumpCustInfo!");
          }
          GPUMP1002ServiceOutVo_Group outvogroup = new GPUMP1002ServiceOutVo_Group();
          outvogroup.setCust_id(gpumpFidcustMapModel.getCust_id());
          outvogroup.setId_no(gpumpCustInfoModel.getId_no());
          outvogroup.setId_type(gpumpCustInfoModel.getId_type());
          outvogroup.setName(gpumpCustInfoModel.getName());
          outvogroup.setMobile_no(gpumpCustInfoModel.getMobile_no());
          outvogroup.setFace_collecttime(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(
              gpumpCustInfoModel.getModify_time()));
          outvogroup.setSimilarity(similarity.get(i));
          outvogrouplist.add(outvogroup);
        } else {
          LOGGER.warn("cust_id " + cust_id + " is not exist for gpumpCustInfo.");
        }
      } else {
        LOGGER.warn("feature_id " + feature_id + " is not exist for gpumpFidcustMap.");
      }
    }
    return outvogrouplist;
  }

  @Override
  public Object transform(JSONObject indata) throws Exception {
    // TODO Auto-generated method stub
    JSONObject tx_body = indata.getJSONObject("tx_body");
    if (tx_body == null) {
      LOGGER.error("tx_body is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
    }
    JSONObject entity = tx_body.getJSONObject("entity");
    if (entity == null) {
      LOGGER.error("entity is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
    }
    JSONObject com2 = tx_body.getJSONObject("com2");
    if (com2 == null) {
      LOGGER.error("com2 is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
    }
    TxRequestMsg reqMsg = (TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
    GPUMP1002ServiceInVo invo =
        (GPUMP1002ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1002ServiceInVo.class);
    ;
    TxRequestMsgCom2 com = JSON.parseObject(JSON.toJSONString(com2), TxRequestMsgCom2.class);
    TxRequestMsgBody MsgBody = reqMsg.getTx_body();
    MsgBody.setEntity(invo);
    MsgBody.setCom2(com);
    reqMsg.setTx_body(MsgBody);
    return reqMsg;
  }

  @Override
  public List<GpuRegisterTask> getGpuTask() {
    // TODO Auto-generated method stub
    return null;
  }

  public static List<GPUMP1002ServiceOutVo_Group> sort(List<GPUMP1002ServiceOutVo_Group> list,
      Integer num) {
    list.sort(Comparator.comparing(GPUMP1002ServiceOutVo_Group::getSimilarity).reversed());
    List<GPUMP1002ServiceOutVo_Group> GPUMP1002ServiceOutVo_GroupList =
        new ArrayList<GPUMP1002ServiceOutVo_Group>();
    if (list.size() < num) {
      num = list.size();
    }
    for (int i = 0; i < num; i++) {
      GPUMP1002ServiceOutVo_Group group = list.get(i);
      GPUMP1002ServiceOutVo_GroupList.add(group);
    }
    return GPUMP1002ServiceOutVo_GroupList;
  }

  public static List<Double> StringtoDouble(List<String> similarity) {
    List<Double> doubleList = new ArrayList<Double>();
    for (int i = 0; i < similarity.size(); i++) {
      Double similari = Double.parseDouble(similarity.get(i));
      doubleList.add(similari);
    }
    return doubleList;
  }
  
  /**
   * 保存图片到nas目录，目录 yyyyMMddHHmm，每10分钟一个目录 文件名 客户号_yyyyMMddHHmmss.jpg
   *
   * @param param 交易流程数据类
 * @throws IOException 
   */
  public void saveFaceImageByUrl(ServiceInVoParam1002 param,TraceLog traceLog) throws IOException {
	  String logImgCof=SysParaUtil.getStrPara("LOGIMGCOF:1","0");
	  if("1".equals(logImgCof)){
	    String sysChannelID = param.getSysChannelID();
	    String face_image = param.getFace_image();
	    HashMap<String, Long> logtime = param.getLogtime();
		String log_mage_addr_nas = PhotoUtil.getPath("image_addr:1", "/"+sysChannelID+"/faceComplmage", "GPUMP1002_"+param.getTransflow());
	    traceLog.setFace_image(face_image);
	    traceLog.setLog_image_addr_nas(log_mage_addr_nas);
    }
  }
}
