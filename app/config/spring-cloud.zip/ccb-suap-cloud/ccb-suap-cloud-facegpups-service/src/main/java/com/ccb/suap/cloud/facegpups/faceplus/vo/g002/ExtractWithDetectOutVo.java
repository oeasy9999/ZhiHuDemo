package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

import java.io.Serializable;
public class ExtractWithDetectOutVo implements Serializable {

	private static final long serialVersionUID = -6322422754329611651L;
	private String result;
	private String feature;
	private String yaw;
	private String pitch;
	private String roll;
	private String saturation;
	private String errorMessage;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getFeature() {
		return feature;
	}
	public void setFeature(String feature) {
		this.feature = feature;
	}
	public String getYaw() {
		return yaw;
	}
	public void setYaw(String yaw) {
		this.yaw = yaw;
	}
	public String getPitch() {
		return pitch;
	}
	public void setPitch(String pitch) {
		this.pitch = pitch;
	}
	public String getRoll() {
		return roll;
	}
	public void setRoll(String roll) {
		this.roll = roll;
	}
	public String getSaturation() {
		return saturation;
	}
	public void setSaturation(String saturation) {
		this.saturation = saturation;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "ExtractWithDetectOutVo [result=" + result + ", feature=" + feature + ", yaw=" + yaw + ", pitch=" + pitch
				+ ", roll=" + roll + ", saturation=" + saturation + ", errorMessage=" + errorMessage + "]";
	}
	
	
}
