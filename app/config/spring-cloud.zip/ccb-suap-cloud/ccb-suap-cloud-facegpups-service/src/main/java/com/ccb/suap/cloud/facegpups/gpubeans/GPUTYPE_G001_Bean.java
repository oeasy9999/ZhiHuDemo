package com.ccb.suap.cloud.facegpups.gpubeans;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.facegpups.faceplus.vo.AddFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.AddFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CleanGroupRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CleanGroupResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareImageRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareImageResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteGroupRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DeleteGroupResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DetectImageRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.DetectImageResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupListReponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupListRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupSizeRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetGroupSizeResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetVersionRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.GetVersionResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.InitGroupRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.InitGroupResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.SearchFeatureRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.SearchFeatureResponse;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.CompareOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.DetectOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.ExtractWithDetectOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.FaceRect;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.FaceVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.Faceattr;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.FeatureLoactionVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.GroupAddOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.GroupCleanOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.GroupDeleteFeatureOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.GroupDeleteOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.GroupGetSizeOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.GroupInitOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.GroupListOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.GroupSearchOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.LocationVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.VerifyOutVo;
import com.ccb.suap.cloud.facegpups.faceplus.vo.g001.VersionOutVo;
import com.ccb.suap.cloud.facegpups.gpubeans.tranerrorcode.GpuCodeUtil_G001;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.resource.httpresource.HttpCommPoolService;
import com.ccb.suap.cloud.facegpups.resource.httpresource.HtttpUtil;
import com.ccb.suap.cloud.facegpups.resource.httpresource.MultipartFormDataParams;
import com.ccb.suap.cloud.facegpups.scheduled.GpuInfoReflushScheduled;
import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.util.JSONUtils;
import com.ccb.suap.util.file.FileUtils;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ResourceUtils;

import sun.misc.BASE64Decoder;
public class GPUTYPE_G001_Bean implements GpuInterface{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(GpuInfoReflushScheduled.class);

	public String dump(String appname)
	{
		String filename;
		String data = null;
		try {
			String dumpfile_path=new File(ResourceUtils.getURL("classpath:").getPath()).getParentFile().getParentFile().getParent()+File.separator+"baffle";
			dumpfile_path=dumpfile_path.substring(5);
			
			filename=appname+"_G001.rsp";
			dumpfile_path=dumpfile_path+File.separator+filename;
			File F=new File(dumpfile_path);
			LOGGER.debug(dumpfile_path);
			if(F.exists()){
				LOGGER.debug(appname+"baffle begin");
				data = FileUtils.readFile(dumpfile_path);
				LOGGER.debug("file data is : "+JSONUtils.formatJson(data,100));
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}
	public GetFeatureResponse getFeature(GetFeatureRequest req,TraceLog traceLog) {
		// TODO Auto-generated method stub
		//LOGGER.debug("getFeature : "+req.toString());
		String extractflag=req.getExtractflag();
		GetFeatureResponse rsp=new GetFeatureResponse();
		
		if(extractflag==null)
		{
			extractflag="0";
		}
		String url="http://"+req.getIp()+":"+req.getPort2()+"/extract_with_detect";
//		traceLog.setUrl(url);

		//List<String> faces =new ArrayList<String>();
//		Map<String, String> textMap = new HashMap<String, String>();
//		textMap.put("faceattr", "1");
//		if("2".equals(extractflag))
//		{
//			//返回最大人脸
//			textMap.put("maxface", "1");
//		}
//		Map<String, String> fileMap = new HashMap<String, String>();
//		fileMap.put("image", req.getImage());

		MultipartFormDataParams params = new MultipartFormDataParams();
		Map<String, String> textMap = new HashMap<String, String>();
		textMap.put("faceattr", "1");
		if("2".equals(extractflag))
		{
			//返回最大人脸
			textMap.put("maxface", "1");
		}
		params.setTextMap(textMap);
		params.addFileParams("image", req.getImage());

		String result=dump("getFeature");
		traceLog.setRequestJsonString_getFeature(JSONObject.toJSON(textMap).toString());
		if(result==null) {
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G001_PORT2", "/extract_with_detect", params);
			} catch (Exception e) {
				LOGGER.error("send extract_with_detect error:" + e.getMessage());
			}
//			result = htttpUtil.httpPostFrom(url, textMap, fileMap);
		}
		traceLog.setResponseJsonString_getFeature(result);
		//String result = htttpUtil.httpPostFrom(url, textMap, fileMap);
		LOGGER.debug("getFeature GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		rsp.setResult(true);
		JSONArray userInfos = jsonObject.getJSONArray("faces");
		ExtractWithDetectOutVo extractwithdetectoutvo=(ExtractWithDetectOutVo)JSONObject.toJavaObject(jsonObject, ExtractWithDetectOutVo.class);
		if(extractwithdetectoutvo!=null)
		{
			String error=extractwithdetectoutvo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		if(userInfos!=null && userInfos.size() > 0)
		{
			JSONArray array = (JSONArray) jsonObject.getJSONArray("faces");
			List<FaceVo> allFaces =new ArrayList<FaceVo>();	
			if(array.size()>1&&"0".equals(extractflag))
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPUEXTRACTERERROR_MOREFACE);
				return rsp;
			}else if(array.size()==0)
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPUDETECTERROR_FACESNULL);
				return rsp;
			}else
			{
				for(int i=0;i<array.size();i++)
				{
					JSONObject userinfoobject =(JSONObject) array.get(i);
					FaceVo userbean = (FaceVo) JSONObject.parseObject(JSON.toJSONString(userinfoobject), FaceVo.class);
					allFaces.add(userbean);
				}
				if("1".equals(extractflag))
				{
					//取最中间人脸
					//faces.add(getCenterFace(allFaces,req.getImage()).getFeature());
					rsp.setFeature(getCenterFace(allFaces,req.getImage()).getFeature());
				}else
				{
					//去最大人脸
					rsp.setFeature(allFaces.get(0).getFeature());
				}
			}
		}
		return rsp;
	}
	@Override
	public DetectImageResponse detectImage(DetectImageRequest req,TraceLog traceLog,String chanel_id ) {
		//LOGGER.debug("detectImage "+req.toString());
		String url="http://"+req.getIp()+":"+req.getPort2()+"/detect";
//		traceLog.setUrl(url);
//		Map<String, String> textMap = new HashMap<String, String>();
		DetectImageResponse rsp=new DetectImageResponse();
		rsp.setResult(true);
		//textMap.put("maxface", "1");
//		textMap.put("faceattr", "1");
//		if(attrs==null||"".equals(attrs.trim()))
//		{
//			textMap.put("attrs", "quality,age,agender,yaw,pitch,roll,blurness");
//		}else
//		{
//			textMap.put("attrs", attrs);
//		}

//		Map<String, String> fileMap = new HashMap<String, String>();
//		fileMap.put("image", req.getImage());

		String result=dump("detectImage");

		MultipartFormDataParams params = new MultipartFormDataParams();
		Map<String, String> textMap = new HashMap<String, String>();
		textMap.put("faceattr", "1");
		params.setTextMap(textMap);
		params.addFileParams("image", req.getImage());

		traceLog.setRequestJsonString_detectImage(JSONObject.toJSON(textMap).toString());
		if(result==null) {
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G001_PORT2", "/detect", params);
			} catch (Exception e) {
				LOGGER.error("send detect error:" + e.getMessage());
			}
//			result = htttpUtil.httpPostFrom(url, textMap, fileMap);
		}
		traceLog.setResponseJsonString_detectImage(result);
		//String result = htttpUtil.httpPostFrom(url, textMap, fileMap);
		//LOGGER.debug("detectImage GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("result is not json! "+e.getMessage(),e);
			LOGGER.error(e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		DetectOutVo detectoutvo=null;
		double quality = 0;
		try {
			detectoutvo = (DetectOutVo)JSONObject.toJavaObject(jsonObject, DetectOutVo.class);
			if(detectoutvo!=null)
			{
				String error=detectoutvo.getError();
				if(error!=null)
				{
					rsp.setResult(false);
					rsp.setError(GpuCodeUtil_G001.tranCode(error));
					return rsp;
				}
			}else
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
				return rsp;
			}
			List<FaceVo> faceslist = detectoutvo.getFaces();
			if(faceslist==null||faceslist.size()==0)
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPUDETECTERROR_FACESNULL);
				return rsp;
			}else if(faceslist.size()>1)
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPUDETECTERROR_FACESMORE);
				return rsp;
				
			}
			FaceVo faceVo = faceslist.get(0);
			Faceattr faceattr = faceVo.getFaceattr();
			double face_roll=Double.parseDouble(SysParaUtil.getStrValue("Face_roll_"+chanel_id+":1","20"));
			double roll=Math.abs(Double.parseDouble(faceattr.getRoll()));
			//算法人脸摇摆角度超过配置参数
			if(roll>face_roll){
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPUDETECTERROR_ROLL);
				return rsp;
			}
			double face_pitch=Double.parseDouble(SysParaUtil.getStrValue("Face_pitch_"+chanel_id+":1","20"));
			double pitch = Math.abs(Double.parseDouble(faceattr.getPitch()));
			if(pitch>face_pitch){
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPUDETECTERROR_PITCH);
				return rsp;
			}
			double face_yaw=Double.parseDouble(SysParaUtil.getStrValue("Face_yaw_"+chanel_id+":1","20"));
			double yaw = Math.abs(Double.parseDouble(faceattr.getYaw()));
			if(yaw>face_yaw){
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPUDETECTERROR_YAW);
				return rsp;
			}
			System.out.println("Face_blurness_"+chanel_id+":1");
			double face_blurness=Double.parseDouble(SysParaUtil.getStrValue("Face_blurness_"+chanel_id+":1","20"));
			double blurness = Math.abs(Double.parseDouble(faceattr.getBlurness())*100);
			if(blurness>face_blurness){
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPUDETECTERROR_BLURNESS);
				return rsp;
			}
			//quality = getquality(faceattr.getRoll(), faceattr.getPitch(), faceattr.getYaw(), faceattr.getBlurness());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("getquality Exception : "+e.getMessage(),e);
		}
		rsp.setQuality(quality+"");
		return rsp;
	}
	@Override
	public AddFeatureResponse addFeature(AddFeatureRequest req,TraceLog traceLog) {
		// TODO Auto-generated method stub
		//LOGGER.debug("addFeature : "+req.toString());
		String url="http://"+req.getIp()+":"+req.getPort1()+"/group/add";
//		traceLog.setUrl(url);
		Map<String, String> textMap = new HashMap<String, String>();
		AddFeatureResponse rsp=new AddFeatureResponse();
		rsp.setResult(true);
		textMap.put("groupname", req.getGroupname());
		textMap.put("featureid", req.getFeatureid());
		textMap.put("feature", req.getFeature());

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.setTextMap(textMap);

		String result=dump("addFeature");
		traceLog.setRequestJsonString_addFeature(JSONObject.toJSON(textMap).toString());
		if(result==null)
		{
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G001_PORT1", "/group/add", params);
			} catch (Exception e) {
				LOGGER.error("send /group/add error:" + e.getMessage());
			}

//			result=htttpUtil.httpPostFrom(url, textMap, null);
		}
		traceLog.setResponseJsonString_addFeature(result);
		//String result=htttpUtil.httpPostFrom(url, textMap, null);
		//LOGGER.debug("addFeature GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("result is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		
		GroupAddOutVo gpuoutvo=(GroupAddOutVo)JSONObject.toJavaObject(jsonObject, GroupAddOutVo.class);
		if(gpuoutvo!=null)
		{
			String error=gpuoutvo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		rsp.setFeatureid(req.getFeatureid());
		return rsp;
	}

	@Override
	public SearchFeatureResponse searchFeature(SearchFeatureRequest req,TraceLog traceLog) {
		LOGGER.debug("searchFeature "+req.toString());
		Map<String, String> textMap = new HashMap<String, String>();
		SearchFeatureResponse rsp=new SearchFeatureResponse();
		rsp.setResult(true);
		String url="http://"+req.getIp()+":"+req.getPort1()+"/group/search";
//		traceLog.setUrl(url);
		textMap.put("groupname", req.getGroupname());
		textMap.put("feature", req.getFeature());
		textMap.put("limit", req.getHitsize());
		textMap.put("threshold", req.getThreshold());

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.setTextMap(textMap);

		traceLog.setRequestJsonString_searchFeature(JSONObject.toJSON(textMap).toString());
		String result=dump("searchFeature");
		if(result==null)
		{
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G001_PORT1", "/group/search", params);
			} catch (Exception e) {
				LOGGER.error("send /group/search error:" + e.getMessage());
			}

//			result=htttpUtil.httpPostFrom(url, textMap, null);
		}
		traceLog.setResponseJsonString_searchFeature(result);
		//String result =htttpUtil.httpPostFrom(url, textMap, null);
		LOGGER.debug("search GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("result is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		GroupSearchOutVo groupsearchoutvo = (GroupSearchOutVo)JSONObject.toJavaObject(jsonObject, GroupSearchOutVo.class);
		if(groupsearchoutvo!=null)
		{
			String error=groupsearchoutvo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		rsp.setFeatureids(groupsearchoutvo.getIds());
		rsp.setScores(groupsearchoutvo.getScores());
		return rsp;
	}
	@Override
	public DeleteFeatureResponse deleteFeature(DeleteFeatureRequest req,TraceLog traceLog) {
		LOGGER.debug("deleteFeature"+req.toString());
		Map<String, String> textMap = new HashMap<String, String>();
		DeleteFeatureResponse rsp=new DeleteFeatureResponse();
		rsp.setResult(true);
		String url="http://"+req.getIp()+":"+req.getPort1()+"/group/delete";
//		traceLog.setUrl(url);
		textMap.put("groupname", req.getGroupname());
		textMap.put("featureid",req.getFeatureid() );

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.setTextMap(textMap);

		String result=dump("deleteFeature");
		traceLog.setRequestJsonString_deleteFeature(JSONObject.toJSON(textMap).toString());
		if(result==null)
		{
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G001_PORT1", "/group/delete", params);
			} catch (Exception e) {
				LOGGER.error("send /group/delete error:" + e.getMessage());
			}

//			result=htttpUtil.httpPostFrom(url, textMap, null);
		}
		traceLog.setResponseJsonString_deleteFeature(result);
		//String result =htttpUtil.httpPostFrom(url, textMap, null);
		//LOGGER.debug("deleteFeature GPU result: "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("result is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		GroupDeleteFeatureOutVo groupdeleteoutvo= (GroupDeleteFeatureOutVo)JSONObject.toJavaObject(jsonObject, GroupDeleteFeatureOutVo.class);
		if(groupdeleteoutvo!=null)
		{
			String error=groupdeleteoutvo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		return rsp;
	}

	@Override
	public CompareFeatureResponse compareFeature(CompareFeatureRequest req,TraceLog traceLog) {
		//LOGGER.debug("compareFeature"+req.toString());
		Map<String, String> textMap = new HashMap<String, String>();
		String url="http://"+req.getIp()+":"+req.getPort2()+"/compare";
//		traceLog.setUrl(url);
		CompareFeatureResponse rsp=new CompareFeatureResponse();
		rsp.setResult(true);
		textMap.put("feat1", req.getFeature1());
		textMap.put("feat2", req.getFeature2());
		//LOGGER.debug("feat1 length--- "+req.getFeature1().length());
		//LOGGER.debug("feat2 length--- "+req.getFeature2().length());
		JSONObject json = (JSONObject) JSONObject.toJSON(textMap);

		String result=dump("compareFeature");
		traceLog.setRequestJsonString_compareFeature(json.toString());
		if(result==null)
		{
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G001_PORT2", "/compare", json.toJSONString());
			} catch (Exception e) {
				LOGGER.error("send /group/compare error:" + e.getMessage());
			}

//			result=htttpUtil.postJson(url, json.toJSONString());
		}
		traceLog.setResponseJsonString_compareFeature(result);
		//String result=htttpUtil.postJson(url, json.toJSONString());
		//LOGGER.debug("compare GPU result: "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("result is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		
		CompareOutVo compareOutVo=(CompareOutVo)JSONObject.toJavaObject(jsonObject, CompareOutVo.class);
		if(compareOutVo!=null)
		{
			String error=compareOutVo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		rsp.setScore(compareOutVo.getConfidence());
		return rsp;
	}

	@Override
	public CompareImageResponse compareImage(CompareImageRequest req,TraceLog traceLog) {
		//LOGGER.debug("compareImage "+req.toString());
		Map<String, String> fileMap = new HashMap<String, String>();
		CompareImageResponse rsp=new CompareImageResponse();
		rsp.setResult(true);
		String url="http://"+req.getIp()+":"+req.getPort2()+"/verify";
//		traceLog.setUrl(url);
		fileMap.put("image_best", req.getImage1());
		fileMap.put("image_idcard", req.getImage2());

		MultipartFormDataParams params = new MultipartFormDataParams();
		params.addFileParams("image_best", req.getImage1());
		params.addFileParams("image_idcard", req.getImage2());

		String result=dump("compareImage");
		traceLog.setRequestJsonString_compareImage(JSONObject.toJSON(fileMap).toString());
		
		if(result==null)
		{
			try {
				result = HttpCommPoolService.HTTPCommPool.sendAndWait("G001_PORT2", "/verify", params);
			} catch (Exception e) {
				LOGGER.error("send /verify error:" + e.getMessage());
			}
//			result = htttpUtil.httpPostFrom(url, null, fileMap);
		}
		traceLog.setResponseJsonString_compareImage(result);
		//String result = htttpUtil.httpPostFrom(url, null, fileMap);
		//LOGGER.debug("verify GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		VerifyOutVo verifyoutvo = JSONObject.toJavaObject(jsonObject, VerifyOutVo.class);
		if(verifyoutvo!=null)
		{
			String error=verifyoutvo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		rsp.setScore(verifyoutvo.getConfidence());
		return rsp;
	}

	@Override
	public GetGroupSizeResponse getGroupSize(GetGroupSizeRequest req) {
		LOGGER.debug("getGroupSize "+req.toString());
		Map<String, String> textMap = new HashMap<String, String>();
		GetGroupSizeResponse rsp=new GetGroupSizeResponse();
		rsp.setResult(true);
		textMap.put("groupname", req.getGroupname());
		String url="http://"+req.getIp()+":"+req.getPort1()+"/group/getsize";
		String result = HtttpUtil.httpPostFrom(url, textMap,null);
		LOGGER.debug("getsize GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		
		GroupGetSizeOutVo groupgetsizeoutvo=JSONObject.toJavaObject(jsonObject, GroupGetSizeOutVo.class);
		if(groupgetsizeoutvo!=null)
		{
			String error=groupgetsizeoutvo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		rsp.setSize(groupgetsizeoutvo.getSize());
		return rsp;
	}
	@Override
	public GetVersionResponse getVersion(GetVersionRequest req) {
		LOGGER.debug("getVersion "+req.toString());
		String url="http://"+req.getIp()+":"+req.getPort1()+"/version";
		GetVersionResponse rsp=new GetVersionResponse();
		rsp.setResult(true);
		String result = HtttpUtil.getCurlData(url);
		LOGGER.debug("getVersion GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		VersionOutVo versionoutvo=JSONObject.toJavaObject(jsonObject, VersionOutVo.class);
		if(versionoutvo!=null)
		{
			String error=versionoutvo.getError();
			if(error!=null)
			{
				LOGGER.error("error is : "+error);
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		rsp.setVersion(versionoutvo.getVersion());
		return rsp;
	}
	
	@Override
	public CleanGroupResponse cleanGroup(CleanGroupRequest req) {
		LOGGER.debug("cleanGroup "+req.toString());
		String url="http://"+req.getIp()+":"+req.getPort1()+"/group/clean";
		CleanGroupResponse rsp=new CleanGroupResponse();
		rsp.setResult(true);
		Map<String, String> textMap = new HashMap<String, String>();
		textMap.put("groupname", req.getGroupname());
		String result = HtttpUtil.httpPostFrom(url, textMap,null);
		LOGGER.debug("cleanGroup GPU result ------ "+result);
		if(StringUtils.checkEmpty(result))
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		JSONObject jsonObject;
		try {
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		GroupCleanOutVo groupcleanoutvo=JSONObject.toJavaObject(jsonObject, GroupCleanOutVo.class);
		if(groupcleanoutvo!=null)
		{
			String error=groupcleanoutvo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		return rsp;
	}
	
	/**
	 * 获取最中心人脸
	 * @param list
	 * @return
	 */
	public static FaceVo getCenterFace(List<FaceVo> list,String img){
		//如果只有一个人脸直接返回
		if(list.size()==1){
			return list.get(0);
		}
		//中心节点坐标
		LocationVo centerLocation=getCenterForImg(img);
		//获取计算离中心点最近图片
		return mathCenterFace(list, centerLocation);
	}
	/**
	 * 通过图片获取中心点坐标
	 * @param img
	 * @return
	 */
	public static LocationVo getCenterForImg(String img){
		LocationVo geo=new LocationVo();
		//获取图片像素
		try {
			BASE64Decoder decoder = new BASE64Decoder();
	 		byte[] byteStream = decoder.decodeBuffer(img);
			InputStream is = new ByteArrayInputStream(byteStream);
			BufferedImage src = javax.imageio.ImageIO.read(is);
			
			int width = src.getWidth();
			int height = src.getHeight();
			//System.out.println(width);
			//System.out.println(height);
			geo=new LocationVo(width/2, height/2);
		} catch (IOException e) {
			LOGGER.error(e.getMessage(),e);
			return null;
		}
		return geo;
	}
	public static FaceVo mathCenterFace(List<FaceVo> list,LocationVo centerLocation){
		// 中心点的经纬度
		double centerX=centerLocation.getX();
		double centerY=centerLocation.getY();
		
		List<FeatureLoactionVo> ilist = new ArrayList<FeatureLoactionVo>();
		for (int i=0; i< list.size();i++) {
			//通过特征值坐标获取中心坐标
			FaceRect rect=list.get(i).getFaceRect();
			Double left=Double.parseDouble(rect.getLeft());
			Double right=Double.parseDouble(rect.getRight());
			Double top=Double.parseDouble(rect.getTop());
			Double bottom=Double.parseDouble(rect.getBottom());
			Double x=(right+left)/2;
			Double y=(bottom+top)/2;
			System.out.println("(" + x + "," + y+ ")");
			Double z = GetShotLocal(x, y, centerX, centerY);//获取距离
			System.out.println(z);
			// 获取最短距离后把经纬度和距离,索引存放到对象中
			FeatureLoactionVo localaddress = new FeatureLoactionVo(x, y, z,i);
			// 将对象用list保存
			ilist.add(localaddress);
		}

		List<FeatureLoactionVo> shotlocal = getLocalList(ilist);
		//获取距离最短信息
		Double lat = shotlocal.get(0).getLat();
		Double lon = shotlocal.get(0).getLon();
		Double localDouble = shotlocal.get(0).getDistance();
		System.err.println("最近的距离：" + localDouble + "。对应的经纬是：" + "(" + lat + "," + lon + ") index:"+shotlocal.get(0).getIndex());
		return list.get(shotlocal.get(0).getIndex());
	}
	/**
	 * 获取最短的距离
	 * 
	 * @param lat
	 * @param lon
	 * @param initlat
	 * @param initlon
	 * @return
	 */
	public static Double GetShotLocal(Double lat, Double lon, Double initlat, Double initlon) {
		Double x = (initlat - lat) * (initlat - lat);
		Double y = (initlon - lon) * (initlon - lon);
		Double z = Math.sqrt(x + y);
		return z;
	}
	/**
	 * 对List<LocalAddress> 进行排序
	 * 
	 * @return
	 */
	public static List<FeatureLoactionVo> getLocalList(List<FeatureLoactionVo> list) {
		Collections.sort(list, new Comparator<FeatureLoactionVo>() {
			@Override
			public int compare(FeatureLoactionVo arg0, FeatureLoactionVo arg1) {
				Double double1 = arg0.getDistance();
				Double double2 = arg1.getDistance();
				if (double1 > double2) {
					return 1;
				} else if (double1 == double2) {
					return 0;
				} else {
					return -1;
				}
			}
		});
		return list;
	}
	
	public static double getquality(String roll,String pitch,String yaw,String blurness)
	{
		LOGGER.debug("roll is : "+roll+" ,pitch is : "+pitch+" ,yaw is : "+yaw+" ,blurness is : "+blurness);
		double sum_roll=Math.abs(Double.parseDouble(roll));
		if(sum_roll>=90)
		{
			sum_roll=0;
		}else
		{
			sum_roll=(1-sum_roll/90)*25;
		}
		
		double sum_pitch=(1-(Math.abs(Double.parseDouble(pitch)))/90)*25;
		double sum_yaw=(1-(Math.abs(Double.parseDouble(yaw)))/90)*25;
		double sum_blurness=(1-Math.abs(Double.parseDouble(blurness)))*25;
		LOGGER.debug("sum_roll is : "+sum_roll+" ,sum_pitch is : "+sum_pitch+" ,sum_yaw is : "+sum_yaw+" ,sum_blurness is : "+sum_blurness);
		return sum_roll+sum_pitch+sum_yaw+sum_blurness;
	}
	
	@Override
	public InitGroupResponse initGroup(InitGroupRequest req) {
		LOGGER.debug("initGroup "+req.toString());
		Map<String, String> textMap = new HashMap<String, String>();
		InitGroupResponse rsp=new InitGroupResponse();
		rsp.setResult(true);
		textMap.put("groupname", req.getGroupname());
		String url="http://"+req.getIp()+":"+req.getPort1()+"/group/init";
		JSONObject jsonObject;
		try {
			String result = HtttpUtil.httpPostFrom_data(url, textMap,null);
			if(StringUtils.checkEmpty(result))
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
				return rsp;
			}
			LOGGER.debug("initGroup GPU result ------ "+result);
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		GroupInitOutVo groupinitoutvo=JSONObject.toJavaObject(jsonObject, GroupInitOutVo.class);
		if(groupinitoutvo!=null)
		{
			String error=groupinitoutvo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		return rsp;
	}
	@Override
	public GetGroupListReponse getGroupList(GetGroupListRequest req) {
		LOGGER.debug("getGroupList "+req.toString());
		String url="http://"+req.getIp()+req.getPort1()+"/group/list";
		GetGroupListReponse rsp=new GetGroupListReponse();
		rsp.setResult(true);
		JSONObject jsonObject;
		try {
			String result = HtttpUtil.getCurlData(url);
			if(StringUtils.checkEmpty(result))
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
				return rsp;
			}
			LOGGER.debug("getGroupList GPU result ------ "+result);
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		GroupListOutVo grouplistoutvo=JSONObject.toJavaObject(jsonObject, GroupListOutVo.class);
		if(grouplistoutvo!=null)
		{
			String error=grouplistoutvo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		List<String> groups = grouplistoutvo.getGroups();
		rsp.setGroups(groups);
		return rsp;
	}
	
	@Override
	public DeleteGroupResponse deleteGroup(DeleteGroupRequest req) {
		LOGGER.debug("deleteGroup "+req.toString());
		Map<String, String> textMap = new HashMap<String, String>();
		DeleteGroupResponse rsp=new DeleteGroupResponse();
		rsp.setResult(true);
		textMap.put("groupname", req.getGroupname());
		String url="http://"+req.getIp()+":"+req.getPort1()+"/group/free";
		JSONObject jsonObject;
		try {
			String result = HtttpUtil.httpPostFrom_data(url, textMap,null);
			if(StringUtils.checkEmpty(result))
			{
				rsp.setResult(false);
				rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
				return rsp;
			}
			LOGGER.debug("initGroup GPU result ------ "+result);
			jsonObject = JSONObject.parseObject(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("return is not json! "+e.getMessage(),e);
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR_JSON);
			return rsp;
		}
		GroupDeleteOutVo groupdeleteoutvo=JSONObject.toJavaObject(jsonObject, GroupDeleteOutVo.class);
		if(groupdeleteoutvo!=null)
		{
			String error=groupdeleteoutvo.getError();
			if(error!=null)
			{
				rsp.setResult(false);
				rsp.setError(GpuCodeUtil_G001.tranCode(error));
				return rsp;
			}
		}else
		{
			rsp.setResult(false);
			rsp.setError(GpumpErrorInfoModel.GPURESULTERROR);
			return rsp;
		}
		return rsp;
	}

	public static void main(String[] args) {
		String option=args[0];
		if("-h".equals(option)||"-help".equals(option))
		{
			System.out.println("optipn for one value");
			System.out.println("1 --- getFeature ,获取特征值。param1 1,param2 ip:port,param3 imagefile");
			System.out.println("2 --- compare ,2个特征值比对");
			System.out.println("3 --- verify ,2个图片比对");
			System.out.println("4 --- add ,2个添加特征值到人脸库");
			System.out.println("5 --- search ,特征值一比N比对");
			return;
		}
		if("1".equals(args[0]))
		{
			
		}
	}
}
