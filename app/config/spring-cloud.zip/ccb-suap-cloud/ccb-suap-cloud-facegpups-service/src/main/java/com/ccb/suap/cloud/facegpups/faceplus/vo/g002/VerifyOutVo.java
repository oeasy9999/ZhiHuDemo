package com.ccb.suap.cloud.facegpups.faceplus.vo.g002;

public class VerifyOutVo {

	private String result;
	private String score;
	private String errorMessage;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	@Override
	public String toString() {
		return "VerifyOutVo [result=" + result + ", score=" + score + ", errorMessage=" + errorMessage + "]";
	}

	
}
