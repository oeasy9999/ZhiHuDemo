package com.ccb.suap.cloud.facegpups.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import com.ccb.suap.cloud.facegpups.model.GpumpSysparaModel;

@Mapper
@Component
public interface GpumpSysparaMapper {
		
    GpumpSysparaModel select(@Param("paracode") String paracode, @Param("paratype") String paratype);
    
    GpumpSysparaModel selectCommPara(String paracode);
    
    GpumpSysparaModel selectServerPara(String paracode);

    List<GpumpSysparaModel> selectAll();
    
    int count();
    
    int insert(GpumpSysparaModel model);
    
    int update(GpumpSysparaModel model);
    
    int delete(GpumpSysparaModel model);
    
    int checkDataBaseStatus();
}
