package com.ccb.suap.cloud.facegpups.beans;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareImageRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareImageResponse;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import com.ccb.suap.cloud.facegpups.model.GpumpRealFacedbModel;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpGpuInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpRealFacedbParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.PhotoUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1009ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1009ServiceOutVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1010ServiceInVo;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.log.TraceLog;
/**
 * 传入2张图片比对
 * @author zhanzifeng
 *
 */
public class GPUMP1009_Bean  extends GPUMPBean{
	private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");
	//private static final Logger LOGGER = LoggerBuilder.getLogger("./logs","facegpups-GPUMP1009","100MB",SysParaUtil.getStrValue("LogLevel:1","info").toLowerCase());
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws Exception {
		LOGGER.debug("---------调用GPUMP1009_Bean服务---------");
		LOGGER.debug("reqMsg: "+reqMsg.toString());
		if(!checkPara(rspMsg,reqMsg))
		{
			TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1009", null);
			return rspMsg; 
		}
		TxResponseMsgHead tx_header = rspMsg.getTx_header();
		String traceid=tx_header.getSys_evt_trace_id();
		logtime.put("verifyTime", (long) 0);
		logtime.put("saveFileTime", (long) 0);
		saveFaceImageByUrl(reqMsg,logtime,traceLog);
		GPUMP1009ServiceInVo invo=(GPUMP1009ServiceInVo)reqMsg.getTx_body().getEntity();
		String face_image = invo.getFace_image();
		String face_refer_image = invo.getFace_refer_image();
		TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		String sysChannelID=Com2.getSysChannelID();
		String GroupName=Com2.getGroupName();
		LOGGER.debug("sysChannelID : "+sysChannelID);
		LOGGER.debug("GroupName : "+GroupName);
		String similarity=null;
		boolean flag=false;
		GpumpLogicFacedbModel gpumpLogicFacedbModel=ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID+":"+GroupName);
		if(gpumpLogicFacedbModel!=null)
		{
			String logic_db_id=gpumpLogicFacedbModel.getLogic_db_id();
			
			if("1".equals(gpumpLogicFacedbModel.getType())&&!"T".equals(gpumpLogicFacedbModel.getIs_mount_gpu()))
			{
				
				LOGGER.debug(logic_db_id+" is a register base,have no mount gpu.");
				//注册库并且没有挂载GPU,向下找有没有快速库
				List<GpumpLogicFacedbModel> gpumpLogicFacedbModel_list =ServiceParaUtil.getLogicFacedbValueBySourceDbId(logic_db_id,"2");
				if(gpumpLogicFacedbModel_list!=null&&!gpumpLogicFacedbModel_list.isEmpty())
				{
					//随机获取一个快速库
					gpumpLogicFacedbModel = gpumpLogicFacedbModel_list.get((int)(Math.random()*gpumpLogicFacedbModel_list.size()));
				
					List<GpumpRealFacedbModel> GpumpRealFacedbModel_list = gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
					if(GpumpRealFacedbModel_list!=null)
					{
						GpumpRealFacedbModel gpumpRealFacedbModel = GpumpRealFacedbModel_list.get((int)(Math.random()*GpumpRealFacedbModel_list.size()));
						GpumpGpuInfoModel gpumpGpuInfo = gpumpRealFacedbModel.getGpumpGpuInfo();
						if(gpumpGpuInfo!=null)
						{
							similarity = verifyForTwoImage(face_image, face_refer_image, gpumpGpuInfo, traceid, logtime,traceLog);
							flag=true;
						}else
						{
							LOGGER.warn(" this RealFacedb,have no GpuInfo!");
						}
					}else
					{
						LOGGER.warn(" this register base,have no RealFacedb!");
					}
				}else{
					LOGGER.warn(GroupName+"  fast db is not exist!");
				}
			}else 
			{
				if("1".equals(gpumpLogicFacedbModel.getType())&&"T".equals(gpumpLogicFacedbModel.getIs_mount_pag())){
					//查找注册库挂载的页位库
					List<GpumpLogicFacedbModel> gpumpLogicFacedbModel_list =ServiceParaUtil.getLogicFacedbValueBySourceDbId(logic_db_id,"3");
					if(gpumpLogicFacedbModel_list!=null)
					{
						//随机获取一个注册库
						gpumpLogicFacedbModel = gpumpLogicFacedbModel_list.get((int)(Math.random()*gpumpLogicFacedbModel_list.size()));
					}else{
						LOGGER.error(GroupName+"  page db is not exist!");
						throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
					}
				}
				
				
				List<GpumpRealFacedbModel> gpumpRealFacedbModelList = gpumpLogicFacedbModel.getGpumpRealFacedbModelList();
				if(gpumpRealFacedbModelList!=null)
				{
					GpumpRealFacedbModel gpumpRealFacedbModel=gpumpRealFacedbModelList.get((int)(Math.random()*gpumpRealFacedbModelList.size()));//随机获取一个物理库
					GpumpGpuInfoModel gpumpGpuInfoModel=gpumpRealFacedbModel.getGpumpGpuInfo();
					if(gpumpGpuInfoModel!=null)
					{
						LOGGER.error("gpumpGpuInfoModel is null,real_db_id is : "+gpumpRealFacedbModel.getReal_db_id());
						similarity = verifyForTwoImage(face_image, face_refer_image, gpumpGpuInfoModel, traceid, logtime,traceLog);
						flag=true;
					}else
					{
						LOGGER.warn("this RealFacedb base have no GpuInfo!");
					}
				}else
				{
					LOGGER.warn(" this fast base,have no RealFacedb!");
				}
			}
		}else
		{
			LOGGER.warn("gpumpLogicFacedbModel is null!");
		}
		
		//如果都没找到，随机找一个gpu
		if(!flag)
		{
			LOGGER.warn("can not find a gpu to verify,must be random acquistion a gpu!");
			Hashtable<String, GpumpGpuInfoModel> gpuinfo_list = GpumpGpuInfoParaUtil.getParaByName();
			if(gpuinfo_list==null||gpuinfo_list.size()==0)
			{
				LOGGER.error("gpuinfo is null!");
				throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
			}
			List<GpumpGpuInfoModel> gpuinfolist=new ArrayList<GpumpGpuInfoModel>(gpuinfo_list.values());
			GpumpGpuInfoModel gpumpGpuInfoModel=gpuinfolist.get((int)(Math.random()*gpuinfolist.size()));
			similarity = verifyForTwoImage(face_image, face_refer_image, gpumpGpuInfoModel, traceid, logtime,traceLog);
		}
		GPUMP1009ServiceOutVo outvo=new GPUMP1009ServiceOutVo();
		outvo.setSimilarity(similarity);
		TxResponseMsgBody MsgBody=new TxResponseMsgBody();
		MsgBody.setEntity(outvo);
		rspMsg.setTx_body(MsgBody);
		TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1009",GpumpErrorInfoModel.NOERROR);
		return rspMsg;
	}

	@Override
	public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		boolean flag=true;
		 TxResponseMsgHead rspHeader =rspMsg.getTx_header();
		 GPUMP1009ServiceInVo invo=(GPUMP1009ServiceInVo) reqMsg.getTx_body().getEntity();
		 TxRequestMsgCom2 Com2=reqMsg.getTx_body().getCom2();
		if(invo.getFace_refer_image()==null)
		 {
			 LOGGER.error("checkPara ---- Face_image can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_REFERFACEIMAGE));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_REFERFACEIMAGE);
			 flag= false;
		 }else if(invo.getFace_image()==null)
		 {
			 LOGGER.error("checkPara ---- Face_image can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE);
			 flag= false;
		 }else if(Com2.getGroupName()==null)
		 {
			 LOGGER.error("checkPara ---- GroupName can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
			 flag= false;
		 }else if(Com2.getSysChannelID()==null)
		 {
			 LOGGER.error("checkPara ---- SysChannelID can not be null!");
			 rspHeader.setSys_resp_desc(GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
			 rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
			 flag= false;
		 }
		rspMsg.setTx_header(rspHeader);
		return flag;
	}

	@Override
	public Object transform(JSONObject indata) throws Exception {
		JSONObject tx_body=indata.getJSONObject("tx_body");
		if(tx_body==null)
		{
			LOGGER.error("tx_body is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject entity=tx_body.getJSONObject("entity");
		if(entity==null)
		{
			LOGGER.error("entity is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		JSONObject com2=tx_body.getJSONObject("com2");
		if(com2==null)
		{
			LOGGER.error("com2 is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
		}
		TxRequestMsg reqMsg=(TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
		GPUMP1009ServiceInVo invo=(GPUMP1009ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1009ServiceInVo.class);
		TxRequestMsgCom2 com=JSON.parseObject(JSON.toJSONString(com2),TxRequestMsgCom2.class);
		
		TxRequestMsgBody MsgBody=reqMsg.getTx_body();
		MsgBody.setEntity(invo);
		MsgBody.setCom2(com);
		reqMsg.setTx_body(MsgBody);
		return reqMsg;
	}

	@Override
	public List<GpuRegisterTask> getGpuTask() {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * 比对2张人脸图片的特征值
	 * @param faceImage1			人脸图片1
	 * @param faceImage2			人脸图片2
	 * @param gpumpGpuInfoModel		GPU实例
	 * @param traceid				全局交易流水号
	 * @param logtime				各环节耗时缓存
	 * @param traceLog				报文日志缓存类
	 * @return	相似度
	 */
	public String verifyForTwoImage(String faceImage1,String faceImage2,GpumpGpuInfoModel gpumpGpuInfoModel,String traceid,HashMap<String, Long> logtime,TraceLog traceLog)
	{
		String gpu_type_id = gpumpGpuInfoModel.getGpu_type_id();
		String gpuclassname="com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_" + gpu_type_id + "_Bean";
		//GpuInterface gpuBean=GpuMeth.getBeanClass(gpuclassname);
		GpuInterface gpuBean=(GpuInterface) Utils.getInstance(gpuclassname);
		if(gpuBean==null)
		{
			LOGGER.error("GPUMP "+gpu_type_id+" service is no exist!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.GPUGROUPERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUGROUPERROR));
		}
		CompareImageRequest verifyinvo=new CompareImageRequest();
		verifyinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
		verifyinvo.setPort1(gpumpGpuInfoModel.getGpu_port1());
		verifyinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
		verifyinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
		verifyinvo.setTraceid(traceid);
		verifyinvo.setImage1(faceImage1);
		verifyinvo.setImage2(faceImage2);
		LOGGER.debug("begin verify for GPU");
		long start = System.currentTimeMillis();
		CompareImageResponse verifyOutVo = gpuBean.compareImage(verifyinvo,traceLog);
		long end = System.currentTimeMillis();
		//verifyTime=verifyTime+end-start;
		logtime.put("verifyTime", logtime.get("verifyTime")+end-start);
		traceLog.setCompareImageTime(traceLog.getCompareImageTime()+end-start);
		if(verifyOutVo==null)
		{
			LOGGER.error("verify user error!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.GPURESULTERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPURESULTERROR));
		}
		if(!verifyOutVo.getResult())
		{
			LOGGER.error("verify user error!message is "+verifyOutVo.getError());
			throw new CommonRuntimeException(verifyOutVo.getError(),GpumpErrorInfoParaUtil.getErrorMsg(verifyOutVo.getError()));
		}
		LOGGER.debug(verifyOutVo.toString());
		String similarity=verifyOutVo.getScore();
		LOGGER.info("verify return Confidence is "+similarity);
		if(similarity==null)
		{
			LOGGER.error("compare return Confidence is null!");
			throw new CommonRuntimeException(GpumpErrorInfoModel.GPURESULTERROR,GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPURESULTERROR));
		}
		LOGGER.debug("end verify for GPU");
		return similarity;
	}
	  /**
	   * 保存图片到nas目录，目录 yyyyMMddHHmm，每10分钟一个目录 文件名 客户号_yyyyMMddHHmmss.jpg
	   *
	   * @param param 交易流程数据类
	 * @throws IOException 
	   */
	  public void saveFaceImageByUrl(TxRequestMsg reqMsg,HashMap<String, Long> logtime,TraceLog traceLog) throws IOException {
		  String logImgCof=SysParaUtil.getStrPara("LOGIMGCOF:1","1");
		  if("1".equals(logImgCof)){
			GPUMP1009ServiceInVo invo = (GPUMP1009ServiceInVo) reqMsg.getTx_body().getEntity();
		    String sysChannelID = reqMsg.getTx_body().getCom2().getSysChannelID();
		    String face_image = invo.getFace_image();
		    String face_image2 = invo.getFace_refer_image();
		    String transflow = reqMsg.getTx_header().getSys_evt_trace_id();
			String log_image_addr_nas = PhotoUtil.getPath("image_addr:1", "/"+sysChannelID+"/faceComplmage", "GPUMP1009_"+transflow+"_1");
			String log_image_addr_nas2 = PhotoUtil.getPath("image_addr:1", "/"+sysChannelID+"/faceComplmage", "GPUMP1009_"+transflow+"_2");
			traceLog.setFace_image(face_image);
			traceLog.setFace_image2(face_image2);
		    traceLog.setLog_image_addr_nas(log_image_addr_nas);
		    traceLog.setLog_image_addr_nas2(log_image_addr_nas2);
	    }
	  }

}
