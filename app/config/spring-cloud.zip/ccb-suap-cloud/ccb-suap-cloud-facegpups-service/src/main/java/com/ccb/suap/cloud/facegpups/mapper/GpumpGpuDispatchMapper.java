package com.ccb.suap.cloud.facegpups.mapper;

import com.ccb.suap.cloud.facegpups.model.GpumpGpuDispatchModel;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface GpumpGpuDispatchMapper {
  List<GpumpGpuDispatchModel> selectAll();

}
