package com.ccb.suap.cloud.exception;

public class ActionFlowExceedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 564538811814032386L;

	public ActionFlowExceedException() {
		super();
	}

	public ActionFlowExceedException(final String s) {
		super(s);
	}
}