package com.ccb.suap.cloud.facegpups.model;

import java.io.Serializable;

public class GpumpSequenceModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String seq_name;
	private int current_val;
	private int increment_val;
	private int num;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getSeq_name() {
		return seq_name;
	}
	public void setSeq_name(String seq_name) {
		this.seq_name = seq_name;
	}
	public int getCurrent_val() {
		return current_val;
	}
	public void setCurrent_val(int current_val) {
		this.current_val = current_val;
	}
	public int getIncrement_val() {
		return increment_val;
	}
	public void setIncrement_val(int increment_val) {
		this.increment_val = increment_val;
	}
	
}
