package com.ccb.suap.cloud.facegpups.beans;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.exception.CommonRuntimeException;
import com.ccb.suap.cloud.facegpups.controller.FacegpupsController;
import com.ccb.suap.cloud.facegpups.dao.factory.GpumpDaoFactory;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.facegpups.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareImageRequest;
import com.ccb.suap.cloud.facegpups.faceplus.vo.CompareImageResponse;
import com.ccb.suap.cloud.facegpups.inf.GpuInterface;
import com.ccb.suap.cloud.facegpups.model.GpumpCustInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpErrorInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpGpuInfoModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicCapModel;
import com.ccb.suap.cloud.facegpups.model.GpumpLogicFacedbModel;
import com.ccb.suap.cloud.facegpups.service.Gpump1001RollbackService;
import com.ccb.suap.cloud.facegpups.service.RedisService;
import com.ccb.suap.cloud.facegpups.service.RockerMqService;
import com.ccb.suap.cloud.facegpups.service.SequenceService;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpErrorInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.GpumpGpuInfoParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.PhotoUtil;
import com.ccb.suap.cloud.facegpups.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.facegpups.service.utils.SysParaUtil;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTask;
import com.ccb.suap.cloud.facegpups.task.GpuRegisterTaskThread;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1001ServiceInVo;
import com.ccb.suap.cloud.facegpups.vo.GPUMP1001ServiceOutVo;
import com.ccb.suap.cloud.facegpups.vo.ServiceInVoParam1001;
import com.ccb.suap.util.Utils;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.log.thread.MultithreadingLogExecutor;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Decoder;
/*
 * 人脸1:N注册
 * */

public class GPUMP1001_Bean extends GPUMPBean {

  private static final Logger LOGGER = LoggerFactory.getLogger("GPUMPBeans");
  private static final Logger LOGGER_TASK = LoggerFactory.getLogger("TASK");
  private static final Logger LOGGER_IMAGETASK = LoggerFactory.getLogger("IMAGETASK");

  private SequenceService sequenceService = GpumpDaoFactory.getDaoManager().getSequenceService();
  private Gpump1001RollbackService gpump1001RollbackService =
      GpumpDaoFactory.getDaoManager().getGpump1001RollbackService();
  private RockerMqService RockerMqService = GpumpDaoFactory.getDaoManager().getRockerMqService();
  private RedisService redisService = GpumpDaoFactory.getDaoManager().getRedisService();

  @Override
  public boolean checkPara(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
    boolean flag = true;
    TxResponseMsgHead rspHeader = rspMsg.getTx_header();
    GPUMP1001ServiceInVo invo = (GPUMP1001ServiceInVo) reqMsg.getTx_body().getEntity();
    TxRequestMsgCom2 Com2 = reqMsg.getTx_body().getCom2();
    if (invo.getId_type() == null || invo.getId_type().length() > 4) {
      LOGGER.error("checkPara ---- Id_type is null,or too long!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_IDTYPE));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_IDTYPE);
      flag = false;
    }
    if (invo.getCust_id() == null) {
      LOGGER.error("checkPara ---- Cust_id can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_CUSTID);
      flag = false;
    } else if (invo.getFace_image() == null) {
      LOGGER.error("checkPara ---- Face_image can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_FACEIMAGE);
      flag = false;
    } else if (Com2.getGroupName() == null) {
      LOGGER.error("checkPara ---- GroupName can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_GROUPNAME);
      flag = false;
    } else if (Com2.getSysChannelID() == null) {
      LOGGER.error("checkPara ---- SysChannelID can not be null!");
      rspHeader.setSys_resp_desc(
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID));
      rspHeader.setSys_resp_code(GpumpErrorInfoModel.PARAMENOEXIST_SYSCHANNELID);
      flag = false;
    } else if (invo.getThreshold() == null) {
      LOGGER.warn("checkPara ---- threshold is not null,set 95.");
      invo.setThreshold("95");
    }
    rspMsg.setTx_header(rspHeader);
    return flag;
  }

  @Override
  public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,
      HashMap<String, Long> logtime, TraceLog traceLog) throws Exception {
    LOGGER.info("---------调用GPUMP1001_Bean服务---------");
    if (!FacegpupsController.dbflag) {
      throw new CommonRuntimeException(GpumpErrorInfoModel.DB_EXCEPTION,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.DB_EXCEPTION));
    }
    if (!checkPara(rspMsg, reqMsg)) {
      TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1001", null);
      return rspMsg;
    }
    ServiceInVoParam1001 param = new ServiceInVoParam1001();
    //设置交易流程参数
    setparam(param, logtime, reqMsg);
    //获取逻辑库列表
    genLogicFaceModel(param);
    // 校验逻辑库容量是否超限
    checkLogicFaceDbCap(param);
    //保存注册图片,返回本地保存路径
    saveFaceImageByUrl(param,traceLog);

    //如果有参考图片，先对比
    String face_refer_image = param.getFace_refer_image();
    if (face_refer_image != null && face_refer_image.length() > 0) {
      boolean result =
          compareForTwoImage(param.getFace_image(), face_refer_image, param.getThreshold(),
              param.getTraceid(), param.getLogtime(), traceLog);
      if (!result) {
        LOGGER.error("compareForTwoFeature error!");
        throw new CommonRuntimeException(GpumpErrorInfoModel.GPUSEARCHERROR,
            GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUSEARCHERROR));
      }
    }
    try {
      GpumpLogicFacedbModel gpumpLogicFacedbModel = param.getGpumpLogicFacedbModel();
      String cust_id = param.getCust_id();
      //判断是否挂载页位库
      if ("T".equals(gpumpLogicFacedbModel.getIs_mount_pag())) {

        String real_group_id = null;
        //通过查找客户信息查询客户特征值是否在分表存在
        GpumpCustInfoModel gpumpCustInfmodel =
            redisService.selectCustInfo(gpumpLogicFacedbModel.getLogic_db_id(), cust_id);
        if (gpumpCustInfmodel != null) {
          real_group_id = gpumpCustInfmodel.getReal_group_id();
          if (real_group_id != null && !"".equals(real_group_id)) {
            //通过客户的存在的页位表ID查询页位库信息和页位库挂载的gpu
            gpumpLogicFacedbModel = ServiceParaUtil.getAllGpuDBMsgByID(real_group_id);
          } else {
            LOGGER.error("page gpumpLogicFacedbModel is null!");
            throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,
                GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
          }
        } else {
          String sysChannelID = param.getSysChannelID();
          String GroupName = param.getGroupName();
          //客户信息不存在，通过取模的方式确定客户信息存放的页位库
          gpumpLogicFacedbModel =
              ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID + ":" + GroupName, cust_id, "3");
          if (gpumpLogicFacedbModel == null) {
            LOGGER.error("page gpumpLogicFacedbModel is null!");
            throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,
                GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
          }
          real_group_id = gpumpLogicFacedbModel.getLogic_db_id();
        }
        param.setReal_group_id(real_group_id);
        //如果是页位库，则将页位库存储在param

      }
      param.setGpumpLogicFacedbModel(gpumpLogicFacedbModel);
      String logic_db_id = gpumpLogicFacedbModel.getLogic_db_id();
      SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
      String date = sdf.format(new Date());
      String feature_id_new = date + sequenceService.select("SEQ_" + logic_db_id) + "";
      param.setFeature_id_new(feature_id_new);
      gpump1001RollbackService.Gpump1001Rollback(param, traceLog);
      //提交事务后redis处理开始
      redisConduct(param);
    } catch (CommonRuntimeException e) {
      List<GpuRegisterTask> gpuRegisterTask_list = param.getGpuRegisterTask_list();
      GpuRegisterTaskThread GpuRegisterTaskThread =
          new GpuRegisterTaskThread(gpuRegisterTask_list, param.getTraceid());
      MultithreadingLogExecutor.addLogTaskRoolback(GpuRegisterTaskThread);
      String image_addr = param.getImage_addr();
      if (image_addr != null && !"".equals(image_addr.trim())) {
        deleteImage(image_addr);
      }
      LOGGER.error("gpump1001RollbackService error,message is : " + e.getMessage(), e);
      throw e;
    } catch (Exception e) {
      List<GpuRegisterTask> gpuRegisterTask_list = param.getGpuRegisterTask_list();
      GpuRegisterTaskThread GpuRegisterTaskThread =
          new GpuRegisterTaskThread(gpuRegisterTask_list, param.getTraceid());
      MultithreadingLogExecutor.addLogTaskRoolback(GpuRegisterTaskThread);
      String image_addr = param.getImage_addr();
      if (image_addr != null && !"".equals(image_addr.trim())) {
        deleteImage(image_addr);
      }
      throw e;
    }

/*    RegisterImage registerimage = new RegisterImage();
    registerimage.setImage_addr(param.getImage_addr());
    registerimage.setImage_addr_nas(param.getImage_addr_nas());
    registerimage.setImage_addr_old(param.getImage_addr_old());
    registerimage.setLog_image_addr(param.getLog_image_addr());
    registerimage.setLog_image_addr_nas(param.getLog_mage_addr_nas());
    RegisterTask.addTask(param.getTraceid() + "_" + param.getCust_id(), registerimage);
    JSONObject json = (JSONObject) JSONObject.toJSON(registerimage);
    LOGGER_IMAGETASK.debug(param.getTraceid() + "_" + param.getCust_id() + "||" + json.toString());*/

    GPUMP1001ServiceOutVo outvo = new GPUMP1001ServiceOutVo();
    TxResponseMsgBody MsgBody = new TxResponseMsgBody();
    MsgBody.setEntity(outvo);
    rspMsg.setTx_body(MsgBody);

    TxResponseMsgHead.setTxResponseMsgHead(rspMsg, "GPUMP1001", GpumpErrorInfoModel.NOERROR);
    LOGGER.debug("GPUMP1001_Bean end!");
    return rspMsg;
  }

  /**
   * 设置服务流程参数方法
   *
   * @param param 流程数据类
   * @param logtime 各环节耗时缓存
   * @param reqMsg 请求数据
   */
  void setparam(ServiceInVoParam1001 param, HashMap<String, Long> logtime, TxRequestMsg reqMsg) {

    TxRequestMsgHead reqMsgHead = reqMsg.getTx_header();
    String traceid = reqMsgHead.getSys_evt_trace_id();
    List<GpuRegisterTask> gpuRegisterTask_list = new ArrayList<GpuRegisterTask>();//记录已经到GPU注册的任务
    List<String> redisTask_list = new ArrayList<String>();//记录已经到GPU注册的任务
    logtime.put("insertTime", (long) 0);
    logtime.put("updateTime", (long) 0);
    logtime.put("selectTime", (long) 0);
    logtime.put("registerForGpuTime", (long) 0);
    logtime.put("deleteForGpuTime", (long) 0);
    logtime.put("compareTime", (long) 0);
    logtime.put("extractForGpuTime", (long) 0);
    logtime.put("saveFileTime", (long) 0);
    GPUMP1001ServiceInVo invo = (GPUMP1001ServiceInVo) reqMsg.getTx_body().getEntity();
    TxRequestMsgCom2 Com2 = reqMsg.getTx_body().getCom2();
    String GroupName = Com2.getGroupName();
    String sysChannelID = Com2.getSysChannelID();
    param.setThreshold(invo.getThreshold());
    param.setSysChannelID(sysChannelID);
    param.setGroupName(GroupName);
    param.setFace_image(invo.getFace_image());
    param.setFace_refer_image(invo.getFace_refer_image());
    param.setCust_id(invo.getCust_id());
    param.setId_no(invo.getId_no());
    param.setId_type(invo.getId_type());
    param.setName(invo.getName());
    param.setMobile_no(invo.getMobile_no());
    param.setLogtime(logtime);
    param.setTraceid(traceid);
    param.setGpuRegisterTask_list(gpuRegisterTask_list);
    param.setRedisTask_list(redisTask_list);
    param.setTransflow(reqMsg.getTx_header().getSys_evt_trace_id());
  }

  private void checkLogicFaceDbCap(ServiceInVoParam1001 param) {
    String logic_db_id = param.getGpumpLogicFacedbModel().getLogic_db_id();
    String cust_id = param.getCust_id();
    GpumpCustInfoModel gpumpCustInfoModel = redisService.selectCustInfo(logic_db_id, cust_id);
    if (null != gpumpCustInfoModel) {
      return;
    }
    String key = "LOGICFACEDB_CAPACITY_" + logic_db_id;
    GpumpLogicCapModel facedbModel = redisService.selectLogicDbCap(key);
    int capacity = Integer.valueOf(facedbModel.getCapacity());
    int total_capacity = Integer.valueOf(facedbModel.getTotalCapacity());
   
    param.setCapacity(capacity);
    param.setTotalCapacity(total_capacity);
    if(total_capacity>0){
	    if (capacity > total_capacity) {
	      throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBCAPACITYERROR,
	          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBCAPACITYERROR));
	    }
    }
  }

  /**
   * 处理redis任务方法
   *
   * @param param 交易流程数据类
   */
  public void redisConduct(ServiceInVoParam1001 param) {
    List<String> redisTask_list = param.getRedisTask_list();
    if (redisTask_list != null && redisTask_list.size() > 0) {
      for (String task : redisTask_list) {
        String arg[] = task.split("\\|\\|");
        if (arg.length >= 3) {
          String type = arg[0];
          String key = arg[1];
          String data = arg[2];
          RockerMqService.sendRedisOrMq(key, data, type);
        } else {
          LOGGER.warn("this task no 3 param, data is : " + task);
        }
      }
    } else {
      LOGGER.debug("redisTask_list is null");
    }
  }

  /**
   * 获取逻辑库实例方法，设置到流程数据实例内
   *
   * @param param 交易流程数据类
   */
  public void genLogicFaceModel(ServiceInVoParam1001 param) {
    String sysChannelID = param.getSysChannelID();
    String GroupName = param.getGroupName();
    //根据渠道号查询逻辑库
    GpumpLogicFacedbModel gpumpLogicFacedbModel =
        ServiceParaUtil.getAllGpuDBMsgByName(sysChannelID + ":" + GroupName);
    if (gpumpLogicFacedbModel == null) {
      LOGGER.error(GroupName + " is not exist!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
    } else if (!gpumpLogicFacedbModel.getType().equals("1")) {
      LOGGER.error(GroupName + " is not register base!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.LOGICFACEDBERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.LOGICFACEDBERROR));
    }
	
	/*	if("T".equals(gpumpLogicFacedbModel.getIs_mount_pag())){
			//获取分页库分页库
			GpumpLogicFacedbModel	gpumpLogicFacedbModel2=ServiceParaUtil.getAllGpuDBMsgByName(param);
			gpumpLogicFacedbModel = gpumpLogicFacedbModel2;
		}*/
    param.setGpumpLogicFacedbModel(gpumpLogicFacedbModel);
  }

  /**
   * 对比2各图片的相似度是否达到阈值
   *
   * @param faceImage1 人脸图片1
   * @param faceImage2 人脸图片2
   * @param threshold 比对阈值
   * @param traceid 交易全局流水号
   * @param logtime 各环节耗时缓存
   * @param traceLog 日志报文缓存类
   * @return boolean   true比对成功，false比对失败
   */
  public boolean compareForTwoImage(String faceImage1, String faceImage2, String threshold,
      String traceid, HashMap<String, Long> logtime, TraceLog traceLog) {

    Hashtable<String, GpumpGpuInfoModel> paraByName = GpumpGpuInfoParaUtil.getParaByName();
    if (paraByName == null || paraByName.size() == 0) {
      LOGGER.error("compareForTwoFeature ----- GPU info is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPULISTERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPULISTERROR));
    }
    String[] keys = paraByName.keySet().toArray(new String[0]);
    String randomkey = keys[(int) (Math.random() * paraByName.size())];
    GpumpGpuInfoModel gpumpGpuInfoModel = paraByName.get(randomkey);
    String gpuclassname = "com.ccb.suap.cloud.facegpups.gpubeans.GPUTYPE_"
        + gpumpGpuInfoModel.getGpu_type_id()
        + "_Bean";
    //GpuInterface gpuBean=GpuMeth.getBeanClass(gpuclassname);
    GpuInterface gpuBean = (GpuInterface) Utils.getInstance(gpuclassname);
    if (gpuBean == null) {
      LOGGER.error("GPUMP " + gpumpGpuInfoModel.getGpu_type_id() + " service is no exist!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPUGROUPERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPUGROUPERROR));
    }
    CompareImageRequest verifyinvo = new CompareImageRequest();
    verifyinvo.setIp(gpumpGpuInfoModel.getGpu_ip());
    verifyinvo.setPort1(gpumpGpuInfoModel.getGpu_port2());
    verifyinvo.setPort2(gpumpGpuInfoModel.getGpu_port2());
    verifyinvo.setPort3(gpumpGpuInfoModel.getGpu_port3());
    verifyinvo.setImage1(faceImage1);
    verifyinvo.setImage2(faceImage2);
    verifyinvo.setTraceid(traceid);
    long start = System.currentTimeMillis();
    CompareImageResponse verifyOutVo = gpuBean.compareImage(verifyinvo, traceLog);
    long end = System.currentTimeMillis();
    //compareTime=compareTime+end-start;
    logtime.put("compareTime", logtime.get("compareTime") + end - start);
    traceLog.setCompareImageTime(traceLog.getCompareImageTime() + end - start);
    //LOGGER.debug(verifyOutVo.toString());
    if (!verifyOutVo.getResult()) {
      LOGGER.error("verify user error!message is " + verifyOutVo.getError());
      throw new CommonRuntimeException(verifyOutVo.getError(),
          GpumpErrorInfoParaUtil.getErrorMsg(verifyOutVo.getError()));
    }
    Double sum1 =
        Double.parseDouble(verifyOutVo.getScore() == null ? "0" : verifyOutVo.getScore().trim());
    Double sum2 = Double.parseDouble(threshold);
    LOGGER.debug("compare return Confidence is " + sum1 + " ,threshold is " + sum2);
    if (sum1 != null && sum2 != null) {
      return sum1 >= sum2 ? true : false;
    } else {
      LOGGER.error("compare return score is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.GPURESULTERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.GPURESULTERROR));
    }
  }

  /**
   * 保存图片到本地目录，同时设置图片的本地路径和异步nas路径，目录 yyyyMMddHHmm，每10分钟一个目录 文件名 客户号_yyyyMMddHHmmss.jpg
   *
   * @param param 交易流程数据类
 * @throws IOException 
   */
  public void saveFaceImageByUrl(ServiceInVoParam1001 param,TraceLog traceLog) throws IOException {
    String sysChannelID = param.getSysChannelID();
    String face_image = param.getFace_image();
    HashMap<String, Long> logtime = param.getLogtime();
    String cust_id = param.getCust_id();
    String file_name =
        cust_id + "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
	String image_addr_nas = PhotoUtil.getPath("image_addr:1", File.separator+sysChannelID+"/FACEMODEL/", file_name);
    param.setImage_addr_nas(image_addr_nas);
    traceLog.setFace_image(face_image);
    traceLog.setImage_addr_nas(image_addr_nas);
    String logImgCof=SysParaUtil.getStrPara("LOGIMGCOF:1","0");
    if("1".equals(logImgCof)){
		String log_mage_addr_nas = PhotoUtil.getPath("image_addr:1", "/"+sysChannelID+"/faceRegImage", cust_id+"_"+param.getTransflow());
	    traceLog.setLog_image_addr_nas(log_mage_addr_nas);
    }

  }

  /**
   * 保存图片，指定文件路径
   *
   * @param filepath 文件绝对路径
   * @param imagedata 文件数据
   * @param logtime 各环节耗时缓存
   */
  public boolean saveFaceImage(String filepath, String imagedata, HashMap<String, Long> logtime) {
    LOGGER.debug("begin to save file url is : " + filepath);
    long start = System.currentTimeMillis();
    boolean flag = true;
    File f = new File(filepath);
    if (!f.getParentFile().exists()) {
      f.getParentFile().mkdirs();
    }
    FileOutputStream targetFile = null;
    try {
      targetFile = new FileOutputStream(f);
      BASE64Decoder decoder = new BASE64Decoder();
      byte[] bytes = decoder.decodeBuffer(imagedata);
      targetFile.write(bytes);
      targetFile.close();
    } catch (FileNotFoundException e) {
      // TODO Auto-generated catch block
      flag = false;
      LOGGER.error("save file error : " + e.getMessage(), e);
    } catch (IOException e) {
      // TODO Auto-generated catch block
      flag = false;
      LOGGER.error("save file error : " + e.getMessage(), e);
    } finally {
      if (targetFile != null) {
        try {
          targetFile.close();
        } catch (IOException e) {
          // TODO Auto-generated catch block
          LOGGER.error("targetFile error:" + e);
        }
      }
    }
    long end = System.currentTimeMillis();
    //saveFileTime=saveFileTime+end-start;
    logtime.put("saveFileTime", logtime.get("saveFileTime") + end - start);
    LOGGER.debug("end to save file.");
    return flag;
  }

  @Override
  public Object transform(JSONObject indata) throws Exception {
    JSONObject tx_body = indata.getJSONObject("tx_body");
    if (tx_body == null) {
      LOGGER.error("tx_body is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
    }
    JSONObject entity = tx_body.getJSONObject("entity");
    if (entity == null) {
      LOGGER.error("entity is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
    }
    JSONObject com2 = tx_body.getJSONObject("com2");
    if (com2 == null) {
      LOGGER.error("com2 is null!");
      throw new CommonRuntimeException(GpumpErrorInfoModel.MESSAGEFORMATERROR,
          GpumpErrorInfoParaUtil.getErrorMsg(GpumpErrorInfoModel.MESSAGEFORMATERROR));
    }
    TxRequestMsg reqMsg = (TxRequestMsg) JSONObject.toJavaObject(indata, TxRequestMsg.class);
    GPUMP1001ServiceInVo invo =
        (GPUMP1001ServiceInVo) JSONObject.toJavaObject(entity, GPUMP1001ServiceInVo.class);
    TxRequestMsgCom2 com = JSON.parseObject(JSON.toJSONString(com2), TxRequestMsgCom2.class);

    TxRequestMsgBody MsgBody = reqMsg.getTx_body();
    MsgBody.setEntity(invo);
    MsgBody.setCom2(com);
    reqMsg.setTx_body(MsgBody);
    return reqMsg;
  }

  @Override
  public List<GpuRegisterTask> getGpuTask() {
    // TODO Auto-generated method stub
    return null;
  }
}
