package com.ccb.suap.cloud.facegpups.model;

import java.io.Serializable;
import java.util.Date;

public class GpumpCustInfoModel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String logic_db_id;
	private String real_group_id;			//分页库REAL_GROUP_ID
	private String cust_id;
	private String id_type;
	private String id_no;
	private String name;
	private String mobile_no;
	private String image_addr;
	private Date create_time;
	private Date modify_time;
	private Date recognition_time;
	
	public String getLogic_db_id() {
		return logic_db_id;
	}
	public void setLogic_db_id(String logic_db_id) {
		this.logic_db_id = logic_db_id;
	}
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getImage_addr() {
		return image_addr;
	}
	public void setImage_addr(String image_addr) {
		this.image_addr = image_addr;
	}
	public Date getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}
	public Date getModify_time() {
		return modify_time;
	}
	public void setModify_time(Date modify_time) {
		this.modify_time = modify_time;
	}
	public Date getRecognition_time() {
		return recognition_time;
	}
	public void setRecognition_time(Date recognition_time) {
		this.recognition_time = recognition_time;
	}
	public String getReal_group_id() {
		return real_group_id;
	}
	public void setReal_group_id(String real_group_id) {
		this.real_group_id = real_group_id;
	}
	
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
}
