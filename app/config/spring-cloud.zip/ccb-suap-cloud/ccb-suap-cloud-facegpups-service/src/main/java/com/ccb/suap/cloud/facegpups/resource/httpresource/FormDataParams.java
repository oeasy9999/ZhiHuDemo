package com.ccb.suap.cloud.facegpups.resource.httpresource;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * HTTP请求 以 form表单方式发送请求参数类
 * @author pengdy
 *
 */
public class FormDataParams {

	private Map<String, Object> params = new HashMap<String, Object>();
	
	public void addParams(String name, Object value) {
		this.params.put(name, value);
	}
	
	public String toParams() {
		StringBuffer sb = new StringBuffer();
		for(Iterator<String> it=params.keySet().iterator();it.hasNext();) {
			String key = (String) it.next();
			Object value = params.get(key);
			sb.append(key).append("=").append(value).append("&");
		}
		return sb.toString();
	}

	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}

}
