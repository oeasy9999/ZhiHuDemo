package com.ccb.suap.cloud.facegpups.faceplus.vo;
public class GetFeatureResponse {

	private boolean result;
	private String error;
	private String feature;
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getFeature() {
		return feature;
	}
	public void setFeature(String feature) {
		this.feature = feature;
	}
	@Override
	public String toString() {
		return "GetFeatureResponse [result=" + result + ", error=" + error +", feature=" + feature + "]";
	}
	
	
	

}
