package com.ccb.suap.cloud.facegpups.faceplus.vo;

import java.util.List;

public class GetGroupListReponse {

	private boolean result;
	private String error;
	private List<String> groups;
	public boolean isResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public List<String> getGroups() {
		return groups;
	}
	public void setGroups(List<String> groups) {
		this.groups = groups;
	}
	@Override
	public String toString() {
		return "GetGroupListReponse [result=" + result + ", error=" + error + ", groups=" + groups + "]";
	}
	
}
