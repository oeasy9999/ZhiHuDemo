package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class INREC3001ServiceOutVo extends TxResponseMsgEntity{
	
	private String id_type;					//证件类型
	private String id_no;					//证件号码
	private String name;					//姓名
	private String channel_custno;			//渠道客户号
	private String ccb_custno;				//建行P6客户号
	private String branch_id;				//分行号
	private String mobile_no;				//手机号码
	private String face_channel;			//图片注册/更新渠道
	private String face_type;				//图片类型
	private String face_level;				//图片等级
	private String face_collecttime;		//人脸照片最近更新时间(YYYYMMDDHHMISS)
	private String face_image;				//人脸图片
	
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getChannel_custno() {
		return channel_custno;
	}
	public void setChannel_custno(String channel_custno) {
		this.channel_custno = channel_custno;
	}
	public String getCcb_custno() {
		return ccb_custno;
	}
	public void setCcb_custno(String ccb_custno) {
		this.ccb_custno = ccb_custno;
	}
	public String getBranch_id() {
		return branch_id;
	}
	public void setBranch_id(String branch_id) {
		this.branch_id = branch_id;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getFace_channel() {
		return face_channel;
	}
	public void setFace_channel(String face_channel) {
		this.face_channel = face_channel;
	}
	public String getFace_type() {
		return face_type;
	}
	public void setFace_type(String face_type) {
		this.face_type = face_type;
	}
	public String getFace_level() {
		return face_level;
	}
	public void setFace_level(String face_level) {
		this.face_level = face_level;
	}
	public String getFace_collecttime() {
		return face_collecttime;
	}
	public void setFace_collecttime(String face_collecttime) {
		this.face_collecttime = face_collecttime;
	}
	public String getFace_image() {
		return face_image;
	}
	public void setFace_image(String face_image) {
		this.face_image = face_image;
	}
	
	@Override
	public String toString() {
		return "INREC3001ServiceOutVo [id_type=" + id_type + ", id_no=" + id_no + ", name=" + name + ", channel_custno="
				+ channel_custno + ", ccb_custno=" + ccb_custno + ", branch_id=" + branch_id + ", mobile_no="
				+ mobile_no + ", face_channel=" + face_channel + ", face_type=" + face_type + ", face_level="
				+ face_level + ", face_collecttime=" + face_collecttime + ", face_image=" + face_image + "]";
	}
	
	
	
	
	
	
	
	
	
}
