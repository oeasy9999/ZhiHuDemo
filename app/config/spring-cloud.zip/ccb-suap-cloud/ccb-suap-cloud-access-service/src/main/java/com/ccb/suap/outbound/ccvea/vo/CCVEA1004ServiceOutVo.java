package com.ccb.suap.outbound.ccvea.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class CCVEA1004ServiceOutVo extends TxResponseMsgEntity{
	
	private String Rslt_Ret_Inf;					//结果返回信息
	private String Cmp_Rslt_Ind;					//比对结果标志
	private String Smlr_Dgr_Cmnt;					//相似程度说明
	
	public String getRslt_Ret_Inf() {
		return Rslt_Ret_Inf;
	}
	public void setRslt_Ret_Inf(String rslt_Ret_Inf) {
		Rslt_Ret_Inf = rslt_Ret_Inf;
	}
	public String getCmp_Rslt_Ind() {
		return Cmp_Rslt_Ind;
	}
	public void setCmp_Rslt_Ind(String cmp_Rslt_Ind) {
		Cmp_Rslt_Ind = cmp_Rslt_Ind;
	}
	public String getSmlr_Dgr_Cmnt() {
		return Smlr_Dgr_Cmnt;
	}
	public void setSmlr_Dgr_Cmnt(String smlr_Dgr_Cmnt) {
		Smlr_Dgr_Cmnt = smlr_Dgr_Cmnt;
	}
	
	@Override
	public String toString() {
		return "CCVEA1004ServiceOutVo [Rslt_Ret_Inf=" + Rslt_Ret_Inf + ", Cmp_Rslt_Ind=" + Cmp_Rslt_Ind
				+ ", Smlr_Dgr_Cmnt=" + Smlr_Dgr_Cmnt + "]";
	}
	
	
	
	

	
	
	
	
	
	
}
