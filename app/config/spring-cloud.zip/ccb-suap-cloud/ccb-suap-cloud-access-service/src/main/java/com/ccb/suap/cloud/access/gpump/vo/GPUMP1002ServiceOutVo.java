package com.ccb.suap.cloud.access.gpump.vo;

import java.util.List;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class GPUMP1002ServiceOutVo extends TxResponseMsgEntity{
	
	private String result_list_size;									//比对结果列表数量
	private List<GPUMP1002ServiceOutList> result_list;					//比对结果列表
	
	public String getResult_list_size() {
		return result_list_size;
	}
	public void setResult_list_size(String result_list_size) {
		this.result_list_size = result_list_size;
	}
	public List<GPUMP1002ServiceOutList> getResult_list() {
		return result_list;
	}
	public void setResult_list(List<GPUMP1002ServiceOutList> result_list) {
		this.result_list = result_list;
	}
	
	@Override
	public String toString() {
		return "GPUMP1002ServiceOutVo [result_list_size=" + result_list_size + ", result_list=" + result_list + "]";
	}
	
	
	
	
	
	
	
	
	
	
}
