package com.ccb.suap.cloud.access.gpump.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class GPUMP1008ServiceInVo extends TxRequestMsgEntity{
	
	private String cust_id;							//渠道客户号
	private String face_image;						//人脸图片
	
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getFace_image() {
		return face_image;
	}
	public void setFace_image(String face_image) {
		this.face_image = face_image;
	}
	
	@Override
	public String toString() {
		return "GPUMP1008ServiceInVo [cust_id=" + cust_id + ", face_image=" + face_image + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
