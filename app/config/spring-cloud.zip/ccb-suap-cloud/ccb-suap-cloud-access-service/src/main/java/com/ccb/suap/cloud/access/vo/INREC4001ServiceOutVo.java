package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class INREC4001ServiceOutVo extends TxResponseMsgEntity{
	
	
	private String similarity;				//相似度

	public String getSimilarity() {
		return similarity;
	}

	public void setSimilarity(String similarity) {
		this.similarity = similarity;
	}

	@Override
	public String toString() {
		return "INREC4001ServiceOutVo [similarity=" + similarity + "]";
	}
	
	
	
	
	
	
	

	
	
	
	
	
}
