package com.ccb.suap.cloud.access.threadLocal;

/**
 * 	使用此对象需要在INRECInterceptor的afterCompletion中销毁
 */

import java.util.HashMap;
import java.util.Map;

public class CosttimeThreadLocal {
	
	private static ThreadLocal<Map<String, Long>> costtimeThreadLocal = new MapThreadLocal();
	
	private static class MapThreadLocal extends ThreadLocal<Map<String, Long>>{
		
		@Override
		protected Map<String, Long> initialValue() {
			return new HashMap<>();
		}
		
	}
	
	
	/**
	 * 	私有化构造方法，防止外部创建实例
	 */
	private CosttimeThreadLocal() {
		
	}
	
	
	public static void set(Map<String, Long> map) {
		costtimeThreadLocal.set(map);
	}
	
	
	public static Map<String, Long> getMap() {
		return costtimeThreadLocal.get();
	}
	
	
	public static Long get(String key) {
		return costtimeThreadLocal.get().get(key);
	}
	
	
	public static void put(String key, Long value) {
		getMap().put(key, value);
	}
	
	
	public static void add(String key, Long value) {
		Long value_old = get(key);
		
		if(value_old == null) {
			put(key, value);
		}else {
			put(key, value + value_old);
		}
		
	}
	
	
	public static void remove() {
		costtimeThreadLocal.remove();
	}
	
	
	
}
