package com.ccb.suap.cloud.access.vo;

public class ServiceInVoParam2001 extends ServiceInVoParam1001And2001{
	
	private INREC2001ServiceInVo inVo;							//请求信息实体域

	public INREC2001ServiceInVo getInVo() {
		return inVo;
	}

	public void setInVo(INREC2001ServiceInVo inVo) {
		this.inVo = inVo;
	}

	@Override
	public String toString() {
		return "ServiceInVoParam2001 [inVo=" + inVo + "]";
	}

	
	
	
	
	
	
	
	
	
	
	
}
