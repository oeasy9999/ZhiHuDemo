package com.ccb.suap.cloud.access.datatransform.message;

public class TxResponseMsgBody {

	private TxResponseMsgEntity entity;

	public TxResponseMsgBody() {
		super();
		this.entity = new TxResponseMsgEntity();
	}

	public TxResponseMsgEntity getEntity() {
		return entity;
	}

	public void setEntity(TxResponseMsgEntity entity) {
		this.entity = entity;
	}

	@Override
	public String toString() {
		return "TxResponseMsgBody [entity=" + entity + "]";
	}
	
	
	
	
}
