package com.ccb.suap.cloud.access.vo;

import org.apache.commons.lang.StringUtils;

public class INREC1001And2001ServiceInVo extends INRECBaseServiceInVo{

	private String face_eigen;				//人脸特征值
	private String face_image;				//人脸图片
	private String channel_cardno;			//渠道绑定卡号
	private String title;					//尊称
	private String is_vip;					//是否VIP客户
	private String dot_num;					//采集网点号
	private String location;				//采集地点位置（GPS地理信息）
	private String vender_code;				//厂商标识
	private String vender_version;			//提取人脸特征厂商库版本号
	private String wifimac;					//wifimac地址
	private String bluetooth;				//蓝牙地址
	private String device_info;				//设备信息
	
	/**
	 *	 提取人脸特征终端类别
	 * 		1：PC
	 * 		2：IOS
	 * 		3：Android
	 * 		4：网点摄像头
	 * 		5：其他
	 */
	private String device_type;
	
	private String device_code;				//终端设备号(类似IMEI设备唯一标示)
	private String device_version;			//终端设备版本号
	private String device_authcode;			//设备认证码
	private String reserve_info1;			//预留信息1
	private String reserve_info2;			//预留信息2
	private String reserve_info3;			//预留信息3
	
	public String getFace_eigen() {
		return face_eigen;
	}
	public void setFace_eigen(String face_eigen) {
		this.face_eigen = face_eigen;
	}
	public String getFace_image() {
		return face_image;
	}
	public void setFace_image(String face_image) {
		this.face_image = face_image;
	}
	public String getChannel_cardno() {
		return channel_cardno;
	}
	public void setChannel_cardno(String channel_cardno) {
		this.channel_cardno = channel_cardno;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getIs_vip() {
		return is_vip;
	}
	public void setIs_vip(String is_vip) {
		this.is_vip = is_vip;
	}
	public String getDot_num() {
		return dot_num;
	}
	public void setDot_num(String dot_num) {
		this.dot_num = dot_num;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getVender_code() {
		return vender_code;
	}
	public void setVender_code(String vender_code) {
		this.vender_code = vender_code;
	}
	public String getVender_version() {
		return vender_version;
	}
	public void setVender_version(String vender_version) {
		this.vender_version = vender_version;
	}
	public String getDevice_type() {
		return device_type;
	}
	public void setDevice_type(String device_type) {
		this.device_type = device_type;
	}
	public String getDevice_code() {
		return device_code;
	}
	public void setDevice_code(String device_code) {
		this.device_code = device_code;
	}
	public String getDevice_version() {
		return device_version;
	}
	public void setDevice_version(String device_version) {
		this.device_version = device_version;
	}
	public String getDevice_authcode() {
		return device_authcode;
	}
	public void setDevice_authcode(String device_authcode) {
		this.device_authcode = device_authcode;
	}
	public String getReserve_info1() {
		return reserve_info1;
	}
	public void setReserve_info1(String reserve_info1) {
		this.reserve_info1 = reserve_info1;
	}
	public String getReserve_info2() {
		return reserve_info2;
	}
	public void setReserve_info2(String reserve_info2) {
		this.reserve_info2 = reserve_info2;
	}
	public String getReserve_info3() {
		return reserve_info3;
	}
	public void setReserve_info3(String reserve_info3) {
		this.reserve_info3 = reserve_info3;
	}
	public String getWifimac() {
		return wifimac;
	}
	public void setWifimac(String wifimac) {
		this.wifimac = wifimac;
	}
	public String getBluetooth() {
		return bluetooth;
	}
	public void setBluetooth(String bluetooth) {
		this.bluetooth = bluetooth;
	}
	public String getDevice_info() {
		return device_info;
	}
	public void setDevice_info(String device_info) {
		this.device_info = device_info;
	}
	
	@Override
	public String toString() {
		if(StringUtils.isEmpty(face_image))
			face_image = "0";
		return "INREC1001ServiceInVo [face_eigen=" + face_eigen + ", face_image=" + face_image.length() + ", channel_cardno="
				+ channel_cardno + ", title=" + title + ", is_vip=" + is_vip + ", dot_num=" + dot_num + ", location="
				+ location + ", vender_code=" + vender_code + ", vender_version=" + vender_version + ", wifimac="
				+ wifimac + ", bluetooth=" + bluetooth + ", device_info=" + device_info + ", device_type=" + device_type
				+ ", device_code=" + device_code + ", device_version=" + device_version + ", device_authcode="
				+ device_authcode + ", reserve_info1=" + reserve_info1 + ", reserve_info2=" + reserve_info2
				+ ", reserve_info3=" + reserve_info3 + "]";
	}
	
	
	
}
