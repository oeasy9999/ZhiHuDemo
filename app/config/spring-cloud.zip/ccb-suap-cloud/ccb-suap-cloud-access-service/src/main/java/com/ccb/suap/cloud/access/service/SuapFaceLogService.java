package com.ccb.suap.cloud.access.service;

import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.ccb.suap.cloud.access.annotation.CosttimeAnnotation;
import com.ccb.suap.cloud.access.annotation.StatusAnnotation;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.mapper.SuapFaceLogMapper;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.util.LocalMessage;
import com.ccb.suap.util.date.DateUtils;

@Service
@StatusAnnotation
public class SuapFaceLogService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Autowired
	SuapFaceLogMapper dao;

	@CosttimeAnnotation(title = "insertFaceLog")
	public int insert(SuapFaceLogModel suapFaceLogModel) {
		return dao.insert(suapFaceLogModel);
	}
	
	
	public long seq_logid_log() {
		return dao.seq_logid_log();
	}
	
	
	@Async("faceLogExecutor")
	public void handlerFaceLog(SuapFaceLogModel faceLog) {
		
		//获取ip列表
		List<String> ips = null;
		String serverIp = "";
		try {
			ips = LocalMessage.getLocalIP();
			LOGGER.debug("*************ips*************\n"+ips);
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (String ip : ips) {
			if(!"127.0.0.1".equals(ip)) {
				serverIp = serverIp+ip+"/";
			}
		}
		serverIp = serverIp.substring(0, serverIp.length()-1);
		
		faceLog.setHostname(LocalMessage.getHostName());
		faceLog.setServerip(serverIp);
		
		if(StringUtils.isNotBlank(faceLog.getRemarks()) && faceLog.getRemarks().length() > 150)
			faceLog.setRemarks(faceLog.getRemarks().substring(0, 150));
		
		String num = null;
		String patten = SuapSysParaUtil.getStrPara("FACELOG_PATTEN", "yyMMdd");
		try {
			String timeMills = faceLog.getTransflow().substring(9,19)+"000";
			num = DateUtils.getTimeInMillis(patten, Long.parseLong(timeMills));
		} catch (Exception e1) {
			num = new SimpleDateFormat(patten).format(faceLog.getRecvtime());
			LOGGER.error("get table name fail, try to get table name by nowaday, traceflow = " + faceLog.getTransflow() + ", table name = " + num + ", patten = " + patten,e1);
		}
		faceLog.setNum(num);
		
//		//如果需要加密的字段为空，则填充一个0
//		setBaseVariable(faceLog);
		
		try {
			long seq_logid_log = dao.seq_logid_log();
			LOGGER.debug("seq_logid_log: " + seq_logid_log);
			faceLog.setLogid(String.valueOf(num + seq_logid_log) );
			LOGGER.debug("faceLog: " +faceLog);
			dao.insert(faceLog);
		} catch (Exception e) {
			LOGGER.error("insert faceLog error!",e);
			e.printStackTrace();
		}
		
		
	}


//	/**
//	 * 如果idno或custid为空，则赋初值
//	 * @param faceLog
//	 */
//	private void setBaseVariable(SuapFaceLogModel faceLog) {
//		
//		if(StringUtils.isBlank(faceLog.getIdno()))
//			faceLog.setIdno("0");
//		if(StringUtils.isBlank(faceLog.getCustid()))
//			faceLog.setCustid("0");
//		
//	}
	
	
	
}
