package com.ccb.suap.cloud.access.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

public class SuapCustDeviceInfoModel implements Serializable{
	
	private static final long serialVersionUID = -3754856056477776290L;
	
	private String num;					//分库分表
	private String idtype;				//证件类型
	private String idnumber;			//证件号码
	private String channelid;			//渠道号
	private String custname;			//客户名称
	private String cellphome;			//手机号码
	private String channel_cstno;		//渠道客户号
	private String photo_path;			//图片存储路径
	private String titile;				//尊称
	private String isvip;				//是否VIP
	private String cardno;				//绑定卡号
	private String idverify;			//人脸核查标识
	private String siteno;				//采集网点号
	private String location;			//采集地点位置（GPS地理信息）
	private String devicetype;			//设备类型
	private String deviceauthcode;		//设备认证码
	private String devicecode;			//设备特征id
	private String deviceversion;		//设备版本号
	private Date updatetime;			//创建更新时间
	private String isvalid;				//当前渠道是否可用 0-启用，1-关闭
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getIdtype() {
		return idtype;
	}
	public void setIdtype(String idtype) {
		this.idtype = idtype;
	}
	public String getIdnumber() {
		return idnumber;
	}
	public void setIdnumber(String idnumber) {
		this.idnumber = idnumber;
	}
	public String getChannelid() {
		return channelid;
	}
	public void setChannelid(String channelid) {
		this.channelid = channelid;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getCellphome() {
		return cellphome;
	}
	public void setCellphome(String cellphome) {
		this.cellphome = cellphome;
	}
	public String getChannel_cstno() {
		return channel_cstno;
	}
	public void setChannel_cstno(String channel_cstno) {
		this.channel_cstno = channel_cstno;
	}
	public String getPhoto_path() {
		return photo_path;
	}
	public void setPhoto_path(String photo_path) {
		this.photo_path = photo_path;
	}
	public String getTitile() {
		return titile;
	}
	public void setTitile(String titile) {
		this.titile = titile;
	}
	public String getIsvip() {
		return isvip;
	}
	public void setIsvip(String isvip) {
		this.isvip = isvip;
	}
	public String getCardno() {
		return cardno;
	}
	public void setCardno(String cardno) {
		this.cardno = cardno;
	}
	public String getIdverify() {
		return idverify;
	}
	public void setIdverify(String idverify) {
		this.idverify = idverify;
	}
	public String getSiteno() {
		return siteno;
	}
	public void setSiteno(String siteno) {
		this.siteno = siteno;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDevicetype() {
		return devicetype;
	}
	public void setDevicetype(String devicetype) {
		this.devicetype = devicetype;
	}
	public String getDeviceauthcode() {
		return deviceauthcode;
	}
	public void setDeviceauthcode(String deviceauthcode) {
		this.deviceauthcode = deviceauthcode;
	}
	public String getDevicecode() {
		return devicecode;
	}
	public void setDevicecode(String devicecode) {
		this.devicecode = devicecode;
	}
	public String getDeviceversion() {
		return deviceversion;
	}
	public void setDeviceversion(String deviceversion) {
		this.deviceversion = deviceversion;
	}
	public Date getUpdatetime() {
		return updatetime;
	}
	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
	
	/**
	 * 0-启用，1-关闭
	 * @return
	 */
	public String getIsvalid() {
		return isvalid;
	}
	
	/**
	 * 0-启用，1-关闭
	 * @param isvalid
	 */
	public void setIsvalid(String isvalid) {
		this.isvalid = isvalid;
	}
	
	@Override
	public String toString() {
		return "SuapCustDeviceInfoModel [num=" + num + ", idtype=" + idtype + ", idnumber=" + idnumber + ", channelid="
				+ channelid + ", custname=" + custname + ", cellphome=" + cellphome + ", channel_cstno=" + channel_cstno
				+ ", photo_path=" + photo_path + ", titile=" + titile + ", isvip=" + isvip + ", cardno=" + cardno
				+ ", idverify=" + idverify + ", siteno=" + siteno + ", location=" + location + ", devicetype="
				+ devicetype + ", deviceauthcode=" + deviceauthcode + ", devicecode=" + devicecode + ", deviceversion="
				+ deviceversion + ", updatetime=" + updatetime + ", isvalid=" + isvalid + "]";
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
}
