package com.ccb.suap.cloud.access.gpump.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class GPUMP1006ServiceInVo extends TxRequestMsgEntity{
	
	private String cust_id;				//客户id

	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}

	@Override
	public String toString() {
		return "GPUMP3004ServiceInVo [cust_id=" + cust_id + "]";
	}
	
	
	
	
	
	
	
}
