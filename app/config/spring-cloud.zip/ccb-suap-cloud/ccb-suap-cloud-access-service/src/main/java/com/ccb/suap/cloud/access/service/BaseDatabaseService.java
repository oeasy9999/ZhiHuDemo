package com.ccb.suap.cloud.access.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccb.suap.cloud.access.mapper.BaseDatabaseMapper;
import com.ccb.suap.cloud.access.schedule.INRECSchedule;

@Service
public class BaseDatabaseService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INRECSchedule.class);
	
	@Autowired
	private BaseDatabaseMapper baseDatabaseMapper;
	
	public String heartBeat() {
		
		String result = null;
		try {
			long start_time = System.currentTimeMillis();
			result = baseDatabaseMapper.heartBeat();
			long cost_time = System.currentTimeMillis() - start_time;
			if(cost_time >= 1000)
				LOGGER.error("check databases status timeout: " + cost_time);
		} catch (Exception e) {
			LOGGER.error("check databases status error: " + e.getMessage());
			throw new RuntimeException("select database error!" + " " + e.getMessage());
		}
		
		return result;
	}


	
	
	
	
	
	
	
	
	
}
