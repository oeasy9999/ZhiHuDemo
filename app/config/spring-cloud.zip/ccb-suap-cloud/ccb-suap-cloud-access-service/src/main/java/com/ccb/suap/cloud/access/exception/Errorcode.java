package com.ccb.suap.cloud.access.exception;

/**
 * 	错误码信息
 * 		1XXX-请求信息报错
 * 			10XX-请求信息通用报错
 * 			11XX-报文头报错
 * 			12XX-com1域报错
 * 			13XX-com2域报错
 * 			14XX-实体域报错
 * 		2XXX-外呼报错
 * 			20XX-通用返回信息异常
 * 			21XX-GPUMP报错
 * 			22XX-outbound报错
 * 			23XX-redis报错
 * 		3XXX-数据库报错
 * 			31XX-数据库间接报错(缓存信息)
 * 			32XX-数据库直接报错(增删改查)
 * 		4XXX-其他报错
 * @author 86156
 *
 */
public class Errorcode {
	
	private final static String  SERVICE = "INREC";				//系统标识
	
	private final static String MAJOR = "W";					//主服务报错
	private final static String DATAB = "D";					//数据库报错
	private final static String GPUMP = "G";					//调用GPU前置报错
	private final static String CCVEA = "C";					//调用CCVEA报错
	private final static String OUTBD = "O";					//外呼服务报错
	private final static String REDIS = "R";					//调用redis报错
	private final static String ASPCT = "A";					//调用切面报错
	
	private final static String BISNS = "FA";					//业务错误
	@SuppressWarnings("unused")
	private final static String WARMING = "WA";					//交易错误
	private final static String ERROR = "ER";					//系统错误
	
	
	public static final String NOERROR="000000000000"; 	 									//success
	
	//1-请求信息报错
	public static final String HEADMSGNOTNULL=SERVICE+MAJOR+BISNS+"1000";					//请求报文头(tx_header)不能为空
	public static final String TX_BODYNOTNULL=SERVICE+MAJOR+BISNS+"1001";					//请求体(tx_body)不能为空
	
	public static final String VERSIONNOTNULL=SERVICE+MAJOR+BISNS+"1101";					//协议版本号不能为空
	public static final String TRACEIDNOTNULL=SERVICE+MAJOR+BISNS+"1102";					//全局事件跟踪号(sys_evt_trace_id)不能为空
	public static final String REQTIMENOTNULL=SERVICE+MAJOR+BISNS+"1103";					//请求时间不能为空
	public static final String STSTYPENOTNULL=SERVICE+MAJOR+BISNS+"1104";					//报文状态类型不能为空
		
	public static final String COM1ALLNOTNULL=SERVICE+MAJOR+BISNS+"1201";					//com1公共域不能为空
	public static final String CHANLIDNOTNULL=SERVICE+MAJOR+BISNS+"1202";					//系统渠道编号(sysChannelID)不能为空
	public static final String CHANLCDNOTNULL=SERVICE+MAJOR+BISNS+"1203";					//系统渠道交易码(channelTxCode)不能为空
	
	public static final String GRPNAMENOTNULL=SERVICE+MAJOR+BISNS+"1301";					//GroupName不能为空
		
	public static final String ENTITY_NOTNULL=SERVICE+MAJOR+BISNS+"1400";					//entity域不能为空
	public static final String ID_TYPENOTNULL=SERVICE+MAJOR+BISNS+"1401";					//证件类型不能为空
	public static final String ID_NUMBNOTNULL=SERVICE+MAJOR+BISNS+"1402";					//证件号码不能为空
	public static final String CHANLCSTNONULL=SERVICE+MAJOR+BISNS+"1403";					//渠道客户号不能为空
	public static final String CSTNAMENOTNULL=SERVICE+MAJOR+BISNS+"1404";					//姓名不能为空
	public static final String MOBLENONOTNULL=SERVICE+MAJOR+BISNS+"1405";					//手机号码不能为空
	public static final String FACEIMGNOTNULL=SERVICE+MAJOR+BISNS+"1406";					//人脸图片不能为空
	public static final String PHOCOMPAREFAIL=SERVICE+MAJOR+BISNS+"1407";					//人脸图片不匹配(非本人图片)
	public static final String QUALTYNOTMATCH=SERVICE+MAJOR+BISNS+"1408";					//人脸图片质量过低
	public static final String CSTNAMNOTMATCH=SERVICE+MAJOR+BISNS+"1409";					//客户名称不一致
	public static final String CHNCSNNOTMATCH=SERVICE+MAJOR+BISNS+"1410";					//渠道客户号不一致
	public static final String FAC_VEDNOTNULL=SERVICE+MAJOR+BISNS+"1411";					//人脸视频信息不能为空
	public static final String REQ_TIMNOTNULL=SERVICE+MAJOR+BISNS+"1412";					//视频请求信息不能为空
	public static final String SYNMARKNOTNULL=SERVICE+MAJOR+BISNS+"1413";					//视频同步标志不能为空
	public static final String STR_TIMNOTNULL=SERVICE+MAJOR+BISNS+"1414";					//开始录制时间戳不能为空
	public static final String END_TIMNOTNULL=SERVICE+MAJOR+BISNS+"1415";					//结束录制时间戳不能为空
	public static final String CTFN_IDNOTNULL=SERVICE+MAJOR+BISNS+"1416";					//用户所属机构编号不能为空
	public static final String ONLYINDNOTNULL=SERVICE+MAJOR+BISNS+"1417";					//组件编号不能为空
	public static final String BRACHIDNOTNULL=SERVICE+MAJOR+BISNS+"1418";					//分行编号不能为空
	public static final String NODE_NONOTNULL=SERVICE+MAJOR+BISNS+"1419";					//安全节点号不能为空
	public static final String ENCHNIDNOTNULL=SERVICE+MAJOR+BISNS+"1420";					//channelid不能为空(entity域)
	public static final String ENCHNCDNOTNULL=SERVICE+MAJOR+BISNS+"1421";					//channeltxcode不能为空(entity域)
	public static final String ENTRANFNOTNULL=SERVICE+MAJOR+BISNS+"1422";					//transflow不能为空(entity域)
	public static final String ENRECTMNOTNULL=SERVICE+MAJOR+BISNS+"1423";					//recvtime不能为空(entity域)
	public static final String ENRESTMNOTNULL=SERVICE+MAJOR+BISNS+"1424";					//resptime不能为空(entity域)
	public static final String EN_TXCDNOTNULL=SERVICE+MAJOR+BISNS+"1425";					//txcode不能为空(entity域)
	public static final String ENTRANSNOTNULL=SERVICE+MAJOR+BISNS+"1426";					//transret不能为空(entity域)
	public static final String ENHOSNMNOTNULL=SERVICE+MAJOR+BISNS+"1427";					//hostname不能为空(entity域)
	public static final String ENSERIPNOTNULL=SERVICE+MAJOR+BISNS+"1428";					//serverip不能为空(entity域)
	public static final String ENERRCDNOTNULL=SERVICE+MAJOR+BISNS+"1429";					//errorcode不能为空(entity域)
	public static final String ENIMGPANOTNULL=SERVICE+MAJOR+BISNS+"1430";					//facefilepath不能为空(entity域)
	public static final String IMGNAMENOTNULL=SERVICE+MAJOR+BISNS+"1431";					//图片名称(image_name)不能为空
	public static final String MSGCONTNOTNULL=SERVICE+MAJOR+BISNS+"1432";					//msgContent不能为空
	
	
	//2-外调返回报错
	public static final String RSPMSGNOTFOUND=SERVICE+MAJOR+ERROR+"2000";					//响应信息为空(异常)
	public static final String HEADERNOTFOUND=SERVICE+MAJOR+ERROR+"2001";					//响应头(tx_header)为空(异常)
	
	public static final String SENDGPUMPERROR=SERVICE+GPUMP+ERROR+"2100";					//GPUMP调用失败
	public static final String IDTYPENOTFOUND=SERVICE+GPUMP+BISNS+"2101";					//找不到相关证件类型
	public static final String IDNUMGNOTFOUND=SERVICE+GPUMP+BISNS+"2102";					//找不到相关证件号码
	public static final String CSTINFNOTFOUND=SERVICE+GPUMP+BISNS+"2103";					//找不到相关客户信息
	public static final String CSTDEVNOTFOUND=SERVICE+GPUMP+BISNS+"2104";					//找不到相关客户渠道注册信息
	public static final String NOCUSTINFFOUND=SERVICE+GPUMP+BISNS+"2105";					//客户记录不存在
	public static final String GPUBDYNOTFOUND=SERVICE+GPUMP+ERROR+"2106";					//GPUMP返回tx_body不存在
	public static final String GPUENTNOTFOUND=SERVICE+GPUMP+ERROR+"2107";					//GPUMP返回实体域不存在
	
	public static final String SENDCCVEAERROR=SERVICE+CCVEA+ERROR+"2201";					//CCVEA调用失败
	public static final String CCVBDYNOTFOUND=SERVICE+CCVEA+ERROR+"2202";					//CCVEA返回tx_body不存在
	public static final String CCVENTNOTFOUND=SERVICE+CCVEA+ERROR+"2203";					//CCVEA返回实体域不存在
	public static final String SENCC1001ERROR=SERVICE+CCVEA+ERROR+"2204";					//CCVEA1001调用失败
	public static final String SENCC1002ERROR=SERVICE+CCVEA+ERROR+"2205";					//CCVEA1002调用失败
	public static final String SENCC1003ERROR=SERVICE+CCVEA+ERROR+"2206";					//CCVEA1003调用失败
	public static final String SENCC1004ERROR=SERVICE+CCVEA+ERROR+"2207";					//CCVEA1004调用失败
	public static final String SENCC1005ERROR=SERVICE+CCVEA+ERROR+"2208";					//CCVEA1005调用失败
	public static final String SENSAFEBDERROR=SERVICE+CCVEA+ERROR+"2209";					//外呼SafeOutbound调用失败
	public static final String SAFEBDDATANULL=SERVICE+CCVEA+ERROR+"2210";					//SafeOutbound返回空数据
	public static final String SAFEBDHERDNULL=SERVICE+CCVEA+ERROR+"2211";					//SafeOutbound返回空header
	
	public static final String REDIS_SRVERROR=SERVICE+REDIS+ERROR+"2300";					//redis服务异常
	public static final String IDNUMRNOTFOUND=SERVICE+REDIS+BISNS+"2301";					//找不到相关客户信息
	public static final String REDIS_SAVFAILD=SERVICE+REDIS+ERROR+"2302";					//redis数据存储失败
	public static final String REDIS_DELFAILD=SERVICE+REDIS+ERROR+"2303";					//redis数据删除失败
	public static final String REDIS_GETERROR=SERVICE+REDIS+ERROR+"2304";					//redis数据获取失败
	public static final String DATACHANGERROR=SERVICE+REDIS+ERROR+"2305";					//redis数据转换异常
	
	public static final String SENDRSTTPERROR=SERVICE+OUTBD+ERROR+"2401";					//restTemplate外呼服务异常
	public static final String AIAUDRETISNULL=SERVICE+OUTBD+ERROR+"2402";					//aiaudio返回对象为空
	public static final String AIAUDBYRETFAIL=SERVICE+OUTBD+BISNS+"2403";					//反光/压缩失败
	
	public static final String REDIS_ASPERROR=SERVICE+ASPCT+ERROR+"2501";					//RedisAspect切面调用失败
	public static final String COSTT_ASPERROR=SERVICE+ASPCT+ERROR+"2502";					//CosttimeAspect切面调用失败
	public static final String STATUSASPERROR=SERVICE+ASPCT+ERROR+"2503";					//StatusAspecet切面调用失败

	
	//3-数据库报错
	public static final String DATABASEDISUSE=SERVICE+DATAB+ERROR+"3100";					//数据库不可用
	public static final String FACECFGNOTNULL=SERVICE+DATAB+ERROR+"3101";					//找不到人脸识别参数配置
	public static final String BSPATHNOTFOUND=SERVICE+DATAB+ERROR+"3102";					//找不到图片保存根目录
	public static final String LOCASRNOTFOUND=SERVICE+DATAB+ERROR+"3103";					//找不到guoupName
	public static final String PHSIZENOTFOUND=SERVICE+DATAB+ERROR+"3104";					//找不到人脸图片大小限制信息
	public static final String LEVELTYPEERROR=SERVICE+DATAB+ERROR+"3105";					//照片类型错误
	public static final String LOCATIONEERROR=SERVICE+DATAB+ERROR+"3106";					//1:N库字段索引错误
	public static final String PARAETYPEERROR=SERVICE+DATAB+ERROR+"3107";					//系统参数类型错误
	
	public static final String INSCSTINFERROR=SERVICE+DATAB+ERROR+"3201";      				//新增客户信息异常
	public static final String INSCSTDEVERROR=SERVICE+DATAB+ERROR+"3202";      				//新增客户渠道注册信息异常
	public static final String SECCSTINFERROR=SERVICE+DATAB+ERROR+"3203";      				//客户信息查询异常
	public static final String SECCSTDEVERROR=SERVICE+DATAB+ERROR+"3204";      				//客户渠道注册信息查询异常
	public static final String DELCSTDEVERROR=SERVICE+DATAB+ERROR+"3205";      				//客户渠道注册信息删除异常
	public static final String DELCSTDEVFAILD=SERVICE+DATAB+ERROR+"3206";      				//客户渠道注册信息删除失败
	public static final String CUSTINFOISNULL=SERVICE+DATAB+BISNS+"3207";      				//客户信息不存在
	public static final String CUSTDEVIISNULL=SERVICE+DATAB+BISNS+"3208";      				//客户渠道注册信息不存在
	public static final String INSCSTINFFAILD=SERVICE+DATAB+ERROR+"3209";      				//新增用户信息失败
	public static final String INSCSTDEVFAILD=SERVICE+DATAB+ERROR+"3210";      				//新增客户渠道注册信息失败
	public static final String UPDCSTINFERROR=SERVICE+DATAB+ERROR+"3211";      				//更新用户信息异常
	public static final String UPDCSTDEVERROR=SERVICE+DATAB+ERROR+"3212";      				//更新客户渠道注册信息异常
	public static final String UPDCSTINFFAILD=SERVICE+DATAB+ERROR+"3213";      				//更新用户信息失败
	public static final String UPDCSTDEVFAILD=SERVICE+DATAB+ERROR+"3214";      				//更新客户渠道注册信息失败
	public static final String SECWHTLSTERROR=SERVICE+DATAB+ERROR+"3215";      				//白名单查询异常
	public static final String SECWHTNAMELSTNULL=SERVICE+DATAB+BISNS+"3216";      			//该客户不属于白名单库
	public static final String SECBLANAMELSTExit=SERVICE+DATAB+BISNS+"3217";      			//该客户属于黑名单库
	public static final String CSTDEVEXIERROR=SERVICE+DATAB+ERROR+"3218";      				//渠道注册信息异常(不应存在)
	public static final String INSFACLOGERROR=SERVICE+DATAB+ERROR+"3219";      				//新增日志信息异常
	public static final String INSFACLOGFAILD=SERVICE+DATAB+ERROR+"3220";      				//新增日志信息失败
	
	public static final String OUTBONDNOTNULL=SERVICE+DATAB+ERROR+"3301";					//找不到外呼参数配置信息
	
	
	//4-其他报错
	public static final String NOSERVERSERROR=SERVICE+MAJOR+BISNS+"4101";         			//未找到对应服务
	public static final String UNKNOWMSGERROR=SERVICE+MAJOR+ERROR+"4102";					//服务异常
	public static final String PHOTOPATHERROR=SERVICE+MAJOR+BISNS+"4103";					//图片路径异常
	public static final String PHOTOSAVEERROR=SERVICE+MAJOR+ERROR+"4104";					//图片保存异常
	public static final String PHOLARGEEERROR=SERVICE+MAJOR+BISNS+"4105";					//图片大于系统设定值
	public static final String PHO_LOADEERROR=SERVICE+MAJOR+ERROR+"4106";					//图片读取异常
	public static final String FACEMSGNOTNULL=SERVICE+MAJOR+ERROR+"4107";					//人脸图片信息不能为空
	public static final String ERRORCODE_NULL=SERVICE+MAJOR+ERROR+"4108";					//未定义异常
	public static final String PHOTOCOMISFAIL=SERVICE+MAJOR+BISNS+"4109";					//图片比对不通过
	public static final String PHOTOLOADERROR=SERVICE+MAJOR+ERROR+"4110";					//图片读取错误
	public static final String IDVERIFY_FAILD=SERVICE+MAJOR+ERROR+"4111";					//人脸核查失败
	public static final String JSONPARSEERROR=SERVICE+MAJOR+ERROR+"4112";					//JSON转换异常
	public static final String XMLPSBEANERROR=SERVICE+MAJOR+ERROR+"4113";					//JAVA对象转换XML异常
	public static final String BEANPSXMLERROR=SERVICE+MAJOR+ERROR+"4114";					//XML转换JAVA对象异常
	public static final String BASE64DECERROR=SERVICE+MAJOR+ERROR+"4115";					//base64解析异常
	public static final String PYTHONEXCERROR=SERVICE+MAJOR+ERROR+"4116";					//paython调用异常
	public static final String PYTHONEXCFAILD=SERVICE+MAJOR+BISNS+"4117";					//paython调用失败
	public static final String XSTRMNULLERROR=SERVICE+MAJOR+BISNS+"4118";					//XStream对象创建/获取失败
	
	
	
	
	
	
	
	
	
	
}
