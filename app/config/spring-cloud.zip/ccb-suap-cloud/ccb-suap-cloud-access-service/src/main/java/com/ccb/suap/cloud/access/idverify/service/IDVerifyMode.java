package com.ccb.suap.cloud.access.idverify.service;

/**
 * 	根据不同人脸核查模式进行人脸核查
 */

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam1001And2001;

@FunctionalInterface
public interface IDVerifyMode {
	
	public boolean verify(TxRequestMsg reqMsg, SuapFaceConfigModel faceConfig, ServiceInVoParam1001And2001 param);
	
	
	
	
	
	
	
}
