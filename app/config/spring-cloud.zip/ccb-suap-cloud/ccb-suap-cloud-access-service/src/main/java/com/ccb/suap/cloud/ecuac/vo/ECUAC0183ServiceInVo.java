package com.ccb.suap.cloud.ecuac.vo;

import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACRequestMsgBodyEntity;
import com.thoughtworks.xstream.annotations.XStreamAlias;

public class ECUAC0183ServiceInVo implements ECUACRequestMsgBodyEntity{
	
	private static final long serialVersionUID = -2017989711627665131L;
	
	@XStreamAlias("Stm_Chnl_ID")
	private String stm_chnl_id;
	@XStreamAlias("Stm_Chnl_Txn_CD")
	private String stm_chnl_txn_cd;
	@XStreamAlias("Cst_Nm")
	private String cst_nm;
	@XStreamAlias("CrdTp_Cd")
	private String crdtp_cd;
	@XStreamAlias("Crdt_No")
	private String crdt_no;
	@XStreamAlias("Br_ID")
	private String br_id;
	@XStreamAlias("Rmrk_1_Rcrd_Cntnt")
	private String rmrk_1_rcrd_cntnt;
	@XStreamAlias("base64_ECD_Txn_Inf")
	private String base64_ecd_txn_inf;
	@XStreamAlias("base64_Ecrp_Txn_Inf")
	private String base64_ecrp_txn_inf;
	@XStreamAlias("Br_ID_Inf")
	private String br_id_inf;
	@XStreamAlias("Geo_Lo_ID")
	private String geo_lo_id;
	@XStreamAlias("Mftr_Idr_CD")
	private String mftr_idr_cd;
	@XStreamAlias("Mftr_Str_VNo")
	private String mftr_str_vno;
	@XStreamAlias("Ftr_Col_TmnlInf")
	private String ftr_col_tmnlinf;
	@XStreamAlias("Tmnl_Eqmt_No")
	private String tmnl_eqmt_no;
	@XStreamAlias("Tmnl_Eqmt_VNo")
	private String tmnl_eqmt_vno;
	@XStreamAlias("Eqmt_Modl_VNo")
	private String eqmt_modl_vno;
	@XStreamAlias("Eqmt_Ctfn_CD")
	private String eqmt_ctfn_cd;
	@XStreamAlias("Usr_Inf_Dsc")
	private String usr_inf_dsc;
	@XStreamAlias("Eqmt_Inf_Dsc")
	private String eqmt_inf_dsc;
	@XStreamAlias("Aflt_Inf_Dsc")
	private String aflt_inf_dsc;
	@XStreamAlias("Wthr_VIP_Inf_Dsc")
	private String wthr_vip_inf_dsc;
	@XStreamAlias("VIP_Grd_Inf_Dsc")
	private String vip_grd_inf_dsc;
	@XStreamAlias("Apl_Exmp_ID")
	private String apl_exmp_id;
	@XStreamAlias("Rsrv_1_Inf_Dsc")
	private String rsrv_1_inf_dsc;
	@XStreamAlias("Rsrv_2_Inf_Dsc")
	private String rsrv_2_inf_dsc;
	@XStreamAlias("Rsrv_3_Inf_Dsc")
	private String rsrv_3_inf_dsc;
	@XStreamAlias("Rsrv_4_Inf_Dsc")
	private String rsrv_4_inf_dsc;
	@XStreamAlias("Rsrv_5_Inf_Dsc")
	private String rsrv_5_inf_dsc;
	@XStreamAlias("Ext_Stm_Ctfn_Ecrp_Inf")
	private String ext_stm_ctfn_ecrp_inf;
	@XStreamAlias("EcrpAfsEcrptKey_Cntnt")
	private String ecrpafsecrptkey_cntnt;
	@XStreamAlias("ExtStmCtfn_Udt_MpltTm")
	private String extstmctfn_udt_mplttm;
	
	public String getStm_chnl_id() {
		return stm_chnl_id;
	}
	public void setStm_chnl_id(String stm_chnl_id) {
		this.stm_chnl_id = stm_chnl_id;
	}
	public String getStm_chnl_txn_cd() {
		return stm_chnl_txn_cd;
	}
	public void setStm_chnl_txn_cd(String stm_chnl_txn_cd) {
		this.stm_chnl_txn_cd = stm_chnl_txn_cd;
	}
	public String getCst_nm() {
		return cst_nm;
	}
	public void setCst_nm(String cst_nm) {
		this.cst_nm = cst_nm;
	}
	public String getCrdtp_cd() {
		return crdtp_cd;
	}
	public void setCrdtp_cd(String crdtp_cd) {
		this.crdtp_cd = crdtp_cd;
	}
	public String getCrdt_no() {
		return crdt_no;
	}
	public void setCrdt_no(String crdt_no) {
		this.crdt_no = crdt_no;
	}
	public String getBr_id() {
		return br_id;
	}
	public void setBr_id(String br_id) {
		this.br_id = br_id;
	}
	public String getRmrk_1_rcrd_cntnt() {
		return rmrk_1_rcrd_cntnt;
	}
	public void setRmrk_1_rcrd_cntnt(String rmrk_1_rcrd_cntnt) {
		this.rmrk_1_rcrd_cntnt = rmrk_1_rcrd_cntnt;
	}
	public String getBase64_ecd_txn_inf() {
		return base64_ecd_txn_inf;
	}
	public void setBase64_ecd_txn_inf(String base64_ecd_txn_inf) {
		this.base64_ecd_txn_inf = base64_ecd_txn_inf;
	}
	public String getBase64_ecrp_txn_inf() {
		return base64_ecrp_txn_inf;
	}
	public void setBase64_ecrp_txn_inf(String base64_ecrp_txn_inf) {
		this.base64_ecrp_txn_inf = base64_ecrp_txn_inf;
	}
	public String getBr_id_inf() {
		return br_id_inf;
	}
	public void setBr_id_inf(String br_id_inf) {
		this.br_id_inf = br_id_inf;
	}
	public String getGeo_lo_id() {
		return geo_lo_id;
	}
	public void setGeo_lo_id(String geo_lo_id) {
		this.geo_lo_id = geo_lo_id;
	}
	public String getMftr_idr_cd() {
		return mftr_idr_cd;
	}
	public void setMftr_idr_cd(String mftr_idr_cd) {
		this.mftr_idr_cd = mftr_idr_cd;
	}
	public String getMftr_str_vno() {
		return mftr_str_vno;
	}
	public void setMftr_str_vno(String mftr_str_vno) {
		this.mftr_str_vno = mftr_str_vno;
	}
	public String getFtr_col_tmnlinf() {
		return ftr_col_tmnlinf;
	}
	public void setFtr_col_tmnlinf(String ftr_col_tmnlinf) {
		this.ftr_col_tmnlinf = ftr_col_tmnlinf;
	}
	public String getTmnl_eqmt_no() {
		return tmnl_eqmt_no;
	}
	public void setTmnl_eqmt_no(String tmnl_eqmt_no) {
		this.tmnl_eqmt_no = tmnl_eqmt_no;
	}
	public String getTmnl_eqmt_vno() {
		return tmnl_eqmt_vno;
	}
	public void setTmnl_eqmt_vno(String tmnl_eqmt_vno) {
		this.tmnl_eqmt_vno = tmnl_eqmt_vno;
	}
	public String getEqmt_modl_vno() {
		return eqmt_modl_vno;
	}
	public void setEqmt_modl_vno(String eqmt_modl_vno) {
		this.eqmt_modl_vno = eqmt_modl_vno;
	}
	public String getEqmt_ctfn_cd() {
		return eqmt_ctfn_cd;
	}
	public void setEqmt_ctfn_cd(String eqmt_ctfn_cd) {
		this.eqmt_ctfn_cd = eqmt_ctfn_cd;
	}
	public String getUsr_inf_dsc() {
		return usr_inf_dsc;
	}
	public void setUsr_inf_dsc(String usr_inf_dsc) {
		this.usr_inf_dsc = usr_inf_dsc;
	}
	public String getEqmt_inf_dsc() {
		return eqmt_inf_dsc;
	}
	public void setEqmt_inf_dsc(String eqmt_inf_dsc) {
		this.eqmt_inf_dsc = eqmt_inf_dsc;
	}
	public String getAflt_inf_dsc() {
		return aflt_inf_dsc;
	}
	public void setAflt_inf_dsc(String aflt_inf_dsc) {
		this.aflt_inf_dsc = aflt_inf_dsc;
	}
	public String getWthr_vip_inf_dsc() {
		return wthr_vip_inf_dsc;
	}
	public void setWthr_vip_inf_dsc(String wthr_vip_inf_dsc) {
		this.wthr_vip_inf_dsc = wthr_vip_inf_dsc;
	}
	public String getVip_grd_inf_dsc() {
		return vip_grd_inf_dsc;
	}
	public void setVip_grd_inf_dsc(String vip_grd_inf_dsc) {
		this.vip_grd_inf_dsc = vip_grd_inf_dsc;
	}
	public String getApl_exmp_id() {
		return apl_exmp_id;
	}
	public void setApl_exmp_id(String apl_exmp_id) {
		this.apl_exmp_id = apl_exmp_id;
	}
	public String getRsrv_1_inf_dsc() {
		return rsrv_1_inf_dsc;
	}
	public void setRsrv_1_inf_dsc(String rsrv_1_inf_dsc) {
		this.rsrv_1_inf_dsc = rsrv_1_inf_dsc;
	}
	public String getRsrv_2_inf_dsc() {
		return rsrv_2_inf_dsc;
	}
	public void setRsrv_2_inf_dsc(String rsrv_2_inf_dsc) {
		this.rsrv_2_inf_dsc = rsrv_2_inf_dsc;
	}
	public String getRsrv_3_inf_dsc() {
		return rsrv_3_inf_dsc;
	}
	public void setRsrv_3_inf_dsc(String rsrv_3_inf_dsc) {
		this.rsrv_3_inf_dsc = rsrv_3_inf_dsc;
	}
	public String getRsrv_4_inf_dsc() {
		return rsrv_4_inf_dsc;
	}
	public void setRsrv_4_inf_dsc(String rsrv_4_inf_dsc) {
		this.rsrv_4_inf_dsc = rsrv_4_inf_dsc;
	}
	public String getRsrv_5_inf_dsc() {
		return rsrv_5_inf_dsc;
	}
	public void setRsrv_5_inf_dsc(String rsrv_5_inf_dsc) {
		this.rsrv_5_inf_dsc = rsrv_5_inf_dsc;
	}
	public String getExt_stm_ctfn_ecrp_inf() {
		return ext_stm_ctfn_ecrp_inf;
	}
	public void setExt_stm_ctfn_ecrp_inf(String ext_stm_ctfn_ecrp_inf) {
		this.ext_stm_ctfn_ecrp_inf = ext_stm_ctfn_ecrp_inf;
	}
	public String getEcrpafsecrptkey_cntnt() {
		return ecrpafsecrptkey_cntnt;
	}
	public void setEcrpafsecrptkey_cntnt(String ecrpafsecrptkey_cntnt) {
		this.ecrpafsecrptkey_cntnt = ecrpafsecrptkey_cntnt;
	}
	public String getExtstmctfn_udt_mplttm() {
		return extstmctfn_udt_mplttm;
	}
	public void setExtstmctfn_udt_mplttm(String extstmctfn_udt_mplttm) {
		this.extstmctfn_udt_mplttm = extstmctfn_udt_mplttm;
	}
	
	@Override
	public String toString() {
		return "ECUAC0183ServiceInVo [stm_chnl_id=" + stm_chnl_id + ", stm_chnl_txn_cd=" + stm_chnl_txn_cd + ", cst_nm="
				+ cst_nm + ", crdtp_cd=" + crdtp_cd + ", crdt_no=" + crdt_no + ", br_id=" + br_id
				+ ", rmrk_1_rcrd_cntnt=" + rmrk_1_rcrd_cntnt + ", base64_ecd_txn_inf=" + base64_ecd_txn_inf
				+ ", base64_ecrp_txn_inf=" + base64_ecrp_txn_inf + ", br_id_inf=" + br_id_inf + ", geo_lo_id="
				+ geo_lo_id + ", mftr_idr_cd=" + mftr_idr_cd + ", mftr_str_vno=" + mftr_str_vno + ", ftr_col_tmnlinf="
				+ ftr_col_tmnlinf + ", tmnl_eqmt_no=" + tmnl_eqmt_no + ", tmnl_eqmt_vno=" + tmnl_eqmt_vno
				+ ", eqmt_modl_vno=" + eqmt_modl_vno + ", eqmt_ctfn_cd=" + eqmt_ctfn_cd + ", usr_inf_dsc=" + usr_inf_dsc
				+ ", eqmt_inf_dsc=" + eqmt_inf_dsc + ", aflt_inf_dsc=" + aflt_inf_dsc + ", wthr_vip_inf_dsc="
				+ wthr_vip_inf_dsc + ", vip_grd_inf_dsc=" + vip_grd_inf_dsc + ", apl_exmp_id=" + apl_exmp_id
				+ ", rsrv_1_inf_dsc=" + rsrv_1_inf_dsc + ", rsrv_2_inf_dsc=" + rsrv_2_inf_dsc + ", rsrv_3_inf_dsc="
				+ rsrv_3_inf_dsc + ", rsrv_4_inf_dsc=" + rsrv_4_inf_dsc + ", rsrv_5_inf_dsc=" + rsrv_5_inf_dsc
				+ ", ext_stm_ctfn_ecrp_inf=" + ext_stm_ctfn_ecrp_inf + ", ecrpafsecrptkey_cntnt="
				+ ecrpafsecrptkey_cntnt + ", extstmctfn_udt_mplttm=" + extstmctfn_udt_mplttm + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
}
