package com.ccb.suap.cloud.access.beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.service.SuapCustDeviceInfoService;
import com.ccb.suap.cloud.access.service.SuapCustInfoService;
import com.ccb.suap.cloud.access.service.utils.PhotoUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC3001ServiceInVo;
import com.ccb.suap.cloud.access.vo.INREC3001ServiceOutVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

@Controller("INREC3001")
public class INREC3001_Bean extends INRECBean{

	private static final Logger LOGGER = LoggerFactory.getLogger(INREC3001_Bean.class);
	
	@Autowired
	private SuapCustInfoService suapCustInfoService;
	
	@Autowired
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	
//	private SuapCustInfoService suapCustInfoService=InrecDaoFactory.getDaoManager().getSuapCustInfoService();
//	private SuapCustDeviceInfoService suapCustDeviceInfoService=InrecDaoFactory.getDaoManager().getSuapCustDeviceInfoService();
	
	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n------------------调用INREC3001服务------------------");
		setFaceLog(reqMsg);
		
		LOGGER.debug("check InVo: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		INREC3001ServiceInVo inre3001ReqEntity = (INREC3001ServiceInVo) reqMsg.getTx_body().getEntity();
		String id_type = inre3001ReqEntity.getId_type();
		String id_no = inre3001ReqEntity.getId_no();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(id_type+id_no));
		LOGGER.debug("selectCustInfo: num: "+num+", id_type: "+id_type+", id_no: "+id_no);
		SuapCustInfoModel custInfo = suapCustInfoService.selectWithRedis(num, id_type, id_no);
		LOGGER.debug("custInfo in database: "+custInfo);
		
		if(custInfo == null)
			throw new CommonRuntimeException(Errorcode.CUSTINFOISNULL);
		
		
		String path = custInfo.getScenephoto_path();
		LOGGER.debug("path in custInfo: "+path);
		if(org.apache.commons.lang.StringUtils.isEmpty(path))
			throw new CommonRuntimeException(Errorcode.PHOTOPATHERROR);
		String photo = PhotoUtil.loadPhoto(path);
		
		INREC3001ServiceOutVo inrec3001RspEntity = getRsponseEntity(reqMsg, custInfo);
		inrec3001RspEntity.setFace_image(photo);
		
		rspMsg.getTx_body().setEntity(inrec3001RspEntity);
		
		return rspMsg;
	}
	
	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		
		INREC3001ServiceInVo inrec3001ReqEntity = (INREC3001ServiceInVo) reqMsg.getTx_body().getEntity();
		String id_type = inrec3001ReqEntity.getId_type();
		String id_no = inrec3001ReqEntity.getId_no();
		String name = inrec3001ReqEntity.getName();
		
		if("".equals(id_type) || id_type == null)
			throw new CommonRuntimeException(Errorcode.ID_TYPENOTNULL);
		if("".equals(id_no) || id_no == null)
			throw new CommonRuntimeException(Errorcode.ID_NUMBNOTNULL);
		if("".equals(name) || name == null)
			throw new CommonRuntimeException(Errorcode.CSTNAMENOTNULL);
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("selectCustInfo(").append(selectCustInfo)
//		.append(")/getPhoto(").append(getPhoto)
//		.append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}

	
	private void setFaceLog(TxRequestMsg reqMsg) {
		INREC3001ServiceInVo inrec3001ReqEntity = (INREC3001ServiceInVo) reqMsg.getTx_body().getEntity();
		SuapFaceLogModel faceLog = FaceLogThreadLocal.get();
		faceLog.setIdtype(inrec3001ReqEntity.getId_type());
		faceLog.setIdno(inrec3001ReqEntity.getId_no());
		faceLog.setName(inrec3001ReqEntity.getName());
		
	}

	
	/**
	 * 	将客户信息封装至返回实体域中
	 * @param custInfo
	 * @param faceConfig
	 * @return
	 */
	private INREC3001ServiceOutVo getRsponseEntity(TxRequestMsg reqMsg, SuapCustInfoModel custInfo) {
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		
		String idtype = custInfo.getIdtype();
		String id_no = custInfo.getIdnumber();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(idtype+id_no));
		
		INREC3001ServiceOutVo inrec3001RspEntity = new INREC3001ServiceOutVo();
		
		inrec3001RspEntity.setId_type(idtype);
		inrec3001RspEntity.setId_no(id_no);
		inrec3001RspEntity.setName(custInfo.getCustname());
		inrec3001RspEntity.setCcb_custno(custInfo.getCcbcustno());
		inrec3001RspEntity.setBranch_id(custInfo.getBranchid());
		inrec3001RspEntity.setMobile_no(custInfo.getCellphome());
		
		SuapCustDeviceInfoModel cust_device_info = suapCustDeviceInfoService.select(num, idtype, id_no, com1.getSysChannelID());
		inrec3001RspEntity.setChannel_custno(cust_device_info.getChannel_cstno());
		
		SuapFaceConfigModel faceConfig = SuapFaceConfigUtil.getFaceConfig(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		inrec3001RspEntity.setFace_channel(faceConfig.getLocation_source());
		inrec3001RspEntity.setFace_type(faceConfig.getLeveltype());
		inrec3001RspEntity.setFace_level(faceConfig.getLevelgrade());
		
		return inrec3001RspEntity;
	}


	
	
	
	
	
}
