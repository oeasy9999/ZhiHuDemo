package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class INREC1002ServiceInVo extends TxRequestMsgEntity{
	
	private String face_image;				//人脸图片
	private String face_eigen;				//人脸特征值
	private String branch_id;				//分行号
	private String vender_code;				//厂商标识
	private String vender_version;			//提取人脸特征厂商库版本号
	
	/**
	 *	 提取人脸特征终端类别
	 * 		1：PC
	 * 		2：IOS
	 * 		3：Android
	 * 		4：网点摄像头
	 * 		5：其他
	 */
	private String device_type;
	
	private String device_code;				//终端设备号(类似IMEI设备唯一标示)
	private String device_version;			//终端设备版本号
	private String device_authcode;			//设备认证码
	
	public String getFace_image() {
		return face_image;
	}
	public void setFace_image(String face_image) {
		this.face_image = face_image;
	}
	public String getFace_eigen() {
		return face_eigen;
	}
	public void setFace_eigen(String face_eigen) {
		this.face_eigen = face_eigen;
	}
	public String getBranch_id() {
		return branch_id;
	}
	public void setBranch_id(String branch_id) {
		this.branch_id = branch_id;
	}
	public String getVender_code() {
		return vender_code;
	}
	public void setVender_code(String vender_code) {
		this.vender_code = vender_code;
	}
	public String getVender_version() {
		return vender_version;
	}
	public void setVender_version(String vender_version) {
		this.vender_version = vender_version;
	}
	public String getDevice_type() {
		return device_type;
	}
	public void setDevice_type(String device_type) {
		this.device_type = device_type;
	}
	public String getDevice_code() {
		return device_code;
	}
	public void setDevice_code(String device_code) {
		this.device_code = device_code;
	}
	public String getDevice_version() {
		return device_version;
	}
	public void setDevice_version(String device_version) {
		this.device_version = device_version;
	}
	public String getDevice_authcode() {
		return device_authcode;
	}
	public void setDevice_authcode(String device_authcode) {
		this.device_authcode = device_authcode;
	}
	
	@Override
	public String toString() {
		return "INREC2002ServiceInVo [face_image=" + face_image + ", face_eigen=" + face_eigen + ", branch_id="
				+ branch_id + ", vender_code=" + vender_code + ", vender_version=" + vender_version + ", device_type="
				+ device_type + ", device_code=" + device_code + ", device_version=" + device_version
				+ ", device_authcode=" + device_authcode + "]";
	}
	
	
	
	
	
}
