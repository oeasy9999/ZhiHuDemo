package com.ccb.suap.cloud.access.model;

import java.io.Serializable;

public class SuapSysparaModel implements Serializable{
	
	private static final long serialVersionUID = 5268323602517401125L;
	
	private String paracode;			//参数代码
	private String paraname;			//参数名称
	private String paravalue;			//参数值
	private String paratype;			//参数类型
	private String remark;				//备注
	
	public String getParacode() {
		return paracode;
	}
	public void setParacode(String paracode) {
		this.paracode = paracode;
	}
	public String getParaname() {
		return paraname;
	}
	public void setParaname(String paraname) {
		this.paraname = paraname;
	}
	public String getParavalue() {
		return paravalue;
	}
	public void setParavalue(String paravalue) {
		this.paravalue = paravalue;
	}
	public String getParatype() {
		return paratype;
	}
	public void setParatype(String paratype) {
		this.paratype = paratype;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	@Override
	public String toString() {
		return "SuapSyspara [paracode=" + paracode + ", paraname=" + paraname + ", paravalue=" + paravalue
				+ ", paratype=" + paratype + ", remark=" + remark + "]";
	}
	
	
	
	
	
	
	
	
	
	
}
