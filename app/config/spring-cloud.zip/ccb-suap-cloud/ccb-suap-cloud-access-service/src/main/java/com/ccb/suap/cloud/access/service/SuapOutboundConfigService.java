package com.ccb.suap.cloud.access.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccb.suap.cloud.access.annotation.StatusAnnotation;
import com.ccb.suap.cloud.access.controller.ConfigRefreshContoller;
import com.ccb.suap.cloud.access.mapper.SuapOutboundConfigMapper;
import com.ccb.suap.cloud.access.model.SuapOutboundConfigModel;

@Service
@StatusAnnotation
public class SuapOutboundConfigService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigRefreshContoller.class);
	
	@Autowired
	private SuapOutboundConfigMapper dao;
	
	
	public List<SuapOutboundConfigModel> selectAll(){
		
		List<SuapOutboundConfigModel> list = null;
		try {
			list = dao.selectAll();
		} catch (Exception e) {
			LOGGER.error("select OutBound Config fail: all Config!\n"+e.toString()+"\n\n");
			throw e;
		}
		
		return list;
	}
	
	
	public SuapOutboundConfigModel selectOne(String channelcode, String tradecode) {
		
		SuapOutboundConfigModel model = null;
		try {
			model = dao.selectOne(channelcode, tradecode);
		} catch (Exception e) {
			LOGGER.error("select OutBound Config fail: {channelcode:"+channelcode+",tradecode:"+tradecode+"}\n"+e.toString()+"\n\n");
			throw e;
		}
		
		return model;
	}
	
	
	
	
	
	
	
	
	
	
}
