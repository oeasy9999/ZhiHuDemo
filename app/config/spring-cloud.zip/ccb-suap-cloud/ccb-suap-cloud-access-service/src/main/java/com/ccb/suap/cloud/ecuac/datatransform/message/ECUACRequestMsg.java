package com.ccb.suap.cloud.ecuac.datatransform.message;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("TX")
public class ECUACRequestMsg implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@XStreamAlias("TX_HEADER")
	private ECUACRequestMsgHead tx_header;
	@XStreamAlias("TX_BODY")
	private ECUACRequestMsgBody tx_body;
	@XStreamAlias("TX_EMB")
	private String tx_emb;
	
	public ECUACRequestMsgHead getTx_header() {
		return tx_header;
	}
	public void setTx_header(ECUACRequestMsgHead tx_header) {
		this.tx_header = tx_header;
	}
	public ECUACRequestMsgBody getTx_body() {
		return tx_body;
	}
	public void setTx_body(ECUACRequestMsgBody tx_body) {
		this.tx_body = tx_body;
	}
	public String getTx_emb() {
		return tx_emb;
	}
	public void setTx_emb(String tx_emb) {
		this.tx_emb = tx_emb;
	}
	
	@Override
	public String toString() {
		return "TxRequestMsg [tx_header=" + tx_header + ", tx_body=" + tx_body + ", tx_emb=" + tx_emb + "]";
	}
	

	
	
	
	
	
	
}