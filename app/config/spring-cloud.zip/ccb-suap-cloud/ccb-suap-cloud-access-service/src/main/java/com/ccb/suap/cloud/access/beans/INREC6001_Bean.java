package com.ccb.suap.cloud.access.beans;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.service.INRECBeansService;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC6001ServiceInVo;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam6001;
import com.ccb.suap.util.log.TraceLog;

/**
 * 	云端日志同步
 * @author 86156
 *
 */
@Controller("INREC6001")
public class INREC6001_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC6001_Bean.class);
	
	@Autowired
	private INRECBeansService inrecBeansService;
	
//	private INRECBeansService inrecBeansService = InrecDaoFactory.getDaoManager().getINRECBeansService();
	

	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg,TxRequestMsg reqMsg,TraceLog traceLog) throws Exception{
		LOGGER.debug("\n\n------------------调用INREC6001服务------------------");
		
		FaceLogThreadLocal.get().setRemarks("本地推送日志表");
		
		//实体域参数校验
		LOGGER.debug("check requestEntity: "+reqMsg.getTx_body().getEntity());
		checkParaByServerName(rspMsg, reqMsg);
		
		//流程参数，只存储部分参数，详情参考注释
		ServiceInVoParam6001 param = new ServiceInVoParam6001();
		setParam(reqMsg, param);
		
		//插入日志表并保存图片
		inrecBeansService.insertFaceLogAndSavePhoto(reqMsg, param);
		
		LOGGER.debug("success: "+rspMsg);
		return rspMsg;
	}
	
	
	/**
	 *	 设置流程参数
	 * @param reqMsg
	 */
	private void setParam(TxRequestMsg reqMsg, ServiceInVoParam6001 param) {
		
		//请求报文实体域
		INREC6001ServiceInVo inVo = (INREC6001ServiceInVo) reqMsg.getTx_body().getEntity();
		param.setFaceLog(getFaceLog(inVo));
		
		//请求图片
		param.setFace_image(inVo.getFace_image());
		
	}


	/**
	 * 将请求信息封装成日志表对象
	 * @param inVo
	 * @return
	 */
	private SuapFaceLogModel getFaceLog(INREC6001ServiceInVo inVo) {
		SuapFaceLogModel faceLog = new SuapFaceLogModel();
		
		faceLog.setChannelid(inVo.getChannelid());
		faceLog.setChanneltxcode(inVo.getChanneltxcode());
		faceLog.setBranchid(inVo.getBranchid());
		faceLog.setTransflow(inVo.getTransflow());
		faceLog.setIdtype(inVo.getIdtype());
		faceLog.setIdno(inVo.getIdno());
		faceLog.setName(inVo.getName());
		faceLog.setMobile(inVo.getMobile());
		faceLog.setCustid(inVo.getCustid());
		faceLog.setSimilarity(inVo.getSimilarity());
		faceLog.setFacefilepath(inVo.getFacefilepath());
		faceLog.setRecvtime(inVo.getRecvtime());
		faceLog.setResptime(inVo.getResptime());
		faceLog.setTxcode(inVo.getTxcode());
		faceLog.setTransret(inVo.getTransret());
		faceLog.setHostname(inVo.getHostname());
		faceLog.setServerip(inVo.getServerip());
		faceLog.setUsername(inVo.getUsername());
		faceLog.setErrorcode(inVo.getErrorcode());
		faceLog.setVendorcode(inVo.getVendorcode());
		faceLog.setVendorerrcode(inVo.getVendorerrcode());
		faceLog.setErrormsg(inVo.getErrormsg());
		faceLog.setRecvtimemillis(inVo.getRecvtimemillis());
		faceLog.setResptimemillis(inVo.getResptimemillis());
		faceLog.setCosttimeinfo(inVo.getCosttimeinfo());
		faceLog.setRemarks(inVo.getRemarks());
		
		return faceLog;
	}

	
	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		INREC6001ServiceInVo inVo = (INREC6001ServiceInVo)reqMsg.getTx_body().getEntity();
		
		if(StringUtils.isBlank(inVo.getChannelid()))
			throw new CommonRuntimeException(Errorcode.ENCHNIDNOTNULL);
		if(StringUtils.isBlank(inVo.getChanneltxcode()))
			throw new CommonRuntimeException(Errorcode.ENCHNCDNOTNULL);
		if(StringUtils.isBlank(inVo.getTransflow()))
			throw new CommonRuntimeException(Errorcode.ENTRANFNOTNULL);
		if(inVo.getRecvtime() == null)
			throw new CommonRuntimeException(Errorcode.ENRECTMNOTNULL);
		if(inVo.getResptime() == null)
			throw new CommonRuntimeException(Errorcode.ENRESTMNOTNULL);
		if(StringUtils.isBlank(inVo.getTxcode()))
			throw new CommonRuntimeException(Errorcode.EN_TXCDNOTNULL);
		if(StringUtils.isBlank(inVo.getTransret()))
			throw new CommonRuntimeException(Errorcode.ENTRANSNOTNULL);
		if(StringUtils.isBlank(inVo.getHostname()))
			throw new CommonRuntimeException(Errorcode.ENHOSNMNOTNULL);
		if(StringUtils.isBlank(inVo.getServerip()))
			throw new CommonRuntimeException(Errorcode.ENSERIPNOTNULL);
		if(StringUtils.isBlank(inVo.getErrorcode()))
			throw new CommonRuntimeException(Errorcode.ENERRCDNOTNULL);
		
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		SB.append("insertFaceLog(").append(insertFaceLog)
//		.append(")/savePhoto(").append(savePhoto)
//		.append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	


	
	
	
}
