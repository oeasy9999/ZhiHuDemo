package com.ccb.suap.cloud.access.service.utils;

import java.net.InetAddress;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.mapper.SuapSysparaMapper;
import com.ccb.suap.cloud.access.model.SuapSysparaModel;

@Component
public class SuapSysParaUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	public static SuapSysParaUtil sysParaUtil;
	
	@Autowired
	private SuapSysparaMapper suapSysparaMapper;
		
	private static Hashtable<String,String> MyHashTable = new Hashtable<String,String>();

	private static Hashtable<String,String> countTable = new Hashtable<String,String>();

	private static Hashtable<String,String> timeTable = new Hashtable<String,String>();

	// 100000次数刷新一次内存的参数列表

	private final static String countCachePara100000 = " ,INL_CARDBIN,";

	@PostConstruct
	public void onInit() {
		sysParaUtil = this;
		sysParaUtil.suapSysparaMapper = this.suapSysparaMapper;
		System.out.println("***************init sysParaMapper***************");
		init();
		
	}
	public static int init() {

		List<SuapSysparaModel> list = null;
		try {
			list = sysParaUtil.suapSysparaMapper.selectAll();
		} catch (Exception e) {
			LOGGER.error("init sysPara error: "+e.getMessage(), e);
			return -1;
		}

		if (list == null || list.isEmpty())
			return 0;

		for (int i = 0; i < list.size(); i++) {

			SuapSysparaModel syspara = list.get(i);

			MyHashTable.put(syspara.getParacode().toUpperCase(), syspara.getParavalue());

		}

		return 1;

	}
	
	
	public static int refresh()
	{
		MyHashTable= new Hashtable<String,String>();
		List<SuapSysparaModel> list = null;
		try {
			list = sysParaUtil.suapSysparaMapper.selectAll();
		} catch (Exception e) {
			LOGGER.error("refresh sysPara error: "+e.getMessage(), e);
			return -1;
		}

		if (list == null || list.isEmpty())
			return 0;

		for (int i = 0; i < list.size(); i++) {

			SuapSysparaModel syspara = list.get(i);

			MyHashTable.put(syspara.getParacode(), syspara.getParavalue());

		}

		return 1;
	}
	
	
	public static Hashtable<String,String> getPara() {

		return MyHashTable;

	}

	public static int getIntPara(String Key1, int DefaultInt) {

		return getIntValue(Key1, DefaultInt);

	}
	
	public static int getIntParaInServer(String paracode, int defaultInt) {
		try {
			String hostname = InetAddress.getLocalHost().getHostName();
			LOGGER.debug("getHostName:" + hostname);
			
			SuapSysparaModel p = sysParaUtil.suapSysparaMapper.selectServerPara(paracode, hostname);
			if(p!=null) {
				return Integer.parseInt(p.getParavalue());
			} else {
				LOGGER.warn("selectServerPara->[" + paracode + "] is null");
				return defaultInt;
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			LOGGER.error("getIntParaInServer", e);
			return defaultInt;
		}
	}

	public static String getStrPara(String Key1, String DefaultInt) {
		Key1 = Key1.toUpperCase();
		if (Key1 != null && countCachePara100000.indexOf("," + Key1 + ",") >= 0)

			return getStrValueOfCountCache(Key1, DefaultInt, 100000);

		return getStrValue(Key1, DefaultInt);

	}
	
	public static String getStrParaInServer(String paracode, String defaultInt) {
		try {
			String hostname = InetAddress.getLocalHost().getHostName();
			LOGGER.debug("getHostName:" + hostname);
			
			SuapSysparaModel p = sysParaUtil.suapSysparaMapper.selectServerPara(paracode, hostname);
			if(p!=null) {
				return p.getParavalue();
			} else {
				LOGGER.warn("selectServerPara->[" + paracode + "] is null");
				return defaultInt;
			}
		} catch(Exception e) {
			LOGGER.error("getIntParaInServer", e);
			return defaultInt;
		}
	}

	private static int getIntValue(String Key1, int DefaultInt) {

		String LT = (String) MyHashTable.get(Key1);

		if (LT == null)
			return DefaultInt;

		try {

			return (new Integer(LT)).intValue();

		} catch (Exception e) {
			return DefaultInt;
		}

	}

	private static String getStrValue(String Key1, String DefaultStr) {

		String LT = (String) MyHashTable.get(Key1);

		if (LT == null)
			LT = DefaultStr;

		return LT;

	}

	// 从缓存中取数，当超过1000次时，从数据库重新查询获取值。

	public static String getStrValueOfCountCache(String key,
			String defaultValue, int maxCount) {

		String s = (String) countTable.get(key);

		if (s == null)

			s = "0";

		int keyCount = Integer.parseInt(s);

		if (keyCount >= maxCount) {
			
			String value = "";

			/*String Sql = "SELECT paracode,paravalue FROM cm_sys_para t WHERE t.paracode=? ";

			DBACCESS db = new DBACCESS();

			Object[] args = new Object[] { key };

			Vector vResult = db.dbQuery(Sql, args);*/
			SuapSysparaModel syspara = null;
			try {
				syspara = sysParaUtil.suapSysparaMapper.select(key, "0");
			} catch (Exception e) {
				return defaultValue;
			}

			if (syspara == null)
				value = "";

			value = syspara.getParavalue();


			if (value == null)

				value = "";

			value = value.trim();

			if (!"".equals(value)) {

				MyHashTable.put(key, value);

			}

		}

		synchronized (countTable) {

			if (keyCount >= maxCount)

				keyCount = 1;

			else

				keyCount++;

			countTable.put(key, keyCount + "");

		}

		return getStrValue(key, defaultValue);

	}

	// 从缓存中取数，当超过1000次时，从数据库重新查询获取值。

	public static String getStrValueOfCountCache(String key, String defaultValue) {

		return getStrValueOfCountCache(key, defaultValue, 1000);

	}

	/**
	 * 
	 * 获取定时刷新的参数
	 * 
	 * @param key
	 *            键值
	 * 
	 * @param defaultValue
	 *            默认值
	 * 
	 * @param millisecond
	 *            刷新频率
	 * 
	 * @return String 值
	 */

	public static String getStrValueOfTime(String key, String defaultValue,
			long millisecond) {

		boolean isNeedUpdate = false;

		String strTime = (String) timeTable.get(key + "_refreshTime");

		String strNowTime = "";

		if (strTime == null) {

			isNeedUpdate = true;

		} else {

			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(
					"yyyyMMdd HH:mm:ss");

			Date now = new Date();

			strNowTime = sdf.format(now);

			try {

				if (now.getTime() - sdf.parse(strTime).getTime() > millisecond) {

					isNeedUpdate = true;

				}

			} catch (Exception e) {

				isNeedUpdate = true;

			}

		}

		if (isNeedUpdate) {

			String strValue = getStrValue(key, defaultValue);

			synchronized (timeTable) {

				timeTable.put(key, strValue);

				timeTable.put(key + "_refreshTime", strNowTime);

			}

			return strValue;

		} else {

			return (String) timeTable.get(key);

		}

	}

	public static String setStrValue(String key, String value) {
		getPara().put(key, value);
		return getPara().get(key);
	}


}
