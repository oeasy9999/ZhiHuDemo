package com.ccb.suap.cloud.access.vo;

import java.util.List;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class INREC1002ServiceOutVo extends TxResponseMsgEntity{
	
	/**
	 * 	比对结果
	 * 	 1：比对成功
	 * 	 0：比对失败
	 */
	private String result_list_size;
	
	private List<INREC1002ServiceOutList> result_list;			//比对结果列表

	public String getResult_list_size() {
		return result_list_size;
	}

	public void setResult_list_size(String result_list_size) {
		this.result_list_size = result_list_size;
	}

	public List<INREC1002ServiceOutList> getResult_list() {
		return result_list;
	}

	public void setResult_list(List<INREC1002ServiceOutList> result_list) {
		this.result_list = result_list;
	}

	@Override
	public String toString() {
		return "INREC2002ServiceOutVo [result_list_size=" + result_list_size + ", result_list=" + result_list + "]";
	}

	
	
	
	
	
	
	
	
	
	
}
