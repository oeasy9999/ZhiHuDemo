package com.ccb.suap.cloud.access.model;

import java.io.Serializable;
import java.util.Date;

public class SuapTxChannelAuthModel implements Serializable{
	
	private static final long serialVersionUID = -1290604143712238322L;
	
	private String txcode;				//交易代码
	private String channelid;			//渠道号
	private String channeltxcode;		//渠道交易码
	private Date createtime;			//创建时间
	private String creator;				//创建者
	private String remark;				//备注
	
	public String getTxcode() {
		return txcode;
	}
	public void setTxcode(String txcode) {
		this.txcode = txcode;
	}
	public String getChannelid() {
		return channelid;
	}
	public void setChannelid(String channelid) {
		this.channelid = channelid;
	}
	public String getChanneltxcode() {
		return channeltxcode;
	}
	public void setChanneltxcode(String channeltxcode) {
		this.channeltxcode = channeltxcode;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	@Override
	public String toString() {
		return "SuapTxChannelAuthModel [txcode=" + txcode + ", channelid=" + channelid + ", channeltxcode="
				+ channeltxcode + ", createtime=" + createtime + ", creator=" + creator + ", remark=" + remark + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
