package com.ccb.suap.cloud.access.service.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ccb.suap.cloud.access.beans.INREC5001_Bean;

public class XMLUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC5001_Bean.class);
	
//	/**
//	 * 获取code标签的内容
//	 * @param aiaudioRsp
//	 * @return
//	 */
//	public static String getRspCode(String aiaudioRsp) {
//		String code = getString(aiaudioRsp, "Code");
//		return code;
//	}
//	
//	
//	/**
//	 * 获取message标签的内容
//	 * @param aiaudioRsp
//	 * @return
//	 */
//	public static String getMessage(String aiaudioRsp) {
//		String message = getString(aiaudioRsp, "Message");
//		return message;
//	}
//	
//	
//	/**
//	 * 获取vedio标签的内容
//	 * @param aiaudioRsp
//	 * @return
//	 */
//	public static String getVideo(String aiaudioRsp) {
//		String vedio = getString(aiaudioRsp, "Video");
//		return vedio;
//	}
	
	
	/**
	 * 通过标签获取标签内的内容
	 * @param aiaudioRsp
	 * @param label		标签
	 * @return
	 */
	public static String getString(String aiaudioRsp, String label) {
		int messageStartIndex = aiaudioRsp.indexOf("<"+label+"><![CDATA[");
		int messageEndIndex = aiaudioRsp.indexOf("]]></"+label+">");
		LOGGER.debug("messageStartIndex: "+messageStartIndex+", messageEndIndex: "+messageEndIndex);
		String message = aiaudioRsp.substring(messageStartIndex+11+label.length(), messageEndIndex);
		
		return message;
	}
	
	
	
	
	
	
	
	
}
