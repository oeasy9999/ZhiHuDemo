package com.ccb.suap.cloud.access.service.utils;

import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ccb.suap.cloud.access.controller.FaceServiceController;
/**
 * 该工具类用于对业务参数进行缓存、加工等操作(不包括数据库中的人脸信息等业务参数)
 */
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.threadLocal.CosttimeThreadLocal;
import com.ccb.suap.cloud.access.vo.INRECBaseServiceInVo;

public class ServiceParaUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	/**
	 *	 将请求信息封装到GPU前置请求信息中(除了实体域)
	 * @param reqMsg
	 * @return
	 */
	public static TxRequestMsg parseGpuRequestMsg(TxRequestMsg reqMsg) {
		TxRequestMsg gpuRequestMsg = new TxRequestMsg();
		gpuRequestMsg.setTx_header(new TxRequestMsgHead());
		gpuRequestMsg.setTx_body(new TxRequestMsgBody());
		gpuRequestMsg.getTx_body().setCom2(new TxRequestMsgCom2());
		
		TxRequestMsgHead gpuReqHeader = copyHead(reqMsg);
		gpuRequestMsg.setTx_header(gpuReqHeader);
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		TxRequestMsgCom2 gpuReqCom2 = gpuRequestMsg.getTx_body().getCom2();
		gpuReqCom2.setSysChannelID(com1.getSysChannelID());
		gpuReqCom2.setDotNumber(com1.getDotNumber());
		
		SuapFaceConfigModel suapFaceConfigModel = SuapFaceConfigUtil.getFaceConfig(com1.getSysChannelID() + ":" + com1.getChannelTxCode() + ":" + reqMsg.getTx_header().getSys_tx_code());
		gpuReqCom2.setGroupName(suapFaceConfigModel.getLocation_source());
		gpuReqCom2.setSourceGroupName(suapFaceConfigModel.getLocation());
		
		return gpuRequestMsg;
	}
	
	
	/**
	 *	将响应信息封装到人脸交易日志表中
	 * @param resMsg
	 * @param suapFaceLogModel
	 */
	public static void setFaceLogFinally(TxResponseMsg rspMsg, SuapFaceLogModel faceLog) {
		TxResponseMsgHead rspHeader = rspMsg.getTx_header();
		
		if(!"00".equals(rspHeader.getSys_tx_status())) {
			faceLog.setTransret("01");
		}else {
			faceLog.setTransret(rspHeader.getSys_tx_status());
		}
		faceLog.setErrorcode(rspHeader.getSys_resp_code());
		faceLog.setErrormsg(rspHeader.getSys_resp_desc());
		faceLog.setRecvtimemillis(rspHeader.getSys_recv_time());
		faceLog.setResptimemillis(rspHeader.getSys_resp_time());
		
		setCosttime(faceLog);
		
	}
	
	
	/**
	 * 	封装各流程耗时
	 * @param faceLog
	 */
	private static void setCosttime(SuapFaceLogModel faceLog) {
		Map<String, Long> map = CosttimeThreadLocal.getMap();
		
		String costtime = "";
		for (Map.Entry<String, Long> entry : map.entrySet()) {
			costtime = costtime.concat(entry.getKey()).concat("(").concat(String.valueOf(entry.getValue())).concat(")/");
			
		}
		
		if(costtime.length() > 1)
			costtime = costtime.substring(0, costtime.length()-1);
		
		Date sys_recv_time = faceLog.getRecvtime();
		Date sys_resp_time = faceLog.getResptime();
		costtime = costtime.concat("/costTime(").concat(String.valueOf(sys_resp_time.getTime() - sys_recv_time.getTime())).concat(")");
		
		faceLog.setCosttimeinfo(costtime);
	}


	/**
	 *	将客户相关的实体域信息封装到人脸交易日志表中
	 * @param reqMsg
	 * @param faceLog
	 */
	public static void setFaceLogByBaseEntity(TxRequestMsg reqMsg, SuapFaceLogModel faceLog) {
		INRECBaseServiceInVo entity = (INRECBaseServiceInVo) reqMsg.getTx_body().getEntity();
		
		faceLog.setIdtype(entity.getId_type());
		faceLog.setIdno(entity.getId_no());
		faceLog.setName(entity.getName());
		faceLog.setMobile(entity.getMobile_no());
		faceLog.setCustid(entity.getChannel_custno());
		
	}
	
	
	/**
	 * 复制请求头信息，除了tx_code
	 * @param reqMsg
	 * @return
	 */
	public static TxRequestMsgHead copyHead(TxRequestMsg reqMsg) {
		TxRequestMsgHead reqHeader = reqMsg.getTx_header();
		TxRequestMsgHead newHead = new TxRequestMsgHead();
		
		newHead.setSys_pkg_vrsn(reqHeader.getSys_pkg_vrsn());
		newHead.setSys_channel_id(reqHeader.getSys_channel_id());
		newHead.setSys_evt_trace_id(reqHeader.getSys_evt_trace_id());
		newHead.setSys_req_time(reqHeader.getSys_req_time());
		newHead.setSys_pkg_sts_type("00");
		
		return newHead;
	}
	
	
	/**
	 * 复制com1域
	 * @return
	 */
	public static TxRequestMsgCom1 copyCom1(TxRequestMsg reqMsg) {
		TxRequestMsgCom1 reqCom1 = reqMsg.getTx_body().getCom1();
		TxRequestMsgCom1 newCom1 = new TxRequestMsgCom1();
		
		newCom1.setSysChannelID(reqCom1.getSysChannelID());
		newCom1.setChannelTxCode(reqCom1.getChannelTxCode());
		newCom1.setDotNumber(reqCom1.getDotNumber());
		
		return newCom1;
	}
	
	
	/**
	 * 	复制请求对象(不包含com2和实体域)
	 * @param reqMsg
	 * @return
	 */
	public static TxRequestMsg newReqMsg(TxRequestMsg reqMsg) {
		TxRequestMsg newReqMsg = new TxRequestMsg();
		TxRequestMsgBody newReqBody = new TxRequestMsgBody();
		newReqMsg.setTx_body(newReqBody);
		
		newReqMsg.setTx_header(copyHead(reqMsg));
		newReqMsg.getTx_body().setCom1(copyCom1(reqMsg));
		
		return newReqMsg;
	}
	
	
	/**
	 * 根据请求信息和渠道注册信息取出本地图片
	 * @param reqMsg
	 * @param custDeviceInfo_database
	 * @return
	 */
	public static String getPhotoByCustDeviceInfo(TxRequestMsg reqMsg, SuapCustDeviceInfoModel custDeviceInfo_database) {
		SuapFaceConfigModel faceConfig = SuapFaceConfigUtil.getFaceConfig(reqMsg);
		String path = getPhotoPath(faceConfig, custDeviceInfo_database);
		String photo = PhotoUtil.loadPhotoWithTime(path);
		
		return photo;
	}
	
	
	/**
	 * 根据人脸配置表信息和客户信息取出本地图片路径
	 * @param faceConfig
	 * @param custInfo
	 * @return
	 */
	public static String getPhotoPath(SuapFaceConfigModel faceConfig, SuapCustDeviceInfoModel custDeviceInfo_database) {
		String path = custDeviceInfo_database.getPhoto_path();
		if(StringUtils.isEmpty(path))
			throw new CommonRuntimeException(Errorcode.PHOTOPATHERROR);
		
		return path;
	}
	
	
	/**
	 * 根据GPUMP响应信息获取对应实体域
	 */
	@SuppressWarnings("unchecked")
	public static <E extends TxResponseMsgEntity> E getGPURspMsgEntity(TxResponseMsg gpumpRspMsg,Class<E> cl) {
		TxResponseMsgBody tx_body = gpumpRspMsg.getTx_body();
		if(tx_body == null)
			throw new CommonRuntimeException(Errorcode.GPUBDYNOTFOUND);
		
		E entity = (E) tx_body.getEntity();
		if(entity == null)
			throw new CommonRuntimeException(Errorcode.GPUENTNOTFOUND);
		
		return entity;
	}
	
	
	/**
	 * 根据CCVEA响应信息获取对应实体域
	 * @param <E>
	 */
	@SuppressWarnings("unchecked")
	public static <E extends TxResponseMsgEntity> E getCCVEARspEntity(TxResponseMsg ccveaRspMsg, Class<E> cl) {
		TxResponseMsgBody tx_body = ccveaRspMsg.getTx_body();
		if(tx_body == null)
			throw new CommonRuntimeException(Errorcode.CCVBDYNOTFOUND);
		
		E entity = (E) tx_body.getEntity();
		if(entity == null)
			throw new CommonRuntimeException(Errorcode.CCVENTNOTFOUND);
		
		return entity;
	}
	
	
	public static String getBasePthBySyspara(String paracode, String sysChannelid, String photoType) {
		String baseRegImagePath = SuapSysParaUtil.getStrPara(paracode, null);
		if(org.apache.commons.lang.StringUtils.isEmpty(baseRegImagePath)) {
			LOGGER.error("facepicpath error: FACEPICPATH is null!");
			throw new CommonRuntimeException(Errorcode.BSPATHNOTFOUND, null, "请在系统参数表中设置\"FACEPICPATH\"");
		}
		if(!baseRegImagePath.endsWith("/"))
			baseRegImagePath = baseRegImagePath+"/";
		
		
		return baseRegImagePath+sysChannelid+"/"+photoType+"/";
	}
	
	
	/**
	 * 填充客户信息
	 * @param custInfo_database
	 * @param custInfo_reqMsg
	 */
	public static void fillCustInfo(SuapCustInfoModel custInfo_database, SuapCustInfoModel custInfo_reqMsg) {
		if(custInfo_database == null)
			return;
		
		String address = custInfo_reqMsg.getAddress();
		Date birthday = custInfo_reqMsg.getBirthday();
		String branchid = custInfo_reqMsg.getBranchid();
		String career = custInfo_reqMsg.getCareer();
		String ccbcustno = custInfo_reqMsg.getCcbcustno();
		String cellphome = custInfo_reqMsg.getCellphome();
		String company = custInfo_reqMsg.getCompany();
		Date createtime = custInfo_reqMsg.getCreatetime();
		String custname = custInfo_reqMsg.getCustname();
		String education = custInfo_reqMsg.getEducation();
		String habit = custInfo_reqMsg.getHabit();
		String idnumber = custInfo_reqMsg.getIdnumber();
		String idphoto_channel = custInfo_reqMsg.getIdphoto_channel();
		Date idphoto_date = custInfo_reqMsg.getIdphoto_date();
		String idphoto_level = custInfo_reqMsg.getIdphoto_level();
		String idphoto_path = custInfo_reqMsg.getIdphoto_path();
		String idtype = custInfo_reqMsg.getIdtype();
		String idverify = custInfo_reqMsg.getIdverify();
		String income = custInfo_reqMsg.getIncome();
		String industry = custInfo_reqMsg.getIndustry();
		String scenephoto_channel = custInfo_reqMsg.getScenephoto_channel();
		Date scenephoto_date = custInfo_reqMsg.getScenephoto_date();
		String scenephoto_level = custInfo_reqMsg.getScenephoto_level();
		String scenephoto_path = custInfo_reqMsg.getScenephoto_path();
		String school = custInfo_reqMsg.getSchool();
		String sex = custInfo_reqMsg.getSex();
		String updatechannel = custInfo_reqMsg.getUpdatechannel();
		Date updatetime = custInfo_reqMsg.getUpdatetime();
		
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getAddress()))
			custInfo_reqMsg.setAddress(address);
		if(custInfo_reqMsg.getBirthday() == null)
			custInfo_reqMsg.setBirthday(birthday);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getBranchid()))
			custInfo_reqMsg.setBranchid(branchid);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getCareer()))
			custInfo_reqMsg.setCareer(career);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getCcbcustno()))
			custInfo_reqMsg.setCcbcustno(ccbcustno);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getCellphome()))
			custInfo_reqMsg.setCellphome(cellphome);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getCompany()))
			custInfo_reqMsg.setCompany(company);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getCustname()))
			custInfo_reqMsg.setCustname(custname);
		if(custInfo_reqMsg.getCreatetime() == null)
			custInfo_reqMsg.setCreatetime(createtime);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getEducation()))
			custInfo_reqMsg.setEducation(education);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getHabit()))
			custInfo_reqMsg.setHabit(habit);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getIdnumber()))
			custInfo_reqMsg.setIdnumber(idnumber);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getIdphoto_channel()))
			custInfo_reqMsg.setIdphoto_channel(idphoto_channel);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getIdphoto_level()))
			custInfo_reqMsg.setIdphoto_level(idphoto_level);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getIdphoto_path()))
			custInfo_reqMsg.setIdphoto_path(idphoto_path);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getIdtype()))
			custInfo_reqMsg.setIdtype(idtype);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getIdverify()))
			custInfo_reqMsg.setIdverify(idverify);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getIncome()))
			custInfo_reqMsg.setIncome(income);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getIndustry()))
			custInfo_reqMsg.setIndustry(industry);
		if(custInfo_reqMsg.getIdphoto_date() == null)
			custInfo_reqMsg.setIdphoto_date(idphoto_date);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getScenephoto_channel()))
			custInfo_reqMsg.setScenephoto_channel(scenephoto_channel);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getScenephoto_level()))
			custInfo_reqMsg.setScenephoto_level(scenephoto_level);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getScenephoto_path()))
			custInfo_reqMsg.setScenephoto_path(scenephoto_path);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getSchool()))
			custInfo_reqMsg.setSchool(school);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getSex()))
			custInfo_reqMsg.setSex(sex);
		if(custInfo_reqMsg.getScenephoto_date() == null)
			custInfo_reqMsg.setScenephoto_date(scenephoto_date);
		if(org.apache.commons.lang.StringUtils.isBlank(custInfo_reqMsg.getUpdatechannel()))
			custInfo_reqMsg.setUpdatechannel(updatechannel);
		if(custInfo_reqMsg.getUpdatetime() == null)
			custInfo_reqMsg.setUpdatetime(updatetime);
		
	}
	
	
	/**
	 * 填充渠道注册信息
	 * @param custDeviceInfo_database
	 * @param custDeviceInfo_reqMsg
	 */
	public static void fillCustDeviceInfo(SuapCustDeviceInfoModel custDeviceInfo_database, SuapCustDeviceInfoModel custDeviceInfo_reqMsg) {
		
		if(custDeviceInfo_database == null)
			return;
		
		String cardno = custDeviceInfo_database.getCardno();
		String idverify = custDeviceInfo_database.getIdverify();
		String cellphome = custDeviceInfo_database.getCellphome();
		String channel_cstno = custDeviceInfo_database.getChannel_cstno();
		String channelid = custDeviceInfo_database.getChannelid();
		String custname = custDeviceInfo_database.getCustname();
		String deviceauthcode = custDeviceInfo_database.getDeviceauthcode();
		String devicecode = custDeviceInfo_database.getDevicecode();
		String devicetype = custDeviceInfo_database.getDevicetype();
		String deviceversion = custDeviceInfo_database.getDeviceversion();
		String idnumber = custDeviceInfo_database.getIdnumber();
		String idtype = custDeviceInfo_database.getIdtype();
		String isvalid = custDeviceInfo_database.getIsvalid();
		String isvip = custDeviceInfo_database.getIsvip();
		String location = custDeviceInfo_database.getLocation();
		String photo_path = custDeviceInfo_database.getPhoto_path();
		String siteno = custDeviceInfo_database.getSiteno();
		String titile = custDeviceInfo_database.getTitile();
		Date updatetime = custDeviceInfo_database.getUpdatetime();
		
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getCardno()))
			custDeviceInfo_reqMsg.setCardno(cardno);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getIdverify()))
			custDeviceInfo_reqMsg.setIdverify(idverify);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getCellphome()))
			custDeviceInfo_reqMsg.setCellphome(cellphome);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getChannel_cstno()))
			custDeviceInfo_reqMsg.setChannel_cstno(channel_cstno);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getChannelid()))
			custDeviceInfo_reqMsg.setChannelid(channelid);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getCustname()))
			custDeviceInfo_reqMsg.setCustname(custname);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getDeviceauthcode()))
			custDeviceInfo_reqMsg.setDeviceauthcode(deviceauthcode);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getDevicecode()))
			custDeviceInfo_reqMsg.setDevicecode(devicecode);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getDevicetype()))
			custDeviceInfo_reqMsg.setDevicetype(devicetype);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getDeviceversion()))
			custDeviceInfo_reqMsg.setDeviceversion(deviceversion);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getIdnumber()))
			custDeviceInfo_reqMsg.setIdnumber(idnumber);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getIdtype()))
			custDeviceInfo_reqMsg.setIdtype(idtype);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getIsvalid()))
			custDeviceInfo_reqMsg.setIsvalid(isvalid);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getIsvip()))
			custDeviceInfo_reqMsg.setIsvip(isvip);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getLocation()))
			custDeviceInfo_reqMsg.setLocation(location);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getPhoto_path()))
			custDeviceInfo_reqMsg.setPhoto_path(photo_path);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getSiteno()))
			custDeviceInfo_reqMsg.setSiteno(siteno);
		if(org.apache.commons.lang.StringUtils.isBlank(custDeviceInfo_reqMsg.getTitile()))
			custDeviceInfo_reqMsg.setTitile(titile);
		if(custDeviceInfo_reqMsg.getUpdatetime() == null)
			custDeviceInfo_reqMsg.setUpdatetime(updatetime);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
