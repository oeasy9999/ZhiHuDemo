package com.ccb.suap.cloud.access.vo;

import java.util.List;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class INREC3003ServiceOutVo extends TxResponseMsgEntity{
	
	private String result_list_size;								//查询结果列表数量
	private List<INRECCustomerElements> result_list;				//查询结果列表数量
	
	public String getResult_list_size() {
		return result_list_size;
	}
	public void setResult_list_size(String result_list_size) {
		this.result_list_size = result_list_size;
	}
	public List<INRECCustomerElements> getResult_list() {
		return result_list;
	}
	public void setResult_list(List<INRECCustomerElements> result_list) {
		this.result_list = result_list;
	}
	
	@Override
	public String toString() {
		return "INREC3003ServiceOutVo [result_list_size=" + result_list_size + ", result_list=" + result_list + "]";
	}

	
	
	
	
	
	
}
