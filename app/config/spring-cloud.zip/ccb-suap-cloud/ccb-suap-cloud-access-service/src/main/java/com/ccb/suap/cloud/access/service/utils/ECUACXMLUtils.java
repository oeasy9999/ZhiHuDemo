package com.ccb.suap.cloud.access.service.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACRequestMsg;
import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACResponseMsg;
import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACResponseMsgBodyEntity;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.naming.NoNameCoder;
import com.thoughtworks.xstream.io.xml.Xpp3Driver;

public class ECUACXMLUtils {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	private static volatile ConcurrentHashMap<Class<?>, XStream> map = new ConcurrentHashMap<>();
	
	
	/**
	 * 将对象转换成XML格式
	 * @param xStream
	 * @param obj
	 * @return
	 */
	public static String getXMLByAnnotation(XStream xStream, Object obj) {
		
		if(xStream == null)
			throw new CommonRuntimeException(Errorcode.XSTRMNULLERROR);
		
		String xml = "";
		try {
			xml = xStream.toXML(obj);
		} catch (Exception e) {
			LOGGER.error("JAVA_BEAN parse XML error!", e);
			throw new CommonRuntimeException(Errorcode.BEANPSXMLERROR, "01", e.getMessage());
		}
		
		return xml;
	}
	
	
	/**
	 *	 将对象转换成ECUAC0183要求的XML格式
	 * 	1.1 添加了头部信息：<?xml version="1.0" encoding="utf-8"?>
	 * @param reqMsg
	 * @param T
	 * @return
	 */
	public static <T> String getECUACXMLByAnnotation(ECUACRequestMsg reqMsg, Class<T> T) {
		
		Class<?> xStreamKey = null;
		if(T != null) {
			xStreamKey = T;
		}else {
			xStreamKey = reqMsg.getClass();
		}
		
		//从map中取出对象，禁止重复创建同一个key值的对象
		XStream xStream = map.get(xStreamKey);
		if(xStream == null) {
			synchronized (ECUACXMLUtils.class) {
				xStream = map.get(xStreamKey);
				if(xStream == null) {
					xStream = newToXMLInstance(reqMsg.getClass(), T);
					map.put(xStreamKey, xStream);
				}
			}
		}
		
		String xml = getXMLByAnnotation(xStream, reqMsg);
		xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n" + xml;
		
		return xml;
	}
	
	
	/**
	 *	 将XML转换成java对象
	 * @param xml 源XML
	 * @param T 返回的对象类型
	 * @param implement_type 对象中包含的子类/实现类，key为子类/实现类，value为父类/接口
	 * @param class_type 安全防护和注解形式设置别名的类
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T toJavaObject(XStream xStream, String xml, Class<T> T){
		
		if(xStream == null)
			throw new CommonRuntimeException(Errorcode.XSTRMNULLERROR);
		
		T java_bean = null;
		try {
			java_bean = (T) xStream.fromXML(xml);
		} catch (Exception e) {
			LOGGER.error("XML parse JAVA_BEAN error!", e);
			throw new CommonRuntimeException(Errorcode.XMLPSBEANERROR, "01", e.getMessage());
		}
		
		return java_bean;
	}
	
	
	/**
	 *	 将XML转换成ECUAC0183响应对象
	 * @param xml
	 * @param T
	 * @return
	 */
	public static <T> ECUACResponseMsg toECUACTxResponseMsg(String xml, Class<T> T) {
		
		Class<?> xStreamKey = null;
		if(T != null) {
			xStreamKey = T;
		} else {
			xStreamKey = ECUACResponseMsg.class;
		}
		
		//从map中取出对象，禁止重复创建同一个key值的对象
		XStream xStream = map.get(xStreamKey);
		if(xStream == null) {
			synchronized (ECUACXMLUtils.class) {
				xStream = map.get(xStreamKey);
				if(xStream == null) {
					HashMap<Class<?>, Class<?>> implement_type = new HashMap<>();
					implement_type.put(T, ECUACResponseMsgBodyEntity.class);
					
					xStream = newToObjectInstance(implement_type, ECUACResponseMsg.class, T);
					map.put(xStreamKey, xStream);
				}
			}
		}
		
		ECUACResponseMsg rsp_msg = toJavaObject(xStream, xml, ECUACResponseMsg.class);
		
		return rsp_msg;
	}
	
	
	/**
	 * 创建Object转XML的XStream
	 * @param class_type 安全防护和注解形式设置别名的类
	 * @return
	 */
	public static <T> XStream newToXMLInstance(Class<?>... class_type) {
		
		//请将此对象共用，持续创建此对象会导致内存泄漏
		XStream xStream = new XStream(new Xpp3Driver(new NoNameCoder()));
		
		//去除class属性
		xStream.aliasSystemAttribute(null, "class");
		
		setInstance(xStream, null, class_type);
		
		return xStream;
	}
	
	
	/**
	 * 创建XML转Object的XStream
	 * @param class_type 安全防护和注解形式设置别名的类
	 * @return
	 */
	public static <T> XStream newToObjectInstance(Map<Class<?>,Class<?>> implement_type, Class<?>... class_type) {
		
		//请将此对象共用，持续创建此对象会导致内存泄漏
		XStream xStream = new XStream();
		
		setInstance(xStream, implement_type, class_type);
		
		return xStream;
	}
	
	
	/**
	 * 设置XStream,如需设置子类和父类的映射，请在map中存储子类与父类对象的映射关系
	 * @param xStream
	 * @param implement_type 对象中包含的子类/实现类，key为子类/实现类，value为父类/接口
	 * @param class_type 安全防护和注解形式设置别名的类
	 */
	public static <T> void setInstance(XStream xStream, Map<Class<?>,Class<?>> implement_type, Class<?>... class_type) {
		
		//设置默认安全防护
		XStream.setupDefaultSecurity(xStream);
		
		if(class_type != null) {
			xStream.allowTypes(class_type);
			xStream.processAnnotations(class_type);
		}
		
		if(implement_type != null) 
			for (Class<?> class_name : implement_type.keySet()) 
				xStream.addDefaultImplementation(class_name, implement_type.get(class_name));
		
	}
	
	
	
	
	
	
	
	
}
