package com.ccb.suap.cloud.access.context;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ccb.suap.cloud.access.dao.factory.DaoManagerService;

public class mylistener implements ServletContextListener{

	public static Object waitToDel;
	
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		System.out.println("-------------mylistener.contextInitialized--------------------");
		DaoManagerService daoManager = (DaoManagerService) WebApplicationContextUtils.getWebApplicationContext(sce.getServletContext()).getBean("daoManager");
    	waitToDel = daoManager;
		
    	ApplicationContext.appPut("daoManager", daoManager);
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		
	}

}
