package com.ccb.suap.cloud.access.datatransform.message;

public class TxRequestMsgBody {
	

	private TxRequestMsgEntity entity;
	private TxRequestMsgCom1  com1;
	private TxRequestMsgCom2  com2;
	private TxRequestMsgEquipmentInfo equipment_info;
	
	public TxRequestMsgEntity getEntity() {
		return entity;
	}
	public void setEntity(TxRequestMsgEntity entity) {
		this.entity = entity;
	}
	public TxRequestMsgCom1 getCom1() {
		return com1;
	}
	public void setCom1(TxRequestMsgCom1 com1) {
		this.com1 = com1;
	}
	public TxRequestMsgCom2 getCom2() {
		return com2;
	}
	public void setCom2(TxRequestMsgCom2 com2) {
		this.com2 = com2;
	}
	public TxRequestMsgEquipmentInfo getEquipment_info() {
		return equipment_info;
	}
	public void setEquipment_info(TxRequestMsgEquipmentInfo equipment_info) {
		this.equipment_info = equipment_info;
	}
	
	@Override
	public String toString() {
		return "TxRequestMsgBody [entity=" + entity + ", com1=" + com1 + ", com2=" + com2 + ", equipment_info="
				+ equipment_info + "]";
	}
	
	
	
	
	
}
