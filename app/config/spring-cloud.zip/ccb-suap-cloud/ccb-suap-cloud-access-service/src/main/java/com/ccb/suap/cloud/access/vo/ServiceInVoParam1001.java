package com.ccb.suap.cloud.access.vo;

public class ServiceInVoParam1001 extends ServiceInVoParam1001And2001{
	
	private INREC1001ServiceInVo inVo;							//请求信息实体域

	public INREC1001ServiceInVo getInVo() {
		return inVo;
	}

	public void setInVo(INREC1001ServiceInVo inVo) {
		this.inVo = inVo;
	}

	@Override
	public String toString() {
		return "ServiceInVoParam1001 [inVo=" + inVo + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
}
