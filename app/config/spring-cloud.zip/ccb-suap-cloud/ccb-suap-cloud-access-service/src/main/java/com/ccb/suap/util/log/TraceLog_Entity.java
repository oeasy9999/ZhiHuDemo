package com.ccb.suap.util.log;

import com.ccb.suap.util.JSONUtils;

public class TraceLog_Entity {
	
	private String name;
	private String requestMessage;
	private String responseMessage;
	private long costtime;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRequestMessage() {
		return requestMessage;
	}
	public void setRequestMessage(String requestMessage) {
		this.requestMessage =  JSONUtils.formatJson(requestMessage,-1);
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage =  JSONUtils.formatJson(responseMessage,-1);
	}
	public long getCosttime() {
		return costtime;
	}
	public void setCosttime(long costtime) {
		this.costtime = costtime;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
