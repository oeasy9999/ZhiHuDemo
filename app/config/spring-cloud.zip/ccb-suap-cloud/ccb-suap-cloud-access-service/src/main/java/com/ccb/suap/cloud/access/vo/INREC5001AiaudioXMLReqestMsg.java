package com.ccb.suap.cloud.access.vo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class INREC5001AiaudioXMLReqestMsg {
	
	
	/**
	 * 输入实体域，获取aidudio请求对象(XML格式)
	 * @param xmlEntity
	 * @return
	 */
	public static String getAiaudioRequestMsg(String xmlEntity) {
		
		String reqMsg = 
				"		<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n" + 
				"		<TX>\r\n" +
				getHeader()+
				getBody(xmlEntity)+
				"		</TX>";
		
		return reqMsg;
	}
	
	
	/**
	 * 获取aiaudio的header部分
	 * @return
	 */
	public static String getHeader() {
		
		String header = 
				"			<TX_HEADER>\r\n" + 
				"				<SYS_HDR_LEN>100</SYS_HDR_LEN>\r\n" + 
				"				<SYS_PKG_VRSN>01</SYS_PKG_VRSN>\r\n" + 
				"				<SYS_TTL_LEN>400</SYS_TTL_LEN>\r\n" + 
				"				<SYS_REQ_SEC_ID>0123456789</SYS_REQ_SEC_ID>\r\n" + 
				"				<SYS_SND_SEC_ID>9876543210</SYS_SND_SEC_ID>\r\n" + 
				"				<SYS_TX_CODE>ReflectDetectVideoServices</SYS_TX_CODE>\r\n" + 
				"				<SYS_TX_VRSN>01</SYS_TX_VRSN>\r\n" + 
				"				<SYS_TX_TYPE>00000</SYS_TX_TYPE>\r\n" + 
				"				<SYS_RESERVED>AA</SYS_RESERVED>\r\n" + 
				"				<SYS_EVT_TRACE_ID>1010203051565678572000255</SYS_EVT_TRACE_ID>\r\n" + 
				"				<SYS_SND_SERIAL_NO>0000000023</SYS_SND_SERIAL_NO>\r\n" + 
				"				<SYS_PKG_TYPE>1</SYS_PKG_TYPE>\r\n" + 
				"				<SYS_MSG_LEN>100</SYS_MSG_LEN>\r\n" + 
				"				<SYS_IS_ENCRYPTED>0</SYS_IS_ENCRYPTED>\r\n" + 
				"				<SYS_ENCRYPT_TYPE>3</SYS_ENCRYPT_TYPE>\r\n" + 
				"				<SYS_COMPRESS_TYPE>0</SYS_COMPRESS_TYPE>\r\n" + 
				"				<SYS_EMB_MSG_LEN>0</SYS_EMB_MSG_LEN>\r\n" + 
				"				<SYS_REQ_TIME>201909251823112311</SYS_REQ_TIME>\r\n" + 
				"				<SYS_TIME_LEFT>1823112311</SYS_TIME_LEFT>\r\n" + 
				"				<SYS_PKG_STS_TYPE>00</SYS_PKG_STS_TYPE>\r\n" + 
				"			</TX_HEADER>\r\n" ; 
		
		return header;
	}
	
	
	/**
	 * 获取aiaudio的body部分
	 * @param entity
	 * @return
	 */
	public static String getBody(String entity) {
		
		String body = 
				"			<TX_BODY>\r\n" + 
				getCommon()+
				entity+
				"			</TX_BODY>\r\n" + 
				"			<txEMB>\r\n" + 
				"			</txEMB>\r\n" ;
						
		return body;
	}
	
	
	/**
	 * 获取aiaudio的Common域
	 * @return
	 */
	public static String getCommon() {
		
		SimpleDateFormat sdf1 = new SimpleDateFormat("YYYYMMDD");
		SimpleDateFormat sdf2 = new SimpleDateFormat("HHmmss");
		Date date = new Date();
		
		String common =
				"				<COMMON>\r\n" + 
				"						<TXN_INSID>440000000</TXN_INSID>\r\n" + 
				"						<TXN_ITT_CHNL_ID>0130</TXN_ITT_CHNL_ID>\r\n" + 
				"						<TXN_ITT_CHNL_CGY_CODE>0001</TXN_ITT_CHNL_CGY_CODE>\r\n" + 
				"						<TXN_DT>"+sdf1.format(date)+"</TXN_DT>\r\n" + 
				"						<TXN_TM>"+sdf2.format(date)+"</TXN_TM>\r\n" + 
				"						<TXN_STFF_ID>999999</TXN_STFF_ID>\r\n" + 
				"						<MULTI_TENANCY_ID>CN000</MULTI_TENANCY_ID>\r\n" + 
				"						<LNG_ID>zh-cn</LNG_ID>\r\n" + 
				"				</COMMON>\r\n";
		
		return common;
	}
	
	
	/**
	 * 获取aiaudio实体域
	 * @param inVo
	 * @param traceId
	 * @param outputType
	 * @return
	 */
	public static String getEntity(INREC5001ServiceInVo inVo, String traceId,String outputType) {
		
		String entity = 
				"				<ENTITY>\r\n" + 
				"					<Timestamp>"+inVo.getVd_1_Rqs_Tm()+"</Timestamp>\r\n" + 
				"					<TraceId>"+traceId+"</TraceId>\r\n" + 
				"					<Async>"+inVo.getVd_Synz_Ind()+"</Async>\r\n" + 
				"					<StartTime>"+inVo.getStrt_Rcd_Tms()+"</StartTime>\r\n" + 
				"					<EndTime>"+inVo.getEnd_Rcd_Tms()+"</EndTime>\r\n" + 
				"					<Location></Location>\r\n" + 
				"					<Video>"+inVo.getBase64_ECD_Txn_Inf()+"</Video>\r\n" + 
				"					<DeviceInfo></DeviceInfo>\r\n" + 
				"					<OutputType>"+outputType+"</OutputType>\r\n" + 
				"					<ColorCode></ColorCode>\r\n" + 
				"				</ENTITY>\r\n";
		
		return entity;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
