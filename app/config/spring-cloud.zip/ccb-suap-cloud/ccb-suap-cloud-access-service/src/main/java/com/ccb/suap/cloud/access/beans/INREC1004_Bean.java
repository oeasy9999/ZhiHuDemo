package com.ccb.suap.cloud.access.beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1004ServiceInVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1004ServiceOutVo;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.service.GPUMPService;
import com.ccb.suap.cloud.access.service.SuapCustDeviceInfoService;
import com.ccb.suap.cloud.access.service.SuapCustInfoService;
import com.ccb.suap.cloud.access.service.utils.CheckParaUtil;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC1004ServiceInVo;
import com.ccb.suap.cloud.access.vo.INREC1004ServiceOutVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

@Controller("INREC1004")
public class INREC1004_Bean extends INRECBean{

	private static final Logger LOGGER = LoggerFactory.getLogger(INREC1004_Bean.class);
	
	@Autowired
	private SuapCustInfoService suapCustInfoService;
	
	@Autowired
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	
	@Autowired
	private GPUMPService GPUMPService;
	
//	private SuapCustInfoService suapCustInfoService=InrecDaoFactory.getDaoManager().getSuapCustInfoService();
//	private SuapCustDeviceInfoService suapCustDeviceInfoService= InrecDaoFactory.getDaoManager().getSuapCustDeviceInfoService();
//	private GPUMPService GPUMPService=InrecDaoFactory.getDaoManager().getGPUMPService();
	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\r\n------------------调用INREC1004服务------------------");
		ServiceParaUtil.setFaceLogByBaseEntity(reqMsg, FaceLogThreadLocal.get());
		
		LOGGER.debug("check InVo: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		//封装GPUMP1004请求报文
		TxRequestMsg gpuRequestMsg = setGPUTxRequestMsg(reqMsg);
		LOGGER.debug("send GPUMP1004");
		long beforeSendGPU = System.currentTimeMillis();
		TxResponseMsg gpump1004Rsp = GPUMPService.sendGPUMP1004(gpuRequestMsg,traceLog);
		long sendGPU = System.currentTimeMillis()-beforeSendGPU;
		traceLog.setSendGpump1004Time(sendGPU);
		traceLog.setHttpcost(sendGPU);
		LOGGER.debug("return by GPUMP1004"+gpump1004Rsp);
		
		if(!(gpump1004Rsp.getTx_header().getSys_resp_code().equals("000000000000"))) 
			throw new CommonRuntimeException(gpump1004Rsp);
		
		GPUMP1004ServiceOutVo gpump1004OutVo = ServiceParaUtil.getGPURspMsgEntity(gpump1004Rsp, GPUMP1004ServiceOutVo.class);
		
		INREC1004ServiceOutVo INREC1004Entity = setInrec1004OutVo(rspMsg, gpump1004OutVo, reqMsg.getTx_body().getCom1().getSysChannelID());
		
		rspMsg.getTx_body().setEntity(INREC1004Entity);
		
		return rspMsg;
	}
	

	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		
		String rspCode = CheckParaUtil.checkParaByLocationIndex(reqMsg);
		if(rspCode != null)
			throw new CommonRuntimeException(rspCode);
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("sendGPU(").append(sendGPU)
//		.append(")/selectCustInfo(").append(selectCustInfo)
//		.append(")/selectCustDevInfo(").append(selectCustDevInfo)
//		.append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	
	/**
	 * 	把请求信息封装成前置对应的请求报文
	 * @param reqMsg
	 * @return
	 */
	private TxRequestMsg setGPUTxRequestMsg(TxRequestMsg reqMsg) {
		TxRequestMsg gpuRequestMsg = ServiceParaUtil.parseGpuRequestMsg(reqMsg);
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		INREC1004ServiceInVo entity = (INREC1004ServiceInVo) reqMsg.getTx_body().getEntity();
		
		GPUMP1004ServiceInVo gpump1004ServiceInVo = new GPUMP1004ServiceInVo();
		
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		if(locationIndex.equals("1")) {
			gpump1004ServiceInVo.setCust_id(entity.getId_no());
		}else if(locationIndex.equals("2")) {
			gpump1004ServiceInVo.setCust_id(entity.getChannel_custno());
		}
		
		gpuRequestMsg.getTx_body().setEntity(gpump1004ServiceInVo);
		gpuRequestMsg.getTx_header().setSys_tx_code("GPUMP1004");
		
		return gpuRequestMsg;
	}
	
	
	/**
	 * 	将GPU相应信息处理封装
	 * @param gpump1004OutVo
	 * @return
	 */
	private INREC1004ServiceOutVo setInrec1004OutVo(TxResponseMsg rspMsg, GPUMP1004ServiceOutVo gpump1004OutVo,String channel_id) {
		INREC1004ServiceOutVo inrec1004ServiceOutVo = new INREC1004ServiceOutVo();
		
		String id_type = gpump1004OutVo.getId_type();
		if(id_type == null)
			throw new CommonRuntimeException(Errorcode.IDTYPENOTFOUND);
		
		String id_no = gpump1004OutVo.getId_no();
		if(id_no == null)
			throw new CommonRuntimeException(Errorcode.IDNUMGNOTFOUND);

		String num = String.valueOf(StringUtils.getBiolInfoTableID(id_type+id_no));
		
		LOGGER.debug("getCustInfo: num: "+num+", id_type: "+id_type+", id_no: "+id_no);
		SuapCustInfoModel custInfo = suapCustInfoService.selectWithRedis(num, id_type, id_no);
		LOGGER.debug("custInfo: "+custInfo);
		
		if(custInfo == null)
			throw new CommonRuntimeException(Errorcode.CSTINFNOTFOUND, "01", "GPUMP 返回 idtype="+id_type+", id_no: "+id_no);
		
		
		LOGGER.debug("getCustDeviceInfo num: "+num+", id_type: "+id_type+", id_no: "+id_no+", channel_id: "+channel_id);
		SuapCustDeviceInfoModel custDeviceInfo = suapCustDeviceInfoService.selectWithRedis(num, id_type, id_no, channel_id);
		LOGGER.debug("custDeviceInfo: "+custDeviceInfo);
		
		if(custDeviceInfo == null || "1".equals(custDeviceInfo.getIsvalid()))
			throw new CommonRuntimeException(Errorcode.CSTDEVNOTFOUND, "01", "GPUMP 返回 idtype="+id_type+", id_no: "+id_no);
		
		
		inrec1004ServiceOutVo.setId_type(gpump1004OutVo.getId_type());
		inrec1004ServiceOutVo.setId_no(gpump1004OutVo.getId_no());
		inrec1004ServiceOutVo.setName(gpump1004OutVo.getName());
		inrec1004ServiceOutVo.setMobile_no(gpump1004OutVo.getMobile_no());
		inrec1004ServiceOutVo.setFace_collecttime(gpump1004OutVo.getFace_collecttime());
		inrec1004ServiceOutVo.setFace_image(gpump1004OutVo.getFace_image());
		
		inrec1004ServiceOutVo.setCcb_custno(custInfo.getCcbcustno());
		inrec1004ServiceOutVo.setBranch_id(custInfo.getBranchid());
		
		inrec1004ServiceOutVo.setChannel_custno(custDeviceInfo.getChannel_cstno());
		inrec1004ServiceOutVo.setTitle(custDeviceInfo.getTitile());
		inrec1004ServiceOutVo.setIs_vip(custDeviceInfo.getIsvip());
		inrec1004ServiceOutVo.setChannel_cardno(custDeviceInfo.getCardno());
		
		return inrec1004ServiceOutVo;
	}


	


	
	
	
	
	
	
}
