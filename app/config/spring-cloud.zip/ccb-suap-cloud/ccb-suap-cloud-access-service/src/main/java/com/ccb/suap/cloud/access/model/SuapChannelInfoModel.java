package com.ccb.suap.cloud.access.model;

import java.io.Serializable;
import java.util.Date;

public class SuapChannelInfoModel implements Serializable{
	
	private static final long serialVersionUID = -7254507596579325712L;
	
	private String channelid;			//渠道号
	private String channelname;			//渠道名称
	private String channeldesc;			//渠道描述
	private String creator;				//
	private Date createtime;			//
	private String remark;				//备注
	
	public String getChannelid() {
		return channelid;
	}
	public void setChannelid(String channelid) {
		this.channelid = channelid;
	}
	public String getChannelname() {
		return channelname;
	}
	public void setChannelname(String channelname) {
		this.channelname = channelname;
	}
	public String getChanneldesc() {
		return channeldesc;
	}
	public void setChanneldesc(String channeldesc) {
		this.channeldesc = channeldesc;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	@Override
	public String toString() {
		return "SuapChannelInfoModel [channelid=" + channelid + ", channelname=" + channelname + ", channeldesc="
				+ channeldesc + ", creator=" + creator + ", createtime=" + createtime + ", remark=" + remark + "]";
	}
	
	
	
	
	
	
	
	
	
}
