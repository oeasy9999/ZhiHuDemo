package com.ccb.suap.cloud.access.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import com.ccb.suap.cloud.access.model.SuapTxChannelAuthModel;

@Mapper
public interface SuapTxChannelAuthMapper {
	
	@Insert("insert into SUAP_TX_CHANNEL_AUTH(TXCODE,CHANNELID,CHANNELTXCODE,CREATETIME,CREATOR,REMARK) values(#{txcode},#{channelid},#{channeltxcode},#{createtime},#{creator},#{remark})")
	int insert(SuapTxChannelAuthModel suapTxChannelAuthModel);
	
	
	
	
	
}
