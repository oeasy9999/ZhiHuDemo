package com.ccb.suap.cloud.access.beans;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.model.SuapOutboundConfigModel;
import com.ccb.suap.cloud.access.service.OutBoundService;
import com.ccb.suap.cloud.access.service.RestTemplateService;
import com.ccb.suap.cloud.access.service.utils.XMLUtil;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapOutboundConfigUtil;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.cloud.access.threadLocal.CosttimeThreadLocal;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC5001AiaudioXMLReqestMsg;
import com.ccb.suap.cloud.access.vo.INREC5001ServiceInVo;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1005ServiceInVo;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1005ServiceOutVo;
import com.ccb.suap.util.log.TraceLog;

@Controller("INREC5001")
public class INREC5001_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC5001_Bean.class);
	
	@Autowired
	private RestTemplateService restTemplateService;
	
	@Autowired
	private OutBoundService outbound;
	
//	private RestTemplateService restTemplateService = InrecDaoFactory.getDaoManager().getRestTemplateService();
//	private OutBoundService outbound = InrecDaoFactory.getDaoManager().getOutBoundService();
	

	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n\n------------------调用INREC5001服务------------------");
		
		setFaceLogByReqEntity(reqMsg);
		
		INREC5001ServiceInVo entity = (INREC5001ServiceInVo) reqMsg.getTx_body().getEntity();
		SuapOutboundConfigModel outboundConfig = SuapOutboundConfigUtil.getOutboundConfigByReqMsg(reqMsg);
		LOGGER.debug("outboundConfig: "+outboundConfig);
		if(outboundConfig == null) {
			TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
			LOGGER.error("can not found the outboundConfig: key = "+com1.getSysChannelID()+":"+com1.getChannelTxCode());
			throw new CommonRuntimeException(Errorcode.OUTBONDNOTNULL, "1", "key = "+com1.getSysChannelID()+":"+com1.getChannelTxCode());
		}
		
		LOGGER.debug("check requestEntity");
		checkParaByServerName(rspMsg, reqMsg);
		
		String aiaudioReqEntity = INREC5001AiaudioXMLReqestMsg.getEntity(entity, reqMsg.getTx_header().getSys_evt_trace_id(), outboundConfig.getOutputtype());
		String aiaudioReqMsg = INREC5001AiaudioXMLReqestMsg.getAiaudioRequestMsg(aiaudioReqEntity);
		LOGGER.debug("send aiaudio: ");
		String url = SuapSysParaUtil.getStrPara("AIAUDIOURL", null);
		long beforeSendAiaudio = System.currentTimeMillis();
		String aiaudioRsp = restTemplateService.postForEntity(url, aiaudioReqMsg, String.class);
		CosttimeThreadLocal.put("sendAiaudio", System.currentTimeMillis()-beforeSendAiaudio);
		
		checkMessageReturnByAiaudio(aiaudioRsp);
		
		TxRequestMsg ccvea1005ReqMsg = getCCVEA1005ReqMsg(reqMsg, aiaudioRsp);
		traceLog.setUrl("CCVEA1005");
		
		LOGGER.debug("send ccvea1005: ");
		long beforeSendCCVEA1005 = System.currentTimeMillis();
		TxResponseMsg ccvea1005RspMsg = outbound.sendCCVEA1005(ccvea1005ReqMsg,traceLog);
		long sendCCVEA1005 = System.currentTimeMillis()-beforeSendCCVEA1005;
		CosttimeThreadLocal.put("sendCCVEA1005", sendCCVEA1005);
		traceLog.setSendCCVEA1005Time(sendCCVEA1005);
		traceLog.setHttpcost(traceLog.getHttpcost()+traceLog.getSendCCVEA1005Time());
		
		TxResponseMsgHead ccvea1005RspHeader = ccvea1005RspMsg.getTx_header();
		LOGGER.debug("resp_code in ccvea1005ResponseMsg: {resp_code: "+ccvea1005RspHeader.getSys_resp_code()+", resp_desc: "+ccvea1005RspHeader.getSys_resp_desc()+"}");
		if(!"000000000000".equals(ccvea1005RspHeader.getSys_resp_code())) {
			LOGGER.error("fail in ccvea1005ResponseMsg: {resp_code: "+ccvea1005RspHeader.getSys_resp_code()+", resp_desc: "+ccvea1005RspHeader.getSys_resp_desc()+"}");
			throw new CommonRuntimeException(ccvea1005RspMsg);
		}
		
		CCVEA1005ServiceOutVo ccvea1005RspEntity = ServiceParaUtil.getCCVEARspEntity(ccvea1005RspMsg, CCVEA1005ServiceOutVo.class);
		rspMsg.getTx_body().setEntity(ccvea1005RspEntity);
		
		return rspMsg;
	}


	private void setFaceLogByReqEntity(TxRequestMsg reqMsg) {
		INREC5001ServiceInVo entity = (INREC5001ServiceInVo) reqMsg.getTx_body().getEntity();
		SuapFaceLogModel faceLog = FaceLogThreadLocal.get();
		faceLog.setBranchid(entity.getBr_ID());
		faceLog.setIdtype(entity.getCrdTp_Cd());
		faceLog.setIdno(entity.getCrdt_No());
		faceLog.setName(entity.getCst_Nm());
		faceLog.setMobile(entity.getRmrk_1_Rcrd_Cntnt());
		faceLog.setCustid(entity.getCst_ID());
		
	}


	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		INREC5001ServiceInVo entity = (INREC5001ServiceInVo) reqMsg.getTx_body().getEntity();
		String cst_Nm = entity.getCst_Nm();
		String crdTp_Cd = entity.getCrdTp_Cd();
		String crdt_No = entity.getCrdt_No();
		String base64_ECD_Txn_Inf = entity.getBase64_ECD_Txn_Inf();
		String vd_1_Rqs_Tm = entity.getVd_1_Rqs_Tm();
		String vd_Synz_Ind = entity.getVd_Synz_Ind();
		String strt_Rcd_Tms = entity.getStrt_Rcd_Tms();
		String end_Rcd_Tms = entity.getEnd_Rcd_Tms();
		String ctfn_Ahn_Stm_ID = entity.getCtfn_Ahn_Stm_ID();
		String ext_Stm_Only1_Ind = entity.getExt_Stm_Only1_Ind();
		String br_ID = entity.getBr_ID();
		String bde_Node_No = entity.getBDE_Node_No();
		
		if(StringUtils.isEmpty(cst_Nm)) {
			LOGGER.error("cst_Nm is null");
			throw new CommonRuntimeException(Errorcode.CSTNAMENOTNULL);
		}
		if(StringUtils.isEmpty(crdTp_Cd)) {
			LOGGER.error("crdTp_Cd is null");
			throw new CommonRuntimeException(Errorcode.ID_TYPENOTNULL);
		}
		if(StringUtils.isEmpty(crdt_No)) {
			LOGGER.error("crdt_No is null");
			throw new CommonRuntimeException(Errorcode.ID_NUMBNOTNULL);
		}
		if(StringUtils.isEmpty(base64_ECD_Txn_Inf)) {
			LOGGER.error("base64_ECD_Txn_Inf is null");
			throw new CommonRuntimeException(Errorcode.FAC_VEDNOTNULL);
		}
		if(StringUtils.isEmpty(vd_1_Rqs_Tm)) {
			LOGGER.error("vd_1_Rqs_Tm is null");
			throw new CommonRuntimeException(Errorcode.REQ_TIMNOTNULL);
		}
		if(StringUtils.isEmpty(vd_Synz_Ind)) {
			LOGGER.error("vd_Synz_Ind is null");
			throw new CommonRuntimeException(Errorcode.SYNMARKNOTNULL);
		}
		if(StringUtils.isEmpty(strt_Rcd_Tms)) {
			LOGGER.error("strt_Rcd_Tms is null");
			throw new CommonRuntimeException(Errorcode.STR_TIMNOTNULL);
		}
		if(StringUtils.isEmpty(end_Rcd_Tms)) {
			LOGGER.error("end_Rcd_Tms is null");
			throw new CommonRuntimeException(Errorcode.END_TIMNOTNULL);
		}
		if(StringUtils.isEmpty(ctfn_Ahn_Stm_ID)) {
			LOGGER.error("ctfn_Ahn_Stm_ID is null");
			throw new CommonRuntimeException(Errorcode.CTFN_IDNOTNULL);
		}
		if(StringUtils.isEmpty(ext_Stm_Only1_Ind)) {
			LOGGER.error("ext_Stm_Only1_Ind is null");
			throw new CommonRuntimeException(Errorcode.ONLYINDNOTNULL);
		}
		if(StringUtils.isEmpty(br_ID)) {
			LOGGER.error("br_ID is null");
			throw new CommonRuntimeException(Errorcode.BRACHIDNOTNULL);
		}
		if(StringUtils.isEmpty(bde_Node_No)) {
			LOGGER.error("bde_Node_No is null");
			throw new CommonRuntimeException(Errorcode.NODE_NONOTNULL);
		}
		
		
	}
	
	// TODO
//	@Override
//	public void setTime(long[] timeArr) {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("sendAiaudio(").append(timeArr[0])
//		.append(")/sendCCVEA1005(").append(timeArr[1])
//		.append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	
	/**
	 * 检测aiaudio接口是否成功返回，否则报错
	 * @param aiaudioRsp
	 */
	private void checkMessageReturnByAiaudio(String aiaudioRsp) {
		if(StringUtils.isEmpty(aiaudioRsp)) {
			LOGGER.error("return by aidudio error: no message found!");
			throw new CommonRuntimeException(Errorcode.AIAUDRETISNULL);
		}
		
		String rspCodeByAiaudio = XMLUtil.getString(aiaudioRsp, "Code");
		if(!"1".equals(rspCodeByAiaudio)) {
			String rspMessageAidudio= XMLUtil.getString(aiaudioRsp, "Message");
			LOGGER.error("fail while send Aiaudio: {code: "+rspCodeByAiaudio+", message: "+rspMessageAidudio+"}");
			
			TxResponseMsg aiaudioRspMsg = new TxResponseMsg();
			TxResponseMsgHead aiaudioRspHerder = new TxResponseMsgHead();
			aiaudioRspMsg.setTx_header(aiaudioRspHerder);
			aiaudioRspHerder.setSys_resp_code(Errorcode.AIAUDBYRETFAIL);
			aiaudioRspHerder.setSys_resp_desc(rspMessageAidudio);
			
			throw new CommonRuntimeException(aiaudioRspMsg, "反光/压缩失败");
		}
		LOGGER.debug("the code return by aiaudio: "+rspCodeByAiaudio);
	}
	
	
	/**
	 * 封装CCVEA1005请求信息
	 * @param reqMsg
	 * @param aiaudioRsp
	 * @return
	 */
	private TxRequestMsg getCCVEA1005ReqMsg(TxRequestMsg reqMsg, String aiaudioRsp) {
		TxRequestMsg ccvea1005ReqMsg = ServiceParaUtil.newReqMsg(reqMsg);
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		INREC5001ServiceInVo entity = (INREC5001ServiceInVo) reqMsg.getTx_body().getEntity();
		
		CCVEA1005ServiceInVo ccvea1005ReqEntity = new CCVEA1005ServiceInVo();
		ccvea1005ReqMsg.getTx_body().setEntity(ccvea1005ReqEntity);
		
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMDDHH");
		ccvea1005ReqEntity.setSYSTEM_TIME(sdf.format(new Date()));
		
		ccvea1005ReqEntity.setStm_Chnl_ID(com1.getSysChannelID());
		ccvea1005ReqEntity.setStm_Chnl_Txn_CD(com1.getChannelTxCode());
		ccvea1005ReqEntity.setCst_ID(entity.getCst_ID());
		ccvea1005ReqEntity.setExt_Stm_Ctfn_Ecrp_Inf(entity.getExt_Stm_Ctfn_Ecrp_Inf());
		ccvea1005ReqEntity.setCst_Nm(entity.getCst_Nm());
		ccvea1005ReqEntity.setCrdTp_Cd(entity.getCrdTp_Cd());
		ccvea1005ReqEntity.setCrdt_No(entity.getCrdt_No());
		ccvea1005ReqEntity.setRmrk_1_Rcrd_Cntnt(entity.getRmrk_1_Rcrd_Cntnt());
		ccvea1005ReqEntity.setBase64_ECD_Txn_Inf(XMLUtil.getString(aiaudioRsp, "Video"));
		ccvea1005ReqEntity.setBase64_Ecrp_Txn_Inf(entity.getBase64_Ecrp_Txn_Inf());
		ccvea1005ReqEntity.setEqmt_Inf_Cntnt(entity.getEqmt_Inf_Cntnt());
		ccvea1005ReqEntity.setVd_1_Rqs_Tm(entity.getVd_1_Rqs_Tm());
		ccvea1005ReqEntity.setVd_Rqs_ID(entity.getVd_Rqs_ID());
		ccvea1005ReqEntity.setVd_Synz_Ind(entity.getVd_Synz_Ind());
		ccvea1005ReqEntity.setStrt_Rcd_Tms(entity.getStrt_Rcd_Tms());
		ccvea1005ReqEntity.setEnd_Rcd_Tms(entity.getEnd_Rcd_Tms());
		ccvea1005ReqEntity.setRsrv_1_Inf_Dsc(entity.getRsrv_1_Inf_Dsc());
		ccvea1005ReqEntity.setRsrv_2_Inf_Dsc(entity.getRsrv_2_Inf_Dsc());
		ccvea1005ReqEntity.setRsrv_3_Inf_Dsc(entity.getRsrv_3_Inf_Dsc());
		ccvea1005ReqEntity.setRsrv_4_Inf_Dsc(entity.getRsrv_4_Inf_Dsc());
		ccvea1005ReqEntity.setRsrv_5_Inf_Dsc(entity.getRsrv_5_Inf_Dsc());
		ccvea1005ReqEntity.setCtfn_Ahn_Stm_ID(entity.getCtfn_Ahn_Stm_ID());
		ccvea1005ReqEntity.setBLNG_INST_NM(entity.getBLNG_INST_NM());
		ccvea1005ReqEntity.setMt_Apl_PD_ECD(entity.getMt_Apl_PD_ECD());
		ccvea1005ReqEntity.setTlr_Nm(entity.getTlr_Nm());
		ccvea1005ReqEntity.setExt_Stm_NM(entity.getExt_Stm_NM());
		ccvea1005ReqEntity.setBr_ID(entity.getBr_ID());
		ccvea1005ReqEntity.setBr_Nm(entity.getBr_Nm());
		ccvea1005ReqEntity.setBDE_Node_No(entity.getBDE_Node_No());
		
		ccvea1005ReqMsg.getTx_header().setSys_tx_code("CCVEA1005");
		
		return ccvea1005ReqMsg;
	}
	
	


	

	
}
