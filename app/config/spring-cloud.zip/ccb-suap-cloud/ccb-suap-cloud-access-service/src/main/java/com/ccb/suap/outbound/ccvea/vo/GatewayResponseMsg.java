package com.ccb.suap.outbound.ccvea.vo;
public class GatewayResponseMsg {

	private String return_code;
	private String return_message;
	private String sys_evt_trace_id;
	private String gateway_cost;
	private String response_info;
	
	public String getReturn_code() {
		return return_code;
	}
	public void setReturn_code(String return_code) {
		this.return_code = return_code;
	}
	public String getReturn_message() {
		return return_message;
	}
	public void setReturn_message(String return_message) {
		this.return_message = return_message;
	}
	public String getSys_evt_trace_id() {
		return sys_evt_trace_id;
	}
	public void setSys_evt_trace_id(String sys_evt_trace_id) {
		this.sys_evt_trace_id = sys_evt_trace_id;
	}
	public String getGateway_cost() {
		return gateway_cost;
	}
	public void setGateway_cost(String gateway_cost) {
		this.gateway_cost = gateway_cost;
	}
	public String getResponse_info() {
		return response_info;
	}
	public void setResponse_info(String response_info) {
		this.response_info = response_info;
	}
	@Override
	public String toString() {
		int response_info_length=0;
		if(response_info!=null)
		{
			response_info_length=response_info.length();
		}
		return "GetwayRequestMsg [return_code=" + return_code + ", return_message=" + return_message
				+ ", sys_evt_trace_id=" + sys_evt_trace_id + ", gateway_cost=" + gateway_cost + ", response_info_length="
				+ response_info_length + "]";
	}
	
	
}
