package com.ccb.suap.cloud.ecuac.datatransform.message;

import java.io.Serializable;

public abstract interface ECUACRequestMsgBodyEntity extends Serializable {
	
	
	
}