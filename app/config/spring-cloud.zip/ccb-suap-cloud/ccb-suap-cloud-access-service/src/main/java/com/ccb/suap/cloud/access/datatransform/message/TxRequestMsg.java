package com.ccb.suap.cloud.access.datatransform.message;

public class TxRequestMsg {
	
	private TxRequestMsgHead tx_header;
	private TxRequestMsgBody tx_body;
	
	public TxRequestMsgHead getTx_header() {
		return tx_header;
	}
	public void setTx_header(TxRequestMsgHead tx_header) {
		this.tx_header = tx_header;
	}
	public TxRequestMsgBody getTx_body() {
		return tx_body;
	}
	public void setTx_body(TxRequestMsgBody tx_body) {
		this.tx_body = tx_body;
	}
	
	@Override
	public String toString() {
		return "TxRequestMsg [tx_header=" + tx_header + ", tx_body=" + tx_body + "]";
	}
	
	
	
	
	
}
