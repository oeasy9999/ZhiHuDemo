package com.ccb.suap.cloud.access.vo;

public class INREC3001ServiceInVo extends INRECBaseServiceInVo{
	
	
	
	
	
	
	
	
	
	
}
