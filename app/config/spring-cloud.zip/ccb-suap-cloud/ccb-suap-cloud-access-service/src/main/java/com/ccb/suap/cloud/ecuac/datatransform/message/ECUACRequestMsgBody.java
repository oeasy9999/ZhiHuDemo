package com.ccb.suap.cloud.ecuac.datatransform.message;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class ECUACRequestMsgBody implements Serializable {
	
	private static final long serialVersionUID = 1096884886L;
	
	@XStreamAlias("COMMON")
	private ECUACRequestMsgBodyCommon common;
	@XStreamAlias("ENTITY")
	private ECUACRequestMsgBodyEntity entity;
	
	public ECUACRequestMsgBodyCommon getCommon() {
		return common;
	}
	public void setCommon(ECUACRequestMsgBodyCommon common) {
		this.common = common;
	}
	public ECUACRequestMsgBodyEntity getEntity() {
		return entity;
	}
	public void setEntity(ECUACRequestMsgBodyEntity entity) {
		this.entity = entity;
	}
	
	@Override
	public String toString() {
		return "TxRequestMsgBody [common=" + common + ", entity=" + entity + "]";
	}
	
	
	
	
	
	
	
	
	
	
}