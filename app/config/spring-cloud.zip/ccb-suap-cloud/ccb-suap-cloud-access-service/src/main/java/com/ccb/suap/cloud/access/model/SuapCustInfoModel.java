package com.ccb.suap.cloud.access.model;

import java.io.Serializable;
import java.util.Date;

public class SuapCustInfoModel implements Serializable{

	private static final long serialVersionUID = -6319603496030232046L;
	
	private String num;					//分库分表
	private String ccbcustno;			//建行P6客户号
	private String custname;			//客户名称
	private String idtype;				//证件类型
	private String idnumber;			//证件号码
	private String branchid;			//分行号
	private String cellphome;			//手机号码
	private Date createtime;			//创建时间
	private String sex;					//性别
	private Date birthday;				//出生日期
	private String address;				//居住地址
	private String company;				//工作单位
	private String industry;			//行业
	private String career;				//职业
	private String school;				//学校
	private String education;			//学历
	private String income;				//收入
	private String habit;				//爱好
	private String idphoto_path;		//证件照路径
	private String idphoto_level;		//证件照等级
	private Date idphoto_date;			//证件照采集/更新时间
	private String idphoto_channel;		//证件照采集/更新渠道
	private String scenephoto_path;		//现场照路径
	private String scenephoto_level;	//现场照等级
	private Date scenephoto_date;		//现场照采集/更新时间
	private String scenephoto_channel;	//现场照采集/更新渠道
	private String updatechannel;		//创建更新的渠道来源
	private String idverify;			//是否人脸核查
	private Date updatetime;			//创建更新时间
	
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getCcbcustno() {
		return ccbcustno;
	}
	public void setCcbcustno(String ccbcustno) {
		this.ccbcustno = ccbcustno;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getIdtype() {
		return idtype;
	}
	public void setIdtype(String idtype) {
		this.idtype = idtype;
	}
	public String getIdnumber() {
		return idnumber;
	}
	public void setIdnumber(String idnumber) {
		this.idnumber = idnumber;
	}
	public String getBranchid() {
		return branchid;
	}
	public void setBranchid(String branchid) {
		this.branchid = branchid;
	}
	public String getCellphome() {
		return cellphome;
	}
	public void setCellphome(String cellphome) {
		this.cellphome = cellphome;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getCareer() {
		return career;
	}
	public void setCareer(String career) {
		this.career = career;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getIncome() {
		return income;
	}
	public void setIncome(String income) {
		this.income = income;
	}
	public String getHabit() {
		return habit;
	}
	public void setHabit(String habit) {
		this.habit = habit;
	}
	public String getIdphoto_path() {
		return idphoto_path;
	}
	public void setIdphoto_path(String idphoto_path) {
		this.idphoto_path = idphoto_path;
	}
	public String getIdphoto_level() {
		return idphoto_level;
	}
	public void setIdphoto_level(String idphoto_level) {
		this.idphoto_level = idphoto_level;
	}
	public Date getIdphoto_date() {
		return idphoto_date;
	}
	public void setIdphoto_date(Date idphoto_date) {
		this.idphoto_date = idphoto_date;
	}
	public String getIdphoto_channel() {
		return idphoto_channel;
	}
	public void setIdphoto_channel(String idphoto_channel) {
		this.idphoto_channel = idphoto_channel;
	}
	public String getScenephoto_path() {
		return scenephoto_path;
	}
	public void setScenephoto_path(String scenephoto_path) {
		this.scenephoto_path = scenephoto_path;
	}
	public String getScenephoto_level() {
		return scenephoto_level;
	}
	public void setScenephoto_level(String scenephoto_level) {
		this.scenephoto_level = scenephoto_level;
	}
	public Date getScenephoto_date() {
		return scenephoto_date;
	}
	public void setScenephoto_date(Date scenephoto_date) {
		this.scenephoto_date = scenephoto_date;
	}
	public String getScenephoto_channel() {
		return scenephoto_channel;
	}
	public void setScenephoto_channel(String scenephoto_channel) {
		this.scenephoto_channel = scenephoto_channel;
	}
	public String getUpdatechannel() {
		return updatechannel;
	}
	public void setUpdatechannel(String updatechannel) {
		this.updatechannel = updatechannel;
	}
	public String getIdverify() {
		return idverify;
	}
	public void setIdverify(String idverify) {
		this.idverify = idverify;
	}
	public Date getUpdatetime() {
		return updatetime;
	}
	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
	
	@Override
	public String toString() {
		return "SuapCustInfoModel [num=" + num + ", ccbcustno=" + ccbcustno + ", custname=" + custname + ", idtype="
				+ idtype + ", idnumber=" + idnumber + ", branchid=" + branchid + ", cellphome=" + cellphome
				+ ", createtime=" + createtime + ", sex=" + sex + ", birthday=" + birthday + ", address=" + address
				+ ", company=" + company + ", industry=" + industry + ", career=" + career + ", school=" + school
				+ ", education=" + education + ", income=" + income + ", habit=" + habit + ", idphoto_path="
				+ idphoto_path + ", idphoto_level=" + idphoto_level + ", idphoto_date=" + idphoto_date
				+ ", idphoto_channel=" + idphoto_channel + ", scenephoto_path=" + scenephoto_path
				+ ", scenephoto_level=" + scenephoto_level + ", scenephoto_date=" + scenephoto_date
				+ ", scenephoto_channel=" + scenephoto_channel + ", updatechannel=" + updatechannel + ", idverify="
				+ idverify + ", updatetime=" + updatetime + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
