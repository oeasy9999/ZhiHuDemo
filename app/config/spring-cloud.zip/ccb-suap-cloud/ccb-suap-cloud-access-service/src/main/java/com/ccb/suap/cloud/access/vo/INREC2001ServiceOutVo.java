package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class INREC2001ServiceOutVo extends TxResponseMsgEntity {
	
	
}
