package com.ccb.suap.cloud.access.beans;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEquipmentInfo;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1001ServiceInVo;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.service.GPUMPService;
import com.ccb.suap.cloud.access.service.INRECBeansService;
import com.ccb.suap.cloud.access.service.SuapCustDeviceInfoService;
import com.ccb.suap.cloud.access.service.SuapCustInfoService;
import com.ccb.suap.cloud.access.service.utils.PhotoUtil;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC1003ServiceInVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

@Controller("INREC1003")
public class INREC1003_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC1003_Bean.class);
	
	@Autowired
	private SuapCustInfoService suapCustInfoService;
	
	@Autowired
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	
	@Autowired
	private GPUMPService GPUMPService;
	
	@Autowired
	private INRECBeansService inrecBeansService;
	
//	private SuapCustInfoService suapCustInfoService=InrecDaoFactory.getDaoManager().getSuapCustInfoService();
//	private SuapCustDeviceInfoService suapCustDeviceInfoService= InrecDaoFactory.getDaoManager().getSuapCustDeviceInfoService();
//	private GPUMPService GPUMPService=InrecDaoFactory.getDaoManager().getGPUMPService();

	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n\n------------------调用INREC1003服务------------------");
		ServiceParaUtil.setFaceLogByBaseEntity(reqMsg, FaceLogThreadLocal.get());
		
		LOGGER.debug("check requestEntity: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		INREC1003ServiceInVo entity = (INREC1003ServiceInVo) reqMsg.getTx_body().getEntity();
		String idtype = entity.getId_type();
		String idno = entity.getId_no();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(idtype+idno));
		
		LOGGER.debug("find cust info: num = " + num + ", idtype = " + idtype + ", idno = " + idno);
//		SuapCustInfoModel suapCustInfoModel = getCustInfo(num, idtype, idno);
		SuapCustInfoModel suapCustInfoModel = suapCustInfoService.selectWithRedis(num, idtype, idno);
		
		if(suapCustInfoModel == null)
			throw new CommonRuntimeException(Errorcode.CUSTINFOISNULL);
		
		//封装渠道注册信息，查询渠道注册信息中是否已存在记录
		SuapCustDeviceInfoModel custDeviceInfo_reqMsg = getCustDeviceInfo(reqMsg);
		LOGGER.debug("suapCustDeviceInfoModel in requsetMessage: "+custDeviceInfo_reqMsg);
		SuapCustDeviceInfoModel custDeviceInfo_database = suapCustDeviceInfoService.selectWithRedis(num, idtype, idno, com1.getSysChannelID());
		LOGGER.debug("suapCustDeviceInfoModel in database: " + custDeviceInfo_database);
		ServiceParaUtil.fillCustDeviceInfo(custDeviceInfo_database, custDeviceInfo_reqMsg);
		
		//获取渠道注册信息图片保存路径
		String path = PhotoUtil.getPath(ServiceParaUtil.getBasePthBySyspara("FACEPICPATH", reqMsg.getTx_body().getCom1().getSysChannelID(), "faceModelImage"), suapCustInfoModel.getIdtype()+"_"+suapCustInfoModel.getIdnumber()+"_B" + ".jpg");
		custDeviceInfo_reqMsg.setPhoto_path(path);
		LOGGER.debug("phtot path in suapCustDeviceInfoModel: " + path);
		
		//获取注册图片
		String scenephoto_path = suapCustInfoModel.getScenephoto_path();
		String image_custInfo = PhotoUtil.loadPhotoWithTime(scenephoto_path);
		
		// 新增/更新渠道注册信息
		if(custDeviceInfo_database == null) {
			LOGGER.debug("insert custDeviceInfo");
			inrecBeansService.handlerCustDeviceInfoAndSavePhoto(custDeviceInfo_reqMsg, image_custInfo, "INSERT");
		}else {
			LOGGER.debug("update custDeviceInfo");
			inrecBeansService.handlerCustDeviceInfoAndSavePhoto(custDeviceInfo_reqMsg, image_custInfo, "UPDATE");
		}
		
		TxRequestMsg gpump1001ReqMsg = getGPUMP1001ReqMsg(rspMsg, reqMsg, suapCustInfoModel,custDeviceInfo_reqMsg.getChannel_cstno());
		LOGGER.debug("send GPUMP1001: " + gpump1001ReqMsg);
		TxResponseMsg gpump1001Rsp = GPUMPService.sendGPUMP1001(gpump1001ReqMsg);
		LOGGER.debug("return by GPUMP1001: " + gpump1001Rsp);
		
		if(!"000000000000".equals(gpump1001Rsp.getTx_header().getSys_resp_code()))
			throw new CommonRuntimeException(gpump1001Rsp);
		
//		saveRedis(suapCustDeviceInfoModel);
		
		return rspMsg;
	}

	
//	private void saveRedis(SuapCustDeviceInfoModel suapCustDeviceInfoModel) {
//		String idtype = suapCustDeviceInfoModel.getIdtype();
//		String idnumber = suapCustDeviceInfoModel.getIdnumber();
//		String channelid = suapCustDeviceInfoModel.getChannelid();
//		
//		redisService.set(idtype + "_" + idnumber + "_" + channelid, JSONObject.toJSONString(suapCustDeviceInfoModel));
//		
//	}


//	private SuapCustInfoModel getCustInfo(String num, String idtype, String idno) {
//		
//		String json = redisService.get(idtype + "_" + idno);
//		if(org.apache.commons.lang.StringUtils.isNotBlank(json))
//			return JSONObject.toJavaObject(JSONObject.parseObject(json), SuapCustInfoModel.class);
//		
//		return suapCustInfoService.select(num, idtype, idno);
//	}


//	private SuapCustDeviceInfoModel getCustDeviceInfo(String num, String idtype, String idno, String sysChannelID) {
//		
//		String json = redisService.get(idtype + "_" + idno + "_" + sysChannelID);
//		if(org.apache.commons.lang.StringUtils.isNotBlank(json))
//			return JSONObject.toJavaObject(JSONObject.parseObject(json), SuapCustDeviceInfoModel.class);
//		
//		return suapCustDeviceInfoService.select(num, idtype, idno, sysChannelID);
//	}

	
	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		INREC1003ServiceInVo entity = (INREC1003ServiceInVo) reqMsg.getTx_body().getEntity();
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		
		String id_type = entity.getId_type();
		String id_no = entity.getId_no();
		String channel_custno = entity.getChannel_custno();
		String name = entity.getName();
		
		if(id_type == null || "".equals(id_type.trim()))
			throw new CommonRuntimeException(Errorcode.ID_TYPENOTNULL);
		if(id_no == null || "".equals(id_no.trim()))
			throw new CommonRuntimeException(Errorcode.ID_NUMBNOTNULL);
		if(locationIndex.equals("2") && (channel_custno == null || "".equals(channel_custno)))
			throw new CommonRuntimeException(Errorcode.CHANLCSTNONULL);
		if(name == null || "".equals(name))
			throw new CommonRuntimeException(Errorcode.CSTNAMENOTNULL);
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("insertCustDevInfo(").append(insertCustDevInfo).append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	

	/**
	 *	 封装客户渠道信息
	 * @param entity
	 * @return
	 */
	private SuapCustDeviceInfoModel getCustDeviceInfo(TxRequestMsg reqMsg) {
		SuapCustDeviceInfoModel suapCustDeviceInfoModel = new SuapCustDeviceInfoModel();
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		TxRequestMsgEquipmentInfo equipment_info = reqMsg.getTx_body().getEquipment_info();
		INREC1003ServiceInVo entity = (INREC1003ServiceInVo) reqMsg.getTx_body().getEntity();
		
		String id_no = entity.getId_no();
		String id_type = entity.getId_type();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(id_type+id_no));
		
		suapCustDeviceInfoModel.setNum(num);
		suapCustDeviceInfoModel.setIdtype(entity.getId_type());
		suapCustDeviceInfoModel.setIdnumber(entity.getId_no());
		suapCustDeviceInfoModel.setChannelid(com1.getSysChannelID());
		suapCustDeviceInfoModel.setCustname(entity.getName());
		suapCustDeviceInfoModel.setCellphome(entity.getMobile_no());
		suapCustDeviceInfoModel.setChannel_cstno(entity.getChannel_custno());
		suapCustDeviceInfoModel.setTitile(entity.getTitle());
		suapCustDeviceInfoModel.setIsvip(entity.getIs_vip());
		suapCustDeviceInfoModel.setCardno(entity.getChannel_cardno());
		suapCustDeviceInfoModel.setUpdatetime(new Date());
		if(equipment_info != null)
			suapCustDeviceInfoModel.setDevicecode(equipment_info.getEquipmentId());
		
		return suapCustDeviceInfoModel;
	}

	
	/**
	 * GPUMP1001请求信息封装
	 * @param suapCustInfoModel
	 * @return
	 */
	private TxRequestMsg getGPUMP1001ReqMsg(TxResponseMsg rspMsg, TxRequestMsg reqMsg, SuapCustInfoModel suapCustInfoModel,String channel_custno) {
		TxRequestMsg gpump1001ReqMsg = ServiceParaUtil.parseGpuRequestMsg(reqMsg);
		
		SuapFaceConfigModel faceConfig = SuapFaceConfigUtil.getFaceConfig(reqMsg);
		String locationindex = faceConfig.getLocationindex();
		
		//获取人脸照
		String path = suapCustInfoModel.getScenephoto_path();
		if("".equals(path) || path == null)
			throw new CommonRuntimeException(Errorcode.PHOTOPATHERROR);
		String photo = PhotoUtil.loadPhoto(path);
		if(photo == null)
			throw new CommonRuntimeException(Errorcode.PHOTOLOADERROR);
		
		GPUMP1001ServiceInVo gpump1001ReqEntity = new GPUMP1001ServiceInVo();
		gpump1001ReqEntity.setFace_image(photo);
		gpump1001ReqEntity.setId_type(suapCustInfoModel.getIdtype());
		gpump1001ReqEntity.setId_no(suapCustInfoModel.getIdnumber());
		gpump1001ReqEntity.setName(suapCustInfoModel.getCustname());
		gpump1001ReqEntity.setMobile_no(suapCustInfoModel.getCellphome());
		gpump1001ReqEntity.setThreshold(faceConfig.getSimilarity());
		//设置渠道客户号
		if("1".equals(locationindex))
			gpump1001ReqEntity.setCust_id(suapCustInfoModel.getIdnumber());
		if("2".equals(locationindex))
			gpump1001ReqEntity.setCust_id(channel_custno);
		
		gpump1001ReqMsg.getTx_header().setSys_tx_code("GPUMP1001");
		gpump1001ReqMsg.getTx_body().setEntity(gpump1001ReqEntity);
		return gpump1001ReqMsg;
	}

	
	
	
	
	
}
