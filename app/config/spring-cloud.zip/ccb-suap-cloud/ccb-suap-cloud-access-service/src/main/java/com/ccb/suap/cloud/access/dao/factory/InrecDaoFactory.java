package com.ccb.suap.cloud.access.dao.factory;

import com.ccb.suap.cloud.access.context.ApplicationContext;

public class InrecDaoFactory {

	//静态工厂
//	public static final IFactoryDao getStaticFactoryDaoImpl() {
//		return new StaticFactoryDaoImpl();
//	}
	
	public static DaoManagerService getDaoManager() {
		return (DaoManagerService) ApplicationContext.getAppContext().get("daoManager");
		
	}
}
