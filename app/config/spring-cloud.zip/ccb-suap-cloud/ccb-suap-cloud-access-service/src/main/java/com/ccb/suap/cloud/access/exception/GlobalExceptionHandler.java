package com.ccb.suap.cloud.access.exception;

/**
 * 全局异常处理类
 */
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.access.mapper.TraceLogger;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.service.SuapFaceLogService;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapErrorInfoUtil;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.util.log.TraceLog;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Autowired
	private TraceLogger traceLogger;
	
	@Autowired
	private SuapFaceLogService faceLogService;
	
	
	@ExceptionHandler(CommonRuntimeException.class)
	@ResponseBody
	public TxResponseMsg doExceptionHandler(CommonRuntimeException e) {
		LOGGER.error("CommonRuntimeException: "+e);
		TxResponseMsg rspMsg = e.getRspMsg();
		String rspCode = e.getRspCode();
		String rspDesc = e.getRspDesc();
		String status = e.getStatus();
		SuapFaceLogModel faceLog = e.getFaceLog();
		TraceLog traceLog = e.getTraceLog();
		
		TxResponseMsgHead rspHeader = rspMsg.getTx_header();
		
		if(StringUtils.isBlank(status))
			status = "02";
		if(StringUtils.isBlank(rspHeader.getSys_tx_status()))
			rspHeader.setSys_tx_status(status);
		
		String errorCode = getErrorCode(rspCode,rspMsg);
		String errorMsg = getErrorMsg(rspCode,rspDesc,rspMsg);

		rspHeader.setSys_resp_code(errorCode);
		
		rspHeader.setSys_resp_desc(errorMsg);
		traceLog.setErrormessage(errorMsg);
		
		Date resp_time = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		rspMsg.getTx_header().setSys_resp_time(sdf.format(resp_time));
		faceLog.setResptime(resp_time);
		
		LOGGER.error("------------------TxReponseMsg------------------\n"+rspMsg);
		
		if("1".equals(SuapSysParaUtil.getStrPara("LogFlag", null))) {
			ServiceParaUtil.setFaceLogFinally(rspMsg, faceLog);
//			SuapFaceLogThread suapFaceLogThread = new SuapFaceLogThread(faceLog);
//			MultithreadingLogExecutor.addLogTask(suapFaceLogThread);
			faceLogService.handlerFaceLog(faceLog);
		}
		
		traceLog.setEndTime(System.currentTimeMillis());
		traceLog.setResponseJsonString_client(JSONObject.toJSONString(rspMsg));
		
		traceLogger.dispose(traceLog);
		
		return rspMsg;
	}


	/**
	 *	 获取错误码
	 *	 1.	优先获取rspMsg中的错误码
	 *	 2. rspMsg中没有则获取Exception中rspCode
	 *	 3.	都没有则返回Errorcode.UNKNOWMSGERROR
	 * @param rspCode
	 * @param rspMsg
	 * @return
	 */
	private String getErrorCode(String rspCode, TxResponseMsg rspMsg) {
		
		String resp_code_rspMsg = rspMsg.getTx_header().getSys_resp_code();
		if(StringUtils.isNotBlank(resp_code_rspMsg))
			return resp_code_rspMsg;
		
		if(StringUtils.isNotBlank(rspCode))
			return rspCode;
		
		LOGGER.error("errorCode is null, rspCode: " + rspCode + ", resp_code_rspMsg: " + resp_code_rspMsg);
		return Errorcode.UNKNOWMSGERROR;
	}


	/**
	 *	 获取错误描述
	 *	 1.  优先从数据库中获取
	 *	 2. 数据库中没有则从rspMsg中获取
	 *	 3. rspMsg中亦无则从Exception中获取
	 *	 4. 都没有则返回"异常描述未定义"
	 * @param rspCode
	 * @param rspDesc
	 * @param rspMsg
	 * @return
	 */
	private String getErrorMsg(String rspCode, String rspDesc, TxResponseMsg rspMsg) {
		String error_msg_database = SuapErrorInfoUtil.getErrorMsgOfNull(rspCode);
		String error_msg_rspMsg = rspMsg.getTx_header().getSys_resp_desc();
		
		if(StringUtils.isNotBlank(error_msg_database))
			return error_msg_database;
		
		if(StringUtils.isNotBlank(error_msg_rspMsg))
			return error_msg_rspMsg;
		
		if(StringUtils.isNotBlank(rspDesc))
			return rspDesc;
		
		LOGGER.error("can not get errorMsg, error_msg_database: " + ", error_msg_rspMsg: " + error_msg_rspMsg + ", rspDesc: " + rspDesc);
		return "异常描述未定义";
	}
	
	
	
	
	
	
	
	
}
