package com.ccb.suap.cloud.access.beans;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1002ServiceInVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1002ServiceOutList;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1002ServiceOutVo;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.service.GPUMPService;
import com.ccb.suap.cloud.access.service.SuapCustDeviceInfoService;
import com.ccb.suap.cloud.access.service.SuapCustInfoService;
import com.ccb.suap.cloud.access.service.utils.PhotoUtil;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC1002ServiceInVo;
import com.ccb.suap.cloud.access.vo.INREC1002ServiceOutList;
import com.ccb.suap.cloud.access.vo.INREC1002ServiceOutVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

@Controller("INREC1002")
public class INREC1002_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC1002_Bean.class);
	
	@Autowired
	private SuapCustInfoService suapCustInfoService;
	
	@Autowired
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	
	@Autowired
	private GPUMPService GPUMPService;
	
//	private SuapCustInfoService suapCustInfoService=InrecDaoFactory.getDaoManager().getSuapCustInfoService();
//	private SuapCustDeviceInfoService suapCustDeviceInfoService= InrecDaoFactory.getDaoManager().getSuapCustDeviceInfoService();
//	private GPUMPService GPUMPService=InrecDaoFactory.getDaoManager().getGPUMPService();
	
	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n\n------------------调用INREC1002服务------------------");
		
		setFaceLogByReqEntity(reqMsg);
		
		SuapFaceLogModel faceLog = FaceLogThreadLocal.get();
		
		//根据请求信息获取相关人脸参数配置信息
		SuapFaceConfigModel faceConfig = SuapFaceConfigUtil.getFaceConfig(reqMsg);
		LOGGER.debug("faceConfig: "+faceConfig);
		
		//获取请求报文体：包括实体，公共域com1
		INREC1002ServiceInVo entity = (INREC1002ServiceInVo) reqMsg.getTx_body().getEntity();
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		
		//初始化响应的报文体实体（列表保存）
		List<INREC1002ServiceOutList> list = new ArrayList<INREC1002ServiceOutList>();
		INREC1002ServiceOutVo outVo = new INREC1002ServiceOutVo();
		outVo.setResult_list(list);
		rspMsg.getTx_body().setEntity(outVo);
		
		//实体域参数校验
		LOGGER.debug("check requestEntity: "+entity);
		checkParaByServerName(rspMsg, reqMsg);
		
		//保存请求图片
		String path = PhotoUtil.getPath(ServiceParaUtil.getBasePthBySyspara("FACEPICPATH", reqMsg.getTx_body().getCom1().getSysChannelID(), "FaceCompImage"), reqMsg.getTx_header().getSys_evt_trace_id() + ".jpg");
		PhotoUtil.savePhotoWithTime(entity.getFace_image(), path);
		faceLog.setFacefilepath(path);
		LOGGER.debug("request photo path: "+path);
		
		//发往GPUMP1002比对
		TxRequestMsg gpump1002ReqMsg = getGPUMP1002ReqMsg(reqMsg);
		LOGGER.debug("send GPUMP1002: "+gpump1002ReqMsg);
		TxResponseMsg gpump1002Rsp = GPUMPService.sendGPUMP1002(gpump1002ReqMsg);
		LOGGER.debug("return by GPUMP1002: "+gpump1002Rsp);
		if(!"000000000000".equals(gpump1002Rsp.getTx_header().getSys_resp_code()))
			throw new CommonRuntimeException(gpump1002Rsp);
		
//		setCustInfoAndCustDeviceInfo(reqMsg, gpump1002Rsp);
		
		//比对结果数量为0，直接返回空集合
		GPUMP1002ServiceOutVo gpump1002RspEntity = ServiceParaUtil.getGPURspMsgEntity(gpump1002Rsp, GPUMP1002ServiceOutVo.class);
		if("0".equals(gpump1002RspEntity.getResult_list_size())) {
			LOGGER.warn("result_list_size is 0!");
			outVo.setResult_list_size("0");
			return rspMsg;
		}
		
		List<GPUMP1002ServiceOutList> gpump1002ResultList = gpump1002RspEntity.getResult_list();
		
		String idTypeLog = "";
		String idNoLog = "";
		String nameLog = "";
		String mobileLog = "";
		String custIdLog = "";
		String similarityLog = "";
		
		LOGGER.debug("\n");
		for (GPUMP1002ServiceOutList resultListOutVo : gpump1002ResultList) {
			idTypeLog =idTypeLog+"/"+resultListOutVo.getId_type();
			idNoLog =idNoLog+"/"+resultListOutVo.getId_no();
			nameLog =nameLog+"/"+resultListOutVo.getName();
			mobileLog =mobileLog+"/"+resultListOutVo.getMobile_no();
			custIdLog =custIdLog+"/"+resultListOutVo.getCust_id();
			similarityLog =similarityLog+"/"+resultListOutVo.getSimilarity();
			
			INREC1002ServiceOutList gpuResultVo = new INREC1002ServiceOutList();
			
			gpuResultVo.setFace_collecttime(resultListOutVo.getFace_collecttime());
			gpuResultVo.setSimilarity(resultListOutVo.getSimilarity());
			
			//查询客户信息
			String id_type = resultListOutVo.getId_type();
			String id_no = resultListOutVo.getId_no();
			String num = String.valueOf(StringUtils.getBiolInfoTableID(id_type+id_no));
			
			LOGGER.debug("custInfo GPUMP1002: {num:"+num+",id_type:"+id_type+",id_no: "+id_no+",name: "+resultListOutVo.getName()+"}");
//			SuapCustInfoModel suapCustInfoModel = getCustInfo(num, id_type, id_no);
			SuapCustInfoModel suapCustInfoModel = suapCustInfoService.selectWithRedis(num, id_type, id_no);
			LOGGER.debug("custInfo in the database: "+suapCustInfoModel);
			if(suapCustInfoModel == null) {
				LOGGER.warn("can not found custInfo in database!");
				FaceLogThreadLocal.get().setRemarks("can not found custInfo in database, num: " + num + ", id_type: " + id_type +", id_no: " + id_no);
				list.add(gpuResultVo);
				continue;
			}
			gpuResultVo.setId_type(suapCustInfoModel.getIdtype());
			gpuResultVo.setId_no(suapCustInfoModel.getIdnumber());
			gpuResultVo.setName(suapCustInfoModel.getCustname());
			gpuResultVo.setMobile_no(suapCustInfoModel.getCellphome());
			gpuResultVo.setCcb_custno(suapCustInfoModel.getCcbcustno());
			gpuResultVo.setBranch_id(suapCustInfoModel.getBranchid());
			
			LOGGER.debug("select custDeviceInfo: {num:"+num+",id_type: "+id_type+",id_no:"+id_no+",channelId: "+com1.getSysChannelID()+"}");
//			SuapCustDeviceInfoModel suapCustDeviceInfoModel = getCustDeviceInfo(num, id_type, id_no, com1.getSysChannelID());
			SuapCustDeviceInfoModel suapCustDeviceInfoModel = suapCustDeviceInfoService.selectWithRedis(num, id_type, id_no, com1.getSysChannelID());
			if(suapCustDeviceInfoModel == null || "1".equals(suapCustDeviceInfoModel.getIsvalid())) {
				LOGGER.warn("can not find custDeviceInfo in database!");
				FaceLogThreadLocal.get().setRemarks("can not found custDeviceInfo in database, num: " + num + ", id_type: " + id_type +", id_no: " + id_no + ", channelID: " + com1.getSysChannelID());
				continue;
			}
			gpuResultVo.setChannel_custno(suapCustDeviceInfoModel.getChannel_cstno());
			gpuResultVo.setChannel_cardno(suapCustDeviceInfoModel.getCardno());
			gpuResultVo.setTitle(suapCustDeviceInfoModel.getTitile());
			gpuResultVo.setIs_vip(suapCustDeviceInfoModel.getIsvip());
			
			//判断该渠道是否返回图片，是则读取本地图片
			if(faceConfig.getDistpic().equals("1")) {
				String photoPath = suapCustDeviceInfoModel.getPhoto_path();
				if(org.apache.commons.lang.StringUtils.isBlank(photoPath)) {
					LOGGER.warn("can not found photo_path in custInfo!");
					gpuResultVo.setRegistry_photo("no photo has found!");
					continue;
				}
				
				String registry_photo = PhotoUtil.loadPhoto(photoPath);
				gpuResultVo.setRegistry_photo(registry_photo);
			}
			
			LOGGER.debug("customer in database: "+gpuResultVo+"\n");
			list.add(gpuResultVo);
		}
		
		idTypeLog = idTypeLog.substring(1);
		idNoLog = idNoLog.substring(1);
		nameLog = nameLog.substring(1);
		mobileLog = mobileLog.substring(1);
		custIdLog = custIdLog.substring(1);
		similarityLog = similarityLog.substring(1);
		
		faceLog.setIdtype(idTypeLog);
		faceLog.setIdno(idNoLog);
		faceLog.setName(nameLog);
		faceLog.setMobile(mobileLog);
		faceLog.setCustid(custIdLog);
		faceLog.setSimilarity(similarityLog);
		
		outVo.setResult_list_size(String.valueOf(list.size()));
		
		return rspMsg;
	}


//	private SuapCustInfoModel getCustInfo(String num, String id_type, String id_no) {
//		
//		String json = redisService.get(id_type + "_" + id_no);
//		if(org.apache.commons.lang.StringUtils.isNotBlank(json))
//			return JSONObject.toJavaObject(JSONObject.parseObject(json), SuapCustInfoModel.class);
//		
//		return suapCustInfoService.select(num, id_type, id_no);
//		
//	}
	
	
//	private SuapCustDeviceInfoModel getCustDeviceInfo(String num, String id_type, String id_no, String sysChannelID) {
//		
//		String json = redisService.get(id_type + "_" + id_no + "_" + sysChannelID);
//		if(org.apache.commons.lang.StringUtils.isNotBlank(json))
//			return JSONObject.toJavaObject(JSONObject.parseObject(json), SuapCustDeviceInfoModel.class);
//		
//		return suapCustDeviceInfoService.select(num, id_type, id_no, sysChannelID);
//	}

	
	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
//		封装的请求体实体
		INREC1002ServiceInVo entity = (INREC1002ServiceInVo) reqMsg.getTx_body().getEntity();
//		验证人脸照片
		if(entity.getFace_image() == null)
			throw new CommonRuntimeException(Errorcode.FACEIMGNOTNULL);
		
		//从系统参数表中读取图片大小限制值
		String size = SuapSysParaUtil.getStrPara("FACEPICSIZE", null);
		size = size.replaceAll(" ", "");
		if(size == null || "".equals(size))
			throw new CommonRuntimeException(Errorcode.PHSIZENOTFOUND);
		
		//判断图片消耗的时间是否超出系统设置值
		boolean flag = PhotoUtil.judgeSizeByByte(entity.getFace_image(), Integer.parseInt(size));
		if(!flag)
			throw new CommonRuntimeException(Errorcode.PHOLARGEEERROR);
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("judgePhotoSize(").append(judgePhotoSize)
//		.append(")/sendGPU(").append(sendGPU)
//		.append(")/selectCustInfo(").append(selectCustInfo)
//		.append(")/loadPhoto(").append(loadPhoto)
//		.append(")/selectCustDevInfo(").append(selectCustDevInfo)
//		.append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	
	/**
	 * 设置日志表部分信息
	 * @param reqMsg
	 */
	private void setFaceLogByReqEntity(TxRequestMsg reqMsg) {
		INREC1002ServiceInVo entity = (INREC1002ServiceInVo) reqMsg.getTx_body().getEntity();
		
		SuapFaceLogModel faceLog = FaceLogThreadLocal.get();
		faceLog.setBranchid(entity.getBranch_id());
		faceLog.setVendorcode(entity.getVender_code());
		
	}
	
	
	/**
	 * 	把请求信息封装成前置对应的请求报文
	 * @param reqMsg
	 * @return
	 */
	private TxRequestMsg getGPUMP1002ReqMsg(TxRequestMsg reqMsg) {
		TxRequestMsg gpuRequestMsg = ServiceParaUtil.parseGpuRequestMsg(reqMsg);
		
		INREC1002ServiceInVo entity = (INREC1002ServiceInVo) reqMsg.getTx_body().getEntity();
		
		GPUMP1002ServiceInVo gpump1002ServiceInVo = new GPUMP1002ServiceInVo();
		String image = entity.getFace_image();
		image = image.replaceAll("\r", "");
		image = image.replaceAll("\n", "");
		image = image.replaceAll(" ", "");
		gpump1002ServiceInVo.setFace_image(image);
		gpump1002ServiceInVo.setFace_eigen(entity.getFace_eigen());
		
		SuapFaceConfigModel suapFaceConfigModel = SuapFaceConfigUtil.getFaceConfig(reqMsg);
		gpump1002ServiceInVo.setHit_size(suapFaceConfigModel.getHitnum());
		gpump1002ServiceInVo.setThreshold(suapFaceConfigModel.getSimilarity());
		
		gpuRequestMsg.getTx_body().setEntity(gpump1002ServiceInVo);
		gpuRequestMsg.getTx_header().setSys_tx_code("GPUMP1002");
		
		return gpuRequestMsg;
	}
	
	


	


	
	
	
	
}
