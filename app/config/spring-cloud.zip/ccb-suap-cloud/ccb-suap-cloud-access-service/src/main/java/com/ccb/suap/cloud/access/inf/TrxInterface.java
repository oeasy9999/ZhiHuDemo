package com.ccb.suap.cloud.access.inf;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.util.log.TraceLog;

/**
 * 交易处理接口
 * @author zhanzifeng
 *
 */
public interface TrxInterface {

	public  TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog tracelog)throws Exception;
	
	/**
	 * 	校验请求信息中,entity信息的合法性
	 * @param rspMsg
	 * @param entityw
	 * @return
	 * @throws Exception
	 */
	void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception;
	

	
	
}
