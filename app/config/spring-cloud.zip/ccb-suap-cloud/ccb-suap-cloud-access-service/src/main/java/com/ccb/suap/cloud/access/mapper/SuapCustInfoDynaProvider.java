package com.ccb.suap.cloud.access.mapper;

import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.jdbc.SQL;

import com.ccb.suap.cloud.access.model.SuapCustInfoModel;

public class SuapCustInfoDynaProvider {
	
	public String update(SuapCustInfoModel suapCustInfoModel) {
		return new SQL() {{
			UPDATE("SUAP_CUST_INFO_"+suapCustInfoModel.getNum());
			if(StringUtils.isNotBlank(suapCustInfoModel.getCcbcustno())) 
				SET("CCBCUSTNO=#{ccbcustno}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getCustname())) 
				SET("CUSTNAME=#{custname}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getBranchid())) 
				SET("BRANCHID=#{branchid}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getCellphome())) 
				SET("CELLPHOME=#{cellphome}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getSex())) 
				SET("SEX=#{sex}");
			if(suapCustInfoModel.getBirthday() != null) 
				SET("BIRTHDAY=#{birthday}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getAddress())) 
				SET("ADDRESS=#{address}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getCompany())) 
				SET("COMPANY=#{company}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getIndustry())) 
				SET("INDUSTRY=#{industry}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getCareer())) 
				SET("CAREER=#{career}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getSchool())) 
				SET("SCHOOL=#{school}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getEducation())) 
				SET("EDUCATION=#{education}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getIncome())) 
				SET("INCOME=#{income}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getHabit())) 
				SET("HABIT=#{habit}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getIdphoto_path())) 
				SET("IDPHOTO_PATH=#{idphoto_path}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getIdphoto_level())) 
				SET("IDPHOTO_LEVEL=#{idphoto_level}");
			if(suapCustInfoModel.getIdphoto_date() != null) 
				SET("IDPHOTO_DATE=#{idphoto_date}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getIdphoto_channel())) 
				SET("IDPHOTO_CHANNEL=#{idphoto_channel}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getScenephoto_path())) 
				SET("SCENEPHOTO_PATH=#{scenephoto_path}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getScenephoto_level())) 
				SET("SCENEPHOTO_LEVEL=#{scenephoto_level}");
			if(suapCustInfoModel.getScenephoto_date() != null) 
				SET("SCENEPHOTO_DATE=#{scenephoto_date}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getScenephoto_channel())) 
				SET("SCENEPHOTO_CHANNEL=#{scenephoto_channel}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getUpdatechannel())) 
				SET("UPDATECHANNEL=#{updatechannel}");
			if(StringUtils.isNotBlank(suapCustInfoModel.getIdverify())) 
				SET("IDVERIFY=#{idverify}");
			if(suapCustInfoModel.getUpdatetime() != null) 
				SET("UPDATETIME=#{updatetime}");
			
			WHERE("IDTYPE=#{idtype}").WHERE("IDNUMBER=db_encrypt(#{idnumber})");
			
		}}.toString();
	}
	
}
