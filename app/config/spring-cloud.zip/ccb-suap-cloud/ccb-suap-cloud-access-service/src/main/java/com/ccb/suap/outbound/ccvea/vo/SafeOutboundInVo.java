package com.ccb.suap.outbound.ccvea.vo;

public class SafeOutboundInVo extends GatewayRequestMsg{
	
	private String append_url;
	private String req_msg_type;
	
	public String getAppend_url() {
		return append_url;
	}
	public void setAppend_url(String append_url) {
		this.append_url = append_url;
	}
	public String getReq_msg_type() {
		return req_msg_type;
	}
	public void setReq_msg_type(String req_msg_type) {
		this.req_msg_type = req_msg_type;
	}
	
	@Override
	public String toString() {
		return "SafeOutboundInVo [append_url=" + append_url + ", req_msg_type=" + req_msg_type + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
