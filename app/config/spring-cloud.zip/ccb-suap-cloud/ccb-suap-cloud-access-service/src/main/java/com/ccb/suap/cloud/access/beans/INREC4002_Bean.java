package com.ccb.suap.cloud.access.beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1009ServiceInVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1009ServiceOutVo;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.service.GPUMPService;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.vo.INREC4002ServiceInVo;
import com.ccb.suap.cloud.access.vo.INREC4002ServiceOutVo;
import com.ccb.suap.util.log.TraceLog;

@Controller("INREC4002")
public class INREC4002_Bean extends INRECBean{

	private static final Logger LOGGER = LoggerFactory.getLogger(INREC4002_Bean.class);
	
	@Autowired
	private GPUMPService GPUMPService;
	
//	private GPUMPService GPUMPService=InrecDaoFactory.getDaoManager().getGPUMPService();
	
	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n------------------调用INREC4002服务------------------");
		
		LOGGER.debug("check InVo: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		TxRequestMsg gpump1009ReqMsg = getGPUMP1009ReqMsg(reqMsg);
		LOGGER.debug("send GPUMP1009");
		long beforeSelectCustInfo = System.currentTimeMillis();
		TxResponseMsg gpump1009Rsp = GPUMPService.sendGPUMP1009(gpump1009ReqMsg,traceLog);
		long sendGPU1009 = System.currentTimeMillis()-beforeSelectCustInfo;
		traceLog.setSendGpumq1009Time(sendGPU1009);
		traceLog.setHttpcost(traceLog.getHttpcost()+traceLog.getSendGpumq1009Time());
		
		LOGGER.debug("return by GPUMP1009: "+gpump1009Rsp);
		if(!"000000000000".equals(gpump1009Rsp.getTx_header().getSys_resp_code())) 
			throw new CommonRuntimeException(gpump1009Rsp);
		
		INREC4002ServiceOutVo inrec4002RspEntity = new INREC4002ServiceOutVo();
		GPUMP1009ServiceOutVo gpump1009RspEntity = (GPUMP1009ServiceOutVo) gpump1009Rsp.getTx_body().getEntity();
		inrec4002RspEntity.setSimilarity(gpump1009RspEntity.getSimilarity());
		
		rspMsg.getTx_body().setEntity(inrec4002RspEntity);
		
		return rspMsg;
	}
	

	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		
		INREC4002ServiceInVo inrec4002ReqEntity = (INREC4002ServiceInVo) reqMsg.getTx_body().getEntity();
		String face_image1 = inrec4002ReqEntity.getFace_image1();
		String face_image2 = inrec4002ReqEntity.getFace_image2();
		
		if("".equals(face_image1) || face_image1 == null)
			throw new CommonRuntimeException(Errorcode.FACEIMGNOTNULL);
		if("".equals(face_image2) || face_image2 == null)
			throw new CommonRuntimeException(Errorcode.FACEIMGNOTNULL);
		
	}
	
	
	/**
	 * GPUMP1009请求信息封装
	 * @param reqMsg
	 * @return
	 */
	private TxRequestMsg getGPUMP1009ReqMsg(TxRequestMsg reqMsg) {
		TxRequestMsg gpump1009ReqMsg = ServiceParaUtil.newReqMsg(reqMsg);
		INREC4002ServiceInVo inrec4002ReqEntity = (INREC4002ServiceInVo) reqMsg.getTx_body().getEntity();
		GPUMP1009ServiceInVo gpump1009ReqEntity = new GPUMP1009ServiceInVo();
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		SuapFaceConfigModel faceConfig = SuapFaceConfigUtil.getFaceConfig(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		
		TxRequestMsgCom2 com2 = new TxRequestMsgCom2();
		com2.setSysChannelID(com1.getSysChannelID());
		com2.setGroupName(faceConfig.getLocation_source());
		
		gpump1009ReqEntity.setFace_image(inrec4002ReqEntity.getFace_image1());
		gpump1009ReqEntity.setFace_refer_image(inrec4002ReqEntity.getFace_image2());
		
		gpump1009ReqMsg.getTx_body().setCom2(com2);
		gpump1009ReqMsg.getTx_body().setEntity(gpump1009ReqEntity);
		
		return gpump1009ReqMsg;
	}

	
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("sendGPU1009(").append(sendGPU1009).append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	

	
	
	
	
	
}
