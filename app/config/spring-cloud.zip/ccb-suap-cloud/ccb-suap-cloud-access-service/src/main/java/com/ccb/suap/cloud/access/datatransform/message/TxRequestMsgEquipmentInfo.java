package com.ccb.suap.cloud.access.datatransform.message;

public class TxRequestMsgEquipmentInfo {
	
	private String equipmentId;					//设备ID(设备唯一标识)
	private String equipmentName;				//设备名称
	
	public String getEquipmentId() {
		return equipmentId;
	}
	public void setEquipmentId(String equipmentId) {
		this.equipmentId = equipmentId;
	}
	public String getEquipmentName() {
		return equipmentName;
	}
	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}
	
	@Override
	public String toString() {
		return "TxRequestMsgEquipmentInfo [equipmentId=" + equipmentId + ", equipmentName=" + equipmentName + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
