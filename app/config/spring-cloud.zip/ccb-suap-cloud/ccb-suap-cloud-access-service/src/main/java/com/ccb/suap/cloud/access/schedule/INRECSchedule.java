package com.ccb.suap.cloud.access.schedule;

import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.access.service.BaseDatabaseService;
import com.ccb.suap.cloud.access.service.RedisService;
import com.ccb.suap.cloud.access.service.utils.RedisUtil;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;

import redis.clients.jedis.exceptions.JedisDataException;

@Component
@EnableScheduling
public class INRECSchedule {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INRECSchedule.class);
	
	@Autowired
	private BaseDatabaseService baseDatabaseService;
	@Autowired
	private RedisService redisService;
	@Autowired
	private RedisUtil redisUtil;
	
	//单线程线程池，用于判断心跳是否超时
	ExecutorService databseHeratBeat = Executors.newSingleThreadExecutor();
	ExecutorService redisHeratBeat = Executors.newSingleThreadExecutor();
	
	//记录对应模块的可用状态
	private boolean databaseStatus = true;
	private boolean redisStatus = true;
	
	
	@Scheduled(cron="*/5 * * * * ?")
	public void checkDatabaseStatus() {
		
		long start_time = System.currentTimeMillis();
		long cost_time = 0L;
		Future<String> future = databseHeratBeat.submit(() -> baseDatabaseService.heartBeat());
		
		String result = null;
		int database_timeout_time = SuapSysParaUtil.getIntPara("DATABASE_TIMEOUT_TIME", 3);
		try {
			result = future.get(database_timeout_time, TimeUnit.SECONDS);
			databaseStatus = true;
		} catch (InterruptedException | ExecutionException | TimeoutException e) {
			e.printStackTrace();
			cost_time = System.currentTimeMillis() - start_time;
			databaseStatus = false;
			LOGGER.error("timeout while execute database: " + new Date() + ", cost_time: " + cost_time);
			return;
		}
		
		if(StringUtils.isBlank(result) || !"1".equals(result))
			databaseStatus = false;
		
	}
	
	
	@Scheduled(cron="*/5 * * * * ?")
	public void checkRedisIsReadOnly() {
		
		long start_time = System.currentTimeMillis();
		long cost_time = 0L;
		Future<Boolean> future = redisHeratBeat.submit(() -> redisIsReadOnly());
		
		int redis_timeout_time = SuapSysParaUtil.getIntPara("DATABASE_TIMEOUT_TIME", 3);
		try {
			redisStatus = future.get(redis_timeout_time, TimeUnit.SECONDS);
			if(!redisStatus)
				redisUtil.refreshJedisSentinelPool();
		} catch (InterruptedException | ExecutionException | TimeoutException e) {
			cost_time = System.currentTimeMillis() - start_time;
			LOGGER.error("timeout while set redis in INRECSchedule: " + new Date() + ", cost_time: " + cost_time);
			return;
		}
		
	}


	/**
	 * 	判断redis连接池中的链接是否允许set操作
	 * @return
	 */
	private boolean redisIsReadOnly() {
		
		try {
			redisService.set("READONLY_HEARTBEAT", "READONLY_CHECK");
		} catch (Exception e) {
			if(e instanceof JedisDataException && e.getMessage().contains("READONLY")) {
				LOGGER.error("set redis faild, currentHostMaster: " + redisUtil.getCurrentHostMaster());
				return false;
			}
		}
		
		return true;
	}


	public boolean getDatabaseStatus() {
		return databaseStatus;
	}

	public boolean getRedisStatus() {
		return redisStatus;
	}


	
	
	
	
	
	
	
	
	
}
