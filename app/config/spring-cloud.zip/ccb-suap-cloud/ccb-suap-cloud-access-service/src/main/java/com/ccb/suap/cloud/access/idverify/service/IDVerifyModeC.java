package com.ccb.suap.cloud.access.idverify.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.anydef.api.EcuacAPI;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.service.OutBoundService;
import com.ccb.suap.cloud.access.service.utils.ECUACXMLUtils;
import com.ccb.suap.cloud.access.service.utils.SimpleDateFormatUtil;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC1001And2001ServiceInVo;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam1001And2001;
import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACRequestMsg;
import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACRequestMsgBody;
import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACRequestMsgBodyCom1;
import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACRequestMsgBodyCommon;
import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACRequestMsgHead;
import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACResponseMsg;
import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACResponseMsgHead;
import com.ccb.suap.cloud.ecuac.vo.ECUAC0183ServiceInVo;
import com.ccb.suap.cloud.ecuac.vo.ECUAC0183ServiceOutVo;
import com.ccb.suap.outbound.ccvea.vo.SafeOutboundInVo;
import com.ccb.suap.outbound.ccvea.vo.SafeOutboundOutVo;

/**
 * 	ECUAC0183专线核查
 * @author 86156
 *
 */

@Service("IDVerify3")
public class IDVerifyModeC implements IDVerifyMode{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Autowired
	private OutBoundService outboundService;
	
	
	@Override
	public boolean verify(TxRequestMsg reqMsg, SuapFaceConfigModel faceConfig, ServiceInVoParam1001And2001 param) {
		char[] mode_arr = getModeArr(faceConfig);
		List<String> Ignore_errorcode_list = getECUACIgnoreErrorcodeList();
		
		for (char c : mode_arr) {
			SafeOutboundOutVo safeOutboundOutVo = sendSafeOutboundByMode(reqMsg, c);
			ECUACResponseMsg ecuac_resp_msg = getEcuacResponseMsg(safeOutboundOutVo);
			String resp_code = getResp_code(safeOutboundOutVo, ecuac_resp_msg);
			
			if("000000000000".equals(resp_code))
				return true;
			
			//如通讯，流控等报错，则进行下一个核查
			if(Ignore_errorcode_list.contains(resp_code)) {
				LOGGER.debug(resp_code + "is in Ignore_errorcode_list where selected by SysPara: IDVERIFY_IGNORE_ERRORCODE");
				FaceLogThreadLocal.get().setRemarks("send ecuac0183_mode error, mode: " + c + ", resp_code: " + resp_code);
				continue;
			}
			
			String resp_msg = getResp_msg(safeOutboundOutVo, ecuac_resp_msg);
			throw new CommonRuntimeException(resp_code, resp_msg, "01", "ecuac0183_mode is " + c);
			
		}
		
		return false;
	}


	/**
	 *	 获取ECUAC0183专线核查模式char数组
	 * @param faceConfig
	 * @return
	 */
	private char[] getModeArr(SuapFaceConfigModel faceConfig) {
		String ecuac0183_mode = faceConfig.getEcuac0183_mode();
		LOGGER.debug("dcuac0183_mode in faceConfig: " + ecuac0183_mode);
		
		if(StringUtils.isBlank(ecuac0183_mode))
			ecuac0183_mode = "21";
		
		return ecuac0183_mode.toCharArray();
	}
	
	
	/**
	 *	 获取人脸核查通讯,流控等错误码集合
	 * @return
	 */
	private List<String> getECUACIgnoreErrorcodeList() {
		String ignore_errorcode = SuapSysParaUtil.getStrPara("IDVERIFY_IGNORE_ERRORCODE", null);
		LOGGER.debug("IDVERIFY_IGNORE_ERRORCODE in Syspara: " + ignore_errorcode);
		if(StringUtils.isBlank(ignore_errorcode))
			return new ArrayList<String>();
		
		String[] ignore_errorcode_arr = ignore_errorcode.split(",");
		List<String> ignore_errorcode_list = Arrays.asList(ignore_errorcode_arr);
		
		return ignore_errorcode_list;
	}


	/**
	 * 	发送到ECUAC0183专线进行人脸核查
	 * @param reqMsg
	 * @param c
	 * @return
	 */
	private SafeOutboundOutVo sendSafeOutboundByMode(TxRequestMsg reqMsg, char c) {
		
		SafeOutboundInVo safeOutboundInVo = getSafeOutboundInVo(reqMsg,c);
		
		LOGGER.debug("send SafeOutbound, safeOutboundInVo: " + JSONObject.toJSONString(safeOutboundInVo));
		SafeOutboundOutVo safeOutboundOutVo = outboundService.sendSafeOutbound(safeOutboundInVo);
		LOGGER.debug("return by SafeOutbound, safeOutboundOutVo: " + JSONObject.toJSONString(safeOutboundOutVo));
		
		return safeOutboundOutVo;
	}
	
	
	/**
	 * 获取ECUAC返回对象
	 * @param safeOutboundOutVo
	 * @return
	 */
	private ECUACResponseMsg getEcuacResponseMsg(SafeOutboundOutVo safeOutboundOutVo) {
		
		String resp_code_ourbound = safeOutboundOutVo.getReturn_code();
		if(!"000000000000".equals(resp_code_ourbound))
			return null;
		
		String resp_data = safeOutboundOutVo.getResponse_info();
		if(StringUtils.isBlank(resp_data))
			throw new CommonRuntimeException(Errorcode.SAFEBDDATANULL, "01", "外呼SafeOutbound接口返回空resp_data");
		
//		BASE64Decoder decoder = new BASE64Decoder();
//		try {
//			resp_data = new String(decoder.decodeBuffer(resp_data));
//		} catch (IOException e) {
//			LOGGER.error("base64 decoder error: ", e);
//			throw new CommonRuntimeException(Errorcode.BASE64DECERROR, "01", "BASE64解析错误: " + e.getMessage());
//		}
		
		ECUACResponseMsg ecuac_resp_msg = ECUACXMLUtils.toECUACTxResponseMsg(resp_data, ECUAC0183ServiceOutVo.class);
		ECUACResponseMsgHead ecuac_resp_header = ecuac_resp_msg.getTx_header();
		
		if(ecuac_resp_header == null)
			throw new CommonRuntimeException(Errorcode.SAFEBDHERDNULL, "01", "外呼SafeOutbound接口返回空header");
		
		return ecuac_resp_msg;
	}
	
	
	/**
	 *	 获取响应信息中的错误码
	 * @param safeOutboundOutVo
	 * @return
	 */
	private String getResp_code(SafeOutboundOutVo safeOutboundOutVo, ECUACResponseMsg ecuac_resp_msg) {
		
		String resp_code_ourbound = safeOutboundOutVo.getReturn_code();
		if(!"000000000000".equals(resp_code_ourbound))
			return resp_code_ourbound;
		
		return ecuac_resp_msg.getTx_header().getSys_resp_code();
	}

	
	/**
	 *	 获取响应信息中的错误描述
	 * @param safeOutboundOutVo
	 * @return
	 */
	private String getResp_msg(SafeOutboundOutVo safeOutboundOutVo, ECUACResponseMsg ecuac_resp_msg) {
		
		String resp_code_ourbound = safeOutboundOutVo.getReturn_code();
		if(!"000000000000".equals(resp_code_ourbound))
			return safeOutboundOutVo.getReturn_message();
		
		return ecuac_resp_msg.getTx_header().getSys_resp_desc();
	}
	
	
	/**
	 *	 封装ECUAC0183请求报文
	 * @param reqMsg
	 * @param c
	 * @return
	 */
	private SafeOutboundInVo getSafeOutboundInVo(TxRequestMsg reqMsg, char c) {
		SafeOutboundInVo safeOutboundInVo = new SafeOutboundInVo();
		
		ECUACRequestMsg ecuac_req_msg= getDefaultTxRequestMsg(reqMsg);
		ECUAC0183ServiceInVo ecuac_entity = (ECUAC0183ServiceInVo) ecuac_req_msg.getTx_body().getEntity();
		
		String sys_req_time = ecuac_req_msg.getTx_header().getSys_req_time();
		
		String channel_str = SuapSysParaUtil.getStrPara("IDVERIFY_SAFEMODE_CHANNELID", "undefined:undefined,undefined:undefined");
		LOGGER.debug("IDVERIFY_SAFEMODE_CHANNELID in table suap_sys_para: " + channel_str);
		String channelid_police = null;
		String channel_txcode_police = null;
		String channelid_not_police = null;
		String channel_txcode_not_police = null;
		
		try {
			String[] channel_arr = channel_str.split(",");
			String[] channel_police = channel_arr[0].split(":");
			String[] channel_not_police = channel_arr[1].split(":");
			
			channelid_police = channel_police[0];
			channel_txcode_police = channel_police[1];
			channelid_not_police = channel_not_police[0];
			channel_txcode_not_police = channel_not_police[1];
		} catch (Exception e) {
			LOGGER.error("IDVERIFY_SAFEMODE_CHANNELID in table suap_sys_para error, IDVERIFY_SAFEMODE_CHANNELID = " + channel_str, e);
			throw new CommonRuntimeException(Errorcode.PARAETYPEERROR, "01", "IDVERIFY_SAFEMODE_CHANNELID in table suap_sys_para error, IDVERIFY_SAFEMODE_CHANNELID = " + channel_str + " , " + e.getMessage());
		}
		
		
		//1.公安一所， 2.非公安一所
		switch (c) {
		case '1':
			ecuac_entity.setStm_chnl_id(channelid_police);
			ecuac_entity.setStm_chnl_txn_cd(channel_txcode_police);
			ecuac_entity.setExt_stm_ctfn_ecrp_inf("");
			ecuac_entity.setExtstmctfn_udt_mplttm(sys_req_time.substring(0, 14));
			ecuac_entity.setEcrpafsecrptkey_cntnt(getSigndate(ecuac_req_msg));
			break;
		case '2':
			ecuac_entity.setStm_chnl_id(channelid_not_police);
			ecuac_entity.setStm_chnl_txn_cd(channel_txcode_not_police);
			break;

		default:
			throw new CommonRuntimeException(Errorcode.PARAETYPEERROR, "01", c + "is not in ecuac0183_mode!");
		}
		
		String ECUAC0183_REQ_MSG = ECUACXMLUtils.getECUACXMLByAnnotation(ecuac_req_msg, ECUAC0183ServiceInVo.class);
		LOGGER.debug("ECUAC0183_REQ_MSG: " + ECUAC0183_REQ_MSG);
		
		safeOutboundInVo.setGroupid("ECUAC");
		safeOutboundInVo.setReq_msg_type("XML");
		safeOutboundInVo.setTx_code("ECUAC0183");
		safeOutboundInVo.setTraceId(reqMsg.getTx_header().getSys_evt_trace_id());
		safeOutboundInVo.setCcb_param(ECUAC0183_REQ_MSG);
		
		return safeOutboundInVo;
	}


	/**
	 * 获取ECUAC0183请求对象
	 * @param reqMsg
	 * @return
	 */
	private ECUACRequestMsg getDefaultTxRequestMsg(TxRequestMsg reqMsg) {
		
		INREC1001And2001ServiceInVo inrecInVo = (INREC1001And2001ServiceInVo) reqMsg.getTx_body().getEntity();
		
		String trace_id = reqMsg.getTx_header().getSys_evt_trace_id();
		String cust_name = inrecInVo.getName();
		String id_type = inrecInVo.getId_type();
		String id_no = inrecInVo.getId_no();
		String face_image = inrecInVo.getFace_image();
		
		String date = SimpleDateFormatUtil.getStrNow("yyyyMMddHHmmssSSS");
		
		ECUACRequestMsg ecuac_req_msg = new ECUACRequestMsg();
		
		ECUACRequestMsgHead ecuac_header = new ECUACRequestMsgHead();
		ECUACRequestMsgBody ecuac_body = new ECUACRequestMsgBody();
		
		ECUACRequestMsgBodyCommon ecuac_common = new ECUACRequestMsgBodyCommon();
		ECUACRequestMsgBodyCom1 ecuac_com1 = new ECUACRequestMsgBodyCom1();
		ECUAC0183ServiceInVo ecuac_entity = new ECUAC0183ServiceInVo();
		
		ecuac_common.setCom1(ecuac_com1);
		ecuac_body.setCommon(ecuac_common);
		ecuac_body.setEntity(ecuac_entity);
		
		ecuac_req_msg.setTx_header(ecuac_header);
		ecuac_req_msg.setTx_body(ecuac_body);
		
		ecuac_header.setSys_hdr_len("1");
		ecuac_header.setSys_pkg_vrsn("01");
		ecuac_header.setSys_ttl_len("1");
		ecuac_header.setSys_req_sec_id("101020");
		ecuac_header.setSys_snd_sec_id("101020");
		ecuac_header.setSys_tx_code("ECUAC0183");
		ecuac_header.setSys_tx_vrsn("1");
		ecuac_header.setSys_tx_type("000000");
		ecuac_header.setSys_reserved("0");
		ecuac_header.setSys_evt_trace_id(trace_id);
		ecuac_header.setSys_snd_serial_no("0000000000");
		ecuac_header.setSys_pkg_type("1");
		ecuac_header.setSys_msg_len("10");
		ecuac_header.setSys_is_encrypted("0");
		ecuac_header.setSys_encrypt_type("3");
		ecuac_header.setSys_compress_type("0");
		ecuac_header.setSys_emb_msg_len("10");
		ecuac_header.setSys_req_time(date);
		ecuac_header.setSys_time_left("000030000");
		ecuac_header.setSys_pkg_sts_type("00");
		
		String txn_itt_chnl_id = SuapSysParaUtil.getStrPara("IDVERIFY_SAFEMODE_ITT_CHNL_ID", "0007");
		ecuac_com1.setTxn_insid("110000000");
		ecuac_com1.setTxn_itt_chnl_id(txn_itt_chnl_id);
		ecuac_com1.setTxn_itt_chnl_cgy_code("0001");
		ecuac_com1.setTxn_dt(date.substring(0, 8));
		ecuac_com1.setTxn_tm(date.substring(8, 14));
		ecuac_com1.setTxn_stff_id("999999");
		ecuac_com1.setMulti_tenancy_id("CN000");
		ecuac_com1.setLng_id("zh-cn");
		
		ecuac_entity.setStm_chnl_id("");//TODO
		ecuac_entity.setStm_chnl_txn_cd("");//TODO
		ecuac_entity.setCst_nm(cust_name);
		ecuac_entity.setCrdtp_cd(id_type);
		ecuac_entity.setCrdt_no(id_no);
		ecuac_entity.setBr_id("");//TODO
		ecuac_entity.setRmrk_1_rcrd_cntnt("19903149144");
		ecuac_entity.setBase64_ecd_txn_inf("");
		ecuac_entity.setBase64_ecrp_txn_inf(face_image);
		ecuac_entity.setBr_id_inf("");
		ecuac_entity.setGeo_lo_id("");
		ecuac_entity.setMftr_idr_cd("");
		ecuac_entity.setMftr_str_vno("");
		ecuac_entity.setFtr_col_tmnlinf("");
		ecuac_entity.setTmnl_eqmt_no("");
		ecuac_entity.setTmnl_eqmt_vno("");
		ecuac_entity.setEqmt_modl_vno("");
		ecuac_entity.setEqmt_ctfn_cd("");
		ecuac_entity.setUsr_inf_dsc("");
		ecuac_entity.setEqmt_inf_dsc("");
		ecuac_entity.setAflt_inf_dsc("");
		ecuac_entity.setWthr_vip_inf_dsc("");
		ecuac_entity.setVip_grd_inf_dsc("");
		ecuac_entity.setApl_exmp_id("");//TODO UUID
		ecuac_entity.setRsrv_1_inf_dsc("");
		ecuac_entity.setRsrv_2_inf_dsc("");
		ecuac_entity.setRsrv_3_inf_dsc("");
		ecuac_entity.setRsrv_4_inf_dsc("");
		ecuac_entity.setRsrv_5_inf_dsc("");
		ecuac_entity.setExt_stm_ctfn_ecrp_inf("");//TODO 加解密相关
		ecuac_entity.setEcrpafsecrptkey_cntnt("");//TODO 加解密相关
		ecuac_entity.setExtstmctfn_udt_mplttm("");//TODO 加解密相关
		
		return ecuac_req_msg;
	}
	

	/**
	 * 获取签名
	 * @param ecuac_req_msg
	 * @return
	 */
	private String getSigndate(ECUACRequestMsg ecuac_req_msg) {
		
		EcuacAPI api = new EcuacAPI();
		ECUAC0183ServiceInVo ecuac_entity = (ECUAC0183ServiceInVo) ecuac_req_msg.getTx_body().getEntity();
		
		String trace_id = ecuac_req_msg.getTx_header().getSys_evt_trace_id();
		String date = ecuac_entity.getExtstmctfn_udt_mplttm();
		String cust_name = ecuac_entity.getCst_nm();
		String id_no = ecuac_entity.getCrdt_no();
		String face_image = ecuac_entity.getBase64_ecrp_txn_inf();
		
		String data = trace_id + "||" + date + "||" + cust_name + "||" + id_no + "||" + face_image;
		
		String publicKey = SuapSysParaUtil.getStrPara("IDVERIFY_SAFEMODE_PUBLICKEY", null);
		String privateKey = SuapSysParaUtil.getStrPara("IDVERIFY_SAFEMODE_PRIVATEKEY", null);
		
		if(StringUtils.isBlank(publicKey) || StringUtils.isBlank(privateKey)) {
			LOGGER.error("IDVERIFY_SAFEMODE_PUBLICKEY or IDVERIFY_SAFEMODE_PRIVATEKEY is null in table suap_sys_para!");
			throw new CommonRuntimeException(Errorcode.PARAETYPEERROR, "01", "suap_sys_para error, IDVERIFY_SAFEMODE_PUBLICKEY: " + publicKey + " , IDVERIFY_SAFEMODE_PRIVATEKEY: " + privateKey);
		}
		
		String signdata = api.sign(publicKey, privateKey, data);
		
		return signdata;
	}
	
	
	
	
	
	
	
	
	
}
