package com.ccb.suap.cloud.access.beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1005ServiceInVo;
import com.ccb.suap.cloud.access.service.GPUMPService;
import com.ccb.suap.cloud.access.service.SuapCustDeviceInfoService;
import com.ccb.suap.cloud.access.service.utils.CheckParaUtil;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC1006ServiceInVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

@Controller("INREC1006")
public class INREC1006_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC1006_Bean.class);
	
	@Autowired
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	
	@Autowired
	private GPUMPService GPUMPService;
	
	
//	private SuapCustDeviceInfoService suapCustDeviceInfoService= InrecDaoFactory.getDaoManager().getSuapCustDeviceInfoService();
//	private GPUMPService GPUMPService=InrecDaoFactory.getDaoManager().getGPUMPService();

	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n------------------调用INREC1006服务------------------");
		ServiceParaUtil.setFaceLogByBaseEntity(reqMsg, FaceLogThreadLocal.get());
		
		INREC1006ServiceInVo entity = (INREC1006ServiceInVo) reqMsg.getTx_body().getEntity();
		
		LOGGER.debug("check InVo: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		TxRequestMsg gpuRequestMsg = setGPUTxRequestMsg(reqMsg);
		traceLog.setRequestJsonString_gpump1003(JSONObject.toJSONString(gpuRequestMsg));
		LOGGER.debug("send GPUMP1003: ");
		long beforeSendGPU = System.currentTimeMillis();
		TxResponseMsg gpump1003Rsp = GPUMPService.sendGPUMP1003(gpuRequestMsg,traceLog);
		long sendGPU = System.currentTimeMillis()-beforeSendGPU;
		traceLog.setSendGpump1003Time(sendGPU);
		traceLog.setHttpcost(sendGPU);
		
		LOGGER.debug("return by GPUMP1003: "+gpump1003Rsp);
		if(!"000000000000".equals(gpump1003Rsp.getTx_header().getSys_resp_code()))
			throw new CommonRuntimeException(gpump1003Rsp);
		
		String id_no = entity.getId_no();
		String id_type = entity.getId_type();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(id_type+id_no));
		LOGGER.debug("closeCustDeviceInfo: num: "+num+", id_type: "+id_type+", id_no: "+id_no+", ChannelId: "+reqMsg.getTx_body().getCom1().getSysChannelID());
		suapCustDeviceInfoService.closeWithRedis(num, id_type, id_no, reqMsg.getTx_body().getCom1().getSysChannelID());
		
		return rspMsg;
	}
	
	
	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		
		String rspCode = CheckParaUtil.checkParaByLocationIndex(reqMsg);
		if(rspCode != null)
			throw new CommonRuntimeException(rspCode);
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("sendGPU(").append(sendGPU)
//		.append(")/deleteCustDevInfo(").append(deleteCustDevInfo)
//		.append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	
	/**
	 * 	把请求信息封装成前置对应的请求报文
	 */
	private TxRequestMsg setGPUTxRequestMsg(TxRequestMsg reqMsg) {
		TxRequestMsg gpuRequestMsg = ServiceParaUtil.parseGpuRequestMsg(reqMsg);
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		INREC1006ServiceInVo entity = (INREC1006ServiceInVo) reqMsg.getTx_body().getEntity();
		
		GPUMP1005ServiceInVo gpump1005ServiceInVo = new GPUMP1005ServiceInVo();
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		if(locationIndex.equals("1")) {
			gpump1005ServiceInVo.setCust_id(entity.getId_no());			
		}else if(locationIndex.equals("2")) {
			gpump1005ServiceInVo.setCust_id(entity.getChannel_custno());
		}
		
		gpuRequestMsg.getTx_body().setEntity(gpump1005ServiceInVo);
		gpuRequestMsg.getTx_header().setSys_tx_code("GPUMP1003");
		
		return gpuRequestMsg;
	}


	

	
}
