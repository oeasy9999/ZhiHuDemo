package com.ccb.suap.cloud.access.beans;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.service.RedisService;
import com.ccb.suap.cloud.access.vo.INREC3003ServiceInVo;
import com.ccb.suap.cloud.access.vo.INREC3003ServiceOutVo;
import com.ccb.suap.cloud.access.vo.INRECCustomerElements;
import com.ccb.suap.util.log.TraceLog;

@Controller("INREC3003")
public class INREC3003_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC3003_Bean.class);
	
	@Autowired
	private RedisService redisService;
	
//	private RedisService redisService = InrecDaoFactory.getDaoManager().getRedisService();
	
	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n------------------调用INREC3003服务------------------");
		
		INREC3003ServiceInVo entity = (INREC3003ServiceInVo) reqMsg.getTx_body().getEntity();
		
		LOGGER.debug("check InVo: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		String custInfo = redisService.get(entity.getMobile_no());
		List<INRECCustomerElements> list = null;
		if(StringUtils.isEmpty(custInfo)) {
			list = new ArrayList<>();
		}else {
			list = JSONObject.parseArray(custInfo, INRECCustomerElements.class);
		}
		
		INREC3003ServiceOutVo inrec3003RspEntity = new INREC3003ServiceOutVo();
		inrec3003RspEntity.setResult_list_size(String.valueOf(list.size()));
		inrec3003RspEntity.setResult_list(list);
		
		rspMsg.getTx_body().setEntity(inrec3003RspEntity);
		
		return rspMsg;
	}
	

	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		INREC3003ServiceInVo entity = (INREC3003ServiceInVo) reqMsg.getTx_body().getEntity();
		String mobile_no = entity.getMobile_no();
		if(StringUtils.isEmpty(mobile_no))
			throw new CommonRuntimeException(Errorcode.MOBLENONOTNULL);
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
////		SB.append("selectCustInfo(").append(selectCustInfo).append(")");
//		SB.append("");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	


	

	
}
