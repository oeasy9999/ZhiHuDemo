package com.ccb.suap.util.log;

public class LogLevel {
    public static final int ERROR = 3;
    public static final int INFO = 2;
    public static final int DEBUG = 1;
}
