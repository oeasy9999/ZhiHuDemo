package com.ccb.suap.outbound.ccvea.vo;

public class SafeOutboundOutVo extends GatewayResponseMsg{
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
