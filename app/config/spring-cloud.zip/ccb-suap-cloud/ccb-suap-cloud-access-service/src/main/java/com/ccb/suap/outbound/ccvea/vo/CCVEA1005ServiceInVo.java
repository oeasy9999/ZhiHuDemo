package com.ccb.suap.outbound.ccvea.vo;

import java.io.Serializable;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class CCVEA1005ServiceInVo extends TxRequestMsgEntity implements Serializable{
	
	private static final long serialVersionUID = -5818357545061253073L;
	
	private String SYSTEM_TIME;							//客户端当前时间
	private String Stm_Chnl_ID;							//#系统渠道编号
	private String Stm_Chnl_Txn_CD;						//#系统渠道交易码
	private String Cst_ID;								//客户或账号、操作员号、流水
	private String Ext_Stm_Ctfn_Ecrp_Inf;				//交易类型（前端交易类型，用于识别不同交易）
	private String Cst_Nm;								//客户名称
	private String CrdTp_Cd;							//证件类型
	private String Crdt_No;								//证件号码
	private String Rmrk_1_Rcrd_Cntnt;					//手机号码
	private String base64_ECD_Txn_Inf;					//人脸视频流
	private String base64_Ecrp_Txn_Inf;					//位置信息内容
	private String Eqmt_Inf_Cntnt;						//设备信息内容
	private String Vd_1_Rqs_Tm;							//视频请求时间
	private String Vd_Rqs_ID;							//视频请求编号
	private String Vd_Synz_Ind;							//视频同步标志
	private String Strt_Rcd_Tms;						//开始录制时间戳
	private String End_Rcd_Tms;							//结束录制时间戳
	private String Rsrv_1_Inf_Dsc;						//备用字段1
	private String Rsrv_2_Inf_Dsc;						//备用字段2
	private String Rsrv_3_Inf_Dsc;						//备用字段3
	private String Rsrv_4_Inf_Dsc;						//备用字段4
	private String Rsrv_5_Inf_Dsc;						//备用字段5
	private String Ctfn_Ahn_Stm_ID;						//用户所属机构编号
	private String BLNG_INST_NM;						//用户所属机构名称
	private String Mt_Apl_PD_ECD;						//用户柜员号
	private String Tlr_Nm;								//用户柜员名称
	private String Ext_Stm_Only1_Ind;					//组件编号
	private String Ext_Stm_NM;							//组件名称
	private String Br_ID;								//分行编号
	private String Br_Nm;								//分行名称
	private String BDE_Node_No;							//安全节点号
	
	public String getSYSTEM_TIME() {
		return SYSTEM_TIME;
	}
	public void setSYSTEM_TIME(String sYSTEM_TIME) {
		SYSTEM_TIME = sYSTEM_TIME;
	}
	public String getStm_Chnl_ID() {
		return Stm_Chnl_ID;
	}
	public void setStm_Chnl_ID(String stm_Chnl_ID) {
		Stm_Chnl_ID = stm_Chnl_ID;
	}
	public String getStm_Chnl_Txn_CD() {
		return Stm_Chnl_Txn_CD;
	}
	public void setStm_Chnl_Txn_CD(String stm_Chnl_Txn_CD) {
		Stm_Chnl_Txn_CD = stm_Chnl_Txn_CD;
	}
	public String getCst_ID() {
		return Cst_ID;
	}
	public void setCst_ID(String cst_ID) {
		Cst_ID = cst_ID;
	}
	public String getExt_Stm_Ctfn_Ecrp_Inf() {
		return Ext_Stm_Ctfn_Ecrp_Inf;
	}
	public void setExt_Stm_Ctfn_Ecrp_Inf(String ext_Stm_Ctfn_Ecrp_Inf) {
		Ext_Stm_Ctfn_Ecrp_Inf = ext_Stm_Ctfn_Ecrp_Inf;
	}
	public String getCst_Nm() {
		return Cst_Nm;
	}
	public void setCst_Nm(String cst_Nm) {
		Cst_Nm = cst_Nm;
	}
	public String getCrdTp_Cd() {
		return CrdTp_Cd;
	}
	public void setCrdTp_Cd(String crdTp_Cd) {
		CrdTp_Cd = crdTp_Cd;
	}
	public String getCrdt_No() {
		return Crdt_No;
	}
	public void setCrdt_No(String crdt_No) {
		Crdt_No = crdt_No;
	}
	public String getRmrk_1_Rcrd_Cntnt() {
		return Rmrk_1_Rcrd_Cntnt;
	}
	public void setRmrk_1_Rcrd_Cntnt(String rmrk_1_Rcrd_Cntnt) {
		Rmrk_1_Rcrd_Cntnt = rmrk_1_Rcrd_Cntnt;
	}
	public String getBase64_ECD_Txn_Inf() {
		return base64_ECD_Txn_Inf;
	}
	public void setBase64_ECD_Txn_Inf(String base64_ECD_Txn_Inf) {
		this.base64_ECD_Txn_Inf = base64_ECD_Txn_Inf;
	}
	public String getBase64_Ecrp_Txn_Inf() {
		return base64_Ecrp_Txn_Inf;
	}
	public void setBase64_Ecrp_Txn_Inf(String base64_Ecrp_Txn_Inf) {
		this.base64_Ecrp_Txn_Inf = base64_Ecrp_Txn_Inf;
	}
	public String getEqmt_Inf_Cntnt() {
		return Eqmt_Inf_Cntnt;
	}
	public void setEqmt_Inf_Cntnt(String eqmt_Inf_Cntnt) {
		Eqmt_Inf_Cntnt = eqmt_Inf_Cntnt;
	}
	public String getVd_1_Rqs_Tm() {
		return Vd_1_Rqs_Tm;
	}
	public void setVd_1_Rqs_Tm(String vd_1_Rqs_Tm) {
		Vd_1_Rqs_Tm = vd_1_Rqs_Tm;
	}
	public String getVd_Rqs_ID() {
		return Vd_Rqs_ID;
	}
	public void setVd_Rqs_ID(String vd_Rqs_ID) {
		Vd_Rqs_ID = vd_Rqs_ID;
	}
	public String getVd_Synz_Ind() {
		return Vd_Synz_Ind;
	}
	public void setVd_Synz_Ind(String vd_Synz_Ind) {
		Vd_Synz_Ind = vd_Synz_Ind;
	}
	public String getStrt_Rcd_Tms() {
		return Strt_Rcd_Tms;
	}
	public void setStrt_Rcd_Tms(String strt_Rcd_Tms) {
		Strt_Rcd_Tms = strt_Rcd_Tms;
	}
	public String getEnd_Rcd_Tms() {
		return End_Rcd_Tms;
	}
	public void setEnd_Rcd_Tms(String end_Rcd_Tms) {
		End_Rcd_Tms = end_Rcd_Tms;
	}
	public String getRsrv_1_Inf_Dsc() {
		return Rsrv_1_Inf_Dsc;
	}
	public void setRsrv_1_Inf_Dsc(String rsrv_1_Inf_Dsc) {
		Rsrv_1_Inf_Dsc = rsrv_1_Inf_Dsc;
	}
	public String getRsrv_2_Inf_Dsc() {
		return Rsrv_2_Inf_Dsc;
	}
	public void setRsrv_2_Inf_Dsc(String rsrv_2_Inf_Dsc) {
		Rsrv_2_Inf_Dsc = rsrv_2_Inf_Dsc;
	}
	public String getRsrv_3_Inf_Dsc() {
		return Rsrv_3_Inf_Dsc;
	}
	public void setRsrv_3_Inf_Dsc(String rsrv_3_Inf_Dsc) {
		Rsrv_3_Inf_Dsc = rsrv_3_Inf_Dsc;
	}
	public String getRsrv_4_Inf_Dsc() {
		return Rsrv_4_Inf_Dsc;
	}
	public void setRsrv_4_Inf_Dsc(String rsrv_4_Inf_Dsc) {
		Rsrv_4_Inf_Dsc = rsrv_4_Inf_Dsc;
	}
	public String getRsrv_5_Inf_Dsc() {
		return Rsrv_5_Inf_Dsc;
	}
	public void setRsrv_5_Inf_Dsc(String rsrv_5_Inf_Dsc) {
		Rsrv_5_Inf_Dsc = rsrv_5_Inf_Dsc;
	}
	public String getCtfn_Ahn_Stm_ID() {
		return Ctfn_Ahn_Stm_ID;
	}
	public void setCtfn_Ahn_Stm_ID(String ctfn_Ahn_Stm_ID) {
		Ctfn_Ahn_Stm_ID = ctfn_Ahn_Stm_ID;
	}
	public String getBLNG_INST_NM() {
		return BLNG_INST_NM;
	}
	public void setBLNG_INST_NM(String bLNG_INST_NM) {
		BLNG_INST_NM = bLNG_INST_NM;
	}
	public String getMt_Apl_PD_ECD() {
		return Mt_Apl_PD_ECD;
	}
	public void setMt_Apl_PD_ECD(String mt_Apl_PD_ECD) {
		Mt_Apl_PD_ECD = mt_Apl_PD_ECD;
	}
	public String getTlr_Nm() {
		return Tlr_Nm;
	}
	public void setTlr_Nm(String tlr_Nm) {
		Tlr_Nm = tlr_Nm;
	}
	public String getExt_Stm_Only1_Ind() {
		return Ext_Stm_Only1_Ind;
	}
	public void setExt_Stm_Only1_Ind(String ext_Stm_Only1_Ind) {
		Ext_Stm_Only1_Ind = ext_Stm_Only1_Ind;
	}
	public String getExt_Stm_NM() {
		return Ext_Stm_NM;
	}
	public void setExt_Stm_NM(String ext_Stm_NM) {
		Ext_Stm_NM = ext_Stm_NM;
	}
	public String getBr_ID() {
		return Br_ID;
	}
	public void setBr_ID(String br_ID) {
		Br_ID = br_ID;
	}
	public String getBr_Nm() {
		return Br_Nm;
	}
	public void setBr_Nm(String br_Nm) {
		Br_Nm = br_Nm;
	}
	public String getBDE_Node_No() {
		return BDE_Node_No;
	}
	public void setBDE_Node_No(String bDE_Node_No) {
		BDE_Node_No = bDE_Node_No;
	}
	
	@Override
	public String toString() {
		return "CCVEA1005ServiceInVo [SYSTEM_TIME=" + SYSTEM_TIME + ", Stm_Chnl_ID=" + Stm_Chnl_ID
				+ ", Stm_Chnl_Txn_CD=" + Stm_Chnl_Txn_CD + ", Cst_ID=" + Cst_ID + ", Ext_Stm_Ctfn_Ecrp_Inf="
				+ Ext_Stm_Ctfn_Ecrp_Inf + ", Cst_Nm=" + Cst_Nm + ", CrdTp_Cd=" + CrdTp_Cd + ", Crdt_No=" + Crdt_No
				+ ", Rmrk_1_Rcrd_Cntnt=" + Rmrk_1_Rcrd_Cntnt + ", base64_ECD_Txn_Inf=" + base64_ECD_Txn_Inf
				+ ", base64_Ecrp_Txn_Inf=" + base64_Ecrp_Txn_Inf + ", Eqmt_Inf_Cntnt=" + Eqmt_Inf_Cntnt
				+ ", Vd_1_Rqs_Tm=" + Vd_1_Rqs_Tm + ", Vd_Rqs_ID=" + Vd_Rqs_ID + ", Vd_Synz_Ind=" + Vd_Synz_Ind
				+ ", Strt_Rcd_Tms=" + Strt_Rcd_Tms + ", End_Rcd_Tms=" + End_Rcd_Tms + ", Rsrv_1_Inf_Dsc="
				+ Rsrv_1_Inf_Dsc + ", Rsrv_2_Inf_Dsc=" + Rsrv_2_Inf_Dsc + ", Rsrv_3_Inf_Dsc=" + Rsrv_3_Inf_Dsc
				+ ", Rsrv_4_Inf_Dsc=" + Rsrv_4_Inf_Dsc + ", Rsrv_5_Inf_Dsc=" + Rsrv_5_Inf_Dsc + ", Ctfn_Ahn_Stm_ID="
				+ Ctfn_Ahn_Stm_ID + ", BLNG_INST_NM=" + BLNG_INST_NM + ", Mt_Apl_PD_ECD=" + Mt_Apl_PD_ECD + ", Tlr_Nm="
				+ Tlr_Nm + ", Ext_Stm_Only1_Ind=" + Ext_Stm_Only1_Ind + ", Ext_Stm_NM=" + Ext_Stm_NM + ", Br_ID="
				+ Br_ID + ", Br_Nm=" + Br_Nm + ", BDE_Node_No=" + BDE_Node_No + "]";
	}
	
	
	
	
	
	
	
	
	
	
}
