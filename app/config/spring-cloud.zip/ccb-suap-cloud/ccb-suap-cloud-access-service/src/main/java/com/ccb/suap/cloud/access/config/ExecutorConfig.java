package com.ccb.suap.cloud.access.config;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;

@Configuration
@EnableAsync
public class ExecutorConfig {
	
	@Bean("faceLogExecutor")
	public Executor faceLogExecutor() {
		
		String ThreadPoolConfig = SuapSysParaUtil.getStrPara("FACELOG_EXECUTOR", "100,100,2147483647,FACELOG_,60");
		String[] ThreadPoolConfigArr = ThreadPoolConfig.split(",");
		
		int corePoolSize = Integer.parseInt(ThreadPoolConfigArr[0]);
		int maxPoolSize = Integer.parseInt(ThreadPoolConfigArr[1]);
		int queueCapacity = Integer.parseInt(ThreadPoolConfigArr[2]);
		String threadNamePrefix = ThreadPoolConfigArr[3];
		int keepAliveSeconds = Integer.parseInt(ThreadPoolConfigArr[4]);
		
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		//核心线程数
        executor.setCorePoolSize(corePoolSize);
        //指定最大线程数
        executor.setMaxPoolSize(maxPoolSize);
        //队列中最大的数目
        executor.setQueueCapacity(queueCapacity);
        //线程名称前缀
        executor.setThreadNamePrefix(threadNamePrefix);
        //rejection-policy：当pool已经达到max size的时候，如何处理新任务
        //CALLER_RUNS：不在新线程中执行任务，而是由调用者所在的线程来执行
        //对拒绝task的处理策略
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        //线程空闲后的最大存活时间
        executor.setKeepAliveSeconds(keepAliveSeconds);
        //加载
        executor.initialize();
        
        return executor;
        
	}
	
	
	@Bean("traceLogExecutor")
	public Executor traceLogExecutor() {
		
		String ThreadPoolConfig = SuapSysParaUtil.getStrPara("TRACELOG_EXECUTOR", "100,100,2147483647,TRACELOG_,60");
		String[] ThreadPoolConfigArr = ThreadPoolConfig.split(",");
		
		int corePoolSize = Integer.parseInt(ThreadPoolConfigArr[0]);
		int maxPoolSize = Integer.parseInt(ThreadPoolConfigArr[1]);
		int queueCapacity = Integer.parseInt(ThreadPoolConfigArr[2]);
		String threadNamePrefix = ThreadPoolConfigArr[3];
		int keepAliveSeconds = Integer.parseInt(ThreadPoolConfigArr[4]);
		
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		//核心线程数
		executor.setCorePoolSize(corePoolSize);
		//指定最大线程数
		executor.setMaxPoolSize(maxPoolSize);
		//队列中最大的数目
		executor.setQueueCapacity(queueCapacity);
		//线程名称前缀
		executor.setThreadNamePrefix(threadNamePrefix);
		//rejection-policy：当pool已经达到max size的时候，如何处理新任务
		//CALLER_RUNS：不在新线程中执行任务，而是由调用者所在的线程来执行
		//对拒绝task的处理策略
		executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		//线程空闲后的最大存活时间
		executor.setKeepAliveSeconds(keepAliveSeconds);
		//加载
		executor.initialize();
		
		return executor;
		
	}
	
	
	
	
	
	
	
	
	
	
	
}


