package com.ccb.suap.cloud.access.mapper;

import org.apache.ibatis.annotations.Select;

import com.ccb.suap.cloud.access.model.SuapWhiteListModel;

public interface SuapWhiteListMapper {
	
	@Select("SELECT IDTYPE,db_decrypt(IDNUMBER) IDNUMBER,CUSTNAME,REMARKS FROM SUAP_WHITELIST WHERE IDNUMBER=db_encrypt(#{idnumber})")
	SuapWhiteListModel selectOne(String idnumber);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
