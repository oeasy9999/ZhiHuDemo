package com.ccb.suap.outbound.ccvea.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class CCVEA1001ServiceOutVo extends TxResponseMsgEntity{
	
	private String Smlr_Dgr_Cmnt;					//核对结果
	private String Cst_Nm;							//客户名称
	private String Crdt_No;							//证件号码
	private String Aflt_Inf_Dsc;					//签发机关
	private String Ftr_Col_Tm;						//发送时间
	private String base64_Ecrp_Txn_Inf;				//照片
	private String Cmp_Rslt_Ind;					//证件状态
	private String Rsrv_2_Inf_Dsc;					//备注
	
	public String getSmlr_Dgr_Cmnt() {
		return Smlr_Dgr_Cmnt;
	}
	public void setSmlr_Dgr_Cmnt(String smlr_Dgr_Cmnt) {
		Smlr_Dgr_Cmnt = smlr_Dgr_Cmnt;
	}
	public String getCst_Nm() {
		return Cst_Nm;
	}
	public void setCst_Nm(String cst_Nm) {
		Cst_Nm = cst_Nm;
	}
	public String getCrdt_No() {
		return Crdt_No;
	}
	public void setCrdt_No(String crdt_No) {
		Crdt_No = crdt_No;
	}
	public String getAflt_Inf_Dsc() {
		return Aflt_Inf_Dsc;
	}
	public void setAflt_Inf_Dsc(String aflt_Inf_Dsc) {
		Aflt_Inf_Dsc = aflt_Inf_Dsc;
	}
	public String getFtr_Col_Tm() {
		return Ftr_Col_Tm;
	}
	public void setFtr_Col_Tm(String ftr_Col_Tm) {
		Ftr_Col_Tm = ftr_Col_Tm;
	}
	public String getBase64_Ecrp_Txn_Inf() {
		return base64_Ecrp_Txn_Inf;
	}
	public void setBase64_Ecrp_Txn_Inf(String base64_Ecrp_Txn_Inf) {
		this.base64_Ecrp_Txn_Inf = base64_Ecrp_Txn_Inf;
	}
	public String getCmp_Rslt_Ind() {
		return Cmp_Rslt_Ind;
	}
	public void setCmp_Rslt_Ind(String cmp_Rslt_Ind) {
		Cmp_Rslt_Ind = cmp_Rslt_Ind;
	}
	public String getRsrv_2_Inf_Dsc() {
		return Rsrv_2_Inf_Dsc;
	}
	public void setRsrv_2_Inf_Dsc(String rsrv_2_Inf_Dsc) {
		Rsrv_2_Inf_Dsc = rsrv_2_Inf_Dsc;
	}
	
	@Override
	public String toString() {
		return "CCVEA1001ServiceOutVo [Smlr_Dgr_Cmnt=" + Smlr_Dgr_Cmnt + ", Cst_Nm=" + Cst_Nm + ", Crdt_No=" + Crdt_No
				+ ", Aflt_Inf_Dsc=" + Aflt_Inf_Dsc + ", Ftr_Col_Tm=" + Ftr_Col_Tm + ", base64_Ecrp_Txn_Inf="
				+ base64_Ecrp_Txn_Inf + ", Cmp_Rslt_Ind=" + Cmp_Rslt_Ind + ", Rsrv_2_Inf_Dsc=" + Rsrv_2_Inf_Dsc + "]";
	}
	
	
	
	

	
	
	
	
	
}
