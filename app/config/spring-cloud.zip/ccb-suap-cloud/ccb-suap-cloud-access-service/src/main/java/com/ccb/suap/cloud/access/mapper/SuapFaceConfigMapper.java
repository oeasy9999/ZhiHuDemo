package com.ccb.suap.cloud.access.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.UpdateProvider;

import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;

@Mapper
public interface SuapFaceConfigMapper {
	
	@Insert("insert into SUAP_FACE_CONFIG(CHANNELCODE,TRADECODE,TXCODE,BRANCHNO,DESTABLE,ISSEPARATE,SEPARATENUM,SEPARATEINDEX,ISHACKCHECK,HACKTHRESHOLD,LEVELTYPE,LEVELGRADE,LOCKNUM,SIMILARITY,ISPICTURE,IDVERIFY,IDVERIFY_MODE,ECUAC0183_MODE,RHVERIFY,ISC00004,DISTPIC,ISPOLICE,REGPIC,HITNUM,ISSYNC1TO1,LOCATION_SOURCE,LOCATION,LOCATIONINDEX,REMARK) values(#{channelcode},#{tradecode},#{txcode},#{branchno},#{destable},#{isseparate},#{separatenum},#{separateindex},#{ishackcheck},#{hackthreshold},#{leveltype},#{levelgrade},#{locknum},#{similarity},#{ispicture},#{idverify},#{idverify_mode},#{ecuac0183_mode},#{rhverify},#{isc00004},#{distpic},#{ispolice},#{regpic},#{hitnum},#{issync1to1},#{location_source},#{location},#{locationindex},#{remark})")
	int insert(SuapFaceConfigModel suapFaceConfigModel);
	
	@Select("SELECT * FROM SUAP_FACE_CONFIG WHERE CHANNELCODE=#{channelcode} AND TRADECODE=#{tradecode} AND TXCODE=#{txcode}")
	SuapFaceConfigModel selectOne(@Param("channelcode")String channelcode,@Param("tradecode")String tradecode,@Param("txcode")String txcode);
	
	@Select("select count(*) from SUAP_FACE_CONFIG")
	int count();
	
	@Delete("delete from SUAP_FACE_CONFIG")
	int deleteAll();
	
	@Delete("delete from SUAP_FACE_CONFIG WHERE CHANNELCODE=#{channelcode} AND TRADECODE=#{tradecode} AND TXCODE=#{txcode}")
	int deleteOne(@Param("channelcode")String channelcode,@Param("tradecode")String tradecode,@Param("txcode")String txcode);
	
	@Select("select * from SUAP_FACE_CONFIG")
	List<SuapFaceConfigModel> selectAll();
	
	@UpdateProvider(type=SuapFaceConfigMapperProvider.class,method="update")
	int update(SuapFaceConfigModel suapFaceConfigModel);
	
}
