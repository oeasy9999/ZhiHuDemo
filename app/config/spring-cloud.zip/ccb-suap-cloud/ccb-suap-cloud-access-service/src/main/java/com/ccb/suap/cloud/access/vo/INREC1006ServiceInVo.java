package com.ccb.suap.cloud.access.vo;

public class INREC1006ServiceInVo extends INRECBaseServiceInVo{
	
	
	
	
	
	
	
	
}
