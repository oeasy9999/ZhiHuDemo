package com.ccb.suap.cloud.access.exception;

import org.apache.commons.lang.StringUtils;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.util.log.TraceLog;

public class CommonRuntimeException extends RuntimeException{
	
	private static final long serialVersionUID = 6509661109396219573L;
	
	private TxResponseMsg rspMsg;
	private String rspCode;
	private String rspDesc;
	private String status;
	private SuapFaceLogModel faceLog;
	private TraceLog traceLog;
	private TxResponseMsg sourceRspMsg;
	private String remarks;

	public CommonRuntimeException() {
		super();
	}

	public CommonRuntimeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public CommonRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * 封装异常(错误码)
	 * @param rspCode
	 */
	public CommonRuntimeException(String rspCode) {
		super(rspCode);
		this.rspCode = rspCode;
	}

	/**
	 * 封装异常(错误码，状态)
	 * @param rspCode
	 * @param status
	 */
	public CommonRuntimeException(String rspCode, String status) {
		super(rspCode);
		this.rspCode = rspCode;
		this.status = status;
	}
	
	/**
	 * 封装异常(错误码，状态，备注)
	 * @param rspCode
	 * @param status
	 * @param remarks
	 */
	public CommonRuntimeException(String rspCode, String status, String remarks) {
		super(rspCode);
		this.rspCode = rspCode;
		this.status = status;
		this.remarks = remarks;
	}
	
	/**
	 *	 封装异常(错误码，错误描述，状态，备注)
	 * @param rspCode
	 * @param rspDesc
	 * @param status
	 * @param remarks
	 */
	public CommonRuntimeException(String rspCode, String rspDesc, String status, String remarks) {
		super(rspCode);
		this.rspCode = rspCode;
		this.rspDesc = rspDesc;
		this.status = status;
		this.remarks = remarks;
	}
	
	public CommonRuntimeException(Throwable cause) {
		super(cause);
	}
	
	/**
	 * 封装异常(外呼返回信息(非"000000000000"))
	 * @param sourceRspMsg
	 */
	public CommonRuntimeException(TxResponseMsg sourceRspMsg) {
		this.sourceRspMsg = sourceRspMsg;
	}
	
	/**
	 * 封装异常(外呼返回信息(非"000000000000")，备注)
	 * @param sourceRspMsg
	 * @param remarks
	 */
	public CommonRuntimeException(TxResponseMsg sourceRspMsg, String remarks) {
		this.sourceRspMsg = sourceRspMsg;
		this.remarks = remarks;
	}
	
	/**
	 * 封装异常(响应报文，错误码，日志)
	 * @param rspMsg
	 * @param rspCode
	 * @param faceLog
	 */
	public CommonRuntimeException(TxResponseMsg rspMsg, String rspCode, SuapFaceLogModel faceLog, TraceLog traceLog) {
		this.rspMsg = rspMsg;
		this.rspCode = rspCode;
		this.faceLog = faceLog;
		this.traceLog = traceLog;
		
	}
	
	/**
	 * 封装异常(响应报文，错误码，日志，备注)
	 * @param rspMsg
	 * @param rspCode
	 * @param faceLog
	 * @param remarks
	 */
	public CommonRuntimeException(TxResponseMsg rspMsg, String rspCode, SuapFaceLogModel faceLog, String remarks) {
		this.rspMsg = rspMsg;
		this.rspCode = rspCode;
		this.faceLog = faceLog;
		this.remarks = remarks;
		
	}
	
	
	public TxResponseMsg getRspMsg() {
		return rspMsg;
	}

	public void setRspMsg(TxResponseMsg rspMsg) {
		this.rspMsg = rspMsg;
	}

	public String getRspCode() {
		return rspCode;
	}

	public void setRspCode(String rspCode) {
		this.rspCode = rspCode;
	}
	
	public String getRspDesc() {
		return rspDesc;
	}

	public void setRspDesc(String rspDesc) {
		this.rspDesc = rspDesc;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public SuapFaceLogModel getFaceLog() {
		return faceLog;
	}

	public TraceLog getTraceLog() {
		return traceLog;
	}

	public void setTraceLog(TraceLog traceLog) {
		this.traceLog = traceLog;
	}

	public void setFaceLog(SuapFaceLogModel faceLog) {
		this.faceLog = faceLog;
	}
	
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	
	/**
	 * 	封装处理异常对象
	 * @param rspMsg
	 * @param rspCode
	 * @param faceLog
	 * @return
	 */
	public CommonRuntimeException newInstance(TxResponseMsg rspMsg, String rspCode, SuapFaceLogModel faceLog, TraceLog traceLog) {
		this.rspMsg = rspMsg;
		this.rspCode = rspCode;
		this.faceLog = faceLog;
		this.traceLog = traceLog;
		if(StringUtils.isNotEmpty(remarks))
			faceLog.setRemarks(remarks);
		//封装异常信息，以sourceRspMsg优先
		if(sourceRspMsg != null)
			parseRspMsg();
		return this;
	}

	/**
	 * 	封装异常信息
	 */
	private void parseRspMsg() {
//		TxResponseMsgHead rspHeader = rspMsg.getTx_header();
//		TxResponseMsgHead sourceRspHeader = sourceRspMsg.getTx_header();
//		rspHeader.setSys_resp_code(sourceRspHeader.getSys_resp_code());
//		rspHeader.setSys_resp_desc(sourceRspHeader.getSys_resp_desc());
		
		TxResponseMsgHead sourceRspHeader = sourceRspMsg.getTx_header();
		this.rspCode = sourceRspHeader.getSys_resp_code();
		this.rspDesc = sourceRspHeader.getSys_resp_desc();
	}

	@Override
	public String toString() {
		return "CommonRuntimeException [rspMsg=" + rspMsg + ", rspCode=" + rspCode + ", faceLog=" + faceLog
				+ ", sourceRspMsg=" + sourceRspMsg + ", remarks=" + remarks + "]";
	}

	
	

	
	
	

	
	
	
	
	
	

	
	
	
	
	
	
}
