//package com.ccb.suap.util.log;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
//import com.ccb.suap.util.log.base.LoggerSingleFile;
//
//
///**
// * 同步记录日志，对于高并发会影响服务器性能
// * 使用log4j提供不同级别的日志记录工具类
// * 
// * <p>Title: </p>
// * <p>Description: 日志工具类，use log4j</p>
// * <p>Copyright: Copyright (c) 2014</p>
// * <p>Company: anydef.com.cn</p>
// * @author pengdy
// * @version 1.0
// */
//public class LogUtil {
//	private static final Logger log = LoggerFactory.getLogger(LogUtil.class);
//	private static LoggerSingleFile loggers = null;
//
//	
//	public static synchronized LoggerSingleFile createLogger() throws Exception{
//	    if (loggers == null) {
//	    	loggers = new LoggerSingleFile();
//	    }
//	    return loggers;
//	}
//	
//	public static void tlog(String msg) {
//		String isPrint = SuapSysParaUtil.getStrPara("IS_PRINT_OUT_TLOG", "1");
//		if("1".equals(isPrint)) {
//			log.info(msg);
//		}
//	}
//	
//	public static void log(String msg){
//		log(msg,null);
//	}
//	
//	/**
//	 * 将日志信息msg记录到txcode.log日志文件
//	 * @param msg
//	 * @param txcode
//	 * @return
//	 */
//	public static boolean log(String msg, String txcode){
//		String logConsoleEnabled = SuapSysParaUtil.getStrPara("LOG_CONSOLE_ENABLED", "false");
//		if ("true".equalsIgnoreCase(logConsoleEnabled)) {
//			System.out.println(msg);
//		}
//		try{
//			if (loggers == null) {
//		    	loggers = new LoggerSingleFile();
//		    }
//			if(txcode==null || "".equals(txcode)){
//				txcode = "IOTEMP";
//			}
//			if("1".equals(SuapSysParaUtil.getStrPara("IS_OFF_TRANSLOG", "0"))) {
//				return true;
//			}
//			return loggers.log(msg, txcode);
////			if("0".equals(SysParaUtil.getStrPara("IS_OFF_TRANSLOG", "1"))) {
////				transLogger.setLevel(Level.OFF);
////	        } else {
////	        	transLogger.setLevel(Level.INFO);
////	        }
////			transLogger.info(msg);
////			return true;
//		}catch(Exception e){
//			e.printStackTrace();
//			return false;
//		}
//	}
//	/**
//	 * 实现debug的方法，记录Debug级别日志
//	 * 
//	 * @param s
//	 */
//	public static void debug(String s) {
//		String logConsoleEnabled = SuapSysParaUtil.getStrPara("LOG_CONSOLE_ENABLED", "false");
//		if ("true".equalsIgnoreCase(logConsoleEnabled)) {
//			System.out.println(s);
//		}
//
//		String logDebugEnabled = SuapSysParaUtil.getStrPara("LOG_DEBUG_ENABLED", "false");
//		if (!"true".equalsIgnoreCase(logDebugEnabled)) {
//			return;
//		}
//
//		log.debug(s);
//	}
//
//	/**
//	 * 记录Info级别日志
//	 * @param s
//	 */
//	public static void info(String s) {
//		String logConsoleEnabled = SuapSysParaUtil.getStrPara("LOG_CONSOLE_ENABLED", "false");
//		if ("true".equalsIgnoreCase(logConsoleEnabled)) {
//			System.out.println(s);
//		}
//		
//		String logInfoEnabled = SuapSysParaUtil.getStrPara("LOG_INFO_ENABLED", "false");
//		if (!"true".equalsIgnoreCase(logInfoEnabled)) {
//			return;
//		}
//
//		log.info(s);
//	}
//
//	/**
//	 * 记录Warn级别日志
//	 * @param s
//	 */
//	public static void warn(String s) {
//		String logConsoleEnabled = SuapSysParaUtil.getStrPara("LOG_CONSOLE_ENABLED", "false");
//		if ("true".equalsIgnoreCase(logConsoleEnabled)) {
//			System.out.println(s);
//		}
//		
//		String logWarnEnabled = SuapSysParaUtil.getStrPara("LOG_WARN_ENABLED", "false");
//		if (!"true".equalsIgnoreCase(logWarnEnabled)) {
//			return;
//		}
//		
//		log.warn(s);
//	}
//
//	/**
//	 * 记录Error级别日志
//	 * @param s
//	 */
//	public static void error(String s) {
//		String logConsoleEnabled = SuapSysParaUtil.getStrPara("LOG_CONSOLE_ENABLED", "false");
//		if ("true".equalsIgnoreCase(logConsoleEnabled)) {
//			System.out.println(s);
//		}
//		
//		String logErrorEnabled = SuapSysParaUtil.getStrPara("LOG_ERROR_ENABLED", "true");
//		if (!"true".equalsIgnoreCase(logErrorEnabled)) {
//			return;
//		}
//		
//		log.error(s);
//	}
//	
//	/**
//	 * 记录Error级别日志
//	 * @param s
//	 * @param tr 异常对象
//	 */
//	public static void error(String s,Throwable tr) {
//		String logErrorEnabled = SuapSysParaUtil.getStrPara("LOG_ERROR_ENABLED", "true");
//		if (!"true".equalsIgnoreCase(logErrorEnabled)) {
//			return;
//		}
//		
//		log.error(s, tr);
//	}
//	
//	/**
//	 * 记录Error级别日志
//	 * @param tr 异常对象
//	 */
//	public static void error(Throwable tr) {
//		String logErrorEnabled = SuapSysParaUtil.getStrPara("LOG_ERROR_ENABLED", "true");
//		if (!"true".equalsIgnoreCase(logErrorEnabled)) {
//			return;
//		}
//		
//		log.error("", tr);
//	}
//}