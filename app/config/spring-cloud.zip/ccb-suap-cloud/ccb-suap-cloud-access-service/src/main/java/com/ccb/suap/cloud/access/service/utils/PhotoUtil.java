package com.ccb.suap.cloud.access.service.utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.threadLocal.CosttimeThreadLocal;
import com.ccb.suap.util.file.FileCipherUtils;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

@SuppressWarnings("restriction")
public class PhotoUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	/**
	 * 计算base64加密前的文件大小
	 * @param image base64加密后的字符串
	 * @return	原始文件大小
	 */
	public static int getSize(String image) {
		if(image == null) return -1;
		
		image = image.replaceAll("\r\n", "");
		Integer equalIndex = image.indexOf("=");
		if(equalIndex>0) image = image.substring(0, equalIndex);
		
		Integer strLength = image.length();
		Integer num = 0;
		if(strLength%8 > 4) {
			num = 2;
		}else if (strLength%8 > 0) {
			num = 1;
		}else {
			num = 0;
		}
		
		Integer size = strLength-(strLength/8)*2-num;
		
		return size;
	}
	
	
	/**
	 * 判断base64字符串源文件是否超出指定大小,超出返回false
	 * @param image	base64字符串
	 * @param size	指定大小，单位为字节
	 * @return
	 */
	public static boolean judgeSizeByByte(String image, int size) {
		
		if(image == null) return false;
		if(size <= 0) return true;
		
		int size2 = getSize(image);
		if(size2 > size) return false;
		
		return true;
	}
	
	
	/**
	 * 判断base64字符串源文件是否超出指定大小,超出返回false
	 * @param image	base64字符串
	 * @param size	指定大小，单位为KB,数据类型为int
	 * @return
	 */
	public static boolean judgeSizeByKB(String image, int size) {
		return judgeSizeByKB(image, (double)size);
	}
	
	
	/**
	 * 判断base64字符串源文件是否超出指定大小,超出返回false
	 * @param image	base64字符串
	 * @param size	指定大小，单位为KB,数据类型为double
	 * @return
	 */
	public static boolean judgeSizeByKB(String image, double size) {
		if(image == null) return false;
		if(size <= 0) return true;
		
		int size2 = getSize(image);
		if(size2 > 1024*size) return false;
		
		return true;
	}
	
	
	/**
	 * 判断base64字符串源文件是否超出指定大小,超出返回false
	 * @param image	base64字符串
	 * @param size	指定大小，单位为MB,数据类型为int
	 * @return
	 */
	public static boolean judgeSizeByMB(String image, int size) {
		return judgeSizeByMB(image, (double)size);
	}
	
	
	/**
	 * 判断base64字符串源文件是否超出指定大小,超出返回false
	 * @param image	base64字符串
	 * @param size	指定大小，单位为MB,数据类型为double
	 * @return
	 */
	public static boolean judgeSizeByMB(String image, double size) {
		if(image == null) return false;
		if(size <= 0) return true;
		
		int size2 = getSize(image);
		if(size2 > 1024*1024*size) return false;
		
		return true;
	}
	
	
	/**
	 * 	保存图片到指定文件夹(统计时间,描述默认为savePhoto)
	 * @param image
	 * @param path
	 */
	public static void savePhotoWithTime(String image, String path) {
		savePhotoWithTime(image, path, "savePhoto");
	}
	
	
	/**
	 * 	保存图片到指定文件夹(统计时间并指定描述)
	 * @param image
	 * @param path
	 */
	public static void savePhotoWithTime(String image, String path, String title) {
		long start = System.currentTimeMillis();
		savePhoto(image, path);
		long costtime = System.currentTimeMillis() - start;
		CosttimeThreadLocal.add(title, costtime);
	}
	
	
	/**
	 * 	保存图片到指定文件夹
	 * @param entity
	 * @return	保存路径
	 */
	public static void savePhoto(String image, String path) {
		if(StringUtils.isEmpty(path)) {
			LOGGER.error("Photo Path error: Path is null!");
			throw new CommonRuntimeException(Errorcode.BSPATHNOTFOUND);
		}
		if(StringUtils.isEmpty(image)) {
			LOGGER.error("Photo is null!");
			throw new CommonRuntimeException(Errorcode.FACEIMGNOTNULL);
		}
		
		try {
			BASE64Decoder decoder = new BASE64Decoder();
			
			File file = new File(path);
			if(!file.getParentFile().exists())
				file.getParentFile().mkdirs();
			FileCipherUtils.EecFileBuffer(Constants.DEFAULT_FILE_KEY, path, decoder.decodeBuffer(image));
		} catch (Exception e) {
			LOGGER.error("save photo fail: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.PHOTOSAVEERROR, "02", e.getMessage());
		}
		
	}
	
	
	/**
	 * 	根据年月日时分获取图片路径
	 * @param basePathKey	根路径
	 * @param picType	图片分类
	 * @param picName	图片名字
	 * @return 图片保存路径
	 */
	public static String getPath(String basePath, String picType, String picName) {
		if(StringUtils.isEmpty(basePath)) {
			LOGGER.error("Face Config error: BASEPATH is null!");
			throw new CommonRuntimeException(Errorcode.BSPATHNOTFOUND);
		}
		if(!basePath.endsWith("/"))
			basePath = basePath + "/";
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH-mm");
		String time = sdf.format(new Date());
		time = time.substring(0, time.length()-1);
		
		StringBuilder path = new StringBuilder();
		path.append(basePath);
		if(StringUtils.isNotBlank(picType))
			path.append(picType);
		
		path.append("/")
		.append(time)
		.append("/")
		.append(picName);
		
		return path.toString();
	}
	
	
	/**
	 * 	根据年月日时分获取图片路径
	 * @param basePathKey	根路径
	 * @param picName	图片名字
	 * @return 图片保存路径
	 */
	public static String getPath(String basePath, String picName) {
		
		return getPath(basePath, null, picName);
	}
	
	
	/**
	 * 	根据年月日时分获取图片路径
	 * @param basePathKey	参数表路径
	 * @param picType	图片分类
	 * @param picName	图片名字
	 * @return 图片保存路径
	 */
	public static String getPathByStrPara(String basePathKey, String picType, String picName) {
		String basePath = SuapSysParaUtil.getStrPara(basePathKey, null);
		if(StringUtils.isEmpty(basePath)) {
			LOGGER.error("Face Config error: FACEPICPATH is null!");
			throw new CommonRuntimeException(Errorcode.BSPATHNOTFOUND);
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH-mm");
		String time = sdf.format(new Date());
		time = time.substring(0, time.length()-1);
		
		StringBuilder path = new StringBuilder();
		path.append(basePath).append(picType)
		.append("/")
		.append(time)
		.append("/")
		.append(picName);
		
		return path.toString();
	}
	
	
	
	/**
	 * 	从本地读取图片(统计时间)
	 * @param path
	 * @return
	 * @throws Exception 
	 */
	public static String loadPhotoWithTime(String path){
		return loadPhotoWithTime(path, "loadPhoto");
	}
	
	
	/**
	 * 	从本地读取图片(统计时间，并指定描述)
	 * @param path
	 * @return
	 * @throws Exception 
	 */
	public static String loadPhotoWithTime(String path, String title){
		
		long start = System.currentTimeMillis();
		String image = loadPhoto(path);
		long costtime = System.currentTimeMillis() - start;
		
		CosttimeThreadLocal.add(title, costtime);
		
		return image;
	}
	
	
	/**
	 * 	从本地读取图片
	 * @param path
	 * @return
	 * @throws Exception 
	 */
	public static String loadPhoto(String path){
		if(StringUtils.isEmpty(path)) {
			LOGGER.error("photo path is null: "+path);
			throw new CommonRuntimeException(Errorcode.PHOTOPATHERROR);
		}
		
		String registry_photo = null;
		try {
			byte[] buffer = FileCipherUtils.DecFileBuffer(Constants.DEFAULT_FILE_KEY, path);
			BASE64Encoder encoder = new BASE64Encoder();
			registry_photo = encoder.encode(buffer);
		} catch (Exception e) {
			LOGGER.error("Load Photo Faild: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.PHO_LOADEERROR);
		}
		
		registry_photo = registry_photo.replaceAll("\r", "");
		registry_photo = registry_photo.replaceAll("\n", "");
		registry_photo = registry_photo.replaceAll(" ", "");
		
		return registry_photo;
	}
	
	
	
	
	
	
	
	
	
}
