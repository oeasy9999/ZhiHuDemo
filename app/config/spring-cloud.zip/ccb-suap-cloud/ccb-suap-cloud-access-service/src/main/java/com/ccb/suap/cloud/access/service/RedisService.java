package com.ccb.suap.cloud.access.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.service.utils.RedisUtil;

@Service
public class RedisService {
	
	@Autowired
	private RedisUtil redisUtil;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	
	/**
	 * 	获取非空数据，空则报错
	 * @param key
	 */
	public String getNotNull(String key) {
		
		String value = get(key);
		
		if(value == null)
			throw new CommonRuntimeException(Errorcode.REDIS_GETERROR, "02", "get redis fail, key = " + key);
		
		return value;
	}
	
	
	/**
	 * 	获取数据，允许为空
	 * @param key
	 * @return
	 */
	public String get(String key) {
		
		String value = null;
		try {
			value = (String) redisUtil.get(key);
		} catch (Exception e) {
			LOGGER.error("get redis fail, key = "+key,e);
//			throw new CommonRuntimeException(Errorcode.REDIS_GETERROR, "02", "get redis fail, key = "+ key + ", "+ e.getMessage());
		}
		
		return value;
	}
	
	
	public void set(String key, String value) {
		
		boolean flag = false;
		try {
			flag = redisUtil.set(key, value);
		} catch (Exception e) {
			LOGGER.error("set redis fail, key = " + key + ", value = " + value,e);
			throw new CommonRuntimeException(Errorcode.REDIS_SAVFAILD, "02", "set redis fail, key = " + key + ", " + e.getMessage());
		}
		
		if(!flag)
			throw new CommonRuntimeException(Errorcode.REDIS_SAVFAILD, "02", "set redis fail, key = " + key + ", value = " + value);
		
	}


	public void delete(String key) {
		
		int row = 0;
		try {
			row = redisUtil.del(key);
		} catch (Exception e) {
			LOGGER.error("delete fail, key = " + key, e);
			throw new CommonRuntimeException(Errorcode.REDIS_DELFAILD, "02", "delete fail, key = " + key + ", " + e.getMessage());
		}
		
		if(row != 1)
			LOGGER.warn("delete fail, key = " + key);
		
	}
	
	
	
	
	
	
}
