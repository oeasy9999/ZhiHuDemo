package com.ccb.suap.cloud.ecuac.vo;

import com.ccb.suap.cloud.ecuac.datatransform.message.ECUACResponseMsgBodyEntity;
import com.thoughtworks.xstream.annotations.XStreamAlias;

public class ECUAC0183ServiceOutVo implements ECUACResponseMsgBodyEntity{
	
	private static final long serialVersionUID = -3567264378260889274L;
	
	@XStreamAlias("Rslt_Ret_Inf")
	private String rslt_ret_inf;
	@XStreamAlias("Cmp_Rslt_Ind")
	private String cmp_rslt_ind;
	@XStreamAlias("Smlr_Dgr_Cmnt")
	private String smlr_dgr_cmnt;
	@XStreamAlias("Apl_Exmp_ID")
	private String apl_exmp_id;
	@XStreamAlias("Rsrv_1_Inf_Dsc")
	private String rsrv_1_inf_dsc;
	@XStreamAlias("Rsrv_2_Inf_Dsc")
	private String rsrv_2_inf_dsc;
	@XStreamAlias("Rsrv_3_Inf_Dsc")
	private String rsrv_3_inf_dsc;
	@XStreamAlias("Rsrv_4_Inf_Dsc")
	private String rsrv_4_inf_dsc;
	@XStreamAlias("Rsrv_5_Inf_Dsc")
	private String rsrv_5_inf_dsc;
	
	public String getRslt_ret_inf() {
		return rslt_ret_inf;
	}
	public void setRslt_ret_inf(String rslt_ret_inf) {
		this.rslt_ret_inf = rslt_ret_inf;
	}
	public String getCmp_rslt_ind() {
		return cmp_rslt_ind;
	}
	public void setCmp_rslt_ind(String cmp_rslt_ind) {
		this.cmp_rslt_ind = cmp_rslt_ind;
	}
	public String getSmlr_dgr_cmnt() {
		return smlr_dgr_cmnt;
	}
	public void setSmlr_dgr_cmnt(String smlr_dgr_cmnt) {
		this.smlr_dgr_cmnt = smlr_dgr_cmnt;
	}
	public String getApl_exmp_id() {
		return apl_exmp_id;
	}
	public void setApl_exmp_id(String apl_exmp_id) {
		this.apl_exmp_id = apl_exmp_id;
	}
	public String getRsrv_1_inf_dsc() {
		return rsrv_1_inf_dsc;
	}
	public void setRsrv_1_inf_dsc(String rsrv_1_inf_dsc) {
		this.rsrv_1_inf_dsc = rsrv_1_inf_dsc;
	}
	public String getRsrv_2_inf_dsc() {
		return rsrv_2_inf_dsc;
	}
	public void setRsrv_2_inf_dsc(String rsrv_2_inf_dsc) {
		this.rsrv_2_inf_dsc = rsrv_2_inf_dsc;
	}
	public String getRsrv_3_inf_dsc() {
		return rsrv_3_inf_dsc;
	}
	public void setRsrv_3_inf_dsc(String rsrv_3_inf_dsc) {
		this.rsrv_3_inf_dsc = rsrv_3_inf_dsc;
	}
	public String getRsrv_4_inf_dsc() {
		return rsrv_4_inf_dsc;
	}
	public void setRsrv_4_inf_dsc(String rsrv_4_inf_dsc) {
		this.rsrv_4_inf_dsc = rsrv_4_inf_dsc;
	}
	public String getRsrv_5_inf_dsc() {
		return rsrv_5_inf_dsc;
	}
	public void setRsrv_5_inf_dsc(String rsrv_5_inf_dsc) {
		this.rsrv_5_inf_dsc = rsrv_5_inf_dsc;
	}
	
	@Override
	public String toString() {
		return "ECUAC0183ServiceOutVo [rslt_ret_inf=" + rslt_ret_inf + ", cmp_rslt_ind=" + cmp_rslt_ind
				+ ", smlr_dgr_cmnt=" + smlr_dgr_cmnt + ", apl_exmp_id=" + apl_exmp_id + ", rsrv_1_inf_dsc="
				+ rsrv_1_inf_dsc + ", rsrv_2_inf_dsc=" + rsrv_2_inf_dsc + ", rsrv_3_inf_dsc=" + rsrv_3_inf_dsc
				+ ", rsrv_4_inf_dsc=" + rsrv_4_inf_dsc + ", rsrv_5_inf_dsc=" + rsrv_5_inf_dsc + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
