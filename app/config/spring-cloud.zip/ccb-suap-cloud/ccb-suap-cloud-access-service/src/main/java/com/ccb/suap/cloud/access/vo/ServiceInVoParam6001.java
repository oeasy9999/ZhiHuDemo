package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.model.SuapFaceLogModel;

public class ServiceInVoParam6001 {
	
	private SuapFaceLogModel faceLog;				//插入数据库的日志对象
	private String face_image;						//请求图片
	
	public SuapFaceLogModel getFaceLog() {
		return faceLog;
	}
	public void setFaceLog(SuapFaceLogModel faceLog) {
		this.faceLog = faceLog;
	}
	public String getFace_image() {
		return face_image;
	}
	public void setFace_image(String face_image) {
		this.face_image = face_image;
	}
	
	@Override
	public String toString() {
		return "ServiceInVoParam6001 [faceLog=" + faceLog + ", face_image=" + face_image + "]";
	}

	
	
	
	
	
	
	
	
	
	
}
