package com.ccb.suap.cloud.access.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import com.ccb.suap.cloud.access.model.SuapBranchModel;

@Mapper
public interface SuapBranchMapper {
	
	@Insert("insert into SUAP_BRANCH(PARENTID,BRANCHID,BRANCHCODE,BRANCHNAME,BRANCHTYPE) values(#{parentid},#{branchid},#{branchcode},#{branchname},#{branchtype})")
	int insert(SuapBranchModel suapBranchModel);
	
	
	
	
	
	
	
	
	
}
