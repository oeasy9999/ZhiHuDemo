package com.ccb.suap.cloud.access.context;

import java.util.UUID;

/**
 * 应用系统会话内存缓存
 */
public  class SessionContext extends Context{
	
	private static final long serialVersionUID = 1L;
	
	private    String         sessionID;
		
	public SessionContext()
	{
		sessionID = GUID() + "-" + System.currentTimeMillis();
	}
	
	/**
	 * 获取会话标识
	 * @return
	 */
	public String getID()
	{
		return sessionID;
	}
	
	/**
  	 * 获取GUID标示
  	 * @return　返回GUID标示号码
  	 */
	 public static final String GUID()
	 {   
		  UUID uuid = UUID.randomUUID(); 
		  return uuid.toString();        
	 } 
	
	/**
	 * 添加当前界面缓存对象
	 * @param pageContext
	 */
	public void createPageContext(String pageID)
	{
		if(getPageContext() == null ||!getPageContext().getPageID().equals(pageID))
		{
			this.remove("pageContext");
			
			PageContext  fpageContext =  new PageContext(pageID);
			fpageContext.sessionContext = this;
			
			put("pageContext", fpageContext);
		}		
	}
	
	/**
	 * 获取当前界面缓存对象
	 * @return
	 */
	public PageContext getPageContext()
	{
		if(containsKey("pageContext"))
			return (PageContext)get("pageContext");
		else
			return null;		
	}
	
	/**
	 * 获取整个应用缓存
	 * @return
	 */
	public ApplicationContext getApplicationContext()throws Exception
	{
		return ApplicationContext.getAppContext();
	}
	 /**
	  * 获取属性值 从当前主会话缓存、应用缓存逐级寻找
	  * @return 不存在则返回null
	  */
	public  Object getAttributes(String key)throws Exception
	{
		
		if (containsKey(key))
		{
			return get(key);
			
		}else if (getApplicationContext()!= null)
		{
			if (getApplicationContext().containsKey(key))
			{
				return getApplicationContext().get(key);
				
			}else
				return null;
		}else
			return null;		
	}
}