package com.ccb.suap.cloud.ecuac.datatransform.message;

import java.io.Serializable;

public class ECUACResponseMsgBodyCommon implements Serializable {
	
	private static final long serialVersionUID = 1586293104L;
	
	
	
	
	
	
}