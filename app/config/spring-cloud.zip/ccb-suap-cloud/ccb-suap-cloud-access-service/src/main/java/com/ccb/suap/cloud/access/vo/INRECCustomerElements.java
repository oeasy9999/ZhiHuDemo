package com.ccb.suap.cloud.access.vo;

public class INRECCustomerElements {
	
	private String id_type;					//证件类型
	private String id_no;					//证件号码
	private String name;					//姓名
	
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "INREC3003ServiceOutList [id_type=" + id_type + ", id_no=" + id_no + ", name=" + name + "]";
	}
	
	
	
	
	
	
	
	
	
}
