package com.ccb.suap.cloud.access.mapper;

import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.ccb.suap.cloud.access.model.SuapFaceLogModel;

@Mapper
public interface SuapFaceLogMapper {
	
	@InsertProvider(type=SuapFaceLogProvider.class,method="insert")
	int insert(SuapFaceLogModel suapFaceLogModel);
	
//	@Select("select * from SUAP_FACE_LOG")
//	List<SuapFaceLogModel> selectAll();

	@Select("select SEQ_LOGID_LOG.nextval from dual")
	long seq_logid_log();
	
	
	
	
	
	
}
