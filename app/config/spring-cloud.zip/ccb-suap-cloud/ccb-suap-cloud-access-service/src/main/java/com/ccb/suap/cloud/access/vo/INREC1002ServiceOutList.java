package com.ccb.suap.cloud.access.vo;

public class INREC1002ServiceOutList {
	
	private String id_type;					//证件类型
	private String id_no;					//证件号码
	private String name;					//姓名
	private String channel_custno;			//渠道客户号
	private String ccb_custno;				//建行P6客户号码
	private String branch_id;				//分行号
	private String mobile_no;				//手机号码
	private String channel_cardno;			//渠道绑定卡号
	private String title;					//尊称
	private String is_vip;					//是否VIP客户
	private String registry_photo;			//人脸注册图片
	private String face_collecttime;		//人脸照片最近更新时间(YYYYMMDDHHMISS)
	private String similarity;				//相似度
	
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getChannel_custno() {
		return channel_custno;
	}
	public void setChannel_custno(String channel_custno) {
		this.channel_custno = channel_custno;
	}
	public String getCcb_custno() {
		return ccb_custno;
	}
	public void setCcb_custno(String ccb_custno) {
		this.ccb_custno = ccb_custno;
	}
	public String getBranch_id() {
		return branch_id;
	}
	public void setBranch_id(String branch_id) {
		this.branch_id = branch_id;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getChannel_cardno() {
		return channel_cardno;
	}
	public void setChannel_cardno(String channel_cardno) {
		this.channel_cardno = channel_cardno;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getIs_vip() {
		return is_vip;
	}
	public void setIs_vip(String is_vip) {
		this.is_vip = is_vip;
	}
	public String getRegistry_photo() {
		return registry_photo;
	}
	public void setRegistry_photo(String registry_photo) {
		this.registry_photo = registry_photo;
	}
	public String getFace_collecttime() {
		return face_collecttime;
	}
	public void setFace_collecttime(String face_collecttime) {
		this.face_collecttime = face_collecttime;
	}
	public String getSimilarity() {
		return similarity;
	}
	public void setSimilarity(String similarity) {
		this.similarity = similarity;
	}
	
	@Override
	public String toString() {
		return "INREC1002ServiceGPUResultVo [id_type=" + id_type + ", id_no=" + id_no + ", name=" + name
				+ ", channel_custno=" + channel_custno + ", ccb_custno=" + ccb_custno + ", branch_id=" + branch_id
				+ ", mobile_no=" + mobile_no + ", channel_cardno=" + channel_cardno + ", title=" + title + ", is_vip="
				+ is_vip + ", registry_photo=" + registry_photo + ", face_collecttime=" + face_collecttime
				+ ", similarity=" + similarity + "]";
	}
	
	
	
	
	
	
	
	
}
