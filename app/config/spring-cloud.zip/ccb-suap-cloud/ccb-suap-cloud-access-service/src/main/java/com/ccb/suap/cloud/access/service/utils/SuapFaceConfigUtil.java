package com.ccb.suap.cloud.access.service.utils;

import java.util.Hashtable;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.access.controller.ConfigRefreshContoller;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.service.SuapFaceConfigService;

@Component
public class SuapFaceConfigUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigRefreshContoller.class);
	
	public static SuapFaceConfigUtil suapFaceConfigUtil;
	
	@Autowired
	private SuapFaceConfigService suapFaceConfigService;
	
	/**
	 * 	以渠道编号、渠道交易码、交易码为key缓存人脸参数信息
	 */
	private static Hashtable<String,SuapFaceConfigModel> MyHashTable = new Hashtable<String,SuapFaceConfigModel>();

//	private static Hashtable<String,String> countTable = new Hashtable<String,String>();

//	private static Hashtable<String,String> timeTable = new Hashtable<String,String>();

	// 100000次数刷新一次内存的参数列表

//	private final static String countCachePara100000 = " ,INL_CARDBIN,";

	@PostConstruct
	public void onInit() {
		suapFaceConfigUtil = this;
		suapFaceConfigUtil.suapFaceConfigService = this.suapFaceConfigService;
		System.out.println("***************init SuapFaceConfig***************");
		init();
		
	}
	
	public static int init() {

		List<SuapFaceConfigModel> list = suapFaceConfigUtil.suapFaceConfigService.selectAll();

		if (list == null || list.isEmpty()) {
			LOGGER.warn("no face config has found!");
			return 0;
		}

		for (int i = 0; i < list.size(); i++) {
			
			SuapFaceConfigModel suapFaceConfigModel = list.get(i);
			
			trimBaseConfig(suapFaceConfigModel);
			setBaseConfig(suapFaceConfigModel);
			
			MyHashTable.put(suapFaceConfigModel.getChannelcode()+":"+suapFaceConfigModel.getTradecode()+":"+suapFaceConfigModel.getTxcode(), suapFaceConfigModel);
			
		}
		
		return 1;

	}
	
	/**
	 * 	刷新人脸参数信息
	 * @return
	 */
	public static int refresh()
	{
		MyHashTable= new Hashtable<String,SuapFaceConfigModel>();
		List<SuapFaceConfigModel> list = suapFaceConfigUtil.suapFaceConfigService.selectAll();

		if (list == null || list.isEmpty()) {
			LOGGER.warn("no face config has found!");
			return 0;
		}

		for (int i = 0; i < list.size(); i++) {

			SuapFaceConfigModel suapFaceConfigModel = list.get(i);
			
			trimBaseConfig(suapFaceConfigModel);
			setBaseConfig(suapFaceConfigModel);
			
			MyHashTable.put(suapFaceConfigModel.getChannelcode()+":"+suapFaceConfigModel.getTradecode()+":"+suapFaceConfigModel.getTxcode(), suapFaceConfigModel);

		}

		return 1;
	}
	
	
	/**
	 * 	去除参数两端的空格
	 * @param suapFaceConfigModel
	 */
	private static void trimBaseConfig(SuapFaceConfigModel suapFaceConfigModel) {
		if(suapFaceConfigModel.getBranchno() != null)
			suapFaceConfigModel.setBranchno(suapFaceConfigModel.getBranchno().trim());
		if(suapFaceConfigModel.getChannelcode() != null)
			suapFaceConfigModel.setChannelcode(suapFaceConfigModel.getChannelcode().trim());
		if(suapFaceConfigModel.getDestable() != null)
			suapFaceConfigModel.setDestable(suapFaceConfigModel.getDestable().trim());
		if(suapFaceConfigModel.getDistpic() != null)
			suapFaceConfigModel.setDistpic(suapFaceConfigModel.getDistpic().trim());
		if(suapFaceConfigModel.getHackthreshold() != null)
			suapFaceConfigModel.setHackthreshold(suapFaceConfigModel.getHackthreshold().trim());
		if(suapFaceConfigModel.getHitnum() != null)
			suapFaceConfigModel.setHitnum(suapFaceConfigModel.getHitnum().trim());
		if(suapFaceConfigModel.getIdverify() != null)
			suapFaceConfigModel.setIdverify(suapFaceConfigModel.getIdverify().trim());
		if(suapFaceConfigModel.getIsc00004() != null)
			suapFaceConfigModel.setIsc00004(suapFaceConfigModel.getIsc00004().trim());
		if(suapFaceConfigModel.getIshackcheck() != null)
			suapFaceConfigModel.setIshackcheck(suapFaceConfigModel.getIshackcheck().trim());
		if(suapFaceConfigModel.getIspicture() != null)
			suapFaceConfigModel.setIspicture(suapFaceConfigModel.getIspicture().trim());
		if(suapFaceConfigModel.getIspolice() != null)
			suapFaceConfigModel.setIspolice(suapFaceConfigModel.getIspolice().trim());
		if(suapFaceConfigModel.getIsseparate() != null)
			suapFaceConfigModel.setIsseparate(suapFaceConfigModel.getIsseparate().trim());
		if(suapFaceConfigModel.getIssync1to1() != null)
			suapFaceConfigModel.setIssync1to1(suapFaceConfigModel.getIssync1to1().trim());
		if(suapFaceConfigModel.getLevelgrade() != null)
			suapFaceConfigModel.setLevelgrade(suapFaceConfigModel.getLevelgrade().trim());
		if(suapFaceConfigModel.getLeveltype() != null)
			suapFaceConfigModel.setLeveltype(suapFaceConfigModel.getLeveltype().trim());
		if(suapFaceConfigModel.getLocation() != null)
			suapFaceConfigModel.setLocation(suapFaceConfigModel.getLocation().trim());
		if(suapFaceConfigModel.getLocation_source() != null)
			suapFaceConfigModel.setLocation_source(suapFaceConfigModel.getLocation_source().trim());
		if(suapFaceConfigModel.getLocationindex() != null)
			suapFaceConfigModel.setLocationindex(suapFaceConfigModel.getLocationindex().trim());
		if(suapFaceConfigModel.getLocknum() != null)
			suapFaceConfigModel.setLocknum(suapFaceConfigModel.getLocknum().trim());
		if(suapFaceConfigModel.getRegpic() != null)
			suapFaceConfigModel.setRegpic(suapFaceConfigModel.getRegpic().trim());
		if(suapFaceConfigModel.getRemark() != null)
			suapFaceConfigModel.setRemark(suapFaceConfigModel.getRemark().trim());
		if(suapFaceConfigModel.getSeparateindex() != null)
			suapFaceConfigModel.setSeparateindex(suapFaceConfigModel.getSeparateindex().trim());
		if(suapFaceConfigModel.getSeparatenum() != null)
			suapFaceConfigModel.setSeparatenum(suapFaceConfigModel.getSeparatenum().trim());
		if(suapFaceConfigModel.getSimilarity() != null)
			suapFaceConfigModel.setSimilarity(suapFaceConfigModel.getSimilarity().trim());
		if(suapFaceConfigModel.getTradecode() != null)
			suapFaceConfigModel.setTradecode(suapFaceConfigModel.getTradecode().trim());
		if(suapFaceConfigModel.getTxcode() != null)
			suapFaceConfigModel.setTxcode(suapFaceConfigModel.getTxcode().trim());
		
	}
	
	
	/**
	 * 	设置人脸参数配置默认值
	 * @param suapFaceConfigModel
	 */
	public static void setBaseConfig(SuapFaceConfigModel suapFaceConfigModel) {
		if(StringUtils.isBlank(suapFaceConfigModel.getIdverify())) 
			suapFaceConfigModel.setIdverify("1");
		if(StringUtils.isBlank(suapFaceConfigModel.getIdverify_mode()))
			suapFaceConfigModel.setIdverify_mode("1");
		if(StringUtils.isBlank(suapFaceConfigModel.getRhverify()))
			suapFaceConfigModel.setRhverify("1");
		if(StringUtils.isBlank(suapFaceConfigModel.getIsc00004())) 
			suapFaceConfigModel.setIsc00004("1");
		if(StringUtils.isBlank(suapFaceConfigModel.getIspolice())) 
			suapFaceConfigModel.setIspolice("2");
		if(StringUtils.isBlank(suapFaceConfigModel.getLeveltype()))
			suapFaceConfigModel.setLeveltype("2");
		if(StringUtils.isBlank(suapFaceConfigModel.getHitnum()))
			suapFaceConfigModel.setHitnum("1");
		if(StringUtils.isBlank(suapFaceConfigModel.getDistpic()))
			suapFaceConfigModel.setDistpic("2");
		if(StringUtils.isBlank(suapFaceConfigModel.getLocationindex()))
			suapFaceConfigModel.setLocationindex("2");
		if(StringUtils.isBlank(suapFaceConfigModel.getSimilarity()))
			suapFaceConfigModel.setSimilarity("85");
	}
	
	
	/**
	 * 	获取人脸参数信息
	 * @return
	 */
	public static Hashtable<String,SuapFaceConfigModel> getPara() {

		return MyHashTable;

	}

//	public static int getIntPara(String Key1, int DefaultInt) {
//
//		return getIntValue(Key1, DefaultInt);
//
//	}
//	
//	public static int getIntParaInServer(String paracode, int defaultInt) {
//		try {
//			String hostname = InetAddress.getLocalHost().getHostName();
//			log.debug("getHostName:" + hostname);
//			
//			SuapFaceConfigModel p = suapFaceConfigUtil.suapFaceConfigMapper.selectServerPara(paracode, hostname);
//			if(p!=null) {
//				return Integer.parseInt(p.getParavalue());
//			} else {
//				log.warn("selectServerPara->[" + paracode + "] is null");
//				return defaultInt;
//			}
//			
//		} catch(Exception e) {
//			e.printStackTrace();
//			log.error("getIntParaInServer", e);
//			return defaultInt;
//		}
//	}
//
//	public static String getStrPara(String Key1, String DefaultInt) {
//
//		if (Key1 != null && countCachePara100000.indexOf("," + Key1 + ",") > 0)
//
//			return getStrValueOfCountCache(Key1, DefaultInt, 100000);
//
//		return getStrValue(Key1, DefaultInt);
//
//	}
//	
//	public static String getStrParaInServer(String paracode, String defaultInt) {
//		try {
//			String hostname = InetAddress.getLocalHost().getHostName();
//			log.debug("getHostName:" + hostname);
//			
//			SuapFaceConfigModel p = suapFaceConfigUtil.suapFaceConfigMapper.selectServerPara(paracode, hostname);
//			if(p!=null) {
//				return p.getParavalue();
//			} else {
//				log.warn("selectServerPara->[" + paracode + "] is null");
//				return defaultInt;
//			}
//		} catch(Exception e) {
//			e.printStackTrace();
//			log.error("getIntParaInServer", e);
//			return defaultInt;
//		}
//	}
//
//	private static int getIntValue(String Key1, int DefaultInt) {
//
//		String LT = (String) MyHashTable.get(Key1);
//
//		if (LT == null)
//			return DefaultInt;
//
//		try {
//
//			return (new Integer(LT)).intValue();
//
//		} catch (Exception e) {
//			return DefaultInt;
//		}
//
//	}
//
//	private static String getStrValue(String Key1, String DefaultStr) {
//
//		String LT = (String) MyHashTable.get(Key1);
//
//		if (LT == null)
//			LT = DefaultStr;
//
//		return LT;
//
//	}
//
//	// 从缓存中取数，当超过1000次时，从数据库重新查询获取值。
//
//	public static String getStrValueOfCountCache(String key,
//			String defaultValue, int maxCount) {
//
//		String s = (String) countTable.get(key);
//
//		if (s == null)
//
//			s = "0";
//
//		int keyCount = Integer.parseInt(s);
//
//		if (keyCount >= maxCount) {
//			
//			String value = "";
//
//			/*String Sql = "SELECT paracode,paravalue FROM cm_sys_para t WHERE t.paracode=? ";
//
//			DBACCESS db = new DBACCESS();
//
//			Object[] args = new Object[] { key };
//
//			Vector vResult = db.dbQuery(Sql, args);*/
//			SuapFaceConfigModel syspara = null;
//			try {
//				syspara = suapFaceConfigUtil.suapFaceConfigMapper.select(key, "0");
//			} catch (Exception e) {
//				return defaultValue;
//			}
//
//			if (syspara == null)
//				value = "";
//
//			value = syspara.getParavalue();
//
//
//			if (value == null)
//
//				value = "";
//
//			value = value.trim();
//
//			if (!"".equals(value)) {
//
//				MyHashTable.put(key, value);
//
//			}
//
//		}
//
//		synchronized (countTable) {
//
//			if (keyCount >= maxCount)
//
//				keyCount = 1;
//
//			else
//
//				keyCount++;
//
//			countTable.put(key, keyCount + "");
//
//		}
//
//		return getStrValue(key, defaultValue);
//
//	}
//
//	// 从缓存中取数，当超过1000次时，从数据库重新查询获取值。
//
//	public static String getStrValueOfCountCache(String key, String defaultValue) {
//
//		return getStrValueOfCountCache(key, defaultValue, 1000);
//
//	}
//
//	/**
//	 * 
//	 * 获取定时刷新的参数
//	 * 
//	 * @param key
//	 *            键值
//	 * 
//	 * @param defaultValue
//	 *            默认值
//	 * 
//	 * @param millisecond
//	 *            刷新频率
//	 * 
//	 * @return String 值
//	 */
//
//	public static String getStrValueOfTime(String key, String defaultValue,
//			long millisecond) {
//
//		boolean isNeedUpdate = false;
//
//		String strTime = (String) timeTable.get(key + "_refreshTime");
//
//		String strNowTime = "";
//
//		if (strTime == null) {
//
//			isNeedUpdate = true;
//
//		} else {
//
//			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(
//					"yyyyMMdd HH:mm:ss");
//
//			Date now = new Date();
//
//			strNowTime = sdf.format(now);
//
//			try {
//
//				if (now.getTime() - sdf.parse(strTime).getTime() > millisecond) {
//
//					isNeedUpdate = true;
//
//				}
//
//			} catch (Exception e) {
//
//				isNeedUpdate = true;
//
//			}
//
//		}
//
//		if (isNeedUpdate) {
//
//			String strValue = getStrValue(key, defaultValue);
//
//			synchronized (timeTable) {
//
//				timeTable.put(key, strValue);
//
//				timeTable.put(key + "_refreshTime", strNowTime);
//
//			}
//
//			return strValue;
//
//		} else {
//
//			return (String) timeTable.get(key);
//
//		}
//
//	}
//
//	public static String setStrValue(String key, String value) {
//		getPara().put(key, value);
//		return getPara().get(key);
//	}
	
	
	/**
	 * 	根据key值获取相关人脸参数配置信息
	 * @param key
	 * @return
	 */
	public static SuapFaceConfigModel getFaceConfig(String key) {
		return MyHashTable.get(key);
	}
	
	
	/**
	 * 	根据key值获取客户索引字段
	 * @param key
	 * @return
	 */
	public static String getLocationIndex(String key) {
		SuapFaceConfigModel faceConfig = getFaceConfig(key);
		if(faceConfig == null) return null;
		
		String locationindex = faceConfig.getLocationindex();
		
		return locationindex;
	}
	
	
	/**
	 *	 根据请求信息获取客户索引字段
	 * @param reqMsg
	 * @return
	 */
	public static String getLocationIndex(TxRequestMsg reqMsg) {
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		return getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
	}
	
	
	/**
	 * 	根据请求信息获取相关人脸参数配置信息
	 * @param reqMsg
	 * @return
	 */
	public static SuapFaceConfigModel getFaceConfig(TxRequestMsg reqMsg) {
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		return MyHashTable.get(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
	}
	
	
	
}
