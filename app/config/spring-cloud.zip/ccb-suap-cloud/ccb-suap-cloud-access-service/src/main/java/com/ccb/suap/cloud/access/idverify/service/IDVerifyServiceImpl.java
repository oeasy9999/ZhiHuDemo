package com.ccb.suap.cloud.access.idverify.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.ccb.suap.cloud.access.config.SpringContextUtil;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam1001And2001;

@Service
public class IDVerifyServiceImpl implements IDVerifyService{
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);

	@Override
	public boolean verify(TxRequestMsg reqMsg, SuapFaceConfigModel faceConfig, ServiceInVoParam1001And2001 param) {
		
		/**
		 * 1.根据人脸核查模式获取对应对象
		 * 	1.1 1 私有云CCVEA1004
		 * 	1.2 2 人行->成开->公安一所
		 *  1.3 3 ECUAC0183 专线核查
		 */
		IDVerifyMode bean = null;
		try {
			bean = (IDVerifyMode) SpringContextUtil.getBean("IDVerify" + faceConfig.getIdverify_mode().trim());
		} catch (Exception e) {
			bean = (IDVerifyMode) SpringContextUtil.getBean("IDVerify1");
		}
		
		//2.执行人脸核查
		return bean.verify(reqMsg, faceConfig, param);
		
	}

	
	
}
