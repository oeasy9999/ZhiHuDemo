package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class INREC3003ServiceInVo extends TxRequestMsgEntity{
	
	private String mobile_no;				//手机号码

	public String getMobile_no() {
		return mobile_no;
	}

	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}

	@Override
	public String toString() {
		return "INREC3003ServiceInVo [mobile_no=" + mobile_no + "]";
	}
	
	
	
	
	
}
