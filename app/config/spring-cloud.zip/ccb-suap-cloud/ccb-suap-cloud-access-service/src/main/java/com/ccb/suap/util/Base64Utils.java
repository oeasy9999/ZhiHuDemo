/**
 * 
 */
package com.ccb.suap.util;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * @author jiangyw
 *
 * 
 */
public class Base64Utils {

	public static String base64Encoder(String strIn) throws Exception{
		
        String strOut = null;
        
        if(strIn == null || strIn.trim().equals("")){
        	
        	return strIn;
        	
        }
        
        BASE64Encoder en=new BASE64Encoder();
        
        byte b[] = strIn.getBytes("utf-8");
        
        strOut = en.encode(b);
        
        strOut = strOut.replace("\n", "");
        
        return strOut;
        
     }

	public static String base64Decoder(String strIn) throws Exception{
		
		String strOut = null;
		
		if(strIn == null || strIn.trim().equals("")){
			
	    	return strIn;
	    	
	    }
		
	    BASE64Decoder de=new BASE64Decoder();
	    
	    byte b[] = de.decodeBuffer(strIn);
	    
	    strOut = new String(b, "utf-8");
	    
	    strOut = strOut.replace("\n", "");
	    
	    return strOut;
	    
	}

	
//	public static void main(String[] args) throws Exception {
//		
//		System.out.println(Base64Utils.base64Decoder("eyJjZWxsX3Bob25lIjoiMTM1Mzk4NzYwNzkiLCJ0aW1lc3RhbXAiOiIyMDE3MDMzMDIyNTY0Nzky%0DNiIsInNtc19jb2RlIjoiMTIzNDU2IiwidHhfY29kZSI6IkdXX0lTTDAwMSJ9"));
//		
//		//{"tx_code":"GW_ISL001","cell_phone":"13539876078"}
//		
//		JSONObject js = new JSONObject();
//		
//		js.put("tx_code", "GW_ISL002");
//		
//		js.put("cell_phone", "13539876079");
//		
//		js.put("sms_code", "123456");
//		
//		System.out.println(Base64Utils.base64Encoder(js.toString()));
//	}

}
