package com.ccb.suap.cloud.ecuac.datatransform.message;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class ECUACResponseMsgHead implements Serializable {
	
	private static final long serialVersionUID = -1708557954L;
	
	@XStreamAlias("SYS_HDR_LEN")
	private String sys_hdr_len;
	@XStreamAlias("SYS_PKG_VRSN")
	private String sys_pkg_vrsn;
	@XStreamAlias("SYS_TTL_LEN")
	private String sys_ttl_len;
	@XStreamAlias("SYS_REQ_SEC_ID")
	private String sys_req_sec_id;
	@XStreamAlias("SYS_SND_SEC_ID")
	private String sys_snd_sec_id;
	@XStreamAlias("SYS_TX_TYPE")
	private String sys_tx_type;
	@XStreamAlias("SYS_EVT_TRACE_ID")
	private String sys_evt_trace_id;
	@XStreamAlias("SYS_SND_SERIAL_NO")
	private String sys_snd_serial_no;
	@XStreamAlias("SYS_PKG_TYPE")
	private String sys_pkg_type;
	@XStreamAlias("SYS_MSG_LEN")
	private String sys_msg_len;
	@XStreamAlias("SYS_IS_ENCRYPTED")
	private String sys_is_encrypted;
	@XStreamAlias("SYS_ENCRYPT_TYPE")
	private String sys_encrypt_type;
	@XStreamAlias("SYS_COMPRESS_TYPE")
	private String sys_compress_type;
	@XStreamAlias("SYS_EMB_MSG_LEN")
	private String sys_emb_msg_len;
	@XStreamAlias("SYS_RECV_TIME")
	private String sys_recv_time;
	@XStreamAlias("SYS_RESP_TIME")
	private String sys_resp_time;
	@XStreamAlias("SYS_PKG_STS_TYPE")
	private String sys_pkg_sts_type;
	@XStreamAlias("SYS_TX_STATUS")
	private String sys_tx_status;
	@XStreamAlias("SYS_RESP_CODE")
	private String sys_resp_code;
	@XStreamAlias("SYS_RESP_DESC_LEN")
	private String sys_resp_desc_len;
	@XStreamAlias("SYS_RESP_DESC")
	private String sys_resp_desc;
	@XStreamAlias("SYS_TX_CODE")
	private String sys_tx_code;
	
	public String getSys_hdr_len() {
		return sys_hdr_len;
	}
	public void setSys_hdr_len(String sys_hdr_len) {
		this.sys_hdr_len = sys_hdr_len;
	}
	public String getSys_pkg_vrsn() {
		return sys_pkg_vrsn;
	}
	public void setSys_pkg_vrsn(String sys_pkg_vrsn) {
		this.sys_pkg_vrsn = sys_pkg_vrsn;
	}
	public String getSys_ttl_len() {
		return sys_ttl_len;
	}
	public void setSys_ttl_len(String sys_ttl_len) {
		this.sys_ttl_len = sys_ttl_len;
	}
	public String getSys_req_sec_id() {
		return sys_req_sec_id;
	}
	public void setSys_req_sec_id(String sys_req_sec_id) {
		this.sys_req_sec_id = sys_req_sec_id;
	}
	public String getSys_snd_sec_id() {
		return sys_snd_sec_id;
	}
	public void setSys_snd_sec_id(String sys_snd_sec_id) {
		this.sys_snd_sec_id = sys_snd_sec_id;
	}
	public String getSys_tx_type() {
		return sys_tx_type;
	}
	public void setSys_tx_type(String sys_tx_type) {
		this.sys_tx_type = sys_tx_type;
	}
	public String getSys_evt_trace_id() {
		return sys_evt_trace_id;
	}
	public void setSys_evt_trace_id(String sys_evt_trace_id) {
		this.sys_evt_trace_id = sys_evt_trace_id;
	}
	public String getSys_snd_serial_no() {
		return sys_snd_serial_no;
	}
	public void setSys_snd_serial_no(String sys_snd_serial_no) {
		this.sys_snd_serial_no = sys_snd_serial_no;
	}
	public String getSys_pkg_type() {
		return sys_pkg_type;
	}
	public void setSys_pkg_type(String sys_pkg_type) {
		this.sys_pkg_type = sys_pkg_type;
	}
	public String getSys_msg_len() {
		return sys_msg_len;
	}
	public void setSys_msg_len(String sys_msg_len) {
		this.sys_msg_len = sys_msg_len;
	}
	public String getSys_is_encrypted() {
		return sys_is_encrypted;
	}
	public void setSys_is_encrypted(String sys_is_encrypted) {
		this.sys_is_encrypted = sys_is_encrypted;
	}
	public String getSys_encrypt_type() {
		return sys_encrypt_type;
	}
	public void setSys_encrypt_type(String sys_encrypt_type) {
		this.sys_encrypt_type = sys_encrypt_type;
	}
	public String getSys_compress_type() {
		return sys_compress_type;
	}
	public void setSys_compress_type(String sys_compress_type) {
		this.sys_compress_type = sys_compress_type;
	}
	public String getSys_emb_msg_len() {
		return sys_emb_msg_len;
	}
	public void setSys_emb_msg_len(String sys_emb_msg_len) {
		this.sys_emb_msg_len = sys_emb_msg_len;
	}
	public String getSys_recv_time() {
		return sys_recv_time;
	}
	public void setSys_recv_time(String sys_recv_time) {
		this.sys_recv_time = sys_recv_time;
	}
	public String getSys_resp_time() {
		return sys_resp_time;
	}
	public void setSys_resp_time(String sys_resp_time) {
		this.sys_resp_time = sys_resp_time;
	}
	public String getSys_pkg_sts_type() {
		return sys_pkg_sts_type;
	}
	public void setSys_pkg_sts_type(String sys_pkg_sts_type) {
		this.sys_pkg_sts_type = sys_pkg_sts_type;
	}
	public String getSys_tx_status() {
		return sys_tx_status;
	}
	public void setSys_tx_status(String sys_tx_status) {
		this.sys_tx_status = sys_tx_status;
	}
	public String getSys_resp_code() {
		return sys_resp_code;
	}
	public void setSys_resp_code(String sys_resp_code) {
		this.sys_resp_code = sys_resp_code;
	}
	public String getSys_resp_desc_len() {
		return sys_resp_desc_len;
	}
	public void setSys_resp_desc_len(String sys_resp_desc_len) {
		this.sys_resp_desc_len = sys_resp_desc_len;
	}
	public String getSys_resp_desc() {
		return sys_resp_desc;
	}
	public void setSys_resp_desc(String sys_resp_desc) {
		this.sys_resp_desc = sys_resp_desc;
	}
	public String getSys_tx_code() {
		return sys_tx_code;
	}
	public void setSys_tx_code(String sys_tx_code) {
		this.sys_tx_code = sys_tx_code;
	}
	
	@Override
	public String toString() {
		return "TxResponseMsgHead [sys_hdr_len=" + sys_hdr_len + ", sys_pkg_vrsn=" + sys_pkg_vrsn + ", sys_ttl_len="
				+ sys_ttl_len + ", sys_req_sec_id=" + sys_req_sec_id + ", sys_snd_sec_id=" + sys_snd_sec_id
				+ ", sys_tx_type=" + sys_tx_type + ", sys_evt_trace_id=" + sys_evt_trace_id + ", sys_snd_serial_no="
				+ sys_snd_serial_no + ", sys_pkg_type=" + sys_pkg_type + ", sys_msg_len=" + sys_msg_len
				+ ", sys_is_encrypted=" + sys_is_encrypted + ", sys_encrypt_type=" + sys_encrypt_type
				+ ", sys_compress_type=" + sys_compress_type + ", sys_emb_msg_len=" + sys_emb_msg_len
				+ ", sys_recv_time=" + sys_recv_time + ", sys_resp_time=" + sys_resp_time + ", sys_pkg_sts_type="
				+ sys_pkg_sts_type + ", sys_tx_status=" + sys_tx_status + ", sys_resp_code=" + sys_resp_code
				+ ", sys_resp_desc_len=" + sys_resp_desc_len + ", sys_resp_desc=" + sys_resp_desc + ", sys_tx_code="
				+ sys_tx_code + "]";
	}
	
	
	
	
	
	
	
	
	
}