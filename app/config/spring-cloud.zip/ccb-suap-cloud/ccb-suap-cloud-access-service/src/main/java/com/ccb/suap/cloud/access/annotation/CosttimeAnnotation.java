package com.ccb.suap.cloud.access.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.core.annotation.AliasFor;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface CosttimeAnnotation {
	
	@AliasFor("value")
	String title() default "";
	
	@AliasFor("title")
	String value() default "";
	
	
	
	
	
	
	
}
