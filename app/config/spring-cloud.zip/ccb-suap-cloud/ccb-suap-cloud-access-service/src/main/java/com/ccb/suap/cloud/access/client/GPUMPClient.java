package com.ccb.suap.cloud.access.client;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;

/*
 * 定义内部服务facegpsps-service的对接方法
 * facegpsps-service项目内必须要有相同的方法才能接收
 * */
@FeignClient(name = "facegpups", fallback = GPUMPClient.ServiceBClientFallback.class)
public interface GPUMPClient {
	
    @GetMapping(value = "/")
    String printServiceB();
    
    default JSONObject GPUMPServer(TxRequestMsg txRequestMsg,String txcode)
    {
    	String filename;
    	String data;
    	try {
    		String dumpfile_path=new File(ResourceUtils.getURL("classpath:").getPath()).getParentFile().getParentFile().getParent();
    		filename=txcode+".rsp";
    		
    		dumpfile_path=URLDecoder.decode(dumpfile_path+File.separator+"baffle"+File.separator+filename, "UTF-8");
    		
    		if(dumpfile_path.startsWith("file:")) {
    			dumpfile_path = dumpfile_path.substring(5);
    		}
    		
    		File resp_file=new File(dumpfile_path);
    		if (resp_file.exists()) {
//    			LOGGER.debug(filename+"\t is exists");
				data = FileUtils.readFileToString(resp_file);
//				LOGGER.error("response file content:"+data);
				JSONObject json=new JSONObject();
//				LOGGER.debug(filename+"\t  is read successfully");
				JSONObject resp_json=json.parseObject(data);
//				LOGGER.debug(filename+"\t is parsed successfully");
				return resp_json;
			}else {
				switch(txcode)
		    	 {
		    	 case "GPUMP1001": 
		    		 return GPUMPServer1001(txRequestMsg);
		    	 case "GPUMP1002": 
		    		 return GPUMPServer1002(txRequestMsg);
		    	 case "GPUMP1003": 
		    		 return GPUMPServer1003(txRequestMsg);
		    	 case "GPUMP1004": 
		    		 return GPUMPServer1004(txRequestMsg);
		    	 case "GPUMP1005": 
		    		 return GPUMPServer1005(txRequestMsg);
		    	 case "GPUMP1006": 
		    		 return GPUMPServer1006(txRequestMsg);
		    	 case "GPUMP1007": 
		    		 return GPUMPServer1007(txRequestMsg);
		    	 case "GPUMP1008": 
		    		 return GPUMPServer1008(txRequestMsg);
		    	 case "GPUMP1009": 
		    		 return GPUMPServer1009(txRequestMsg);
		    	 case "GPUMP1010": 
		    		 return GPUMPServer1010(txRequestMsg);
		    		 
		    	 default:
		    		 return null;
		    	 }
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
    	return null;
		
    	//dump();
    	 
    }
    
	@RequestMapping(value = "/GpumpService/GPUMP1001",method=RequestMethod.POST,consumes="application/json")
    public JSONObject GPUMPServer1001(TxRequestMsg txRequestMsg);
    @RequestMapping(value = "/GpumpService/GPUMP1002",method=RequestMethod.POST,consumes="application/json")
    public JSONObject GPUMPServer1002(TxRequestMsg txRequestMsg);
    @RequestMapping(value = "/GpumpService/GPUMP1003",method=RequestMethod.POST,consumes="application/json")
    public JSONObject GPUMPServer1003(TxRequestMsg txRequestMsg);
    @RequestMapping(value = "/GpumpService/GPUMP1004",method=RequestMethod.POST,consumes="application/json")
    public JSONObject GPUMPServer1004(TxRequestMsg txRequestMsg);
    @RequestMapping(value = "/GpumpService/GPUMP1005",method=RequestMethod.POST,consumes="application/json")
    public JSONObject GPUMPServer1005(TxRequestMsg txRequestMsg);
    @RequestMapping(value = "/GpumpService/GPUMP1006",method=RequestMethod.POST,consumes="application/json")
    public JSONObject GPUMPServer1006(TxRequestMsg txRequestMsg);
    @RequestMapping(value = "/GpumpService/GPUMP1007",method=RequestMethod.POST,consumes="application/json")
    public JSONObject GPUMPServer1007(TxRequestMsg txRequestMsg);
    @RequestMapping(value = "/GpumpService/GPUMP1008",method=RequestMethod.POST,consumes="application/json")
    public JSONObject GPUMPServer1008(TxRequestMsg txRequestMsg);
    @RequestMapping(value = "/GpumpService/GPUMP1009",method=RequestMethod.POST,consumes="application/json")
    public JSONObject GPUMPServer1009(TxRequestMsg txRequestMsg);
    @RequestMapping(value = "/GpumpService/GPUMP1010",method=RequestMethod.POST,consumes="application/json")
    public JSONObject GPUMPServer1010(TxRequestMsg txRequestMsg);
    
    @Component
    class ServiceBClientFallback implements GPUMPClient {

//        private static final Logger LOGGER = LoggerFactory.getLogger(ServiceBClientFallback.class);
        static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);

        public String printServiceB() {
            LOGGER.error("异常发生，进入fallback方法");
            return "FACEGPUPS-SERVICE FAILED! - FALLING BACK";
        }
		@Override
		public JSONObject GPUMPServer1001(TxRequestMsg txRequestMsg) {
			LOGGER.error("facegpups-service GpumpServerGPUMP1001 error!");
			return null;
		}
		@Override
		public JSONObject GPUMPServer1002(TxRequestMsg txRequestMsg) {
			LOGGER.error("facegpups-service GpumpServerGPUMP1002 error!");
			return null;
		}
		@Override
		public JSONObject GPUMPServer1003(TxRequestMsg txRequestMsg) {
			LOGGER.error("facegpups-service GpumpServerGPUMP1003 error!");
			return null;
		}
		@Override
		public JSONObject GPUMPServer1004(TxRequestMsg txRequestMsg) {
			LOGGER.error("facegpups-service GpumpServerGPUMP1004 error!");
			return null;
		}
		@Override
		public JSONObject GPUMPServer1005(TxRequestMsg txRequestMsg) {
			LOGGER.error("facegpups-service GpumpServerGPUMP1005 error!");
			return null;
		}
		@Override
		public JSONObject GPUMPServer1006(TxRequestMsg txRequestMsg) {
			LOGGER.error("facegpups-service GpumpServerGPUMP1006 error!");
			return null;
		}
		@Override
		public JSONObject GPUMPServer1007(TxRequestMsg txRequestMsg) {
			LOGGER.error("facegpups-service GpumpServerGPUMP1007 error!");
			return null;
		}
		@Override
		public JSONObject GPUMPServer1008(TxRequestMsg txRequestMsg) {
			LOGGER.error("facegpups-service GpumpServerGPUMP1008 error!");
			return null;
		}
		@Override
		public JSONObject GPUMPServer1009(TxRequestMsg txRequestMsg) {
			LOGGER.error("facegpups-service GpumpServerGPUMP1009 error!");
			return null;
		}
		@Override
		public JSONObject GPUMPServer1010(TxRequestMsg txRequestMsg) {
			LOGGER.error("facegpups-service GpumpServerGPUMP1010 error!");
			return null;
		}
    }
}