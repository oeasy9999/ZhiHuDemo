package com.ccb.suap.util.string;

import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.StringTokenizer;

import com.ccb.suap.util.Utils;


/**
 * 字符串工具操作类
 * @author deyang
 *
 */
public final class StringUtils {

	public static final String EMPTY_STRING = "";
	public static final char DOT = 46;
	public static final char UNDERSCORE = 95;
	public static final String COMMA_SPACE = ", ";
	public static final String COMMA = ",";
	public static final String OPEN_PAREN = "(";
	public static final String CLOSE_PAREN = ")";
	public static final char SINGLE_QUOTE = 39;
	private static final DecimalFormat df = new DecimalFormat("####0.00");

	public static boolean checkEmpty(String str) {
		return ((str == null) || ("".equals(str.trim())));
	}
	
	public static boolean hasLength(CharSequence str) {
		return ((str != null) && (str.length() > 0));
	}

	public static boolean hasLength(String str) {
		return hasLength((CharSequence)str);
	}

	public final static int getBiolInfoTableID(String custId) {
		int a = byteArrayToInt(custId.getBytes());
		return Math.abs(a) % 100 + 1;
	}
	public final static int byteArrayToInt(byte[] b) {
		int value = 0;
		if(b==null)return value;
		for (int i = 0; i < b.length; i++) {
			int temp = b[i] & 0xFF;
			value = value * 256;
			value = value + temp;
		}
		return value;
	}
	public static boolean hasText(CharSequence str) {
		if (!(hasLength(str)))
			return false;

		int strLen = str.length();
		for (int i = 0; i < strLen; ++i)
			if (!(Character.isWhitespace(str.charAt(i))))
				return true;

		return false;
	}

	public static boolean hasText(String str) {
		return hasText((CharSequence)str);
	}

	public static boolean containsWhitespace(CharSequence str)
	  {
	    if (!(hasLength(str)))
	      return false;

	    int strLen = str.length();
	    for (int i = 0; i < strLen; ++i)
	      if (Character.isWhitespace(str.charAt(i)))
	        return true;


	    return false;
	  }

	  public static boolean containsWhitespace(String str)
	  {
	    return containsWhitespace(str);
	  }

	  public static String trimWhitespace(String str)
	  {
	    if (!(hasLength(str)))
	      return str;

	    StringBuilder sb = new StringBuilder(str);
	    while ((sb.length() > 0) && (Character.isWhitespace(sb.charAt(0))))
	      sb.deleteCharAt(0);

	    while ((sb.length() > 0) && (Character.isWhitespace(sb.charAt(sb.length() - 1))))
	      sb.deleteCharAt(sb.length() - 1);

	    return sb.toString();
	  }
	  
	public static String join(String seperator, String[] strings) {
		int length = strings.length;
		if (length == 0) {
			return "";
		}

		StringBuilder builder = new StringBuilder(length * strings[0].length())
				.append(strings[0]);

		for (int i = 1; i < length; ++i)
			builder.append(seperator).append(strings[i]);

		return builder.toString();
	}

	public static String join(String seperator, Iterator objects) {
		StringBuilder builder = new StringBuilder();
		builder.append(objects.next());
		while (objects.hasNext())
			builder.append(seperator).append(objects.next());

		return builder.toString();
	}

	public static String[] add(String[] x, String sep, String[] y) {
		String[] result = new String[x.length];
		for (int i = 0; i < x.length; ++i)
			result[i] = new StringBuilder().append(x[i]).append(sep)
					.append(y[i]).toString();

		return result;
	}

	public static String repeat(String string, int times) {
		StringBuilder builder = new StringBuilder(string.length() * times);
		for (int i = 0; i < times; ++i)
			builder.append(string);
		return builder.toString();
	}

	public static String replace(String template, String placeholder,
			String replacement) {
		return replace(template, placeholder, replacement, false);
	}

	public static String replace(String template, String placeholder,
			String replacement, boolean wholeWords) {
		int loc = template.indexOf(placeholder);
		if (loc < 0)
			return template;

		boolean actuallyReplace = (!(wholeWords))
				|| (loc + placeholder.length() == template.length())
				|| (!(Character.isJavaIdentifierPart(template.charAt(loc
						+ placeholder.length()))));

		String actualReplacement = (actuallyReplace) ? replacement
				: placeholder;

		return new StringBuffer(template.substring(0, loc))
				.append(actualReplacement)
				.append(replace(template.substring(loc + placeholder.length()),
						placeholder, replacement, wholeWords)).toString();
	}

	public static String replaceOnce(String template, String placeholder,
			String replacement) {
		int loc = template.indexOf(placeholder);
		if (loc < 0)
			return template;

		return new StringBuffer(template.substring(0, loc)).append(replacement)
				.append(template.substring(loc + placeholder.length()))
				.toString();
	}

	public static String[] split(String seperators, String list) {
		return split(seperators, list, false);
	}

	public static String[] split(String seperators, String list, boolean include) {
		StringTokenizer tokens = new StringTokenizer(list, seperators, include);
		String[] result = new String[tokens.countTokens()];
		int i = 0;
		while (tokens.hasMoreTokens())
			result[(i++)] = tokens.nextToken();

		return result;
	}

	public static String unqualify(String qualifiedName) {
		return unqualify(qualifiedName, ".");
	}

	public static String unqualify(String qualifiedName, String seperator) {
		return qualifiedName
				.substring(qualifiedName.lastIndexOf(seperator) + 1);
	}

	public static String qualifier(String qualifiedName) {
		int loc = qualifiedName.lastIndexOf(".");
		if (loc < 0)
			return "";

		return qualifiedName.substring(0, loc);
	}

	public static String[] suffix(String[] columns, String suffix) {
		if (suffix == null)
			return columns;
		String[] qualified = new String[columns.length];
		for (int i = 0; i < columns.length; ++i)
			qualified[i] = suffix(columns[i], suffix);

		return qualified;
	}

	public static String suffix(String name, String suffix) {
		return ((suffix == null) ? name : new StringBuilder().append(name)
				.append(suffix).toString());
	}

	public static String[] prefix(String[] columns, String prefix) {
		if (prefix == null)
			return columns;
		String[] qualified = new String[columns.length];
		for (int i = 0; i < columns.length; ++i)
			qualified[i] = new StringBuilder().append(prefix)
					.append(columns[i]).toString();

		return qualified;
	}

	public static String root(String qualifiedName) {
		int loc = qualifiedName.indexOf(".");
		return ((loc < 0) ? qualifiedName : qualifiedName.substring(0, loc));
	}

	/**
	 * 字符转译为boolean类型， true,t,y,1不区分大小写均为true，其他均为false
	 * @param tfString
	 * @return
	 */
	public static boolean booleanValue(String tfString) {
		String trimmed = tfString.trim().toLowerCase();
		return ((trimmed.equals("true")) || (trimmed.equals("t")) || (trimmed.equals("y")) || (trimmed.equals("1")));
	}

	public static String toString(Object[] array) {
		int len = array.length;
		if (len == 0)
			return "";
		StringBuffer buf = new StringBuffer(len * 12);
		for (int i = 0; i < len - 1; ++i)
			buf.append(array[i]).append(", ");

		return buf.append(array[(len - 1)]).toString();
	}

	public static String[] multiply(String string, Iterator placeholders,
			Iterator replacements) {
		String[] result = { string };
		while (placeholders.hasNext()) {
			result = multiply(result, (String) placeholders.next(),
					(String[]) (String[]) replacements.next());
		}

		return result;
	}

	public static String[] multiply(String[] strings, String placeholder,
			String[] replacements) {
		String[] results = new String[replacements.length * strings.length];
		int n = 0;
		for (int i = 0; i < replacements.length; ++i) {
			for (int j = 0; j < strings.length; ++j)
				results[(n++)] = replaceOnce(strings[j], placeholder,
						replacements[i]);

		}

		return results;
	}

	public static int count(String string, char character) {
		int n = 0;
		for (int i = 0; i < string.length(); ++i)
			if (string.charAt(i) == character)
				++n;

		return n;
	}

	public static int countUnquoted(String string, char character) {
		if ('\'' == character) {
			throw new IllegalArgumentException(
					"Unquoted count of quotes is invalid");
		}

		int count = 0;
		int stringLength = (string == null) ? 0 : string.length();
		boolean inQuote = false;
		for (int indx = 0; indx < stringLength; ++indx)
			if (inQuote)
				if ('\'' == string.charAt(indx))
					inQuote = false;

				else if ('\'' == string.charAt(indx))
					inQuote = true;
				else if (string.charAt(indx) == character)
					++count;

		return count;
	}

	public static boolean isNotEmpty(String string) {
		return ((string != null) && (string.length() > 0));
	}
	
	public static boolean isNotBlank(String str) {
		return str!=null && str.trim().length()!=0;
	}

	public static String qualify(String prefix, String name) {
		return new StringBuilder(prefix.length() + name.length() + 1)
				.append(prefix).append('.').append(name).toString();
	}

	public static String[] qualify(String prefix, String[] names) {
		if (prefix == null)
			return names;
		int len = names.length;
		String[] qualified = new String[len];
		for (int i = 0; i < len; ++i)
			qualified[i] = qualify(prefix, names[i]);

		return qualified;
	}

	public static int firstIndexOfChar(String sqlString, String string,
			int startindex) {
		int matchAt = -1;
		for (int i = 0; i < string.length(); ++i) {
			int curMatch = sqlString.indexOf(string.charAt(i), startindex);
			if (curMatch >= 0)
				if (matchAt == -1)
					matchAt = curMatch;
				else
					matchAt = Math.min(matchAt, curMatch);

		}

		return matchAt;
	}

	public static String truncate(String string, int length) {
		if (string.length() <= length)
			return string;

		return string.substring(0, length);
	}

	public static String toIntStr(String floatStr) {
		if ((floatStr == null) || (floatStr.length() < 1))
			return "0";

		int index = floatStr.indexOf(".");
		if (index == -1)
			return floatStr;
		if (index == 0)
			return "0";
		if ((index == 1) && (floatStr.substring(0, 1).equals("-")))
			return "0";

		String intStr = floatStr.substring(0, index);
		if (intStr.substring(0, 1).equals("-")) {
			long tmp = Long.parseLong(intStr) - 1L;
			intStr = new StringBuilder().append(tmp).append("").toString();
		}
		return intStr;
	}

	public static String toFmtDoubleStr(String doubleStr) {
		return toFmtDoubleStr(Double.parseDouble(doubleStr));
	}

	public static String toFmtDoubleStr(double d) {
		return df.format(d);
	}
	
	/*
     * 中文转unicode编码
     */
    public static String unicodeEncoding(final String gbString) {
    	try {
	        char[] utfBytes = gbString.toCharArray();
	        StringBuffer sb = new StringBuffer();
	        for (int i = 0; i < utfBytes.length; i++) {
	            String hexB = Integer.toHexString(utfBytes[i]);
	            
	            sb.append("\\u" + Utils.fillCharsToStringLeft(hexB, (char)48, 4));
	        }
	        return sb.toString();
    	} catch(Exception e) {
    		e.printStackTrace();
    		return gbString;
    	}
    }
    /*
     * unicode编码转中文
     */
    public static String decodeUnicode(final String dataStr) {
    	try {
	        int start = 0;
	        int end = 0;
	        final StringBuffer buffer = new StringBuffer();
	        while (start > -1) {
	            end = dataStr.indexOf("\\u", start + 2);
	            String charStr = "";
	            if (end == -1) {
	                charStr = dataStr.substring(start + 2, dataStr.length());
	            } else {
	                charStr = dataStr.substring(start + 2, end);
	            }
	            char letter = (char) Integer.parseInt(charStr, 16); // 16进制parse整形字符串。
	            buffer.append(new Character(letter).toString());
	            start = end;
	        }
	        return buffer.toString();
    	} catch(Exception e) {
    		e.printStackTrace();
    		return dataStr;
    	}
    }
}
