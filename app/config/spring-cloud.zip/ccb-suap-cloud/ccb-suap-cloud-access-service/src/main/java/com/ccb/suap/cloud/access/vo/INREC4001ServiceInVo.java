package com.ccb.suap.cloud.access.vo;

public class INREC4001ServiceInVo extends INRECBaseServiceInVo{
	
	private String face_eigen;					//人脸特征值
	private String face_image;					//人脸图片
	
	public String getFace_eigen() {
		return face_eigen;
	}
	public void setFace_eigen(String face_eigen) {
		this.face_eigen = face_eigen;
	}
	public String getFace_image() {
		return face_image;
	}
	public void setFace_image(String face_image) {
		this.face_image = face_image;
	}
	
	@Override
	public String toString() {
		return "INREC4001ServiceInVo [face_eigen=" + face_eigen + ", face_image=" + face_image + "]";
	}
	
	
	
	

	
	
	
}
