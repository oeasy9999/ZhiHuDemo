package com.ccb.suap.cloud.access.vo;

public class INREC1001ServiceInVo extends INREC1001And2001ServiceInVo{
	
	
}
