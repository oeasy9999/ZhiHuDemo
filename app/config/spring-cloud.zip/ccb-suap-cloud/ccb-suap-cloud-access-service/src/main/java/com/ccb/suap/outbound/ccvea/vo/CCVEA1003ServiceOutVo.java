package com.ccb.suap.outbound.ccvea.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class CCVEA1003ServiceOutVo extends TxResponseMsgEntity{
	
	
	
	
	
	
	
	
	
	
}
