package com.ccb.suap.cloud.access.idverify.service;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam1001And2001;

public interface IDVerifyService {

	public boolean verify(TxRequestMsg reqMsg, SuapFaceConfigModel faceConfig, ServiceInVoParam1001And2001 param);
	
	
	
	
	
	
	
	
	
	
	
	
	
}
