package com.ccb.suap.cloud.access.vo;

public class INREC2006ServiceInVo extends INRECBaseServiceInVo{
	
	
	
	
	
	
	
	
}
