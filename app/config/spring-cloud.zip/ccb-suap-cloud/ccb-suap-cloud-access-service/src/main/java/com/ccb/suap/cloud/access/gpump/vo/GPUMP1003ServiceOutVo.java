package com.ccb.suap.cloud.access.gpump.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class GPUMP1003ServiceOutVo extends TxResponseMsgEntity{

}
