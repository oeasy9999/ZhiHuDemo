package com.ccb.suap.cloud.access.mapper;

import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.jdbc.SQL;

import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;

public class SuapCustDeviceInfoDynaProveider {
	
	public String update(SuapCustDeviceInfoModel suapCustDeviceInfoModel) {
		return new SQL() {{
			UPDATE("SUAP_CUST_DEVICE_INFO_"+suapCustDeviceInfoModel.getNum());
			
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getCustname())) 
				SET("CUSTNAME=#{custname}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getCellphome())) 
				SET("CELLPHOME=#{cellphome}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getChannel_cstno())) 
				SET("CHANNEL_CSTNO=db_encrypt(#{channel_cstno})");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getPhoto_path())) 
				SET("PHOTO_PATH=#{photo_path}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getTitile())) 
				SET("TITILE=#{titile}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getIsvip())) 
				SET("ISVIP=#{isvip}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getCardno())) 
				SET("CARDNO=#{cardno}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getSiteno())) 
				SET("SITENO=#{siteno}");
			if(StringUtils.isNotBlank(suapCustDeviceInfoModel.getIdverify()))
				SET("IDVERIFY=#{idverify}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getLocation())) 
				SET("LOCATION=#{location}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getDevicetype())) 
				SET("DEVICETYPE=#{devicetype}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getDeviceauthcode())) 
				SET("DEVICEAUTHCODE=#{deviceauthcode}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getDevicecode())) 
				SET("DEVICECODE=#{devicecode}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getDeviceversion())) 
				SET("DEVICEVERSION=#{deviceversion}");
			if(suapCustDeviceInfoModel.getUpdatetime() != null) 
				SET("UPDATETIME=#{updatetime}");
			if(StringUtils.isNotEmpty(suapCustDeviceInfoModel.getIsvalid())) 
				SET("ISVALID=#{isvalid}");
			
			WHERE("IDTYPE=#{idtype}").WHERE("IDNUMBER=db_encrypt(#{idnumber})").WHERE("CHANNELID=#{channelid}");
			
		}}.toString();
	}
	
	
	
	
	
	
	
	
}
