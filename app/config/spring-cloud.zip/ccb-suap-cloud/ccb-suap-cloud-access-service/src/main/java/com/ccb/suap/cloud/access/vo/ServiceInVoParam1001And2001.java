package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;

public class ServiceInVoParam1001And2001 {
	
	private SuapFaceConfigModel faceConfig;						//人脸参数配置
	private String custNo;										//渠道客户号
	private SuapCustInfoModel custInfo_database;				//数据库中客户信息
	private SuapCustInfoModel custInfo_reqMsg;					//请求信息封装的客户信息
	private SuapCustDeviceInfoModel custDeviceInfo_database;	//数据库中渠道注册信息
	private SuapCustDeviceInfoModel custDeviceInfo_reqMsg;		//请求信息封装的渠道注册信息
	private String idverify_image;								//联网核查中证件照
	
	public SuapFaceConfigModel getFaceConfig() {
		return faceConfig;
	}
	public void setFaceConfig(SuapFaceConfigModel faceConfig) {
		this.faceConfig = faceConfig;
	}
	public String getCustNo() {
		return custNo;
	}
	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}
	public SuapCustInfoModel getCustInfo_database() {
		return custInfo_database;
	}
	public void setCustInfo_database(SuapCustInfoModel custInfo_database) {
		this.custInfo_database = custInfo_database;
	}
	public SuapCustInfoModel getCustInfo_reqMsg() {
		return custInfo_reqMsg;
	}
	public void setCustInfo_reqMsg(SuapCustInfoModel custInfo_reqMsg) {
		this.custInfo_reqMsg = custInfo_reqMsg;
	}
	public SuapCustDeviceInfoModel getCustDeviceInfo_database() {
		return custDeviceInfo_database;
	}
	public void setCustDeviceInfo_database(SuapCustDeviceInfoModel custDeviceInfo_database) {
		this.custDeviceInfo_database = custDeviceInfo_database;
	}
	public SuapCustDeviceInfoModel getCustDeviceInfo_reqMsg() {
		return custDeviceInfo_reqMsg;
	}
	public void setCustDeviceInfo_reqMsg(SuapCustDeviceInfoModel custDeviceInfo_reqMsg) {
		this.custDeviceInfo_reqMsg = custDeviceInfo_reqMsg;
	}
	public String getIdverify_image() {
		return idverify_image;
	}
	public void setIdverify_image(String idverify_image) {
		this.idverify_image = idverify_image;
	}
	
	@Override
	public String toString() {
		return "ServiceInVoParam1001And2001 [faceConfig=" + faceConfig + ", custNo=" + custNo + ", custInfo_database="
				+ custInfo_database + ", custInfo_reqMsg=" + custInfo_reqMsg + ", custDeviceInfo_database="
				+ custDeviceInfo_database + ", custDeviceInfo_reqMsg=" + custDeviceInfo_reqMsg + ", idverify_image="
				+ idverify_image + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
