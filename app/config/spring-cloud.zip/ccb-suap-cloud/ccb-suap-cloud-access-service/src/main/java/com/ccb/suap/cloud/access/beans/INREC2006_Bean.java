package com.ccb.suap.cloud.access.beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.service.SuapCustDeviceInfoService;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC2006ServiceInVo;
import com.ccb.suap.cloud.access.vo.INRECBaseServiceInVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

@Controller("INREC2006")
public class INREC2006_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC2006_Bean.class);
	
	@Autowired
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	
//	private SuapCustDeviceInfoService suapCustDeviceInfoService= InrecDaoFactory.getDaoManager().getSuapCustDeviceInfoService();

	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n------------------调用INREC2006服务------------------");
		ServiceParaUtil.setFaceLogByBaseEntity(reqMsg, FaceLogThreadLocal.get());
		
		INREC2006ServiceInVo entity = (INREC2006ServiceInVo) reqMsg.getTx_body().getEntity();
		
		setChannelCustNo(rspMsg,reqMsg);
		
		LOGGER.debug("check entity: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		String id_no = entity.getId_no();
		String id_type = entity.getId_type();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(id_type+id_no));
		LOGGER.debug("closeCustDeviceInfo: num: "+num+", id_type: "+id_type+", id_no: "+id_no+", ChannelId: "+reqMsg.getTx_body().getCom1().getSysChannelID());
		suapCustDeviceInfoService.closeWithRedis(num, id_type, id_no, reqMsg.getTx_body().getCom1().getSysChannelID());
		return rspMsg;
	}
	
	
	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		INRECBaseServiceInVo entity = (INRECBaseServiceInVo) reqMsg.getTx_body().getEntity();
		
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		
		String id_type = entity.getId_type();
		String id_no = entity.getId_no();
		String channel_custno = entity.getChannel_custno();
		
		if("".equals(id_type) || id_type == null)
			throw new CommonRuntimeException(Errorcode.ID_TYPENOTNULL);
		if("".equals(id_no) || id_no == null)
			throw new CommonRuntimeException(Errorcode.ID_NUMBNOTNULL);
		if(locationIndex.equals("2") && ("".equals(channel_custno) || channel_custno == null))
			throw new CommonRuntimeException(Errorcode.CHANLCSTNONULL);
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("deleteCustDevInfo(").append(deleteCustDevInfo)
//		.append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	
	/**
	 * 	通过id_type,id_no,channelId查出渠道客户号
	 * @param rspMsg
	 * @param reqMsg
	 */
	private void setChannelCustNo(TxResponseMsg rspMsg, TxRequestMsg reqMsg) {
		INREC2006ServiceInVo inrec2006ReqEntity = (INREC2006ServiceInVo) reqMsg.getTx_body().getEntity();
		
		if(inrec2006ReqEntity.getChannel_custno() != null)
			return;
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		
		if("1".equals(locationIndex)) {
			inrec2006ReqEntity.setChannel_custno(inrec2006ReqEntity.getId_no());
			return;
		}
		
		String id_type = inrec2006ReqEntity.getId_type();
		String id_no = inrec2006ReqEntity.getId_no();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(id_type+id_no));
		SuapCustDeviceInfoModel suapCustDeviceInfoModel = null;
		try {
			suapCustDeviceInfoModel = suapCustDeviceInfoService.select(num, id_type, id_no, reqMsg.getTx_body().getCom1().getSysChannelID());
		} catch (Exception e) {
			LOGGER.error("select custInfo fail: ",e);
			throw new CommonRuntimeException(Errorcode.SECCSTINFERROR);
		}
		
		if(suapCustDeviceInfoModel == null)
			throw new CommonRuntimeException(Errorcode.CHANLCSTNONULL);
		
		inrec2006ReqEntity.setChannel_custno(suapCustDeviceInfoModel.getChannel_cstno());
		
	}

	

	
}
