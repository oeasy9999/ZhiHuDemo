package com.ccb.suap.cloud.access.threadLocal;

/**
 * 	使用此对象需要在INRECInterceptor的afterCompletion中销毁
 */

import com.ccb.suap.cloud.access.model.SuapFaceLogModel;

public class FaceLogThreadLocal {
	
	private static ThreadLocal<SuapFaceLogModel> faceLogThreadLocal = new ThreadLocal<SuapFaceLogModel>() {
		
		@Override
		protected SuapFaceLogModel initialValue() {
			return new SuapFaceLogModel();
		};
		
	};
	
	
	/**
	 * 	私有化构造方法，防止外部创建实例
	 */
	private FaceLogThreadLocal() {
		
	}
	
	
	public static void set(SuapFaceLogModel faceLogModel) {
		faceLogThreadLocal.set(faceLogModel);
	}
	
	
	public static SuapFaceLogModel get() {
		return faceLogThreadLocal.get();
	}
	
	
	public static void remove() {
		faceLogThreadLocal.remove();
	}
	
	
	
}
