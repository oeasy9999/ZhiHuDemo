package com.ccb.suap.cloud.access.mapper;

import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.jdbc.SQL;

import com.ccb.suap.cloud.access.model.SuapFaceLogModel;

public class SuapFaceLogProvider {
	
	public String insert(SuapFaceLogModel suapFaceLogModel) {
		String sql = new SQL() {{
			INSERT_INTO("SUAP_FACE_LOG_"+suapFaceLogModel.getNum());
			
			if(StringUtils.isBlank(suapFaceLogModel.getChannelid()))
				suapFaceLogModel.setChannelid("");
			if(StringUtils.isBlank(suapFaceLogModel.getChanneltxcode())) 
				suapFaceLogModel.setChanneltxcode("");
			if(StringUtils.isBlank(suapFaceLogModel.getIdno()))
				suapFaceLogModel.setIdno("");
			if(StringUtils.isBlank(suapFaceLogModel.getCustid()))
				suapFaceLogModel.setCustid("");
			if(StringUtils.isBlank(suapFaceLogModel.getBranchid())) 
				suapFaceLogModel.setBranchid("");
			if(StringUtils.isBlank(suapFaceLogModel.getTransflow())) 
				suapFaceLogModel.setTransflow("");
			if(StringUtils.isBlank(suapFaceLogModel.getTxcode())) 
				suapFaceLogModel.setTxcode("");
			if(StringUtils.isBlank(suapFaceLogModel.getTransret())) 
				suapFaceLogModel.setTransret("");
			if(StringUtils.isBlank(suapFaceLogModel.getHostname()) ) 
				suapFaceLogModel.setHostname("");
			if(StringUtils.isBlank(suapFaceLogModel.getServerip())) 
				suapFaceLogModel.setServerip("");
			if(StringUtils.isBlank(suapFaceLogModel.getErrorcode()) ) 
				suapFaceLogModel.setErrorcode("");
			
			VALUES("LOGID", "#{logid}");
			VALUES("CHANNELID", "#{channelid}");
			VALUES("CHANNELTXCODE", "#{channeltxcode}");
			VALUES("BRANCHID", "#{branchid}");
			VALUES("TRANSFLOW", "#{transflow}");
			VALUES("IDTYPE", "#{idtype}");
			VALUES("IDNO", "db_encrypt(#{idno})");
			VALUES("NAME", "#{name}");
			VALUES("MOBILE", "#{mobile}");
			VALUES("CUSTID", "db_encrypt(#{custid})");
			VALUES("SIMILARITY", "#{similarity}");
			VALUES("RECVTIME", "#{recvtime}");
			VALUES("RESPTIME", "#{resptime}");
			VALUES("TXCODE", "#{txcode}");
			VALUES("TRANSRET", "#{transret}");
			VALUES("HOSTNAME", "#{hostname}");
			VALUES("SERVERIP", "#{serverip}");
			VALUES("USERNAME", "#{username}");
			VALUES("ERRORCODE", "#{errorcode}");
			VALUES("VENDORCODE", "#{vendorcode}");
			VALUES("VENDORERRCODE", "#{vendorerrcode}");
			VALUES("ERRORMSG", "#{errormsg}");
			VALUES("RECVTIMEMILLIS", "#{recvtimemillis}");
			VALUES("RESPTIMEMILLIS", "#{resptimemillis}");
			VALUES("COSTTIMEINFO", "#{costtimeinfo}");
			VALUES("FACEFILEPATH", "#{facefilepath}");
			VALUES("REMARKS", "#{remarks}");
			
		}}.toString();
		
		return sql;
	}
	
	
	
	
	
	
	
}
