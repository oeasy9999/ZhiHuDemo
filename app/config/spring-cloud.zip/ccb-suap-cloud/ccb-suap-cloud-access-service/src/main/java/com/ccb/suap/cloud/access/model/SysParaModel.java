package com.ccb.suap.cloud.access.model;

import java.util.Date;

public class SysParaModel implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8327242722973142267L;

	private String id;
	private String paracode;
	private String paraname;
	private String paravalue;
	private String paratype;
	private String deployid;
	private String remark;
	private String creator;
	private Date createtime;
	private Integer version;
	private String operuserid;
	private Date opertime;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getParacode() {
		return paracode;
	}
	public void setParacode(String paracode) {
		this.paracode = paracode;
	}
	public String getParaname() {
		return paraname;
	}
	public void setParaname(String paraname) {
		this.paraname = paraname;
	}
	public String getParavalue() {
		return paravalue;
	}
	public void setParavalue(String paravalue) {
		this.paravalue = paravalue;
	}
	public String getParatype() {
		return paratype;
	}
	public void setParatype(String paratype) {
		this.paratype = paratype;
	}
	public String getDeployid() {
		return deployid;
	}
	public void setDeployid(String deployid) {
		this.deployid = deployid;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public String getOperuserid() {
		return operuserid;
	}
	public void setOperuserid(String operuserid) {
		this.operuserid = operuserid;
	}
	public Date getOpertime() {
		return opertime;
	}
	public void setOpertime(Date opertime) {
		this.opertime = opertime;
	}
}
