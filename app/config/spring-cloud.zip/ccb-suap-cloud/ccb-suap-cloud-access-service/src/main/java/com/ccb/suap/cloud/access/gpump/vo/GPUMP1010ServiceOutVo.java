package com.ccb.suap.cloud.access.gpump.vo;

import java.util.List;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class GPUMP1010ServiceOutVo extends TxResponseMsgEntity{
	
	private List<String> quality;				//图片质量，范围0-1

	public List<String> getQuality() {
		return quality;
	}

	public void setQuality(List<String> quality) {
		this.quality = quality;
	}

	@Override
	public String toString() {
		return "GPUMP1010ServiceOutVo [quality=" + quality + "]";
	}
	
	
	
	
	
	
	
	
}
