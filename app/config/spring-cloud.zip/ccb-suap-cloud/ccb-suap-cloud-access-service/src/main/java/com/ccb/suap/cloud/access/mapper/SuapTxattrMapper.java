package com.ccb.suap.cloud.access.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

import com.ccb.suap.cloud.access.model.SuapTxattrModel;

@Mapper
public interface SuapTxattrMapper {
	
	@Insert("INSERT INTO suap_txattr(txcode,txname,txpath,isoutbound,ptxcode,ptxpath,appcode,remark) VALUES(#{txcode},#{txname},#{txpath},#{isoutbound},#{ptxcode},#{ptxpath},#{appcode},#{remark})")
	int insert(SuapTxattrModel suap_txattrModel);
	
	
	
	
	
	@Update("UPDATE suap_txattr SET txcode=#{txcode},txname=#{txname},txpath=#{txpath},isoutbound=#{isoutbound},ptxcode=#{ptxcode},ptxpath=#{ptxpath},remark=#{remark}")
	int update(SuapTxattrModel suap_txattrModel);
	
	
	
	
	
	
}
