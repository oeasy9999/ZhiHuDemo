package com.ccb.suap.cloud.access.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.outbound.ccvea.vo.SafeOutboundInVo;

@FeignClient(name = "outbound")
public interface OutBoundClient {
	
	@RequestMapping(value = "/OutBoundService/CCVEA1001",method=RequestMethod.POST,consumes="application/json")
    public JSONObject CCVEAServer1001(TxRequestMsg txRequestMsg);
	@RequestMapping(value = "/OutBoundService/CCVEA1002",method=RequestMethod.POST,consumes="application/json")
	public JSONObject CCVEAServer1002(TxRequestMsg txRequestMsg);
	@RequestMapping(value = "/OutBoundService/CCVEA1003",method=RequestMethod.POST,consumes="application/json")
	public JSONObject CCVEAServer1003(TxRequestMsg txRequestMsg);
	@RequestMapping(value = "/OutBoundService/CCVEA1004",method=RequestMethod.POST,consumes="application/json")
	public JSONObject CCVEAServer1004(TxRequestMsg txRequestMsg);
	@RequestMapping(value = "/OutBoundService/CCVEA1005",method=RequestMethod.POST,consumes="application/json")
	public JSONObject CCVEAServer1005(TxRequestMsg txRequestMsg);
	@RequestMapping(value = "/SafeOutbound",method=RequestMethod.POST,consumes="application/json")
	public JSONObject SafeOutbound(SafeOutboundInVo safeOutboundInVo);
	
	@RequestMapping(value = "/OutBoundService/ZZBRT2001",method=RequestMethod.POST,consumes="application/json")
	public JSONObject ZZBRTServer2001(TxRequestMsg txRequestMsg);
	@RequestMapping(value = "/OutBoundService/ZZBRT2002",method=RequestMethod.POST,consumes="application/json")
	public JSONObject ZZBRTServer2002(TxRequestMsg txRequestMsg);
	@RequestMapping(value = "/OutBoundService/ZZBRT2003",method=RequestMethod.POST,consumes="application/json")
	public JSONObject ZZBRTServer2003(TxRequestMsg txRequestMsg);
	
	
	
	
}
