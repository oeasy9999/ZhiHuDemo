package com.ccb.suap.cloud.access.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ccb.suap.cloud.access.model.SuapCustBlackListModel;

public interface SuapCustBlackListMapper {
	
	@Select("SELECT IDTYPE,db_decrypt(IDNUMBER) IDNUMBER,CHANNELID,CUSTNAME,REMARKS FROM SUAP_CUST_BLACKLIST WHERE IDNUMBER=db_encrypt(#{idnumber}) and CHANNELID=#{channelid}")
	SuapCustBlackListModel selectOne(@Param("idnumber") String idnumber, @Param("channelid") String channelid);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
