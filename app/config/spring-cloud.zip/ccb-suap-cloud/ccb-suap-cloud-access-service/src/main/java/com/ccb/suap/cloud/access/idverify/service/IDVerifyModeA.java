package com.ccb.suap.cloud.access.idverify.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.service.OutBoundService;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.vo.INREC1001And2001ServiceInVo;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam1001And2001;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1004ServiceInVo;

/**
 * 	私有云CCVEA1004人脸核查
 * @author 86156
 *
 */

@Service("IDVerify1")
public class IDVerifyModeA implements IDVerifyMode{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Autowired
	private OutBoundService outboundService;
	
	
	@Override
	public boolean verify(TxRequestMsg reqMsg, SuapFaceConfigModel faceConfig, ServiceInVoParam1001And2001 param) {
		
		checkByCCVEA1004(reqMsg);
		
		return true;
	}
	
	
	/**
	 * 发往CCVEA1004注册私有云总库信息
	 * @param reqMsg
	 */
	private void checkByCCVEA1004(TxRequestMsg reqMsg) {
		TxRequestMsg ccvea1004ReqMsg = getCCVEA1004ReqMsg(reqMsg);
		LOGGER.debug("send CCVEA1004: "+ccvea1004ReqMsg);
		TxResponseMsg ccvea1004Rsp = outboundService.sendCCVEA1004(ccvea1004ReqMsg);
		LOGGER.debug("return by CCVEA1004: "+ccvea1004Rsp);
		
		String resp_code = ccvea1004Rsp.getTx_header().getSys_resp_code();
		String resp_desc = ccvea1004Rsp.getTx_header().getSys_resp_desc();
		if(!"000000000000".equals(resp_code)) {
			LOGGER.error("check By CCVEA1004 fail: "+ccvea1004Rsp.getTx_header());
			throw new CommonRuntimeException(resp_code, resp_desc, "01", "checkByCCVEA1004 error, resp_code: " + resp_code + ", resp_desc: " + resp_desc);
		}
		
	}
	
	
	/**
	 * 封装CCVEA1004请求信息
	 * @param reqMsg
	 * @return
	 */
	private TxRequestMsg getCCVEA1004ReqMsg(TxRequestMsg reqMsg) {
		TxRequestMsg ccvea1004ReqMsg = ServiceParaUtil.newReqMsg(reqMsg);
		CCVEA1004ServiceInVo ccvea1004ReqEntity = new CCVEA1004ServiceInVo();
		ccvea1004ReqMsg.getTx_header().setSys_tx_code("CCVEA1004");
		ccvea1004ReqMsg.getTx_body().setEntity(ccvea1004ReqEntity);
		INREC1001And2001ServiceInVo entity = (INREC1001And2001ServiceInVo) reqMsg.getTx_body().getEntity();
		
		ccvea1004ReqEntity.setSYSTEM_TIME("201908261931");
		ccvea1004ReqEntity.setStm_Chnl_ID("1266");
		ccvea1004ReqEntity.setStm_Chnl_Txn_CD("FACE-ECUAC0183");
		ccvea1004ReqEntity.setCst_Nm(entity.getName());
		ccvea1004ReqEntity.setCrdTp_Cd(entity.getId_type());
		ccvea1004ReqEntity.setCrdt_No(entity.getId_no());
		ccvea1004ReqEntity.setBr_ID(entity.getBranch_id());
		ccvea1004ReqEntity.setRmrk_1_Rcrd_Cntnt(entity.getMobile_no());
		ccvea1004ReqEntity.setBase64_ECD_Txn_Inf("");
		ccvea1004ReqEntity.setBase64_Ecrp_Txn_Inf(entity.getFace_image());
		ccvea1004ReqEntity.setBr_ID_Inf("");
		ccvea1004ReqEntity.setGeo_Lo_ID("");
		ccvea1004ReqEntity.setMftr_Idr_CD("");
		ccvea1004ReqEntity.setMftr_Str_VNo("");
		ccvea1004ReqEntity.setFtr_Col_TmnlInf("");
		ccvea1004ReqEntity.setTmnl_Eqmt_No("");
		ccvea1004ReqEntity.setEqmt_Modl_VNo("");
		ccvea1004ReqEntity.setEqmt_Ctfn_CD("");
		ccvea1004ReqEntity.setUsr_Inf_Dsc("");
		ccvea1004ReqEntity.setEqmt_Inf_Dsc("");
		ccvea1004ReqEntity.setAflt_Inf_Dsc("");
		ccvea1004ReqEntity.setRsrv_1_Inf_Dsc("");
		ccvea1004ReqEntity.setRsrv_2_Inf_Dsc("");
		ccvea1004ReqEntity.setRsrv_3_Inf_Dsc("");
		ccvea1004ReqEntity.setRsrv_4_Inf_Dsc("");
		ccvea1004ReqEntity.setRsrv_5_Inf_Dsc("");
		
		return ccvea1004ReqMsg;
	}
	
	
	
	
	
	
	
	
	
	
}
