package com.ccb.suap.cloud.access.mapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.util.log.MyFileLogger;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.log.TraceLog_Entity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class TraceLogger {
	protected static final Logger common_logger = LoggerFactory.getLogger(TraceLogger.class);
	private static Map<String,Logger> loggerMap = new HashMap<String,Logger>();
	private static Object lock1 = new Object();
	/**
	 * 打印缓存日志方法
	 * @param traceLog  报文日志缓存类
	 * @return
	 */
	@Async("traceLogExecutor")
	public void dispose(TraceLog traceLog) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		traceLog.setEndTime(System.currentTimeMillis());

		//1.总开关判定----------------------------------------
		boolean logFlag = true;
		if(traceLog == null || !logFlag)
//			return false;
			return;


		//3.计算日志名----------------------------------------
		String logName = traceLog.getLogName();
		if(logName.startsWith("/")){
			logName = logName.substring(1);
		}
		logName = logName.replaceAll("/", "_");

		//4.计算各种耗时----------------------------------------
		long startTime = traceLog.getStartTime();
		long endTime = traceLog.getEndTime();
		long httpcost = traceLog.getHttpcost();

		long totalcost = endTime - startTime;

		long codecost = totalcost - httpcost;

		String logPath=SuapSysParaUtil.getStrPara("LogPath","./logs");
//		String logPath="E:\\logfile";
		String maxFileSize=SuapSysParaUtil.getStrPara("MaxFileSize:1","100mb");
		String totalSizeCap=SuapSysParaUtil.getStrPara("TotalSizeCap:1","100gb");
		//获取日志logger对象----------------------------------------
		Logger logger = null;
		synchronized(lock1) {
			logger = loggerMap.get(logName);
			if(logger == null) {
				logger = MyFileLogger.getLogger(logName,logPath,maxFileSize,totalSizeCap);
				loggerMap.put(logName, logger);
			}
		}

		//7logger写入日志----------------------------------------
		synchronized(logger) {
			logger.info("============ [  summary  ] ============");
			logger.info("CCB-Trace-Id     : " + traceLog.getTraceId());
			logger.info("Request-url      : " + traceLog.getUrl());
			logger.info("Start Time       : " + sdf.format(new Date(startTime)));
			logger.info("End Time         : " + sdf.format(new Date(endTime)));
			logger.info("============ [  request_client  ] ============");
			logger.info("HttpRequestBody_client  : ");
			logger.info(traceLog.getRequestJsonString_client());
			
			if(traceLog.getRequestJsonString()!=null)
			{
				logger.info("============ [  request  ] ============");
				logger.info("HttpRequestBody  : ");
				logger.info(traceLog.getRequestJsonString());
			}
			if(traceLog.getRequestJsonString_gpump1011()!=null)
			{
				logger.info("============ [  gpump1011 request  ] ============");
				logger.info("HttpRequestBody gpump1011 : ");
				logger.info(traceLog.getRequestJsonString_gpump1011());
			}
			if(traceLog.getResponseJsonString_gpump1011()!=null)
			{
				logger.info("============ [  gpump1011 response  ] ============");
				logger.info("HttpResponseBody gpump1011 : ");
				logger.info(traceLog.getResponseJsonString_gpump1011());
				logger.info("gpump1011 Use Time   : " + traceLog.getSendGpump1011Time());
			}
			if(traceLog.getRequestJsonString_gpump1010()!=null)
			{
				logger.info("============ [  gpump1010 request  ] ============");
				logger.info("HttpRequestBody gpump1010 : ");
				logger.info(traceLog.getRequestJsonString_gpump1010());
			}
			if(traceLog.getResponseJsonString_gpump1010()!=null)
			{
				logger.info("============ [  gpump1010 response  ] ============");
				logger.info("HttpResponseBody gpump1010 : ");
				logger.info(traceLog.getResponseJsonString_gpump1010());
				logger.info("gpump1010 Use Time   : " + traceLog.getSendGpump1010Time());
			}
			
			if(traceLog.getRequestJsonString_gpump1001()!=null)
			{
				logger.info("============ [  gpump1001 request  ] ============");
				logger.info("HttpRequestBody gpump1001 : ");
				logger.info(traceLog.getRequestJsonString_gpump1001());
			}
			if(traceLog.getResponseJsonString_gpump1001()!=null)
			{
				logger.info("============ [  gpump1001 response  ] ============");
				logger.info("HttpResponseBody gpump1001 : ");
				logger.info(traceLog.getResponseJsonString_gpump1001());
				logger.info("gpump1001 Use Time   : " + traceLog.getSendGpump1001Time());
			}
			if(traceLog.getRequestJsonString_gpump1002()!=null)
			{
				logger.info("============ [  gpump1002 request  ] ============");
				logger.info("HttpRequestBody gpump1002 : ");
				logger.info(traceLog.getRequestJsonString_gpump1002());
			}
			if(traceLog.getResponseJsonString_gpump1002()!=null)
			{
				logger.info("============ [  gpump1002 response  ] ============");
				logger.info("HttpResponseBody gpump1002 : ");
				logger.info(traceLog.getResponseJsonString_gpump1002());
				logger.info("gpump1002 Use Time   : " + traceLog.getSendGpump1002Time());
			}
			if(traceLog.getRequestJsonString_gpump1003()!=null)
			{
				logger.info("============ [  gpump1003 request  ] ============");
				logger.info("HttpRequestBody gpump1003 : ");
				logger.info(traceLog.getRequestJsonString_gpump1003());
			}
			if(traceLog.getResponseJsonString_gpump1003()!=null)
			{
				logger.info("============ [  gpump1003 response  ] ============");
				logger.info("HttpResponseBody gpump1003 : ");
				logger.info(traceLog.getResponseJsonString_gpump1003());
				logger.info("gpump1003 Use Time   : " + traceLog.getSendGpump1003Time());
			}
			if(traceLog.getRequestJsonString_gpump1005()!=null)
			{
				logger.info("============ [  gpump1005 request  ] ============");
				logger.info("HttpRequestBody gpump1005 : ");
				logger.info(traceLog.getRequestJsonString_gpump1005());
			}
			if(traceLog.getResponseJsonString_gpump1005()!=null)
			{
				logger.info("============ [  gpump1005 response  ] ============");
				logger.info("HttpResponseBody gpump1005 : ");
				logger.info(traceLog.getResponseJsonString_gpump1005());
				logger.info("gpump1005 Use Time   : " + traceLog.getSendGpump1005Time());
			}
			if(traceLog.getRequestJsonString_gpump1006()!=null)
			{
				logger.info("============ [  gpump1006 request  ] ============");
				logger.info("HttpRequestBody gpump1006 : ");
				logger.info(traceLog.getRequestJsonString_gpump1006());
			}
			if(traceLog.getResponseJsonString_gpump1006()!=null)
			{
				logger.info("============ [  gpump1006 response  ] ============");
				logger.info("HttpResponseBody gpump1006 : ");
				logger.info(traceLog.getResponseJsonString_gpump1006());
				logger.info("gpump1006 Use Time   : " + traceLog.getSendGpump1006Time());
			}
			
			if(traceLog.getRequestJsonString_gpump1007()!=null)
			{
				logger.info("============ [  gpump1007 request  ] ============");
				logger.info("HttpRequestBody gpump1007 : ");
				logger.info(traceLog.getRequestJsonString_gpump1007());
			}
			if(traceLog.getResponseJsonString_gpump1007()!=null)
			{
				logger.info("============ [  gpump1007 response  ] ============");
				logger.info("HttpResponseBody gpump1007 : ");
				logger.info(traceLog.getResponseJsonString_gpump1007());
				logger.info("gpump1007 Use Time   : " + traceLog.getSendGpump1007Time());
			}
			
			if(traceLog.getRequestJsonString_gpump1008()!=null)
			{
				logger.info("============ [  gpump1008 request  ] ============");
				logger.info("HttpRequestBody gpump1008 : ");
				logger.info(traceLog.getRequestJsonString_gpump1008());
			}
			if(traceLog.getResponseJsonString_gpump1008()!=null)
			{
				logger.info("============ [  gpump1008 response  ] ============");
				logger.info("HttpResponseBody gpump1008 : ");
				logger.info(traceLog.getResponseJsonString_gpump1008());
				logger.info("gpump1008 Use Time   : " + traceLog.getSendGpump1008Time());
			}
			
			if(traceLog.getRequestJsonString_gpump1009()!=null)
			{
				logger.info("============ [  gpump1009 request  ] ============");
				logger.info("HttpRequestBody gpump1009 : ");
				logger.info(traceLog.getRequestJsonString_gpump1009());
			}
			if(traceLog.getResponseJsonString_gpump1009()!=null)
			{
				logger.info("============ [  gpump1009 response  ] ============");
				logger.info("HttpResponseBody gpump1009 : ");
				logger.info(traceLog.getResponseJsonString_gpump1009());
				logger.info("gpump1009 Use Time   : " + traceLog.getSendGpumq1009Time());
			}
			if (traceLog.getRequestJsonString_CCVEA1001()!=null) {
				logger.info("============ [  CCVEA1001 request  ] ============");
				logger.info("HttpRequestBody CCVEA1001 : ");
				logger.info(traceLog.getRequestJsonString_CCVEA1001());
			}
			if (traceLog.getResponseJsonString_CCVEA1001()!=null) {
				logger.info("============ [  CCVEA1001 response  ] ============");
				logger.info("HttpResponseBody CCVEA1001 : ");
				logger.info(traceLog.getResponseJsonString_CCVEA1001());
				logger.info("CCVEA1001 Use Time :" +traceLog.getSendCCVEA1001Time());
			}
			
			if (traceLog.getRequestJsonString_CCVEA1002()!=null) {
				logger.info("============ [  CCVEA1002 request  ] ============");
				logger.info("HttpRequestBody CCVEA1002 : ");
				logger.info(traceLog.getRequestJsonString_CCVEA1002());
			}
			if (traceLog.getResponseJsonString_CCVEA1002()!=null) {
				logger.info("============ [  CCVEA1002 response  ] ============");
				logger.info("HttpResponseBody CCVEA1002 : ");
				logger.info(traceLog.getResponseJsonString_CCVEA1002());
				logger.info("CCVEA1002 Use Time :" +traceLog.getSendCCVEA1002Time());
			}
			
			if (traceLog.getRequestJsonString_CCVEA1003()!=null) {
				logger.info("============ [  CCVEA1003 request  ] ============");
				logger.info("HttpRequestBody CCVEA1003 : ");
				logger.info(traceLog.getRequestJsonString_CCVEA1003());
			}
			if (traceLog.getResponseJsonString_CCVEA1003()!=null) {
				logger.info("============ [  CCVEA1003 response  ] ============");
				logger.info("HttpResponseBody CCVEA1003 : ");
				logger.info(traceLog.getResponseJsonString_CCVEA1003());
				logger.info("CCVEA1003 Use Time :" +traceLog.getSendCCVEA1003Time());
			}
			
			if (traceLog.getRequestJsonString_CCVEA1004()!=null) {
				logger.info("============ [  CCVEA1004 request  ] ============");
				logger.info("HttpRequestBody CCVEA1004 : ");
				logger.info(traceLog.getRequestJsonString_CCVEA1004());
			}
			if (traceLog.getResponseJsonString_CCVEA1004()!=null) {
				logger.info("============ [  CCVEA1004 response  ] ============");
				logger.info("HttpResponseBody CCVEA1004 : ");
				logger.info(traceLog.getResponseJsonString_CCVEA1004());
				logger.info("CCVEA1004 Use Time :" +traceLog.getSendCCVEA1004Time());
			}
			
			if (traceLog.getRequestJsonString_CCVEA1005()!=null) {
				logger.info("============ [  CCVEA1005 request  ] ============");
				logger.info("HttpRequestBody CCVEA1005 : ");
				logger.info(traceLog.getRequestJsonString_CCVEA1005());
			}
			if (traceLog.getResponseJsonString_CCVEA1005()!=null) {
				logger.info("============ [  CCVEA1005 response  ] ============");
				logger.info("HttpResponseBody CCVEA1005 : ");
				logger.info(traceLog.getResponseJsonString_CCVEA1005());
				logger.info("CCVEA1005 Use Time :" +traceLog.getSendCCVEA1005Time());
			}
			
			if(traceLog.getEntity_list() != null && traceLog.getEntity_list().size() > 0)
				printOutboundEntity(logger, traceLog);
			
			logger.info("============ [  detail   ] ============");
			for(String str:traceLog.getLogDetailStrList()){
				logger.info(str);
			}
			if(traceLog.getResponseJsonString()!=null)
			{
				logger.info("============ [ response  ] ============");
				logger.info("HttpResponseBody : ");
				logger.info(traceLog.getResponseJsonString());
			}
			logger.info("============ [ response_client  ] ============");
			logger.info("HttpResponseBody_client : ");
			logger.info(traceLog.getResponseJsonString_client());
			if(traceLog.getErrormessage()!=null)
			{
				logger.info("============ [ Errormessage  ] ============");
				logger.info(traceLog.getErrormessage());
			}
			logger.info("============ [ time cost ] ============");
			logger.info("Total Use Time   : " + totalcost);
			logger.info("Http Use Time    : " + httpcost);
			logger.info("Code Cost        : " + codecost);
			logger.info("#################################################################\r\n\r\n");
		}

//		return true;
	}

	
	private void printOutboundEntity(Logger logger, TraceLog traceLog) {
		List<TraceLog_Entity> list = traceLog.getEntity_list();
		
		for (TraceLog_Entity traceLog_outboundEntity : list) {
			logger.info("============ [  " + traceLog_outboundEntity.getName() + " request  ] ============");
			logger.info("HttpRequestBody " + traceLog_outboundEntity.getName() + " : ");
			logger.info(traceLog_outboundEntity.getRequestMessage());
			logger.info("============ [  " + traceLog_outboundEntity.getName() + " response  ] ============");
			logger.info("HttpResponseBody " + traceLog_outboundEntity.getName() + " : ");
			logger.info(traceLog_outboundEntity.getResponseMessage());
			logger.info(traceLog_outboundEntity.getName() + " Use Time :" + traceLog_outboundEntity.getCosttime());
		}
		
	}
	
	
	
}
