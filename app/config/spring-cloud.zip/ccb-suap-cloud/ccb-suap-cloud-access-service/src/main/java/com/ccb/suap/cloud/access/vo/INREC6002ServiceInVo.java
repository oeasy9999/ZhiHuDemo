package com.ccb.suap.cloud.access.vo;

import java.io.Serializable;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class INREC6002ServiceInVo extends TxRequestMsgEntity implements Serializable{
	
	private static final long serialVersionUID = 8759633215392362982L;
	
	private String image_name;				//图片名称
	private String face_image;				//图片
	private String image_tpye;				//状态标识
	
	public String getImage_name() {
		return image_name;
	}
	public void setImage_name(String image_name) {
		this.image_name = image_name;
	}
	public String getFace_image() {
		return face_image;
	}
	public void setFace_image(String face_image) {
		this.face_image = face_image;
	}
	public String getImage_tpye() {
		return image_tpye;
	}
	public void setImage_tpye(String image_tpye) {
		this.image_tpye = image_tpye;
	}
	
	@Override
	public String toString() {
		return "INREC6002ServiceInVo [image_name=" + image_name + ", face_image=" + face_image + ", image_tpye="
				+ image_tpye + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
