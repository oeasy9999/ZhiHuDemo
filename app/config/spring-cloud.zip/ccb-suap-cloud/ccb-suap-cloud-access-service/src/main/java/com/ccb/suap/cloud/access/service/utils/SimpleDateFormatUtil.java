package com.ccb.suap.cloud.access.service.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SimpleDateFormatUtil {
	
	
	/**
	 * 	以指定格式转换当前时间
	 * @param patten
	 * @return
	 */
	public static String getStrNow(String patten) {
		return getStrByDate(new Date(), patten);
	}
	
	
	/**
	 * 	以指定格式转换指定时间
	 * @param date
	 * @param patten
	 * @return
	 */
	public static String getStrByDate(Date date, String patten) {
		SimpleDateFormat sdf = new SimpleDateFormat(patten);
		return sdf.format(date);
	}
	
	
	/**
	 * 	将String按指定格式转换成Date
	 * @param dateStr
	 * @param patten
	 * @return
	 * @throws Exception
	 */
	public static Date getDateByString(String dateStr, String patten) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(patten);
		Date date = sdf.parse(dateStr);
		
		return date;
	}
	
	
	/**
	 * 以指定格式转换指定延时天数
	 * @param layedDays 延时天数,如昨天为-1，明天为1
	 * @param patten
	 * @return
	 */
	public static String getStrByDelayedDays(int layedDays, String pattern) {
		
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, layedDays);
		
		Date date = calendar.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		
		return sdf.format(date);
	}
	
	
	/**
	 * 以指定格式转换指定延时天数
	 * @param date 需要转换的时间
	 * @param layedDays 延时天数,如昨天为-1，明天为1
	 * @param pattern
	 * @return
	 */
	public static String getStrByDelayedDays(Date date, int layedDays, String pattern) {
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, layedDays);
		
		Date date_new = calendar.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		
		return sdf.format(date_new);
	}
	
	
	
	
}
