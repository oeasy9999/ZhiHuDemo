package com.ccb.suap.cloud.access.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface RedisAnnotation {
	
	dataType dataType();
	actionType actionType();
	
	
	enum dataType {
		CUSTINFO,
		CUSTDEVICEINFO
		
	}
	
	
	enum actionType{
		INSERT,
		DELETE,
		UPDATE,
		SELECT
	}
	
	
	
	
}
