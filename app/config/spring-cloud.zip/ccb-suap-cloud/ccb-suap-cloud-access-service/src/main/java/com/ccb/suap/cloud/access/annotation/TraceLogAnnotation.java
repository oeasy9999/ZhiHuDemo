package com.ccb.suap.cloud.access.annotation;

/**
 * 	用于标记traceLog日志，请求报文需放在接口第一个参数位置
 */

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.core.annotation.AliasFor;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface TraceLogAnnotation {
	
	@AliasFor("value")
	String title() default "";
	
	@AliasFor("title")
	String value() default "";
	
	
	
	
	
	
	
	
}
