package com.ccb.suap.util.file;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import com.ccb.suap.util.Base64;
import com.ccb.suap.util.file.chiper.XORCipher;

public class FileCipherUtils {

	static {
		Security.addProvider(new BouncyCastleProvider());
	}
	private final static byte[] ENC_FILE_PREFIX = {(byte)0x41, (byte)0x6E, (byte)0x79, (byte)0x64, (byte)0x65, (byte)0x66};
	private static String digits = "0123456789abcdef";

	//文件解密用buffer长度
	private static int kBufferSize=8192;


	//分散用密钥，须在上线前与客户端加密工具一致
	private static byte[]  deriveKey = new byte[] {0x31,0x32,0x33,0x34,(byte)0x35,(byte)0x36,(byte)0x37,(byte)0x38};

	//提供了设置buffersize的方法，方便进行设置优化
	public static void setBuffer(int bufferSize)
	{
		kBufferSize = bufferSize;
	}

	//提供了设置分散密钥的方法	
	public static void setDeriveKey(String s) throws UnsupportedEncodingException
	{
		deriveKey = s.getBytes("UTF-8");
	}	

	//口令摘要，入参：客户口令，出参：base64后口令摘要
	public static String getPWD(String userPwd) throws UnsupportedEncodingException, NoSuchAlgorithmException
	{
		byte[] temp = computeDigest(userPwd);
		return new String(Base64.encode(temp));

	}

	//对文件摘要进行验证
	public static int CompareDiget(String fileName,String fileDiget)
	{
		String computeDigest = null;
		try {
			computeDigest = FileDigest(fileName);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		
		if(fileDiget==null)
			return 0;
		if(fileDiget.equals(computeDigest))
			return 1;
		else
			return 0;

		/*byte[] computeDigest = hextoByte(FileDigest(fileName));

		byte[] base64ToByte = Base64.encode(computeDigest);
		FileInputStream fin = null;
		try {
			fin = new FileInputStream(fileName);
			for(int i=0; i<24; i++)
			{
				if(fin.read()!=base64ToByte[i])
				{
					fin.close();
					return 0;
				}
			}
		}catch (Exception e) {
			fin.close();
		} finally {
			if (fin != null) {
				fin.close();
			}
		}
		return 1;*/	


	}



	//计算摘要，入参：口令，出参：摘要值
	public static byte[] computeDigest(String srcString) throws UnsupportedEncodingException, NoSuchAlgorithmException
	{
		byte[] stringDecode = srcString.getBytes("UTF-8");
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(stringDecode);
		return md.digest();
	}


	//密钥分散函数
	public static byte[] wrapKey(byte[] srcBytes, byte[] wrapKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, ShortBufferException, IllegalBlockSizeException, BadPaddingException, NoSuchProviderException, InvalidAlgorithmParameterException
	{
		SecretKeySpec key = new SecretKeySpec(wrapKey, "DESede");
		
		byte[] iv = new byte[8];
		
		System.arraycopy(wrapKey, 0, iv, 0, iv.length);

		IvParameterSpec specIv = new IvParameterSpec(iv);

		Cipher cipher = Cipher.getInstance("DESede/CBC/PKCS7Padding","BC");

		cipher.init(Cipher.ENCRYPT_MODE, key, specIv);


		byte[] cipherText = new byte[cipher.getOutputSize(srcBytes.length)];

		int ctLength = cipher.update(srcBytes, 0, srcBytes.length, cipherText, 0);

		ctLength += cipher.doFinal(cipherText, ctLength);

		return cipherText;
	}


	//密钥分散函数
	private static byte[] getDesKey(String base64Src) throws  InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, ShortBufferException, IllegalBlockSizeException, BadPaddingException, NoSuchProviderException, InvalidAlgorithmParameterException, IOException
	{
		byte[] base64Result = Base64.decode(base64Src);
		byte[] srcBytes = new byte[24];
		for(int i=0;i<24;i++)
		{
			srcBytes[i]=base64Result[i];
		}


		return wrapKey(srcBytes,deriveKey);


	}
	
	//解密文件
	public static boolean DecFile(String cipherFileName, String userPWD) throws Exception
	{
		byte[] key = getDesKey(userPWD);
		return DecFile(key,cipherFileName);
	}


	//解密文件
	public static boolean DecFile(byte[] keyBytes, String srcFileName) throws NoSuchAlgorithmException, NoSuchPaddingException, 
											InvalidKeyException, InvalidAlgorithmParameterException, NoSuchProviderException, IOException
	{
		boolean ret = true;
		
		String destFileName = null;
		
		if(srcFileName.endsWith(".enc")){
			
			destFileName = srcFileName.replaceAll(".enc", "");
		}else{
			throw new IOException("FileName must be endWith by .enc");
			//return false;
		}
		
		FileInputStream in = null;

		FileOutputStream fileout = null;

		CipherInputStream cipherin = null;
		
		try {

			fileout = new FileOutputStream(destFileName);
	
			byte[] bdec = decFile(keyBytes, srcFileName);
			byte[] tb = new byte[ENC_FILE_PREFIX.length];
			System.arraycopy(bdec, 0, tb, 0, tb.length);
			if(tb!=null && Arrays.equals(tb, ENC_FILE_PREFIX)) {
				byte[] tc = new byte[bdec.length - ENC_FILE_PREFIX.length];
				System.arraycopy(bdec, ENC_FILE_PREFIX.length, tc, 0, tc.length);
				fileout.write(tc);
			} else {
				SecretKeySpec key = new SecretKeySpec(keyBytes, "DESede");
				
				//byte[] iv = new byte[8];
				
				//System.arraycopy(keyBytes, 0, iv, 0, iv.length);
				
				//IvParameterSpec specIv = new IvParameterSpec(iv);

				Cipher cipher = Cipher.getInstance("DESede/ECB/ZeroBytePadding","BC");//ECB、CBC、CFB、OFB、CTR/PKCS7Padding/ZeroBytePadding/NoPadding

				cipher.init(Cipher.DECRYPT_MODE, key);
				
				in = new FileInputStream(srcFileName);
				
				cipherin = new CipherInputStream(in,cipher);
				byte[] buffer = new byte[kBufferSize];
				int length;
				while((length=cipherin.read(buffer))!=-1)
				{
					fileout.write(buffer,0,length);
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			if (cipherin != null) {
				try{
					cipherin.close();
				}catch(Exception e){}	
			}

			if (in != null) {
				try{
					in.close();
				}catch(Exception e){}
			}

			if (fileout != null) {
				try{
					fileout.close();
				}catch(Exception e){}
			}
		}
		return ret;

	}
	
	private static byte[] decFile(byte[] keyBytes, String srcFileName) {
		byte[] ret = null;
		DataInputStream dis = null;
		try {
			dis = new DataInputStream(new FileInputStream(srcFileName));
			byte[] dec = new byte[dis.available()];
			dis.readFully(dec);
			
			ret = XORCipher.decode(dec);
			
		} catch(Exception e) {
			return null;
		} finally {
			if (dis != null) {
				try{
					dis.close();
				}catch(Exception e){}
			}
		}
		return ret;
	}
	
	//解密文件
	public static byte[] DecFileBuffer(byte[] keyBytes, String srcFileName) throws NoSuchAlgorithmException, NoSuchPaddingException, 
											InvalidKeyException, InvalidAlgorithmParameterException, NoSuchProviderException, IOException
	{
		byte[] ret = decFile(keyBytes, srcFileName);
		if(ret!=null) {
			byte[] tb = new byte[ENC_FILE_PREFIX.length];
			System.arraycopy(ret, 0, tb, 0, tb.length);
			if(tb!=null && Arrays.equals(tb, ENC_FILE_PREFIX)) {
				byte[] tc = new byte[ret.length - ENC_FILE_PREFIX.length];
				System.arraycopy(ret, ENC_FILE_PREFIX.length, tc, 0, tc.length);
				return tc;
			}
		}
//		String destFileName = null;
//		
//		if(srcFileName.endsWith(".enc")){
//			
//			destFileName = srcFileName.replaceAll(".enc", "");
//		}else{
//			throw new IOException("FileName must be endWith by .enc");
//			//return false;
//		}
		
		
		
		SecretKeySpec key = new SecretKeySpec(keyBytes, "DESede");
		
		//byte[] iv = new byte[8];
		
		//System.arraycopy(keyBytes, 0, iv, 0, iv.length);
		
		//IvParameterSpec specIv = new IvParameterSpec(iv);

		Cipher cipher = Cipher.getInstance("DESede/ECB/ZeroBytePadding","BC");//ECB、CBC、CFB、OFB、CTR/PKCS7Padding/ZeroBytePadding/NoPadding

		cipher.init(Cipher.DECRYPT_MODE, key);

		FileInputStream in = null;

		ByteArrayOutputStream bos = null;

		CipherInputStream cipherin = null;

		try {
			in = new FileInputStream(srcFileName);

			bos = new ByteArrayOutputStream(in.available());
			byte[] buffer = new byte[in.available()];
			cipherin = new CipherInputStream(in,cipher);
			int length;
			while((length=cipherin.read(buffer))!=-1)
			{
				bos.write(buffer,0,length);
			}
			ret = bos.toByteArray();
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (cipherin != null) {
				cipherin.close();
			}

			if (in != null) {
				in.close();
			}

			if (bos != null) {
				bos.close();
			}
		}
		
		return ret;

	}
	
	//加密文件
	public static boolean EecFile(String plainFileName, String userPWD) throws Exception
	{
		byte[] key = getDesKey(userPWD);
		return EecFile(key,plainFileName);
	}
	

	//加密文件
	public static boolean EecFile(byte[] keyBytes, String srcFileName) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, NoSuchProviderException, IOException
	{
		
		FileInputStream in = null;
		DataInputStream dis = null;
		FileOutputStream fileout = null;

		CipherInputStream cipherin = null;

		try {
			in = new FileInputStream(srcFileName);
			dis = new DataInputStream(in);
			byte[] dec = new byte[dis.available()];
			dis.readFully(dec);
			boolean b = encFile(keyBytes, srcFileName+".enc", dec);
			if(b) {
				return b;
			} else {
				SecretKeySpec key = new SecretKeySpec(keyBytes, "DESede");
				
				//byte[] iv = new byte[8];
				
				//System.arraycopy(keyBytes, 0, iv, 0, iv.length);
				
				//IvParameterSpec specIv = new IvParameterSpec(iv);

				Cipher cipher = Cipher.getInstance("DESede/ECB/ZeroBytePadding","BC");

				cipher.init(Cipher.ENCRYPT_MODE, key);
				
				fileout = new FileOutputStream(srcFileName+".enc");
				cipherin = new CipherInputStream(in,cipher);
				byte[] buffer = new byte[kBufferSize];
				int length;
				while((length=cipherin.read(buffer))!=-1)
				{
					fileout.write(buffer,0,length);
				}
			}
		}catch (Exception e) {
			return false;
		} finally {
			if (cipherin != null) {
				try{
					cipherin.close();
				}catch(Exception e){}
			}

			if (in != null) {
				try{
					in.close();
				}catch(Exception e){}
			}
			
			if(dis != null) {
				try{
					dis.close();
				}catch(Exception e){}
			}

			if (fileout != null) {
				try{
					fileout.close();
				}catch(Exception e){}
			}
		}
		
		return true;

	}
	
	private static boolean encFile(byte[] keyBytes, String srcFileName, byte[] srcFileBytes) {
		FileOutputStream fileout = null;
		try {
			byte[] benc = XORCipher.encode(srcFileBytes);
			fileout = new FileOutputStream(srcFileName);
			byte[] prefix = XORCipher.encode(ENC_FILE_PREFIX);
			fileout.write(prefix);
			fileout.write(benc);
		} catch(Exception e) {
			return false;
		} finally {
			if (fileout != null) {
				try{
					fileout.close();
				}catch(Exception e){}
			}
		}
		
		return true;
	}
	
	//加密文件
	public static boolean EecFileBuffer(byte[] keyBytes, String srcFileName, byte[] srcFileBytes) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, NoSuchProviderException, IOException
	{
		if(encFile(keyBytes, srcFileName, srcFileBytes)) {
			return true;
		}
		SecretKeySpec key = new SecretKeySpec(keyBytes, "DESede");
		
		//byte[] iv = new byte[8];
		
		//System.arraycopy(keyBytes, 0, iv, 0, iv.length);
		
		//IvParameterSpec specIv = new IvParameterSpec(iv);

		Cipher cipher = Cipher.getInstance("DESede/ECB/ZeroBytePadding","BC");

		cipher.init(Cipher.ENCRYPT_MODE, key);

		InputStream in = null;

		FileOutputStream fileout = null;

		CipherInputStream cipherin = null;

		try {
			in = (InputStream)new ByteArrayInputStream(srcFileBytes); 

			fileout = new FileOutputStream(srcFileName);
			cipherin = new CipherInputStream(in,cipher);
			byte[] buffer = new byte[kBufferSize];
			int length;
			while((length=cipherin.read(buffer))!=-1)
			{
				fileout.write(buffer,0,length);
			}
		}catch (Exception e) {
			return false;
		} finally {
			if (cipherin != null) {
				try{
					cipherin.close();
				}catch(Exception e){}
			}

			if (in != null) {
				try{
					in.close();
				}catch(Exception e){}
			}

			if (fileout != null) {
				try{
					fileout.close();
				}catch(Exception e){}
			}
		}
		
		return true;

	}


	//计算文件摘要
	public static String FileDigest(String fileName) throws NoSuchAlgorithmException, IOException
	{
		MessageDigest hash = MessageDigest.getInstance("MD5");
		FileInputStream fin = null;
		byte[] hashResult = null;
		try {
			fin = new FileInputStream(fileName);
			int length;
			//fin.skip(24);
			byte[] buffer = new byte[kBufferSize];
			while ((length = fin.read(buffer)) != -1)
				hash.update(buffer,0,length);

			hashResult = hash.digest();
			
			return bytetoHex(hashResult);


		}catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (fin != null) {
				fin.close();
			}
		}
	}


	public static String bytetoHex(byte[] data, int length)
    {
        StringBuffer    buf = new StringBuffer();

        for (int i = 0; i != length; i++)
        {
            int v = data[i] & 0xff;

            buf.append(digits.charAt(v >> 4));
            buf.append(digits.charAt(v & 0xf));
        }

        return buf.toString();
    }
    
    public static String bytetoHex(byte[] data)
    {
        return bytetoHex(data, data.length);
    }

    public static byte[] hextoByte(String s)
    {
        int i = s.length() / 2;
        byte abyte0[] = new byte[i];
        for(int j = 0; j < i; j++)
        {
            String s1 = s.substring(j * 2, j * 2 + 2);
            abyte0[j] = (byte)Integer.parseInt(s1, 16);
        }

        return abyte0;
    }
}
