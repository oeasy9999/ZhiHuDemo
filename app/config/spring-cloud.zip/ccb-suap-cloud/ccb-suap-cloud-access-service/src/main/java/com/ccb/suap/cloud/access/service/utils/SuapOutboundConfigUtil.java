package com.ccb.suap.cloud.access.service.utils;

import java.util.Hashtable;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.access.beans.INREC5001_Bean;
import com.ccb.suap.cloud.access.controller.ConfigRefreshContoller;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.model.SuapOutboundConfigModel;
import com.ccb.suap.cloud.access.service.SuapOutboundConfigService;

@Component
public class SuapOutboundConfigUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigRefreshContoller.class);
	
	public static SuapOutboundConfigUtil outboundConfigUtil;
	
	@Autowired
	private SuapOutboundConfigService outboundConfigService;
	
	
	/**
	 * 	以channelcode:tradecode为key,缓存外呼服务参数配置信息
	 */
	private static Hashtable<String,SuapOutboundConfigModel> MyHashTable = new Hashtable<String,SuapOutboundConfigModel>();
	
	
	@PostConstruct
	public void onInit() {
		outboundConfigUtil = this;
		outboundConfigUtil.outboundConfigService = this.outboundConfigService;
		System.out.println("***************init SuapOutboundConfig***************");
		init();
		
	}
	
	
	/**
	 * 	初始化外呼服务参数配置信息
	 * @return
	 */
	public static int init() {
		
		int result = loadOutboundConfig();
		
		return result;
	}
	
	
	/**
	 * 	刷新外呼服务参数配置信息
	 * @return
	 */
	public static int refresh() {
		
		MyHashTable = new Hashtable<String, SuapOutboundConfigModel>();
		int result = loadOutboundConfig();
		
		return result;
	}
	
	
	/**
	 * 	读取外呼服务参数配置信息，存到map中
	 */
	private static int loadOutboundConfig() {
		
		List<SuapOutboundConfigModel> list = outboundConfigUtil.outboundConfigService.selectAll();
		LOGGER.debug("outboundConfigService bean: "+outboundConfigUtil.outboundConfigService);
		LOGGER.debug("outboundConfig: "+list);
		
		if(list == null || list.size() == 0) {
			LOGGER.warn("no outbound config has found!");
			return 0;
		}
		
		for (SuapOutboundConfigModel suapOutboundConfigModel : list) {
			
			setBaseConfig(suapOutboundConfigModel);
			
			MyHashTable.put(suapOutboundConfigModel.getChannelcode()+":"+suapOutboundConfigModel.getTradecode(), suapOutboundConfigModel);
			LOGGER.debug("MyHashTable: "+MyHashTable);
		}
		
		return 1;
	}


	/**
	 * 	初始化外呼服务参数配置信息
	 * @param suapOutboundConfigModel
	 */
	private static void setBaseConfig(SuapOutboundConfigModel suapOutboundConfigModel) {
		
		if(StringUtils.isEmpty(suapOutboundConfigModel.getOutputtype()))
			suapOutboundConfigModel.setOutputtype("34");
		
	}
	
	
	/**
	 * 	获取所有外呼服务参数配置信息
	 * @return
	 */
	public static Hashtable<String, SuapOutboundConfigModel> getAllConfig(){
		return MyHashTable;
	}
	
	
	/**
	 * 	以key获取对应的外呼服务参数配置信息(key = (channelcode:tradecode))
	 * @param key
	 * @return
	 */
	public static SuapOutboundConfigModel getOutboundConfigByKey(String key){
		return MyHashTable.get(key);
	}
	
	
	/**
	 * 	以请求信息获取对应的外呼服务参数配置信息
	 * @param reqMsg
	 * @return
	 */
	public static SuapOutboundConfigModel getOutboundConfigByReqMsg(TxRequestMsg reqMsg) {
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		
		return getOutboundConfigByKey(com1.getSysChannelID()+":"+com1.getChannelTxCode());
	}
	
	
	
	
	
	
}
