package com.ccb.suap.cloud.access.datatransform.message;

public class TxResponseMsgEntity {
	
}
