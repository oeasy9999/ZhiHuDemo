package com.ccb.suap.cloud.access.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccb.suap.cloud.access.annotation.StatusAnnotation;
import com.ccb.suap.cloud.access.controller.ConfigRefreshContoller;
import com.ccb.suap.cloud.access.mapper.SuapFaceConfigMapper;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;

@Service
@StatusAnnotation
public class SuapFaceConfigService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigRefreshContoller.class);
	
	@Autowired
	SuapFaceConfigMapper dao;
	
	
	public List<SuapFaceConfigModel> selectAll(){
		
		List<SuapFaceConfigModel> list = null;
		try {
			list = dao.selectAll();
		} catch (Exception e) {
			LOGGER.error("select face config fail: all config!\n"+e.toString()+"\n\n");
		}
		
		return list;
	}
	
	
	public SuapFaceConfigModel selectOne(String CHANNELCODE,String TRADECODE,String TXCODE) {
		
		SuapFaceConfigModel suapFaceConfigModel = null;
		try {
			suapFaceConfigModel = dao.selectOne(CHANNELCODE, TRADECODE, TXCODE);
		} catch (Exception e) {
			LOGGER.error("select faceConfig fail: all config!\n"+e.toString()+"\n\n");
			throw e;
		}
		
		return suapFaceConfigModel;
	}
	
	public int count() {
		
		int row = 0;
		try {
			row = dao.count();
		} catch (Exception e) {
			LOGGER.error("count faceConfig fail!\n"+e.toString()+"\n\n");
			throw e;
		}
		
		return row;
	}
	
	public int update(SuapFaceConfigModel suapFaceConfigModel) {
		
		int row = 0;
		try {
			row = dao.update(suapFaceConfigModel);
		} catch (Exception e) {
			LOGGER.error("update faceConfig fail: "+suapFaceConfigModel+"\n"+e.toString()+"\n\n");
			throw e;
		}
		
		return row;
	}
	
	public int deleteOne(String channelcode,String tradecode,String txcode) {
		
		int row = 0;
		try {
			row = dao.deleteOne(channelcode, tradecode, txcode);
		} catch (Exception e) {
			LOGGER.error("delete faceConfig fail: {channelcode: "+channelcode+", trade: "+tradecode+", txcode: "+txcode+"}\n"+e.toString()+"\n\n");
			throw e;
		}
		
		return row;
		
	}
	
	
}
