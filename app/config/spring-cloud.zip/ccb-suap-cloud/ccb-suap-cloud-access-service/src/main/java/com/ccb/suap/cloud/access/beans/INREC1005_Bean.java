package com.ccb.suap.cloud.access.beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1004ServiceInVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1005ServiceOutVo;
import com.ccb.suap.cloud.access.service.GPUMPService;
import com.ccb.suap.cloud.access.service.utils.CheckParaUtil;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC1005ServiceInVo;
import com.ccb.suap.util.log.TraceLog;

@Controller("INREC1005")
public class INREC1005_Bean extends INRECBean{

	private static final Logger LOGGER = LoggerFactory.getLogger(INREC1005_Bean.class);
	
	@Autowired
	private GPUMPService GPUMPService;
	
//	private GPUMPService GPUMPService=InrecDaoFactory.getDaoManager().getGPUMPService();

	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n------------------调用INREC1005服务------------------");
		ServiceParaUtil.setFaceLogByBaseEntity(reqMsg, FaceLogThreadLocal.get());
		
		LOGGER.debug("check InVo: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		TxRequestMsg gpuRequestMsg = setGPUTxRequestMsg(reqMsg);
		LOGGER.debug("send GPUMP1005! ");
		long beforeSendGPU = System.currentTimeMillis();
		TxResponseMsg gpump1005Rsp = GPUMPService.sendGPUMP1005(gpuRequestMsg,traceLog);
		long sendGPU = System.currentTimeMillis()-beforeSendGPU;
		traceLog.setSendGpump1005Time(sendGPU);
		traceLog.setHttpcost(sendGPU);
		LOGGER.debug("return by GPUMP1005: "+gpump1005Rsp);
		
		if(!(gpump1005Rsp.getTx_header().getSys_resp_code().equals("000000000000"))) 
			throw new CommonRuntimeException(gpump1005Rsp);
		
		GPUMP1005ServiceOutVo gpump2005RspEntity = ServiceParaUtil.getGPURspMsgEntity(gpump1005Rsp, GPUMP1005ServiceOutVo.class);
		
		if(!gpump2005RspEntity.getIsexist().equals("1"))
			throw new CommonRuntimeException(Errorcode.NOCUSTINFFOUND);			
		
		return rspMsg;
	}
	

	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		
		String rspCode = CheckParaUtil.checkParaByLocationIndex(reqMsg);
		if(rspCode != null)
			throw new CommonRuntimeException(rspCode);
		
	}
	

	//TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("sendGPU(").append(sendGPU).append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	
	/**
	 * 	把请求信息封装成前置对应的请求报文
	 * @param reqMsg
	 * @return
	 */
	private TxRequestMsg setGPUTxRequestMsg(TxRequestMsg reqMsg) {
		TxRequestMsg gpuRequestMsg = ServiceParaUtil.parseGpuRequestMsg(reqMsg);
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		INREC1005ServiceInVo entity = (INREC1005ServiceInVo) reqMsg.getTx_body().getEntity();
		
		GPUMP1004ServiceInVo gpump1004ServiceInVo = new GPUMP1004ServiceInVo();
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		if(locationIndex.equals("1")) {
			gpump1004ServiceInVo.setCust_id(entity.getId_no());
		}else if(locationIndex.equals("2")) {
			gpump1004ServiceInVo.setCust_id(entity.getChannel_custno());
		}
		
		gpuRequestMsg.getTx_body().setEntity(gpump1004ServiceInVo);
		gpuRequestMsg.getTx_header().setSys_tx_code("GPUMP1005");
		
		return gpuRequestMsg;
	}





	
}
