package com.ccb.suap.cloud.access.controller;

/**
 * 	刷新业务参数
 */
import java.util.Hashtable;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.service.utils.SuapErrorInfoUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.service.utils.SuapOutboundConfigUtil;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;

@RestController
public class ConfigRefreshContoller {
	
	@RequestMapping("refreshAll")
	public String refreshAll() {
		String result = null;
		
		result = refreshFaceConfig();
		if(!"OK".equals(result.toUpperCase()))
			return result;
		
		result = refreshSysPara();
		if(!"OK".equals(result.toUpperCase()))
			return result;
		
		result = refreshErrorInfo();
		if(!"OK".equals(result.toUpperCase()))
			return result;
		
		result = refreshOutboundConfig();
		if(!"OK".equals(result.toUpperCase()))
			return result;
		
		return "ok";
	}
	
	
	@RequestMapping("refreshFaceConfig")
	public String refreshFaceConfig() {
		int num = SuapFaceConfigUtil.refresh();
		
		if(num != 1) {
			return "refresh fail!";
		}
		
		return "ok!";
	}
	
	
	@RequestMapping("refreshSysPara")
	public String refreshSysPara() {
		int num = SuapSysParaUtil.refresh();
		
		if(num != 1) {
			return "refresh fail!";
		}
		
		return "ok!";
	}
	
	
	@RequestMapping("refreshErrorInfo")
	public String refreshErrorInfo() {
		int num = SuapErrorInfoUtil.refresh();
		
		if(num != 1) {
			return "refresh fail!";
		}
		
		return "ok!";
	}

	
	@RequestMapping("refreshOutboundConfig")
	public String refreshOutboundConfig() {
		int num = SuapOutboundConfigUtil.refresh();
		
		if(num != 1) {
			return "refresh fail!";
		}
		
		return "ok!";
	}
	
	
	@SuppressWarnings("rawtypes")
	@RequestMapping("/{para}")
	public JSONObject getConfig(@PathVariable("para") String para) {
		Hashtable table = null;
		switch (para.toUpperCase()) {
		
		case "GETFACECONFIG":
			table = SuapFaceConfigUtil.getPara();
			break;
		case "GETSYSPARA":
			table = SuapSysParaUtil.getPara();
			break;
		case "GETERRORINFO":
			table = SuapErrorInfoUtil.getPara();
			break;
		case "GETOUTBOUNDCONFIG":
			table = SuapOutboundConfigUtil.getAllConfig();
			break;

		default:
			break;
		}
		
		if(table == null)
			return null;
		
		return JSONObject.parseObject(JSONObject.toJSONString(table));
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
