//package com.ccb.suap.util.python;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import com.ccb.suap.cloud.access.controller.FaceServiceController;
//import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
//import com.ccb.suap.cloud.access.exception.Errorcode;
//
///**
// * @ClassName: PythonUtil
// * @description:
// * @author: Nick
// * @create: 2020-06-23 09:55
// **/
//public class PythonUtil {
//	
//	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
//	
//
//    public static boolean execPython(String pythonAddr, String msgContent, String alarmPerson) {
//        String[] arguments = new String[]{"python", pythonAddr, "alarm", msgContent, alarmPerson};
//        
//        Process process = null;
//        BufferedReader in = null;
//        try {
//            process = Runtime.getRuntime().exec(arguments);
//            in = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));
//            String line = null;
//            while ((line = in.readLine()) != null) {
//                System.out.println(line);
//            }
//            
//            //java代码中的process.waitFor()返回值为0表示我们调用python脚本成功，
//            //返回值为1表示调用python脚本失败，这和我们通常意义上见到的0与1定义正好相反
//            int re = process.waitFor();
//            LOGGER.debug("return by python, result: " + re);
//            if(re != 0) {
//            	return false;
//            }
//            
//        } catch (Exception e) {
//            e.printStackTrace();
//            throw new CommonRuntimeException(Errorcode.PYTHONEXCERROR, "01", "python execute error: " + e.getMessage());
//        }finally {
//			if(in != null) {
//				try {
//					in.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//		}
//        
//        return true;
//    }
//
//
//}
