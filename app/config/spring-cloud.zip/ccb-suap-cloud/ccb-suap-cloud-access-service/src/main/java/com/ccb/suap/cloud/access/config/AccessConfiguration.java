package com.ccb.suap.cloud.access.config;

import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ccb.suap.cloud.access.context.mylistener;

@Configuration
public class AccessConfiguration {

    @SuppressWarnings("rawtypes")
	@Bean
    public ServletListenerRegistrationBean myListener()
    {
    	ServletListenerRegistrationBean<mylistener> registrationBean=new ServletListenerRegistrationBean<>(new mylistener());
    	return registrationBean;
    }
    
}