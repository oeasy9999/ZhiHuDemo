package com.ccb.suap.cloud.access.datatransform.message;

public class TxRequestMsgCom1 {

	private String sysChannelID;	//系统渠道编号
	private String channelTxCode;	//系统渠道交易码	
	private String dotNumber;		//网点号
	
	public String getSysChannelID() {
		return sysChannelID;
	}
	public void setSysChannelID(String sysChannelID) {
		this.sysChannelID = sysChannelID;
	}
	public String getChannelTxCode() {
		return channelTxCode;
	}
	public void setChannelTxCode(String channelTxCode) {
		this.channelTxCode = channelTxCode;
	}
	public String getDotNumber() {
		return dotNumber;
	}
	public void setDotNumber(String dotNumber) {
		this.dotNumber = dotNumber;
	}
	
	@Override
	public String toString() {
		return "TxRequestMsgCom1 [sysChannelID=" + sysChannelID + ", channelTxCode=" + channelTxCode + ", dotNumber="
				+ dotNumber + "]";
	}
	
	
	
	
	
}
