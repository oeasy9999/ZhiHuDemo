package com.ccb.suap.cloud.access.model;

import java.io.Serializable;

public class SuapOutboundConfigModel implements Serializable{
	
	private static final long serialVersionUID = -6749094811062514697L;
	
	private String channelcode;						//系统渠道编号
	private String tradecode;						//系统渠道交易码
	private String outputtype;						//压缩/反光标识
	private String remark;							//备注
	
	public String getChannelcode() {
		return channelcode;
	}
	public void setChannelcode(String channelcode) {
		this.channelcode = channelcode;
	}
	public String getTradecode() {
		return tradecode;
	}
	public void setTradecode(String tradecode) {
		this.tradecode = tradecode;
	}
	public String getOutputtype() {
		return outputtype;
	}
	public void setOutputtype(String outputtype) {
		this.outputtype = outputtype;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	@Override
	public String toString() {
		return "SuapOutboundConfigModel [channelcode=" + channelcode + ", tradecode=" + tradecode + ", outputtype="
				+ outputtype + ", remark=" + remark + "]";
	}
	
	
	
	
	

	
	
	
	
	
	
	
	
	
}
