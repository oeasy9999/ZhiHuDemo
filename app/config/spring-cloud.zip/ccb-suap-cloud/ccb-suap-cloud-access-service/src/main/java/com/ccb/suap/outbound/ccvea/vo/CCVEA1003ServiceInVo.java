package com.ccb.suap.outbound.ccvea.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class CCVEA1003ServiceInVo extends TxRequestMsgEntity{
	
	private String SYSTEM_TIME;								//客户端当前时间
	private String Cst_ID;									//送空
	private String Apl_Exmp_ID;								//客户信息系统送：CIC
	private String ExtStmCtfn_Udt_MpltTm;					//yyyyMMddHHmmssSSS
	private String Rmrk_1_Rcrd_Cntnt;						//送值：1230
	private String Rmrk_2_Rcrd_Cntnt;						//送值：1230
	private String ClntEndBaseSVrsnValSt;					//送值：1230
	private String base64_Pic_Txn_Inf;						//送空
	private String Ctf_Mnplt_Mode_ID;						//送值：8
	private String base64_ECD_Txn_Inf;						//姓名
	private String base64_Ecrp_Txn_Inf;						//证件号
	private String Rsrv_1_Inf_Dsc;							//证件起始日期
	private String Rsrv_2_Inf_Dsc;							//证件结束日期
	private String Rsrv_3_Inf_Dsc;							//送空
	private String Rsrv_4_Inf_Dsc;							//送空
	private String Rsrv_5_Inf_Dsc;							//送空
	private String base64_Rdm_Txn_Inf;						//送空
	private String Ctfn_Ahn_Stm_ID;							//用户所属机构编号
	private String BLNG_INST_NM;							//用户所属机构名称
	private String Mt_Apl_PD_ECD;							//用户柜员号
	private String Tlr_Nm;									//用户柜员名称
	private String Ext_Stm_Only1_Ind;						//组件编号
	private String Ext_Stm_NM;								//组件名称
	private String Br_ID;									//分行编号
	private String Br_Nm;									//分行名称
	private String Stm_Chnl_ID;								//安全节点号
	
	public String getSYSTEM_TIME() {
		return SYSTEM_TIME;
	}
	public void setSYSTEM_TIME(String sYSTEM_TIME) {
		SYSTEM_TIME = sYSTEM_TIME;
	}
	public String getCst_ID() {
		return Cst_ID;
	}
	public void setCst_ID(String cst_ID) {
		Cst_ID = cst_ID;
	}
	public String getApl_Exmp_ID() {
		return Apl_Exmp_ID;
	}
	public void setApl_Exmp_ID(String apl_Exmp_ID) {
		Apl_Exmp_ID = apl_Exmp_ID;
	}
	public String getExtStmCtfn_Udt_MpltTm() {
		return ExtStmCtfn_Udt_MpltTm;
	}
	public void setExtStmCtfn_Udt_MpltTm(String extStmCtfn_Udt_MpltTm) {
		ExtStmCtfn_Udt_MpltTm = extStmCtfn_Udt_MpltTm;
	}
	public String getRmrk_1_Rcrd_Cntnt() {
		return Rmrk_1_Rcrd_Cntnt;
	}
	public void setRmrk_1_Rcrd_Cntnt(String rmrk_1_Rcrd_Cntnt) {
		Rmrk_1_Rcrd_Cntnt = rmrk_1_Rcrd_Cntnt;
	}
	public String getRmrk_2_Rcrd_Cntnt() {
		return Rmrk_2_Rcrd_Cntnt;
	}
	public void setRmrk_2_Rcrd_Cntnt(String rmrk_2_Rcrd_Cntnt) {
		Rmrk_2_Rcrd_Cntnt = rmrk_2_Rcrd_Cntnt;
	}
	public String getClntEndBaseSVrsnValSt() {
		return ClntEndBaseSVrsnValSt;
	}
	public void setClntEndBaseSVrsnValSt(String clntEndBaseSVrsnValSt) {
		ClntEndBaseSVrsnValSt = clntEndBaseSVrsnValSt;
	}
	public String getBase64_Pic_Txn_Inf() {
		return base64_Pic_Txn_Inf;
	}
	public void setBase64_Pic_Txn_Inf(String base64_Pic_Txn_Inf) {
		this.base64_Pic_Txn_Inf = base64_Pic_Txn_Inf;
	}
	public String getCtf_Mnplt_Mode_ID() {
		return Ctf_Mnplt_Mode_ID;
	}
	public void setCtf_Mnplt_Mode_ID(String ctf_Mnplt_Mode_ID) {
		Ctf_Mnplt_Mode_ID = ctf_Mnplt_Mode_ID;
	}
	public String getBase64_ECD_Txn_Inf() {
		return base64_ECD_Txn_Inf;
	}
	public void setBase64_ECD_Txn_Inf(String base64_ECD_Txn_Inf) {
		this.base64_ECD_Txn_Inf = base64_ECD_Txn_Inf;
	}
	public String getBase64_Ecrp_Txn_Inf() {
		return base64_Ecrp_Txn_Inf;
	}
	public void setBase64_Ecrp_Txn_Inf(String base64_Ecrp_Txn_Inf) {
		this.base64_Ecrp_Txn_Inf = base64_Ecrp_Txn_Inf;
	}
	public String getRsrv_1_Inf_Dsc() {
		return Rsrv_1_Inf_Dsc;
	}
	public void setRsrv_1_Inf_Dsc(String rsrv_1_Inf_Dsc) {
		Rsrv_1_Inf_Dsc = rsrv_1_Inf_Dsc;
	}
	public String getRsrv_2_Inf_Dsc() {
		return Rsrv_2_Inf_Dsc;
	}
	public void setRsrv_2_Inf_Dsc(String rsrv_2_Inf_Dsc) {
		Rsrv_2_Inf_Dsc = rsrv_2_Inf_Dsc;
	}
	public String getRsrv_3_Inf_Dsc() {
		return Rsrv_3_Inf_Dsc;
	}
	public void setRsrv_3_Inf_Dsc(String rsrv_3_Inf_Dsc) {
		Rsrv_3_Inf_Dsc = rsrv_3_Inf_Dsc;
	}
	public String getRsrv_4_Inf_Dsc() {
		return Rsrv_4_Inf_Dsc;
	}
	public void setRsrv_4_Inf_Dsc(String rsrv_4_Inf_Dsc) {
		Rsrv_4_Inf_Dsc = rsrv_4_Inf_Dsc;
	}
	public String getRsrv_5_Inf_Dsc() {
		return Rsrv_5_Inf_Dsc;
	}
	public void setRsrv_5_Inf_Dsc(String rsrv_5_Inf_Dsc) {
		Rsrv_5_Inf_Dsc = rsrv_5_Inf_Dsc;
	}
	public String getBase64_Rdm_Txn_Inf() {
		return base64_Rdm_Txn_Inf;
	}
	public void setBase64_Rdm_Txn_Inf(String base64_Rdm_Txn_Inf) {
		this.base64_Rdm_Txn_Inf = base64_Rdm_Txn_Inf;
	}
	public String getCtfn_Ahn_Stm_ID() {
		return Ctfn_Ahn_Stm_ID;
	}
	public void setCtfn_Ahn_Stm_ID(String ctfn_Ahn_Stm_ID) {
		Ctfn_Ahn_Stm_ID = ctfn_Ahn_Stm_ID;
	}
	public String getBLNG_INST_NM() {
		return BLNG_INST_NM;
	}
	public void setBLNG_INST_NM(String bLNG_INST_NM) {
		BLNG_INST_NM = bLNG_INST_NM;
	}
	public String getMt_Apl_PD_ECD() {
		return Mt_Apl_PD_ECD;
	}
	public void setMt_Apl_PD_ECD(String mt_Apl_PD_ECD) {
		Mt_Apl_PD_ECD = mt_Apl_PD_ECD;
	}
	public String getTlr_Nm() {
		return Tlr_Nm;
	}
	public void setTlr_Nm(String tlr_Nm) {
		Tlr_Nm = tlr_Nm;
	}
	public String getExt_Stm_Only1_Ind() {
		return Ext_Stm_Only1_Ind;
	}
	public void setExt_Stm_Only1_Ind(String ext_Stm_Only1_Ind) {
		Ext_Stm_Only1_Ind = ext_Stm_Only1_Ind;
	}
	public String getExt_Stm_NM() {
		return Ext_Stm_NM;
	}
	public void setExt_Stm_NM(String ext_Stm_NM) {
		Ext_Stm_NM = ext_Stm_NM;
	}
	public String getBr_ID() {
		return Br_ID;
	}
	public void setBr_ID(String br_ID) {
		Br_ID = br_ID;
	}
	public String getBr_Nm() {
		return Br_Nm;
	}
	public void setBr_Nm(String br_Nm) {
		Br_Nm = br_Nm;
	}
	public String getStm_Chnl_ID() {
		return Stm_Chnl_ID;
	}
	public void setStm_Chnl_ID(String stm_Chnl_ID) {
		Stm_Chnl_ID = stm_Chnl_ID;
	}
	
	@Override
	public String toString() {
		return "CCVEA1003ServiceInVo [SYSTEM_TIME=" + SYSTEM_TIME + ", Cst_ID=" + Cst_ID + ", Apl_Exmp_ID="
				+ Apl_Exmp_ID + ", ExtStmCtfn_Udt_MpltTm=" + ExtStmCtfn_Udt_MpltTm + ", Rmrk_1_Rcrd_Cntnt="
				+ Rmrk_1_Rcrd_Cntnt + ", Rmrk_2_Rcrd_Cntnt=" + Rmrk_2_Rcrd_Cntnt + ", ClntEndBaseSVrsnValSt="
				+ ClntEndBaseSVrsnValSt + ", base64_Pic_Txn_Inf=" + base64_Pic_Txn_Inf + ", Ctf_Mnplt_Mode_ID="
				+ Ctf_Mnplt_Mode_ID + ", base64_ECD_Txn_Inf=" + base64_ECD_Txn_Inf + ", base64_Ecrp_Txn_Inf="
				+ base64_Ecrp_Txn_Inf + ", Rsrv_1_Inf_Dsc=" + Rsrv_1_Inf_Dsc + ", Rsrv_2_Inf_Dsc=" + Rsrv_2_Inf_Dsc
				+ ", Rsrv_3_Inf_Dsc=" + Rsrv_3_Inf_Dsc + ", Rsrv_4_Inf_Dsc=" + Rsrv_4_Inf_Dsc + ", Rsrv_5_Inf_Dsc="
				+ Rsrv_5_Inf_Dsc + ", base64_Rdm_Txn_Inf=" + base64_Rdm_Txn_Inf + ", Ctfn_Ahn_Stm_ID=" + Ctfn_Ahn_Stm_ID
				+ ", BLNG_INST_NM=" + BLNG_INST_NM + ", Mt_Apl_PD_ECD=" + Mt_Apl_PD_ECD + ", Tlr_Nm=" + Tlr_Nm
				+ ", Ext_Stm_Only1_Ind=" + Ext_Stm_Only1_Ind + ", Ext_Stm_NM=" + Ext_Stm_NM + ", Br_ID=" + Br_ID
				+ ", Br_Nm=" + Br_Nm + ", Stm_Chnl_ID=" + Stm_Chnl_ID + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
}
