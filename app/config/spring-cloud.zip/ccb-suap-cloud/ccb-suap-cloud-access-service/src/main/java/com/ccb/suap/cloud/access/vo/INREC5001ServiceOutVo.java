package com.ccb.suap.cloud.access.vo;

import java.io.Serializable;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class INREC5001ServiceOutVo extends TxResponseMsgEntity implements Serializable{
	
	private static final long serialVersionUID = -4474386534989040671L;
	
	private String SYS_EVT_TRACE_ID;							//全局流水号
	private String Cmp_Rslt_Ind;								//比对结果  true：比对成功，false：比对失败
	private String Smlr_Dgr_Cmnt;								//相似度
	private String Rslt_Ret_Inf;								//响应内容
	private String Mftr_Idr_CD;									//厂商标识
	private String base64_ECD_Txn_Inf;							//人脸图片
	private String Ext_Stm_Only1_Ind;							//是否通过活体检测
	private String Ctf_Mnplt_Mode_ID;							//活体检测得分
	private String Rsrv_1_Inf_Dsc;								//备用字段1
	private String Rsrv_2_Inf_Dsc;								//备用字段2
	private String Rsrv_3_Inf_Dsc;								//备用字段3
	
	public String getSYS_EVT_TRACE_ID() {
		return SYS_EVT_TRACE_ID;
	}
	public void setSYS_EVT_TRACE_ID(String sYS_EVT_TRACE_ID) {
		SYS_EVT_TRACE_ID = sYS_EVT_TRACE_ID;
	}
	public String getCmp_Rslt_Ind() {
		return Cmp_Rslt_Ind;
	}
	public void setCmp_Rslt_Ind(String cmp_Rslt_Ind) {
		Cmp_Rslt_Ind = cmp_Rslt_Ind;
	}
	public String getSmlr_Dgr_Cmnt() {
		return Smlr_Dgr_Cmnt;
	}
	public void setSmlr_Dgr_Cmnt(String smlr_Dgr_Cmnt) {
		Smlr_Dgr_Cmnt = smlr_Dgr_Cmnt;
	}
	public String getRslt_Ret_Inf() {
		return Rslt_Ret_Inf;
	}
	public void setRslt_Ret_Inf(String rslt_Ret_Inf) {
		Rslt_Ret_Inf = rslt_Ret_Inf;
	}
	public String getMftr_Idr_CD() {
		return Mftr_Idr_CD;
	}
	public void setMftr_Idr_CD(String mftr_Idr_CD) {
		Mftr_Idr_CD = mftr_Idr_CD;
	}
	public String getBase64_ECD_Txn_Inf() {
		return base64_ECD_Txn_Inf;
	}
	public void setBase64_ECD_Txn_Inf(String base64_ECD_Txn_Inf) {
		this.base64_ECD_Txn_Inf = base64_ECD_Txn_Inf;
	}
	public String getExt_Stm_Only1_Ind() {
		return Ext_Stm_Only1_Ind;
	}
	public void setExt_Stm_Only1_Ind(String ext_Stm_Only1_Ind) {
		Ext_Stm_Only1_Ind = ext_Stm_Only1_Ind;
	}
	public String getCtf_Mnplt_Mode_ID() {
		return Ctf_Mnplt_Mode_ID;
	}
	public void setCtf_Mnplt_Mode_ID(String ctf_Mnplt_Mode_ID) {
		Ctf_Mnplt_Mode_ID = ctf_Mnplt_Mode_ID;
	}
	public String getRsrv_1_Inf_Dsc() {
		return Rsrv_1_Inf_Dsc;
	}
	public void setRsrv_1_Inf_Dsc(String rsrv_1_Inf_Dsc) {
		Rsrv_1_Inf_Dsc = rsrv_1_Inf_Dsc;
	}
	public String getRsrv_2_Inf_Dsc() {
		return Rsrv_2_Inf_Dsc;
	}
	public void setRsrv_2_Inf_Dsc(String rsrv_2_Inf_Dsc) {
		Rsrv_2_Inf_Dsc = rsrv_2_Inf_Dsc;
	}
	public String getRsrv_3_Inf_Dsc() {
		return Rsrv_3_Inf_Dsc;
	}
	public void setRsrv_3_Inf_Dsc(String rsrv_3_Inf_Dsc) {
		Rsrv_3_Inf_Dsc = rsrv_3_Inf_Dsc;
	}
	
	@Override
	public String toString() {
		return "INREC5001ServiceOutVo [SYS_EVT_TRACE_ID=" + SYS_EVT_TRACE_ID + ", Cmp_Rslt_Ind=" + Cmp_Rslt_Ind
				+ ", Smlr_Dgr_Cmnt=" + Smlr_Dgr_Cmnt + ", Rslt_Ret_Inf=" + Rslt_Ret_Inf + ", Mftr_Idr_CD=" + Mftr_Idr_CD
				+ ", base64_ECD_Txn_Inf=" + base64_ECD_Txn_Inf + ", Ext_Stm_Only1_Ind=" + Ext_Stm_Only1_Ind
				+ ", Ctf_Mnplt_Mode_ID=" + Ctf_Mnplt_Mode_ID + ", Rsrv_1_Inf_Dsc=" + Rsrv_1_Inf_Dsc
				+ ", Rsrv_2_Inf_Dsc=" + Rsrv_2_Inf_Dsc + ", Rsrv_3_Inf_Dsc=" + Rsrv_3_Inf_Dsc + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
