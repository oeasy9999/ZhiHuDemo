package com.ccb.suap.cloud.access.service.utils;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import org.springframework.stereotype.Component;

/**
 * 	该工具类通过tx_code缓存对应的实体域以及服务接口类对象
 * @author 86156
 *
 */

@Component
public class TxcodeUtil {
	
	
	/**
	 * 	通过tx_code缓存服务接口类对象
	 */
	private static Hashtable<String,Class<?>> serviceTable = new Hashtable<String,Class<?>>();
	/**
	 * 	基于tx_code缓存请求实体域类对象
	 */
	private static Hashtable<String,Class<?>> reqEntityTable = new Hashtable<String,Class<?>>();
	
	static {
		init();
	}
	
	public static void init() {
		saveServiceTable();
		saveReqEntityTable();
	}
	
	
//	/**
//	 * 	刷新所有类对象
//	 */
//	public static void refreshAllTable() {
//		refreshServiceTable();
//		refreshReqEntityTable();
//	}
//	
//	
//	/**
//	 * 	刷新服务接口类对象
//	 */
//	public static void refreshServiceTable() {
//		serviceTable = new Hashtable<String, Class<?>>();
//		saveServiceTable();
//	}
//	
//	
//	/**
//	 * 	刷新请求实体域类对象
//	 */
//	public static void refreshReqEntityTable() {
//		reqEntityTable = new Hashtable<String, Class<?>>();
//		saveReqEntityTable();
//	}
	
	
	/**
	 * 	获取所有服务接口类对象
	 * @return
	 */
	public static Hashtable<String, Class<?>> getServiceTable() {
		return serviceTable;
	}
	
	
	/**
	 *	 获取所有请求实体域类对象
	 * @return
	 */
	public static Hashtable<String, Class<?>> getReqEntityTable() {
		return reqEntityTable;
	}
	

	/**
	 *	 通过tx_code获取服务接口类对象
	 * @param key
	 * @return
	 */
	public static Class<?> getServiceClassByTxcode(String key){
		return serviceTable.get(key);
	}

	
	/**
	 *	 通过tx_code获取请求实体域类对象
	 * @param key
	 * @return
	 */
	public static Class<?> getReqEntityClassByTxcode(String key){
		return reqEntityTable.get(key);
	}
	

	/**
	 * 	以tx_code为key保存服务接口类对象
	 */
	private static void saveServiceTable() {
		Set<Class<?>> serviceSet = PackageUtil.getClassSet("com.ccb.suap.cloud.access.beans");
		for (Class<?> class1 : serviceSet) {
			String name = class1.getName();
			boolean flag = name.matches("^com.ccb.suap.cloud.access.beans.INREC\\d{4}_Bean$");
			if(flag) {
				serviceTable.put(name.substring(32, 41), class1);
			}
		}
		
	}

	
	/**
	 * 	以tx_code为key保存请求实体域类对象
	 */
	private static void saveReqEntityTable() {
		Set<Class<?>> reqEntitySet = PackageUtil.getClassSet("com.ccb.suap.cloud.access.vo");
		for (Class<?> class1 : reqEntitySet) {
			String name = class1.getName();
			boolean flag = name.matches("^com.ccb.suap.cloud.access.vo.INREC\\d{4}ServiceInVo$");
			if(flag) {
				reqEntityTable.put(name.substring(29, 38), class1);
			}
		}
		
	}
	
	
	
	public static class PackageUtil {
		/**
		 *	 通过包名获取包下的所有类
		 * @param packageName
		 * @return
		 * @throws Exception
		 */
		public static Set<Class<?>> getClassSet(String packageName){
					Set<Class<?>> classes = new LinkedHashSet<Class<?>>();
					boolean recursive = true;
					String packageDirName = packageName.replace('.', '/');
					Enumeration<URL> dirs;
					try {
						dirs = Thread.currentThread().getContextClassLoader().getResources(
								packageDirName);
						while (dirs.hasMoreElements()) {
							URL url = dirs.nextElement();
							String protocol = url.getProtocol();
							if ("file".equals(protocol)) {
								String filePath = URLDecoder.decode(url.getFile(), "UTF-8");
								findAndAddClassesInPackageByFile(packageName, filePath,
										recursive, classes);
							} else if ("jar".equals(protocol)) {
								JarFile jar;
								try {
									jar = ((JarURLConnection) url.openConnection()).getJarFile();
									Enumeration<JarEntry> entries = jar.entries();
									while (entries.hasMoreElements()) {
										JarEntry entry = entries.nextElement();
										String name = entry.getName();
										if (name.charAt(0) == '/') {
											name = name.substring(1);
										}
										if (name.startsWith(packageDirName)) {
											int idx = name.lastIndexOf('/');
											if (idx != -1) {
												packageName = name.substring(0, idx)
														.replace('/', '.');
											}
											if ((idx != -1) || recursive) {
												if (name.endsWith(".class")
														&& !entry.isDirectory()) {
													String className = name.substring(
															packageName.length() + 1, name
																	.length() - 6);
													try {
														classes.add(Thread.currentThread().getContextClassLoader()
																.loadClass(packageName + '.' + className));
													} catch (ClassNotFoundException e) {
														e.printStackTrace();
													}
												}
											}
										}
									}
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
			 
					return classes;

		}
		
		public static void findAndAddClassesInPackageByFile(String packageName,
				String packagePath, final boolean recursive, Set<Class<?>> classes) {
			File dir = new File(packagePath);
			if (!dir.exists() || !dir.isDirectory()) {
				return;
			}
			File[] dirfiles = dir.listFiles(new FileFilter() {
				public boolean accept(File file) {
					return (recursive && file.isDirectory())
							|| (file.getName().endsWith(".class"));
				}
			});
			for (File file : dirfiles) {
				if (file.isDirectory()) {
					findAndAddClassesInPackageByFile(packageName + "."
							+ file.getName(), file.getAbsolutePath(), recursive,
							classes);
				} else {
					String className = file.getName().substring(0,
							file.getName().length() - 6);
					try {
						classes.add(Thread.currentThread().getContextClassLoader()
								.loadClass(packageName + '.' + className));
					} catch (ClassNotFoundException e) {
						e.printStackTrace();
					}
				}
			}
		}
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
