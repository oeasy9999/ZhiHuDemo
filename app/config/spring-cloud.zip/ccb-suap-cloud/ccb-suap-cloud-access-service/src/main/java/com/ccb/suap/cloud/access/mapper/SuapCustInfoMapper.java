package com.ccb.suap.cloud.access.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.UpdateProvider;

import com.ccb.suap.cloud.access.model.SuapCustInfoModel;

@Mapper
public interface SuapCustInfoMapper {
	
	@Insert("insert into SUAP_CUST_INFO_${num}(CCBCUSTNO,CUSTNAME,IDTYPE,IDNUMBER,BRANCHID,CELLPHOME,CREATETIME,SEX,BIRTHDAY,ADDRESS,COMPANY,INDUSTRY,CAREER,SCHOOL,EDUCATION,INCOME,HABIT,IDPHOTO_PATH,IDPHOTO_LEVEL,IDPHOTO_DATE,IDPHOTO_CHANNEL,SCENEPHOTO_PATH,SCENEPHOTO_LEVEL,SCENEPHOTO_DATE,SCENEPHOTO_CHANNEL,UPDATECHANNEL,IDVERIFY,UPDATETIME) values(#{ccbcustno},#{custname},#{idtype},db_encrypt(#{idnumber}),#{branchid},#{cellphome},#{createtime},#{sex},#{birthday},#{address},#{company},#{industry},#{career},#{school},#{education},#{income},#{habit},#{idphoto_path},#{idphoto_level},#{idphoto_date},#{idphoto_channel},#{scenephoto_path},#{scenephoto_level},#{scenephoto_date},#{scenephoto_channel},#{updatechannel},#{idverify},#{updatetime})")
//	@Insert("insert into SUAP_CUST_INFO_${num}(CCBCUSTNO,CUSTNAME,IDTYPE,IDNUMBER,BRANCHID,CELLPHOME,CREATETIME,SEX,BIRTHDAY,ADDRESS,COMPANY,INDUSTRY,CAREER,SCHOOL,EDUCATION,INCOME,HABIT,IDPHOTO_PATH,IDPHOTO_LEVEL,IDPHOTO_DATE,IDPHOTO_CHANNEL,SCENEPHOTO_PATH,SCENEPHOTO_LEVEL,SCENEPHOTO_DATE,SCENEPHOTO_CHANNEL,UPDATECHANNEL,IDVERIFY,UPDATETIME) values(#{ccbcustno},#{custname},#{idtype},#{idnumber},#{branchid},#{cellphome},#{createtime},#{sex},#{birthday},#{address},#{company},#{industry},#{career},#{school},#{education},#{income},#{habit},#{idphoto_path},#{idphoto_level},#{idphoto_date},#{idphoto_channel},#{scenephoto_path},#{scenephoto_level},#{scenephoto_date},#{scenephoto_channel},#{updatechannel},#{idverify},#{updatetime})")
	int insert(SuapCustInfoModel suapCustInfoModel);
	
	@Select("SELECT CCBCUSTNO,CUSTNAME,IDTYPE,db_decrypt(IDNUMBER) IDNUMBER,BRANCHID,CELLPHOME,CREATETIME,SEX,BIRTHDAY,ADDRESS,COMPANY,INDUSTRY,CAREER,SCHOOL,EDUCATION,INCOME,HABIT,IDPHOTO_PATH,IDPHOTO_LEVEL,IDPHOTO_DATE,IDPHOTO_CHANNEL,SCENEPHOTO_PATH,SCENEPHOTO_LEVEL,SCENEPHOTO_DATE,SCENEPHOTO_CHANNEL,UPDATECHANNEL,IDVERIFY,UPDATETIME FROM SUAP_CUST_INFO_${num} WHERE IDTYPE=#{idtype} and IDNUMBER=db_encrypt(#{idno})")
//	@Select("SELECT CCBCUSTNO,CUSTNAME,IDTYPE,IDNUMBER,BRANCHID,CELLPHOME,CREATETIME,SEX,BIRTHDAY,ADDRESS,COMPANY,INDUSTRY,CAREER,SCHOOL,EDUCATION,INCOME,HABIT,IDPHOTO_PATH,IDPHOTO_LEVEL,IDPHOTO_DATE,IDPHOTO_CHANNEL,SCENEPHOTO_PATH,SCENEPHOTO_LEVEL,SCENEPHOTO_DATE,SCENEPHOTO_CHANNEL,UPDATECHANNEL,IDVERIFY,UPDATETIME FROM SUAP_CUST_INFO_${num} WHERE IDTYPE=#{idtype} and IDNUMBER=#{idno}")
	SuapCustInfoModel select(@Param("num") String num,@Param("idtype") String idtype,@Param("idno") String idno);
	
	@UpdateProvider(type=SuapCustInfoDynaProvider.class,method="update")
	int update(SuapCustInfoModel suapCustInfoModel);
	
	@Select("select count(*) from SUAP_CUST_INFO_${num}")
	int count(@Param("num") String num);
	
	@Delete("delete from SUAP_CUST_INFO_${num}")
	int deleteAll(@Param("num") String num);

	@Select("select * from SUAP_CUST_INFO_${num}")
	List<SuapCustInfoModel> selectAll(@Param("num") String num);
	
	
	
	
	
}
