package com.ccb.suap.cloud.access.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import com.ccb.suap.cloud.access.model.SuapChannelInfoModel;

@Mapper
public interface SuapChannelInfoMapper {
	
	@Insert("insert into SUAP_CHANNEL_INFO(CHANNELID,CHANNELNAME,CHANNELDESC,CREATOR,CREATETIME,REMARK) values(#{channelid},#{channelname},#{channeldesc},#{creator},#{createtime},#{remark})")
	int insert(SuapChannelInfoModel suapChannelInfoModel);
	
	
	
	
}
