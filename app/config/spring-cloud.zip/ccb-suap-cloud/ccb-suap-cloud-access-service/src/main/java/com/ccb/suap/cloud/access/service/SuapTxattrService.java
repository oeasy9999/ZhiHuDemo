package com.ccb.suap.cloud.access.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccb.suap.cloud.access.annotation.StatusAnnotation;
import com.ccb.suap.cloud.access.mapper.SuapTxattrMapper;

@Service
@StatusAnnotation
public class SuapTxattrService {
	
	@Autowired
	SuapTxattrMapper dao;
	
	
	
}
