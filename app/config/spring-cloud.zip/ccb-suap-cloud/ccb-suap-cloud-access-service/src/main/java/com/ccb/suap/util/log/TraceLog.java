package com.ccb.suap.util.log;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.util.JSONUtils;
import com.ccb.suap.util.string.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class TraceLog {

	protected static final Logger common_logger = LoggerFactory.getLogger(TraceLog.class);

	//需要设置
	private String traceId;
	private String url="";
	private String logName;
	private int maxValueLength = -1;
	private int level = LogLevel.ERROR;
	private String errormessage;
	private long startTime = System.currentTimeMillis();
	private long endTime;
	private List<TraceLog_Entity> entity_list;
	private long sendGpump1001Time;
	private long sendGpump1002Time;
	private long sendGpump1003Time;
	private long sendGpump1004Time;
	private long sendGpump1005Time;
	private long sendGpump1006Time;
	private long sendGpump1007Time;
	private long sendGpump1008Time;
	private long sendGpumq1009Time;
	private long sendGpump1010Time;
	private long sendGpump1011Time;
	private long sendCCVEA1001Time;
	private long sendCCVEA1002Time;
	private long sendCCVEA1003Time;
	private long sendCCVEA1004Time;
	private long sendCCVEA1005Time;
	
	private long savePhotoTime;
	
	public long getSavePhotoTime() {
		return savePhotoTime;
	}

	public void setSavePhotoTime(long savePhotoTime) {
		this.savePhotoTime = savePhotoTime;
	}

	public long getSendGpump1004Time() {
		return sendGpump1004Time;
	}

	public void setSendGpump1004Time(long sendGpump1004Time) {
		this.sendGpump1004Time = sendGpump1004Time;
	}

	public long getSendGpump1008Time() {
		return sendGpump1008Time;
	}

	public void setSendGpump1008Time(long sendGpump1008Time) {
		this.sendGpump1008Time = sendGpump1008Time;
	}

	public long getSendGpumq1009Time() {
		return sendGpumq1009Time;
	}

	public void setSendGpumq1009Time(long sendGpumq1009Time) {
		this.sendGpumq1009Time = sendGpumq1009Time;
	}

	public long getSendGpump1002Time() {
		return sendGpump1002Time;
	}

	public void setSendGpump1002Time(long sendGpump1002Time) {
		this.sendGpump1002Time = sendGpump1002Time;
	}

	public long getSendGpump1003Time() {
		return sendGpump1003Time;
	}

	public void setSendGpump1003Time(long sendGpump1003Time) {
		this.sendGpump1003Time = sendGpump1003Time;
	}

	public long getSendGpump1011Time() {
		return sendGpump1011Time;
	}

	public void setSendGpump1011Time(long sendGpump1011Time) {
		this.sendGpump1011Time = sendGpump1011Time;
	}

	public long getSendGpump1005Time() {
		return sendGpump1005Time;
	}

	public void setSendGpump1005Time(long sendGpump1005Time) {
		this.sendGpump1005Time = sendGpump1005Time;
	}

	public long getSendGpump1007Time() {
		return sendGpump1007Time;
	}

	public void setSendGpump1007Time(long sendGpump1007Time) {
		this.sendGpump1007Time = sendGpump1007Time;
	}

	public long getSendGpump1006Time() {
		return sendGpump1006Time;
	}

	public void setSendGpump1006Time(long sendGpump1006Time) {
		this.sendGpump1006Time = sendGpump1006Time;
	}

	public long getSendGpump1010Time() {
		return sendGpump1010Time;
	}

	public void setSendGpump1010Time(long sendGpump1010Time) {
		this.sendGpump1010Time = sendGpump1010Time;
	}

	public long getSendGpump1001Time() {
		return sendGpump1001Time;
	}

	public void setSendGpump1001Time(long sendGpump1001Time) {
		this.sendGpump1001Time = sendGpump1001Time;
	}

	private String plainText;
	
	public String getTraceId() {
		return traceId;
	}

	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}

	public String getUrl() {
		return url;
	}
	/**
	 * 设置请求url，用于打印
	 * @param url
	 */
	public void setUrl(String url) {
		common_logger.debug("url: "+url);
		if(url!=null)
		{
			this.url =this.url+" "+url;
		}
	}

	public int getMaxValueLength() {
		return maxValueLength;
	}

	public void setMaxValueLength(int maxValueLength) {
		this.maxValueLength = maxValueLength;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(String levelStr) {
		if(StringUtils.isNotBlank(levelStr)){
			levelStr = levelStr.toUpperCase();
			if("DEBUG".equals(levelStr)) {
				this.level = LogLevel.DEBUG;
			}else if("INFO".equals(levelStr)){
				this.level = LogLevel.INFO;
			}else{
				this.level = LogLevel.ERROR;
			}
		}
		//this.level = level;
	}

	public String getLogName() {
		return logName;
	}

	public void setLogName(String logName) {
		this.logName = logName;
	}

	public long getStartTime() {
		return startTime;
	}

	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}

	public long getEndTime() {
		return endTime;
	}

	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}
	

	public List<TraceLog_Entity> getEntity_list() {
		return entity_list;
	}

	public void setEntity_list(List<TraceLog_Entity> entity_list) {
		this.entity_list = entity_list;
	}
	

	private String requestJsonString;
	private String responseJsonString;
	private String requestJsonString_client;
	private String responseJsonString_client;
	private String requestJsonString_gpump1001;
	private String responseJsonString_gpump1001;
	private String requestJsonString_gpump1002;
	private String responseJsonString_gpump1002;
	private String requestJsonString_gpump1003;
	private String responseJsonString_gpump1003;
	private String requestJsonString_gpump1004;
	private String responseJsonString_gpump1004;
	private String requestJsonString_gpump1005;
	private String responseJsonString_gpump1005;
	private String requestJsonString_gpump1006;
	private String responseJsonString_gpump1006;
	private String requestJsonString_gpump1007;
	private String responseJsonString_gpump1007;
	private String requestJsonString_gpump1008;
	private String responseJsonString_gpump1008;
	private String requestJsonString_gpump1009;
	private String responseJsonString_gpump1009;
	private String requestJsonString_gpump1010;
	private String responseJsonString_gpump1010;
	private String requestJsonString_gpump1011;
	private String responseJsonString_gpump1011;
	private String requestJsonString_CCVEA1001;
	private String requestJsonString_CCVEA1002;
	private String requestJsonString_CCVEA1003;
	private String requestJsonString_CCVEA1004;
	private String requestJsonString_CCVEA1005;
	private String responseJsonString_CCVEA1001;
	private String responseJsonString_CCVEA1002;
	private String responseJsonString_CCVEA1003;
	private String responseJsonString_CCVEA1004;
	private String responseJsonString_CCVEA1005;

	
	public long getSendCCVEA1005Time() {
		return sendCCVEA1005Time;
	}

	public void setSendCCVEA1005Time(long sendCCVEA1005Time) {
		this.sendCCVEA1005Time = sendCCVEA1005Time;
	}

	public String getRequestJsonString_CCVEA1005() {
		return requestJsonString_CCVEA1005;
	}

	public void setRequestJsonString_CCVEA1005(String requestJsonString_CCVEA1005) {
		this.requestJsonString_CCVEA1005 = requestJsonString_CCVEA1005;
	}

	public String getResponseJsonString_CCVEA1005() {
		return responseJsonString_CCVEA1005;
	}

	public void setResponseJsonString_CCVEA1005(String responseJsonString_CCVEA1005) {
		this.responseJsonString_CCVEA1005 = responseJsonString_CCVEA1005;
	}

	public String getRequestJsonString() {
		return requestJsonString;
	}

	
	public String getRequestJsonString_client() {
		return requestJsonString_client;
	}

	public String getRequestJsonString_gpump1011() {
		return requestJsonString_gpump1011;
	}
	public String getRequestJsonString_gpump1010() {
		return requestJsonString_gpump1010;
	}
	public String getRequestJsonString_gpump1001() {
		return requestJsonString_gpump1001;
	}
	public String getRequestJsonString_gpump1002() {
		return requestJsonString_gpump1002;
	}
	public String getRequestJsonString_gpump1003() {
		return requestJsonString_gpump1003;
	}
	
	public String getRequestJsonString_gpump1004() {
		return requestJsonString_gpump1004;
	}

	public void setRequestJsonString_gpump1004(String requestJsonString_gpump1004) {
		this.requestJsonString_gpump1004 = requestJsonString_gpump1004;
	}

	public String getResponseJsonString_gpump1004() {
		return responseJsonString_gpump1004;
	}

	public void setResponseJsonString_gpump1004(String responseJsonString_gpump1004) {
		this.responseJsonString_gpump1004 = responseJsonString_gpump1004;
	}

	public String getRequestJsonString_gpump1008() {
		return requestJsonString_gpump1008;
	}

	public void setRequestJsonString_gpump1008(String requestJsonString_gpump1008) {
		this.requestJsonString_gpump1008 = requestJsonString_gpump1008;
	}

	public String getResponseJsonString_gpump1008() {
		return responseJsonString_gpump1008;
	}

	public void setResponseJsonString_gpump1008(String responseJsonString_gpump1008) {
		this.responseJsonString_gpump1008 = responseJsonString_gpump1008;
	}

	public String getRequestJsonString_gpump1009() {
		return requestJsonString_gpump1009;
	}

	public void setRequestJsonString_gpump1009(String requestJsonString_gpump1009) {
		this.requestJsonString_gpump1009 = requestJsonString_gpump1009;
	}

	public String getResponseJsonString_gpump1009() {
		return responseJsonString_gpump1009;
	}

	public void setResponseJsonString_gpump1009(String responseJsonString_gpump1009) {
		this.responseJsonString_gpump1009 = responseJsonString_gpump1009;
	}

	public String getRequestJsonString_gpump1006() {
		return requestJsonString_gpump1006;
	}
	public String getRequestJsonString_gpump1005() {
		return requestJsonString_gpump1005;
	}
	public String getRequestJsonString_gpump1007() {
		return requestJsonString_gpump1007;
	}
	/**
	 * 设置GPU前置1011服务请求报文，用于打印
	 * @param requestJsonString_gpump1011
	 */
	public void setRequestJsonString_gpump1011(String requestJsonString_gpump1011) {
		this.requestJsonString_gpump1011 =  JSONUtils.formatJson(requestJsonString_gpump1011,maxValueLength);
		common_logger.debug("RequestJson_gpump1011:");
		common_logger.debug(this.requestJsonString_gpump1011);
	}
	/**
	 * 设置GPU前置1010服务请求报文，用于打印
	 * @param requestJsonString_gpump1010
	 */
	public void setRequestJsonString_gpump1010(String requestJsonString_gpump1010) {
		this.requestJsonString_gpump1010 =  JSONUtils.formatJson(requestJsonString_gpump1010,maxValueLength);
		common_logger.debug("RequestJson_gpump1010:");
		common_logger.debug(this.requestJsonString_gpump1010);
	}
	/**
	 * 设置GPU前置1005服务请求报文，用于打印
	 * @param requestJsonString_gpump1005
	 */
	public void setRequestJsonString_gpump1005(String requestJsonString_gpump1005) {
		this.requestJsonString_gpump1005 =  JSONUtils.formatJson(requestJsonString_gpump1005,maxValueLength);
		common_logger.debug("RequestJson_gpump1005:");
		common_logger.debug(this.requestJsonString_gpump1005);
	}
	/**
	 * 设置GPU前置1006服务请求报文，用于打印
	 * @param requestJsonString_gpump1006
	 */
	public void setRequestJsonString_gpump1006(String requestJsonString_gpump1006) {
		this.requestJsonString_gpump1006 =  JSONUtils.formatJson(requestJsonString_gpump1006,maxValueLength);
		common_logger.debug("RequestJson_gpump1006:");
		common_logger.debug(this.requestJsonString_gpump1006);
	}
	/**
	 * 设置GPU前置1007服务请求报文，用于打印
	 * @param requestJsonString_gpump1007
	 */
	public void setRequestJsonString_gpump1007(String requestJsonString_gpump1007) {
		this.requestJsonString_gpump1007 =  JSONUtils.formatJson(requestJsonString_gpump1007,maxValueLength);
		common_logger.debug("RequestJson_gpump1007:");
		common_logger.debug(this.requestJsonString_gpump1007);
	}
	/**
	 * 设置GPU前置1003服务请求报文，用于打印
	 * @param requestJsonString_gpump1003
	 */
	public void setRequestJsonString_gpump1003(String requestJsonString_gpump1003) {
		this.requestJsonString_gpump1003 =  JSONUtils.formatJson(requestJsonString_gpump1003,maxValueLength);
		common_logger.debug("RequestJson_gpump1003:");
		common_logger.debug(this.requestJsonString_gpump1003);
	}
	/**
	 * 设置GPU前置1002服务请求报文，用于打印
	 * @param requestJsonString_gpump1002
	 */
	public void setRequestJsonString_gpump1002(String requestJsonString_gpump1002) {
		this.requestJsonString_gpump1002 =  JSONUtils.formatJson(requestJsonString_gpump1002,maxValueLength);
		common_logger.debug("RequestJson_gpump1002:");
		common_logger.debug(this.requestJsonString_gpump1002);
	}
	/**
	 * 设置GPU前置1001服务请求报文，用于打印
	 * @param requestJsonString_gpump1001
	 */
	public void setRequestJsonString_gpump1001(String requestJsonString_gpump1001) {
		this.requestJsonString_gpump1001 =  JSONUtils.formatJson(requestJsonString_gpump1001,maxValueLength);
		common_logger.debug("RequestJson_gpump1001:");
		common_logger.debug(this.requestJsonString_gpump1001);
	}
	public String getResponseJsonString_gpump1011() {
		return responseJsonString_gpump1011;
	}
	public String getResponseJsonString_gpump1010() {
		return responseJsonString_gpump1010;
	}
	public String getResponseJsonString_gpump1001() {
		return responseJsonString_gpump1001;
	}
	public String getResponseJsonString_gpump1002() {
		return responseJsonString_gpump1002;
	}
	public String getResponseJsonString_gpump1003() {
		return responseJsonString_gpump1003;
	}
	public String getResponseJsonString_gpump1005() {
		return responseJsonString_gpump1005;
	}
	public String getResponseJsonString_gpump1006() {
		return responseJsonString_gpump1006;
	}
	public String getResponseJsonString_gpump1007() {
		return responseJsonString_gpump1007;
	}
	/**
	 * 设置GPU前置1011服务响应报文
	 * @param responseJsonString_gpump1011
	 */
	public void setResponseJsonString_gpump1011(String responseJsonString_gpump1011) {
		this.responseJsonString_gpump1011 =  JSONUtils.formatJson(responseJsonString_gpump1011,maxValueLength);
		common_logger.debug("ResponseJson_gpump1011:");
		common_logger.debug(this.responseJsonString_gpump1011);
	}
	/**
	 * 设置GPU前置1010服务响应报文
	 * @param responseJsonString_gpump1010
	 */
	public void setResponseJsonString_gpump1010(String responseJsonString_gpump1010) {
		this.responseJsonString_gpump1010 =  JSONUtils.formatJson(responseJsonString_gpump1010,maxValueLength);
		common_logger.debug("ResponseJson_gpump1010:");
		common_logger.debug(this.responseJsonString_gpump1010);
	}
	/**
	 * 设置GPU前置1005服务响应报文
	 * @param responseJsonString_gpump1005
	 */
	public void setResponseJsonString_gpump1005(String responseJsonString_gpump1005) {
		this.responseJsonString_gpump1005=  JSONUtils.formatJson(responseJsonString_gpump1005,maxValueLength);
		common_logger.debug("ResponseJson_gpump1005:");
		common_logger.debug(this.responseJsonString_gpump1005);
	}
	/**
	 * 设置GPU前置1006服务响应报文
	 * @param responseJsonString_gpump1006
	 */
	public void setResponseJsonString_gpump1006(String responseJsonString_gpump1006) {
		this.responseJsonString_gpump1006=  JSONUtils.formatJson(responseJsonString_gpump1006,maxValueLength);
		common_logger.debug("ResponseJson_gpump1006:");
		common_logger.debug(this.responseJsonString_gpump1006);
	}
	/**
	 * 设置GPU前置1007服务响应报文
	 * @param responseJsonString_gpump1007
	 */
	public void setResponseJsonString_gpump1007(String responseJsonString_gpump1007) {
		this.responseJsonString_gpump1007=  JSONUtils.formatJson(responseJsonString_gpump1007,maxValueLength);
		common_logger.debug("ResponseJson_gpump1007:");
		common_logger.debug(this.responseJsonString_gpump1007);
	}
	/**
	 * 设置GPU前置1003服务响应报文
	 * @param responseJsonString_gpump1003
	 */
	public void setResponseJsonString_gpump1003(String responseJsonString_gpump1003) {
		this.responseJsonString_gpump1003=  JSONUtils.formatJson(responseJsonString_gpump1003,maxValueLength);
		common_logger.debug("ResponseJson_gpump1003:");
		common_logger.debug(this.responseJsonString_gpump1003);
	}
	/**
	 * 设置GPU前置1002服务响应报文
	 * @param responseJsonString_gpump1002
	 */
	public void setResponseJsonString_gpump1002(String responseJsonString_gpump1002) {
		this.responseJsonString_gpump1002=  JSONUtils.formatJson(responseJsonString_gpump1002,maxValueLength);
		common_logger.debug("ResponseJson_gpump1002:");
		common_logger.debug(this.responseJsonString_gpump1002);
	}
	/**
	 * 设置GPU前置1001服务响应报文，用于打印
	 * @param responseJsonString_gpump1001
	 */
	public void setResponseJsonString_gpump1001(String responseJsonString_gpump1001) {
		this.responseJsonString_gpump1001=  JSONUtils.formatJson(responseJsonString_gpump1001,maxValueLength);
		common_logger.debug("ResponseJson_gpump1001:");
		common_logger.debug(this.responseJsonString_gpump1001);
	}
	/**
	 * 设置客户端请求报文
	 * @param requestJsonString_client
	 */
	public void setRequestJsonString_client(String requestJsonString_client) {
		this.requestJsonString_client =  JSONUtils.formatJson(requestJsonString_client,maxValueLength);
		common_logger.debug("RequestJson_client:");
		common_logger.debug(this.requestJsonString_client);
	}

	public String getResponseJsonString_client() {
		return responseJsonString_client;
	}
	/**
	 * 设置客户端响应报文
	 * @param responseJsonString_client
	 */
	public void setResponseJsonString_client(String responseJsonString_client) {
		this.responseJsonString_client =  JSONUtils.formatJson(responseJsonString_client,maxValueLength);
		common_logger.debug("ResponseJson_client:");
		common_logger.debug(this.responseJsonString_client);
	}

//	public void setRequestJsonString(JSONObject requestJson) {
//		this.requestJsonString =  JSONUtils.formatJson(requestJson,maxValueLength);
//		common_logger.debug("RequestJson:");
//		common_logger.debug(this.requestJsonString);
//	}
//
//	public void setRequestJsonString(String requestJsonString) {
//		this.requestJsonString =  JSONUtils.formatJson(requestJsonString,maxValueLength);
//		common_logger.debug("RequestJson:");
//		common_logger.debug(this.requestJsonString);
//	}
	

	public String getPlainText() {
		return plainText;
	}

	public void setPlainText(String plainText) {
		this.plainText =  JSONUtils.formatJson(plainText,maxValueLength);
		common_logger.debug("decrypt for plainText :");
		common_logger.debug(this.plainText);
	}

	public String getResponseJsonString() {
		return responseJsonString;
	}

	public void setResponseJsonString(JSONObject responseJson) {
		this.responseJsonString = JSONUtils.formatJson(responseJson,maxValueLength);
		common_logger.debug("ResponseJson:");
		common_logger.debug(this.responseJsonString);
	}

	public void setResponseJsonString(String responseJsonString) {
		this.responseJsonString = JSONUtils.formatJson(responseJsonString,maxValueLength);
		common_logger.debug("ResponseJson:");
		common_logger.debug(this.responseJsonString);
	}


	public String getErrormessage() {
		return errormessage;
	}

	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}

	public void debug(Object obj){
		if(LogLevel.DEBUG >= level)
			diposeLogMessage(obj,"DEBUG");
	}
	public void info(Object obj){
		if(LogLevel.INFO >= level)
			diposeLogMessage(obj,"INFO ");
	}
	public void error(Object obj){
		if(LogLevel.ERROR >= level)
			diposeLogMessage(obj,"ERROR");
	}

	private List<String> logDetailStrList = new ArrayList<String>();
	private void setlogDetailStr(String str){
		logDetailStrList.add(str);
		common_logger.debug(str);
	}
	public List<String> getLogDetailStrList(){
		return this.logDetailStrList;
	}

	private int index = 0;
	public long getSendCCVEA1001Time() {
		return sendCCVEA1001Time;
	}

	public void setSendCCVEA1001Time(long sendCCVEA1001Time) {
		this.sendCCVEA1001Time = sendCCVEA1001Time;
	}

	public long getSendCCVEA1002Time() {
		return sendCCVEA1002Time;
	}

	public void setSendCCVEA1002Time(long sendCCVEA1002Time) {
		this.sendCCVEA1002Time = sendCCVEA1002Time;
	}

	public long getSendCCVEA1003Time() {
		return sendCCVEA1003Time;
	}

	public void setSendCCVEA1003Time(long sendCCVEA1003Time) {
		this.sendCCVEA1003Time = sendCCVEA1003Time;
	}

	public long getSendCCVEA1004Time() {
		return sendCCVEA1004Time;
	}

	public void setSendCCVEA1004Time(long sendCCVEA1004Time) {
		this.sendCCVEA1004Time = sendCCVEA1004Time;
	}

	public String getRequestJsonString_CCVEA1001() {
		return requestJsonString_CCVEA1001;
	}

	public void setRequestJsonString_CCVEA1001(String requestJsonString_CCVEA1001) {
		this.requestJsonString_CCVEA1001 = requestJsonString_CCVEA1001;
	}

	public String getRequestJsonString_CCVEA1002() {
		return requestJsonString_CCVEA1002;
	}

	public void setRequestJsonString_CCVEA1002(String requestJsonString_CCVEA1002) {
		this.requestJsonString_CCVEA1002 = requestJsonString_CCVEA1002;
	}

	public String getRequestJsonString_CCVEA1003() {
		return requestJsonString_CCVEA1003;
	}

	public void setRequestJsonString_CCVEA1003(String requestJsonString_CCVEA1003) {
		this.requestJsonString_CCVEA1003 = requestJsonString_CCVEA1003;
	}

	public String getRequestJsonString_CCVEA1004() {
		return requestJsonString_CCVEA1004;
	}

	public void setRequestJsonString_CCVEA1004(String requestJsonString_CCVEA1004) {
		this.requestJsonString_CCVEA1004 = requestJsonString_CCVEA1004;
	}

	public String getResponseJsonString_CCVEA1001() {
		return responseJsonString_CCVEA1001;
	}

	public void setResponseJsonString_CCVEA1001(String responseJsonString_CCVEA1001) {
		this.responseJsonString_CCVEA1001 = responseJsonString_CCVEA1001;
	}

	public String getResponseJsonString_CCVEA1002() {
		return responseJsonString_CCVEA1002;
	}

	public void setResponseJsonString_CCVEA1002(String responseJsonString_CCVEA1002) {
		this.responseJsonString_CCVEA1002 = responseJsonString_CCVEA1002;
	}

	public String getResponseJsonString_CCVEA1003() {
		return responseJsonString_CCVEA1003;
	}

	public void setResponseJsonString_CCVEA1003(String responseJsonString_CCVEA1003) {
		this.responseJsonString_CCVEA1003 = responseJsonString_CCVEA1003;
	}

	public String getResponseJsonString_CCVEA1004() {
		return responseJsonString_CCVEA1004;
	}

	public void setResponseJsonString_CCVEA1004(String responseJsonString_CCVEA1004) {
		this.responseJsonString_CCVEA1004 = responseJsonString_CCVEA1004;
	}

	private long httpcost = 0L;

	public long getHttpcost() {
		return httpcost;
	}
	public void  setHttpcost(long httpcost)
	{
		this.httpcost=httpcost;
	}

	public void diposeLogMessage(Object obj, String levelName){
		String logHead = "["+(++index)+"]";
		logHead = logHead+" ["+levelName+"] ";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		if( obj instanceof HttpLog){
			HttpLog httplog = (HttpLog)obj;

			long thisHttpCost = httplog.getEndtime() - httplog.getStarttime();
			httpcost = httpcost + thisHttpCost;

			setlogDetailStr(logHead+"======== call http ========");
			String httpheadstr = String.format("StartTime:%s  EndTime:%s  UseTime(ms):%s" ,
					sdf.format(new Date(httplog.getStarttime())),
					sdf.format(new Date(httplog.getStarttime())),
					thisHttpCost
			);
			setlogDetailStr(httpheadstr);
			setlogDetailStr("queryUrl    : " + httplog.getQueryUrl());
			setlogDetailStr("requestBody : ");
			Map<String,String> formMap = httplog.getFormMap();
			if(formMap != null && formMap.size() != 0){
				setlogDetailStr("--post form--");
				for (Map.Entry<String,String> entry : formMap.entrySet()){
					setlogDetailStr(entry.getKey()+"="+getCompressString(entry.getValue(),maxValueLength));
				}
			}
			Map<String,String> fileMap = httplog.getFileMap();
			if(fileMap != null && fileMap.size() != 0){
				setlogDetailStr("--multipart/form-data--");
				for (Map.Entry<String,String> entry : fileMap.entrySet()){
					setlogDetailStr(entry.getKey()+"="+getCompressString(entry.getValue(),maxValueLength));
				}
			}

			String requestString = httplog.getRequestString();
			if(requestString!=null){
				if(requestString.startsWith("{") && requestString.endsWith("}")) {
					setlogDetailStr(JSONUtils.formatJson(requestString, maxValueLength));
				}else {
					setlogDetailStr(getCompressString(requestString,maxValueLength));
				}
			}

			JSONObject requestJson = httplog.getRequestJson();
			if(requestJson!=null){
				setlogDetailStr(JSONUtils.formatJson(requestJson, maxValueLength));
			}

			setlogDetailStr("responseBody: ");
			String responseString = httplog.getResponseString();
			if(responseString!=null){
				if(responseString.startsWith("{") && responseString.endsWith("}")) {
					setlogDetailStr(JSONUtils.formatJson(responseString, maxValueLength));
				}else {
					setlogDetailStr(getCompressString(responseString, maxValueLength));
				}
			}

			JSONObject responseJson = httplog.getResponseJson();
			if(responseJson!=null){
				setlogDetailStr(JSONUtils.formatJson(responseJson, maxValueLength));
			}


			setlogDetailStr("errorMessage: " + httplog.getErrorMessage());
		}else if( obj instanceof Exception){
			setlogDetailStr(logHead+ getExceptionMessage((Exception)obj));
		}else if( obj instanceof JSONObject){
			setlogDetailStr(logHead+"\n"+ JSONUtils.formatJson((JSONObject)obj, maxValueLength));
		}else{
			if(obj == null){
				obj = "null";
			}
			setlogDetailStr(logHead+ getCompressString(obj.toString(),maxValueLength));
		}
	}

	public static String getExceptionMessage(Exception e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return e.toString()+"\n"+sw.toString();
	}

	public String getCompressString(String str,int maxLength){
		if(str == null || maxLength <= -1){
			return str;
		}

		if(str.length()> maxLength){
			String result = "|$| omitted print length "+str.length() + " |$|";
			return result;
		}else {
			return str;
		}

	}
}
