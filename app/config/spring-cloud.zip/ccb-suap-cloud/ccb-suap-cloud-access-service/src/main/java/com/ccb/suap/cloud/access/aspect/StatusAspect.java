package com.ccb.suap.cloud.access.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.access.annotation.StatusAnnotation;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.schedule.INRECSchedule;

@Aspect
@Component
@Order(5)
public class StatusAspect {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Autowired
	private INRECSchedule INRECSchedule;
	
	
	@Around("@within(statusAnnotation)")
	public Object CacheEntity(ProceedingJoinPoint jp,StatusAnnotation statusAnnotation) throws Exception {
		
		checkStatus(statusAnnotation);
		
		Object obj = null;
		try {
			obj = jp.proceed();
		} catch (CommonRuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		} catch (Throwable e) {
			LOGGER.error("CosttimeAspect切面调用失败", e);
			throw new CommonRuntimeException(Errorcode.STATUSASPERROR, "02", "CosttimeAspect切面调用失败: "+e.getMessage());
		}
		
		return obj;
	}


	/**
	 * 检查对应模块的可用性，不可用则报错
	 * @param statusAnnotation
	 */
	private void checkStatus(StatusAnnotation statusAnnotation) {
		
		switch (statusAnnotation.TYPE()) {
		case DATABASE:
			checkDatabaseStatus();
			break;

		default:
			break;
		}
		
	}


	/**
	 * 检查数据库状态
	 */
	private void checkDatabaseStatus() {
		if(!INRECSchedule.getDatabaseStatus())
			throw new CommonRuntimeException(Errorcode.DATABASEDISUSE, "01", "数据库不可用");
	}
	
	
	
	
	
	
	
	
}
