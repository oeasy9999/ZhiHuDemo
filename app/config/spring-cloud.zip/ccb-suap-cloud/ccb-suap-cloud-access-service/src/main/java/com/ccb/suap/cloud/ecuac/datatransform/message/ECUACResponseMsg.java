package com.ccb.suap.cloud.ecuac.datatransform.message;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("TX")
public class ECUACResponseMsg implements Serializable {
	
	private static final long serialVersionUID = -1285576874L;
	
	@XStreamAlias("TX_HEADER")
	private ECUACResponseMsgHead tx_header;
	@XStreamAlias("TX_BODY")
	private ECUACResponseMsgBody tx_body;
	@XStreamAlias("TX_EMB")
	private String tx_emb;
	
	public ECUACResponseMsgHead getTx_header() {
		return tx_header;
	}
	public void setTx_header(ECUACResponseMsgHead tx_header) {
		this.tx_header = tx_header;
	}
	public ECUACResponseMsgBody getTx_body() {
		return tx_body;
	}
	public void setTx_body(ECUACResponseMsgBody tx_body) {
		this.tx_body = tx_body;
	}
	public String getTx_emb() {
		return tx_emb;
	}
	public void setTx_emb(String tx_emb) {
		this.tx_emb = tx_emb;
	}
	
	@Override
	public String toString() {
		return "TxResponseMsg [tx_header=" + tx_header + ", tx_body=" + tx_body + ", tx_emb=" + tx_emb + "]";
	}
	
	
	
	
	
	
	
	
	
}