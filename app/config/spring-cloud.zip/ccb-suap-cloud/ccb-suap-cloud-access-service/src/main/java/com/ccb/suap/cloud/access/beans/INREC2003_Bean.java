package com.ccb.suap.cloud.access.beans;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEquipmentInfo;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.service.SuapCustDeviceInfoService;
import com.ccb.suap.cloud.access.service.SuapCustInfoService;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC2003ServiceInVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

@Controller("INREC2003")
public class INREC2003_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC2003_Bean.class);
	
	@Autowired
	private SuapCustInfoService suapCustInfoService;
	
	@Autowired
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	
	
//	private SuapCustInfoService suapCustInfoService=InrecDaoFactory.getDaoManager().getSuapCustInfoService();
//	private SuapCustDeviceInfoService suapCustDeviceInfoService= InrecDaoFactory.getDaoManager().getSuapCustDeviceInfoService();

	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n------------------调用INREC2003服务------------------");
		ServiceParaUtil.setFaceLogByBaseEntity(reqMsg, FaceLogThreadLocal.get());
		
		LOGGER.debug("check InVo: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		INREC2003ServiceInVo entity = (INREC2003ServiceInVo) reqMsg.getTx_body().getEntity();
		String idtype = entity.getId_type();
		String idno = entity.getId_no();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(idtype+idno));
		
		LOGGER.debug("getCustInfo: num: " + num + ", idtype: " + idtype +", idno: " + idno);
		SuapCustInfoModel suapCustInfoModel = suapCustInfoService.selectWithRedis(num, idtype, idno);
		LOGGER.info(JSONObject.toJSONString(suapCustInfoModel));
		if(suapCustInfoModel == null)
			throw new CommonRuntimeException(Errorcode.CUSTINFOISNULL);
		
		LOGGER.debug("insertCustDeviceInfo: num: " + num + ", idtype: " + idtype + ", idno: " + idno + ", channelid: " + com1.getSysChannelID());
		SuapCustDeviceInfoModel suapCustDeviceInfoModel = getCustDeviceInfo(reqMsg);
		LOGGER.debug("suapCustDeviceInfoModel： "+suapCustDeviceInfoModel);
		SuapCustDeviceInfoModel selectInfoModel = suapCustDeviceInfoService.selectWithRedis(num, idtype, idno, com1.getSysChannelID());
		
		if(selectInfoModel == null) {
			suapCustDeviceInfoService.insert(suapCustDeviceInfoModel);
		}else {
			suapCustDeviceInfoService.update(suapCustDeviceInfoModel);
		}
		
		return rspMsg;
	}


	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		INREC2003ServiceInVo inrec2003ReqEntity = (INREC2003ServiceInVo) reqMsg.getTx_body().getEntity();
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		
		String id_type = inrec2003ReqEntity.getId_type();
		String id_no = inrec2003ReqEntity.getId_no();
		String channel_custno = inrec2003ReqEntity.getChannel_custno();
		String name = inrec2003ReqEntity.getName();
		
		if("".equals(id_type) || id_type == null)
			throw new CommonRuntimeException(Errorcode.ID_TYPENOTNULL);
		if("".equals(id_no) || id_no == null)
			throw new CommonRuntimeException(Errorcode.ID_NUMBNOTNULL);
		if("".equals(name) || name == null)
			throw new CommonRuntimeException(Errorcode.CSTNAMENOTNULL);
		if(locationIndex.equals("2") && ("".equals(channel_custno) || channel_custno == null))
			throw new CommonRuntimeException(Errorcode.CHANLCSTNONULL);
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("insertCustDevInfo(").append(insertCustDevInfo).append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	
	/**
	 *	 封装客户渠道信息
	 * @param entity
	 * @return
	 */
	private SuapCustDeviceInfoModel getCustDeviceInfo(TxRequestMsg reqMsg) {
		SuapCustDeviceInfoModel suapCustDeviceInfoModel = new SuapCustDeviceInfoModel();
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		TxRequestMsgEquipmentInfo equipment_info = reqMsg.getTx_body().getEquipment_info();
		INREC2003ServiceInVo entity = (INREC2003ServiceInVo) reqMsg.getTx_body().getEntity();
		
		String id_no = entity.getId_no();
		String id_type = entity.getId_type();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(id_type+id_no));
		
		suapCustDeviceInfoModel.setNum(num);
		suapCustDeviceInfoModel.setIdtype(entity.getId_type());
		suapCustDeviceInfoModel.setIdnumber(entity.getId_no());
		suapCustDeviceInfoModel.setChannelid(com1.getSysChannelID());
		suapCustDeviceInfoModel.setCustname(entity.getName());
		suapCustDeviceInfoModel.setCellphome(entity.getMobile_no());
		suapCustDeviceInfoModel.setChannel_cstno(entity.getChannel_custno());
		suapCustDeviceInfoModel.setTitile(entity.getTitle());
		suapCustDeviceInfoModel.setIsvip(entity.getIs_vip());
		suapCustDeviceInfoModel.setCardno(entity.getChannel_cardno());
		suapCustDeviceInfoModel.setUpdatetime(new Date());
		if(equipment_info != null)
			suapCustDeviceInfoModel.setDevicecode(equipment_info.getEquipmentId());
		
		return suapCustDeviceInfoModel;
	}

	

	
}
