package com.ccb.suap.cloud.access.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ccb.suap.cloud.access.annotation.CosttimeAnnotation;
import com.ccb.suap.cloud.access.annotation.RedisAnnotation;
import com.ccb.suap.cloud.access.annotation.StatusAnnotation;
import com.ccb.suap.cloud.access.annotation.RedisAnnotation.actionType;
import com.ccb.suap.cloud.access.annotation.RedisAnnotation.dataType;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.mapper.SuapCustDeviceInfoMapper;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;

@Service
@StatusAnnotation
public class SuapCustDeviceInfoService {
	
	@Autowired
	SuapCustDeviceInfoMapper dao;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	/**
	 * 新增客户渠道注册信息,若返回信息为0，则报错
	 * @param suapCustDeviceInfoModel
	 * @return
	 */
	@Transactional(rollbackFor = Exception.class)
	@CosttimeAnnotation(title = "insertCustDevInfo")
	@RedisAnnotation(dataType = dataType.CUSTDEVICEINFO, actionType = actionType.INSERT)
	public int insertWithRedis(SuapCustDeviceInfoModel suapCustDeviceInfoModel) {
		
		return insert(suapCustDeviceInfoModel);
	}
	
	
//	/**
//	 * 删除客户渠道注册信息
//	 * @param num
//	 * @param idtype
//	 * @param idno
//	 * @param channel_cstid
//	 * @return
//	 */
//	@RedisAnnotation(dataType = dataType.CUSTDEVICEINFO, actionType = actionType.DELETE)
//	public int delete(String num,String idtype,String idno,String channel_cstid) {
//		int row = 0;
//		try {
//			row = dao.delete(num, idtype, idno, channel_cstid);
//		} catch (Exception e) {
//			LOGGER.error("delete from custDeviceInfo fail: "+e.getMessage(),e);
//			throw new CommonRuntimeException(Errorcode.DELCSTDEVERROR, "02",e.getMessage().toString());
//		}
//		
//		return row;
//	}
	
	
	/**
	 * 关闭渠道注册信息
	 * @param num
	 * @param idtype
	 * @param idno
	 * @param channel_cstid
	 * @return
	 */
	@Transactional(rollbackFor = Exception.class)
	@CosttimeAnnotation(title = "deleteCustDevInfo")
	@RedisAnnotation(dataType = dataType.CUSTDEVICEINFO, actionType = actionType.DELETE)
	public int closeWithRedis(String num,String idtype,String idno,String channelid) {
		
		return close(num, idtype, idno, channelid);
	}
	
	
	/**
	 * 根据表名,id_type,id_no,channelId查询客户渠道注册信息
	 * @param num
	 * @param idtype
	 * @param idno
	 * @param channelid
	 * @return
	 */
	@CosttimeAnnotation(title = "selectCustDevInfo")
	@RedisAnnotation(dataType = dataType.CUSTDEVICEINFO, actionType = actionType.SELECT)
	public SuapCustDeviceInfoModel selectWithRedis(String num,String idtype,String idno,String channelid) {
		
		return select(num, idtype, idno, channelid);
	}
	
	
	/**
	 * 更新客户渠道注册信息,若返回信息为0，则报错
	 * @param suapCustDeviceInfoModel
	 * @return
	 */
	@Transactional(rollbackFor = Exception.class)
	@CosttimeAnnotation(title = "updateCustDevInfo")
	@RedisAnnotation(dataType = dataType.CUSTDEVICEINFO, actionType = actionType.UPDATE)
	public int updateWithRedis(SuapCustDeviceInfoModel suapCustDeviceInfoModel) {
		
		return update(suapCustDeviceInfoModel);
	}
	
	/**
	 * 新增客户渠道注册信息,若返回信息为0，则报错
	 * @param suapCustDeviceInfoModel
	 * @return
	 */
	@CosttimeAnnotation(title = "insertCustDevInfo")
	public int insert(SuapCustDeviceInfoModel suapCustDeviceInfoModel) {
		int row = 0;
		try {
			row = dao.insert(suapCustDeviceInfoModel);
		} catch (Exception e) {
			LOGGER.error("insert into custDeviceInfo fail: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.INSCSTDEVERROR, "02",e.getMessage().toString());
		}
		
		if(row == 0) {
			LOGGER.error("insert into custDeviceInfo fail: no meassage has inserted!");
			throw new CommonRuntimeException(Errorcode.INSCSTDEVFAILD);
		}
		
		return row;
	}
	
	
	/**
	 * 关闭渠道注册信息
	 * @param num
	 * @param idtype
	 * @param idno
	 * @param channelid
	 * @return
	 */
	@CosttimeAnnotation(title = "deleteCustDevInfo")
	public int close(String num,String idtype,String idno,String channelid) {
		int row = 0;
		try {
			row = dao.close(num, idtype, idno, channelid);
		} catch (Exception e) {
			LOGGER.error("close custDeviceInfo fail: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.DELCSTDEVERROR, "02",e.getMessage().toString());
		}
		
		return row;
		
	}
	
	
	/**
	 * 根据表名,id_type,id_no,channelId查询客户渠道注册信息
	 * @param num
	 * @param idtype
	 * @param idno
	 * @param channelid
	 * @return
	 */
	@CosttimeAnnotation(title = "selectCustDevInfo")
	public SuapCustDeviceInfoModel select(String num,String idtype,String idno,String channelid) {
		SuapCustDeviceInfoModel selectCustDev = null;
		try {
			selectCustDev = dao.select(num, idtype, idno, channelid);
		} catch (Exception e) {
			LOGGER.error("select from custDeviceInfo fail: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.SECCSTDEVERROR, "02",e.getMessage().toString());
		}
		
		return selectCustDev;
	}
	
	
	/**
	 * 更新客户渠道注册信息,若返回信息为0，则报错
	 * @param suapCustDeviceInfoModel
	 * @return
	 */
	@CosttimeAnnotation(title = "updateCustDevInfo")
	public int update(SuapCustDeviceInfoModel suapCustDeviceInfoModel) {
		int row = 0;
		try {
			row = dao.update(suapCustDeviceInfoModel);
		} catch (Exception e) {
			LOGGER.error("update custDeviceInfo fail: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.UPDCSTDEVERROR, "02",e.getMessage().toString());
		}
		if(row == 0) {
			LOGGER.error("update custDeviceInfo fail: no message has updated!");
			throw new CommonRuntimeException(Errorcode.UPDCSTDEVFAILD);
		}
		
		return row;
	}
	
	
	
}
