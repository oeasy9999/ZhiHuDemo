package com.ccb.suap.cloud.access.threadLocal;

/**
 * 	使用此对象需要在INRECInterceptor的afterCompletion中销毁
 */

import com.ccb.suap.util.log.TraceLog;

public class TraceLogThreadLocal {

	private static ThreadLocal<TraceLog> traceLogThreadLocal = new ThreadLocal<TraceLog>() {
		
		@Override
		protected TraceLog initialValue() {
			return new TraceLog();
		};
		
	};
	
	/**
	 * 	私有化构造方法，防止外部创建实例
	 */
	private TraceLogThreadLocal() {
		
	}
	
	
	public static TraceLog get() {
		return traceLogThreadLocal.get();
	}
	
	
	public static void set(TraceLog traceLog) {
		traceLogThreadLocal.set(traceLog);
	}
	
	
	public static void remove() {
		traceLogThreadLocal.remove();
	}
	
	
	
	
	
}
