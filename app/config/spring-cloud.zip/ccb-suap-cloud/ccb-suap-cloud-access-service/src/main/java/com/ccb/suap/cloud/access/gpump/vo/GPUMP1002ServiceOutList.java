package com.ccb.suap.cloud.access.gpump.vo;

public class GPUMP1002ServiceOutList {
	
	private String cust_id;				//客户ID
	private String id_type;				//证件类型
	private String id_no;				//证件号码
	private String name;				//姓名
	private String mobile_no;			//手机号码
	private String face_collecttime;	//人脸照片最近更新时间YYYYMMDDHHMISS
	private String similarity;			//相似度
	
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getFace_collecttime() {
		return face_collecttime;
	}
	public void setFace_collecttime(String face_collecttime) {
		this.face_collecttime = face_collecttime;
	}
	public String getSimilarity() {
		return similarity;
	}
	public void setSimilarity(String similarity) {
		this.similarity = similarity;
	}
	
	@Override
	public String toString() {
		return "GPUMP3002ServiceOutResultListVo [cust_id=" + cust_id + ", id_type=" + id_type + ", id_no=" + id_no
				+ ", name=" + name + ", mobile_no=" + mobile_no + ", face_collecttime=" + face_collecttime
				+ ", similarity=" + similarity + "]";
	}
	
	
	
}
