package com.ccb.suap.cloud.access.beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.service.SuapCustInfoService;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC3002ServiceInVo;
import com.ccb.suap.cloud.access.vo.INRECBaseServiceInVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

@Controller("INREC3002")
public class INREC3002_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC3002_Bean.class);
	
	@Autowired
	private SuapCustInfoService suapCustInfoService;
	
//	private SuapCustInfoService suapCustInfoService=InrecDaoFactory.getDaoManager().getSuapCustInfoService();

	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n------------------调用INREC3002服务------------------");
		setFaceLog(reqMsg);
		
		LOGGER.debug("check InVo: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		INREC3002ServiceInVo inre3002ReqEntity = (INREC3002ServiceInVo) reqMsg.getTx_body().getEntity();
		String id_type = inre3002ReqEntity.getId_type();
		String id_no = inre3002ReqEntity.getId_no();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(id_type+id_no));
		LOGGER.debug("selectCustInfo: num: "+num+", id_type: "+id_type+", id_no: "+id_no);
		SuapCustInfoModel custInfo = suapCustInfoService.selectWithRedis(num, id_type, id_no);
		
		if(custInfo == null)
			throw new CommonRuntimeException(Errorcode.CUSTINFOISNULL);
		
		return rspMsg;
	}
	


	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		INRECBaseServiceInVo entity = (INRECBaseServiceInVo) reqMsg.getTx_body().getEntity();
		
		String id_type = entity.getId_type();
		String id_no = entity.getId_no();
		String name = entity.getName();
		
		if("".equals(id_type) || id_type == null)
			throw new CommonRuntimeException(Errorcode.ID_TYPENOTNULL);
		if("".equals(id_no) || id_no == null)
			throw new CommonRuntimeException(Errorcode.ID_NUMBNOTNULL);
		if("".equals(name) || name == null)
			throw new CommonRuntimeException(Errorcode.CSTNAMENOTNULL);
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("selectCustInfo(").append(selectCustInfo).append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	

	private void setFaceLog(TxRequestMsg reqMsg) {
		INREC3002ServiceInVo inrec3002ReqEntity = (INREC3002ServiceInVo) reqMsg.getTx_body().getEntity();
		SuapFaceLogModel faceLog = FaceLogThreadLocal.get();
		faceLog.setIdtype(inrec3002ReqEntity.getId_type());
		faceLog.setIdno(inrec3002ReqEntity.getId_no());
		faceLog.setName(inrec3002ReqEntity.getName());
		
	}

	

	
}
