package com.ccb.suap.cloud.access.vo;

public class INREC1008ServiceInVo extends INRECBaseServiceInVo{
	
	
	
	
	
	
	
	
	
	
	
	
	
}
