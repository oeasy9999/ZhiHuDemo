package com.ccb.suap.cloud.access.service.utils;

/**
 * 本工具类主要用于对业务参数进行校验
 */
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.vo.INRECBaseServiceInVo;

public class CheckParaUtil {
	
	
	/**
	 * 	校验tx_header的信息是否合法
	 * @param reqMsg
	 * @return
	 */
	public static String checkTxRequestMsgHead(TxRequestMsgHead header) {
		if (header.getSys_pkg_vrsn() == null)
			header.setSys_pkg_vrsn("01");
		if (header.getSys_pkg_sts_type() == null)
			header.setSys_pkg_sts_type("00");
		if (header.getSys_evt_trace_id() == null)
			return Errorcode.TRACEIDNOTNULL;
		
		return null;
	}
	
	
	/**
	 * 	校验com1域是否合法
	 * @param reqMsg
	 * @return
	 */
	public static String checkTxRequestMsgCom1(TxRequestMsgCom1 com1) {
		if (com1.getSysChannelID() == null)
			return Errorcode.CHANLIDNOTNULL;
		if (com1.getChannelTxCode() == null) 
			return Errorcode.CHANLCDNOTNULL;
		
		return null;
	}
	
	
//	/**
//	 * 	校验com2域是否合法
//	 * @param rspMsg
//	 * @param com2  com2信息
//	 */
//	public static void checkTxRequestMsgCom2(TxResponseMsg rspMsg, TxRequestMsg reqMsg) {
//		TxRequestMsgCom2 com2 = reqMsg.getTx_body().getCom2();
		
//		if(com2.getGroupName() == null) {
//			rspHeader.setSys_resp_code(Errorcode.GRPNAMENOTNULL);
//			return rspMsg;
//		}else if (com2.getDotNumber() == null) {
//			rspHeader.setSys_resp_code(Errorcode.PARAMENOEXIT);
//			rspHeader.setSys_resp_desc("can not find the dotNumber!");			
//		}else if (com2.getSysChannelID() == null) {
//			rspHeader.setSys_resp_code(Errorcode.PARAMENOEXIT);
//			rspHeader.setSys_resp_desc("can not find the sysChannelID!");
//		}else if (com2.getSourceGroupName() == null) {
//			rspHeader.setSys_resp_code(Errorcode.PARAMENOEXIT);
//			rspHeader.setSys_resp_desc("sourceGroupName can not be null!");									
//		}
		
//	}
	
	
	/**
	 * 	校验人脸识别参数是否合法
	 * @param suapFaceConfigModel
	 * @return
	 */
	public static String checkFaceConfig(SuapFaceConfigModel suapFaceConfigModel) {
		String groupName = suapFaceConfigModel.getLocation_source();
		String leveltype = suapFaceConfigModel.getLeveltype();
		String locationindex = suapFaceConfigModel.getLocationindex();
		
		if(groupName == null)
			return Errorcode.LOCASRNOTFOUND;
		if(!leveltype.equals("1") && !leveltype.equals("2"))
			return Errorcode.LEVELTYPEERROR;
		if(!locationindex.equals("1") && !locationindex.equals("2"))
			return Errorcode.LOCATIONEERROR;
		
		return null;
	}
	
	
	/**
	 * 通过LocationIndex判断id_type,id_no和channel_custno是否合法
	 * @param reqMsg
	 * @return
	 */
	public static String checkParaByLocationIndex(TxRequestMsg reqMsg) {
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		INRECBaseServiceInVo entity = (INRECBaseServiceInVo) reqMsg.getTx_body().getEntity();
		
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		
		String id_type = entity.getId_type();
		String id_no = entity.getId_no();
		String channel_custno = entity.getChannel_custno();
		
		if(locationIndex.equals("1") && ("".equals(id_type) || id_type == null))
			return Errorcode.ID_TYPENOTNULL;
		if(locationIndex.equals("1") && ("".equals(id_no) || id_no == null))
			return Errorcode.ID_NUMBNOTNULL;
		if(locationIndex.equals("2") && ("".equals(channel_custno) || channel_custno == null))
			return Errorcode.CHANLCSTNONULL;
		
		return null;
	}
	
	
	
	
	
	
	
	
	
	
}
