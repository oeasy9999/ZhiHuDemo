package com.ccb.suap.cloud.access.model;

public class SuapCustBlackListModel {
	
	private String IDTYPE;						//证件类型
	private String IDNUMBER;					//证件号码
	private String CHANNELID;					//渠道号
	private String CUSTNAME;					//姓名
	private String REMARKS;						//备注
	
	public String getIDTYPE() {
		return IDTYPE;
	}
	public void setIDTYPE(String iDTYPE) {
		IDTYPE = iDTYPE;
	}
	public String getIDNUMBER() {
		return IDNUMBER;
	}
	public void setIDNUMBER(String iDNUMBER) {
		IDNUMBER = iDNUMBER;
	}
	public String getCHANNELID() {
		return CHANNELID;
	}
	public void setCHANNELID(String cHANNELID) {
		CHANNELID = cHANNELID;
	}
	public String getCUSTNAME() {
		return CUSTNAME;
	}
	public void setCUSTNAME(String cUSTNAME) {
		CUSTNAME = cUSTNAME;
	}
	public String getREMARKS() {
		return REMARKS;
	}
	public void setREMARKS(String rEMARKS) {
		REMARKS = rEMARKS;
	}
	
	@Override
	public String toString() {
		return "SuapCustBlackListModel [IDTYPE=" + IDTYPE + ", IDNUMBER=" + IDNUMBER + ", CHANNELID=" + CHANNELID
				+ ", CUSTNAME=" + CUSTNAME + ", REMARKS=" + REMARKS + "]";
	}
	
	
	
	
	
	
	
	
	
}
