package com.ccb.suap.cloud.access.model;

import java.io.Serializable;
import java.util.Date;

public class SuapVendorInfoModel implements Serializable{
	
	private static final long serialVersionUID = 1277063459887976299L;
	
	private String vendorcode;			//厂商标识
	private String vendorname;			//厂商名称
	private String vendordesc;			//厂商描述
	private Date createtime;			//创建时间
	private String creator;				//创建者
	private Date modifytime;			//修改时间
	private String modifier;			//修改者
	
	public String getVendorcode() {
		return vendorcode;
	}
	public void setVendorcode(String vendorcode) {
		this.vendorcode = vendorcode;
	}
	public String getVendorname() {
		return vendorname;
	}
	public void setVendorname(String vendorname) {
		this.vendorname = vendorname;
	}
	public String getVendordesc() {
		return vendordesc;
	}
	public void setVendordesc(String vendordesc) {
		this.vendordesc = vendordesc;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public Date getModifytime() {
		return modifytime;
	}
	public void setModifytime(Date modifytime) {
		this.modifytime = modifytime;
	}
	public String getModifier() {
		return modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	
	@Override
	public String toString() {
		return "SuapVendorInfoModel [vendorcode=" + vendorcode + ", vendorname=" + vendorname + ", vendordesc="
				+ vendordesc + ", createtime=" + createtime + ", creator=" + creator + ", modifytime=" + modifytime
				+ ", modifier=" + modifier + "]";
	}
	
	
	
	
	
	
	
	
}
