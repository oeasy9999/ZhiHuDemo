package com.ccb.suap.util.file.chiper;

import com.ccb.suap.util.Base64;



public class XORCipher {

	private static final String secrectKey = "Anydef20151010智能身份识别平台FECOI{%biap%}()*&<MNCXZPKL";
	private static final String charset = "UTF-8";
	private static byte[] keyBytes = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,};
	private static String EMPTY_STRING = "";
	static {
		try {
			keyBytes = secrectKey.getBytes(charset);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static String encode(String enc) {
		try {
			if(checkEmpty(enc)) {
				return EMPTY_STRING;
			}
			byte[] b = enc.getBytes(charset);
			for (int i = 0, size = b.length; i < size; i++) {
				for (byte keyBytes0 : keyBytes) {
					b[i] = (byte) (b[i] ^ keyBytes0);
				}
			}
			return new String(Base64.encode(b));
			//return bytes2Hex(b);
		} catch(Exception e) {
			e.printStackTrace();
			return EMPTY_STRING;
		}
	}
	
	public static byte[] encode(byte[] enc) {
		if(enc==null) return null;
		byte[] b = new byte[enc.length];
		System.arraycopy(enc, 0, b, 0, b.length);
		for (int i = 0, size = b.length; i < size; i++) {
			for (byte keyBytes0 : keyBytes) {
				b[i] = (byte) (b[i] ^ keyBytes0);
			}
		}
		return b;
	}

	public static String decode(String dec) {
		try {
			if(checkEmpty(dec)) {
				return EMPTY_STRING;
			}
			byte[] e = Base64.decode(dec.getBytes());
			//byte[] e = hex2Byte(dec);
			byte[] dee = e;
			for (int i = 0, size = e.length; i < size; i++) {
				for (byte keyBytes0 : keyBytes) {
					e[i] = (byte) (dee[i] ^ keyBytes0);
				}
			}
			return new String(e, charset);
		} catch(Exception e) {
			e.printStackTrace();
			return EMPTY_STRING;
		}
	}
	
	public static byte[] decode(byte[] dec) {
		if(dec==null) return null;
		byte[] e = dec;
		byte[] dee = e;
		for (int i = 0, size = e.length; i < size; i++) {
			for (byte keyBytes0 : keyBytes) {
				e[i] = (byte) (dee[i] ^ keyBytes0);
			}
		}
		return e;
	}

	public static String bytes2Hex(byte[] bytes) {
		String ret = "";
		for (byte by : bytes) {
			String hex = Integer.toHexString(by & 0xFF);
			if (hex.length() == 1)
				hex = '0' + hex;

			ret += hex.toUpperCase();
		}
		return ret;
	}
	
	public static byte[] hex2Byte(String hexStr)
			throws IllegalArgumentException {
		String str = "0123456789ABCDEF";
		char[] hexs = hexStr.toCharArray();
		byte[] bytes = new byte[hexStr.length() / 2];
		int n;

		for (int i = 0; i < bytes.length; i++) {
			n = str.indexOf(hexs[2 * i]) * 16;
			n += str.indexOf(hexs[2 * i + 1]);
			bytes[i] = (byte) (n & 0xff);
		}
		return bytes;
	}
	
	public static boolean checkEmpty(String str) {
		return ((str == null) || ("".equals(str.trim())));
	}
}
