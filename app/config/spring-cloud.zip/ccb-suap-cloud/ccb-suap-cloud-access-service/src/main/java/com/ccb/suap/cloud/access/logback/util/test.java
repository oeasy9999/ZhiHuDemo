package com.ccb.suap.cloud.access.logback.util;
import java.io.File;
import java.io.FileNotFoundException;

import org.springframework.util.ResourceUtils;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
/**
 * @author Wzy525110
 */
public class test {
 
    public static void main(String[] args) {
        //LoggerBuilder loggerBuilder =new LoggerBuilder();
//        Logger logger = LoggerBuilder.getLogger("E:\\eppLog\\logs","facegpups-GMUMP1001","1KB","info");
//        logger.debug("shuai1 +++++++++++++++++++++++++++++++++++++debug");
//        logger.warn("shuai2 +++++++++++++++++++++++++++++++++++++warn");
//        logger.info("shuai3 +++++++++++++++++++++++++++++++++++++info");
//        logger.error("shuai4 +++++++++++++++++++++++++++++++++++++error");
    	String sys_url_local=null;
    	try {
			sys_url_local = new File(ResourceUtils.getURL("classpath:").getPath()).getParentFile().getParentFile().getPath()+File.separator+"image";
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//        System.out.println(sys_url_local);
    }
}