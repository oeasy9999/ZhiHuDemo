package com.ccb.suap.cloud.access.gpump.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class GPUMP1004ServiceOutVo extends TxResponseMsgEntity{
	
	private String cust_id;						//客户ID
	private String id_type;						//证件类型
	private String id_no;						//证件号码
	private String name;						//姓名
	private String mobile_no;					//手机号码
	private String face_collecttime;			//最近更新时间
	private String face_recognitiontime;		//最近识别时间
	private String face_image;					//人脸图片
	
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getFace_collecttime() {
		return face_collecttime;
	}
	public void setFace_collecttime(String face_collecttime) {
		this.face_collecttime = face_collecttime;
	}
	public String getFace_recognitiontime() {
		return face_recognitiontime;
	}
	public void setFace_recognitiontime(String face_recognitiontime) {
		this.face_recognitiontime = face_recognitiontime;
	}
	public String getFace_image() {
		return face_image;
	}
	public void setFace_image(String face_image) {
		this.face_image = face_image;
	}
	@Override
	public String toString() {
		return "GPUMP1004ServiceOutVo [cust_id=" + cust_id + ", id_type=" + id_type + ", id_no=" + id_no + ", name="
				+ name + ", mobile_no=" + mobile_no + ", face_collecttime=" + face_collecttime
				+ ", face_recognitiontime=" + face_recognitiontime + ", face_image=" + face_image + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
