package com.ccb.suap.cloud.access.model;

import java.util.Date;

public class TestModel {
	
	private String str;
	private Date time;
	
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	
	@Override
	public String toString() {
		return "TestModel [str=" + str + ", time=" + time + "]";
	}
	
	
	
	
	
	
	
	
	
}
