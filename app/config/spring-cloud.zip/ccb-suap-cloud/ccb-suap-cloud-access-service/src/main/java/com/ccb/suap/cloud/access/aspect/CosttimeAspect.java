package com.ccb.suap.cloud.access.aspect;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.access.annotation.CosttimeAnnotation;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.threadLocal.CosttimeThreadLocal;

@Aspect
@Component
@Order(3)
public class CosttimeAspect {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Around("@annotation(costtimeAnnotation)")
	public Object CacheEntity(ProceedingJoinPoint jp,CosttimeAnnotation costtimeAnnotation) throws Exception{
		
		long start = System.currentTimeMillis();
		
		Object obj = null;
		try {
			obj = jp.proceed();
		} catch (CommonRuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		} catch (Throwable e) {
			LOGGER.error("CosttimeAspect切面调用失败", e);
			throw new CommonRuntimeException(Errorcode.COSTT_ASPERROR, "02", "CosttimeAspect切面调用失败: "+e.getMessage());
		}
		
		long costtime = System.currentTimeMillis() - start;
		String title = getTitle(jp, costtimeAnnotation);
		
		CosttimeThreadLocal.add(title, costtime);
		
		return obj;
	}

	
	/**
	 * 	获取耗时描述
	 * @param jp
	 * @param costtimeAnnotation
	 * @return
	 * @throws Exception 
	 * @throws NoSuchMethodException 
	 */
	private String getTitle(ProceedingJoinPoint jp, CosttimeAnnotation costtimeAnnotation) {
		
		if(StringUtils.isNotBlank(costtimeAnnotation.title()))
			return costtimeAnnotation.title();
		
		if(StringUtils.isNotBlank(costtimeAnnotation.value()))
			return costtimeAnnotation.value();
		
		return jp.getSignature().getName();
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
