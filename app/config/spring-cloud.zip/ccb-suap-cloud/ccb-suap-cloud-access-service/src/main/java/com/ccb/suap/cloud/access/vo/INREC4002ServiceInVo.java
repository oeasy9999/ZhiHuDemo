package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class INREC4002ServiceInVo extends TxRequestMsgEntity{
	
	private String face_eigen1;					//人脸特征值1
	private String face_image1;					//人脸图片1
	private String face_eigen2;					//人脸特征值2
	private String face_image2;					//人脸图片2
	
	public String getFace_eigen1() {
		return face_eigen1;
	}
	public void setFace_eigen1(String face_eigen1) {
		this.face_eigen1 = face_eigen1;
	}
	public String getFace_image1() {
		return face_image1;
	}
	public void setFace_image1(String face_image1) {
		this.face_image1 = face_image1;
	}
	public String getFace_eigen2() {
		return face_eigen2;
	}
	public void setFace_eigen2(String face_eigen2) {
		this.face_eigen2 = face_eigen2;
	}
	public String getFace_image2() {
		return face_image2;
	}
	public void setFace_image2(String face_image2) {
		this.face_image2 = face_image2;
	}
	
	@Override
	public String toString() {
		return "INREC4002ServiceInVo [face_eigen1=" + face_eigen1 + ", face_image1=" + face_image1 + ", face_eigen2="
				+ face_eigen2 + ", face_image2=" + face_image2 + "]";
	}
	
	
	
	
	

	
	
	
	
	
	
	
	
}
