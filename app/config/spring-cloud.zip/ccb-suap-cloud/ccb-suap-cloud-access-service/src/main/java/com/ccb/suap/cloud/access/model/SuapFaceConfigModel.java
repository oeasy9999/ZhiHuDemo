package com.ccb.suap.cloud.access.model;

import java.io.Serializable;

public class SuapFaceConfigModel implements Serializable{
	
	private static final long serialVersionUID = 2353350228590332409L;
	
	private Integer id;					//参数记录ID
	private String channelcode;			//系统渠道编号
	private String tradecode;			//系统渠道交易码
	private String txcode;				//交易码
	private String branchno;			//分行号
	private String destable;			//1:1目标表名
	private String isseparate;			//是否分表
	private String separatenum;			//分表数量
	private String separateindex;		//根据哪个字段分表
	private String ishackcheck;			//是否防黑
	private String hackthreshold;		//防黑阈值
	private String leveltype;			//照片类型
	private String levelgrade;			//照片级别
	private String locknum;				//连续失败锁定次数
	private String similarity;			//比对阈值/识别阈值
	private String ispicture;			//是否上送图片
	private String idverify;			//是否需要身份核查
	private String idverify_mode;		//人脸核查模式
	private String ecuac0183_mode;		//ECUAC0183 专线核查模式
	private String rhverify;			//是否获取人行高清照
	private String isc00004;			//是否需要获取缓存照片
	private String distpic;				//比对是否返回注册图片
	private String ispolice;			//是否需要一所核查
	private String regpic;				//是否使用上送图片采集
	private String hitnum;				//命中数
	private String issync1to1;			//是否需要同步1:1库
	private String location_source;		//源1：N库
	private String location;			//目标1：N库
	private String locationindex;		//1：N库根据哪个字段索引
	private String remark;				//备注
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getChannelcode() {
		return channelcode;
	}
	public void setChannelcode(String channelcode) {
		this.channelcode = channelcode;
	}
	public String getTradecode() {
		return tradecode;
	}
	public void setTradecode(String tradecode) {
		this.tradecode = tradecode;
	}
	public String getTxcode() {
		return txcode;
	}
	public void setTxcode(String txcode) {
		this.txcode = txcode;
	}
	public String getBranchno() {
		return branchno;
	}
	public void setBranchno(String branchno) {
		this.branchno = branchno;
	}
	public String getDestable() {
		return destable;
	}
	public void setDestable(String destable) {
		this.destable = destable;
	}
	public String getIsseparate() {
		return isseparate;
	}
	public void setIsseparate(String isseparate) {
		this.isseparate = isseparate;
	}
	public String getSeparatenum() {
		return separatenum;
	}
	public void setSeparatenum(String separatenum) {
		this.separatenum = separatenum;
	}
	public String getSeparateindex() {
		return separateindex;
	}
	public void setSeparateindex(String separateindex) {
		this.separateindex = separateindex;
	}
	public String getIshackcheck() {
		return ishackcheck;
	}
	public void setIshackcheck(String ishackcheck) {
		this.ishackcheck = ishackcheck;
	}
	public String getHackthreshold() {
		return hackthreshold;
	}
	public void setHackthreshold(String hackthreshold) {
		this.hackthreshold = hackthreshold;
	}
	public String getLeveltype() {
		return leveltype;
	}
	public void setLeveltype(String leveltype) {
		this.leveltype = leveltype;
	}
	public String getLevelgrade() {
		return levelgrade;
	}
	public void setLevelgrade(String levelgrade) {
		this.levelgrade = levelgrade;
	}
	public String getLocknum() {
		return locknum;
	}
	public void setLocknum(String locknum) {
		this.locknum = locknum;
	}
	public String getSimilarity() {
		return similarity;
	}
	public void setSimilarity(String similarity) {
		this.similarity = similarity;
	}
	public String getIspicture() {
		return ispicture;
	}
	public void setIspicture(String ispicture) {
		this.ispicture = ispicture;
	}
	public String getIdverify() {
		return idverify;
	}
	public void setIdverify(String idverify) {
		this.idverify = idverify;
	}
	public String getIdverify_mode() {
		return idverify_mode;
	}
	public void setIdverify_mode(String idverify_mode) {
		this.idverify_mode = idverify_mode;
	}
	public String getEcuac0183_mode() {
		return ecuac0183_mode;
	}
	public void setEcuac0183_mode(String ecuac0183_mode) {
		this.ecuac0183_mode = ecuac0183_mode;
	}
	public String getRhverify() {
		return rhverify;
	}
	public void setRhverify(String rhverify) {
		this.rhverify = rhverify;
	}
	public String getIsc00004() {
		return isc00004;
	}
	public void setIsc00004(String isc00004) {
		this.isc00004 = isc00004;
	}
	public String getDistpic() {
		return distpic;
	}
	public void setDistpic(String distpic) {
		this.distpic = distpic;
	}
	public String getIspolice() {
		return ispolice;
	}
	public void setIspolice(String ispolice) {
		this.ispolice = ispolice;
	}
	public String getRegpic() {
		return regpic;
	}
	public void setRegpic(String regpic) {
		this.regpic = regpic;
	}
	public String getHitnum() {
		return hitnum;
	}
	public void setHitnum(String hitnum) {
		this.hitnum = hitnum;
	}
	public String getIssync1to1() {
		return issync1to1;
	}
	public void setIssync1to1(String issync1to1) {
		this.issync1to1 = issync1to1;
	}
	public String getLocation_source() {
		return location_source;
	}
	public void setLocation_source(String location_source) {
		this.location_source = location_source;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getLocationindex() {
		return locationindex;
	}
	public void setLocationindex(String locationindex) {
		this.locationindex = locationindex;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	@Override
	public String toString() {
		return "SuapFaceConfigModel [id=" + id + ", channelcode=" + channelcode + ", tradecode=" + tradecode
				+ ", txcode=" + txcode + ", branchno=" + branchno + ", destable=" + destable + ", isseparate="
				+ isseparate + ", separatenum=" + separatenum + ", separateindex=" + separateindex + ", ishackcheck="
				+ ishackcheck + ", hackthreshold=" + hackthreshold + ", leveltype=" + leveltype + ", levelgrade="
				+ levelgrade + ", locknum=" + locknum + ", similarity=" + similarity + ", ispicture=" + ispicture
				+ ", idverify=" + idverify + ", idverify_mode=" + idverify_mode + ", rhverify=" + rhverify
				+ ", isc00004=" + isc00004 + ", distpic=" + distpic + ", ispolice=" + ispolice + ", regpic=" + regpic
				+ ", hitnum=" + hitnum + ", issync1to1=" + issync1to1 + ", location_source=" + location_source
				+ ", location=" + location + ", locationindex=" + locationindex + ", remark=" + remark + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
