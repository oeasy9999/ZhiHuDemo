package com.ccb.suap.cloud.access.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ccb.suap.cloud.access.annotation.CosttimeAnnotation;
import com.ccb.suap.cloud.access.annotation.RedisAnnotation;
import com.ccb.suap.cloud.access.annotation.StatusAnnotation;
import com.ccb.suap.cloud.access.annotation.RedisAnnotation.actionType;
import com.ccb.suap.cloud.access.annotation.RedisAnnotation.dataType;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.mapper.SuapCustInfoMapper;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;

@Service
@StatusAnnotation
public class SuapCustInfoService {
	
	@Autowired
	SuapCustInfoMapper dao;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	
	/**
	 * 新增客户信息,若返回信息为0，则报错 (新增成功后同步更新到redis)
	 * @param suapCustInfoModel
	 * @return
	 */
	@CosttimeAnnotation(title = "insertCustInfo")
	@RedisAnnotation(dataType = dataType.CUSTINFO, actionType = actionType.INSERT)
	public int insertWithRedis(SuapCustInfoModel suapCustInfoModel) {
		
		return insert(suapCustInfoModel);
	}
	
	
	/**
	 * 根据表名,id_type,id_no查询客户信息 (优先查询redis中客户信息, 找不到则查找数据库)
	 * @param num
	 * @param idtype
	 * @param idno
	 * @return
	 */
	@CosttimeAnnotation(title = "selectCustInfo")
	@RedisAnnotation(dataType = dataType.CUSTINFO, actionType = actionType.SELECT)
	public SuapCustInfoModel selectWithRedis(String num,String idtype,String idno) {
		
		return select(num, idtype, idno);
	}
	
	
	/**
	 * 更新客户信息,若返回信息为0，则报错 (更新成功后同步到redis中)
	 * @param suapCustInfoModel
	 * @return
	 */
	@Transactional(rollbackFor = Exception.class)
	@CosttimeAnnotation(title = "updateCustInfo")
	@RedisAnnotation(dataType = dataType.CUSTINFO, actionType = actionType.UPDATE)
	public int updateWithRedis(SuapCustInfoModel suapCustInfoModel) {
		
		return update(suapCustInfoModel);
	}
	
	
	/**
	 * 新增客户信息,若返回信息为0，则报错
	 * @param suapCustInfoModel
	 * @return
	 */
	@CosttimeAnnotation(title = "insertCustInfo")
	public int insert(SuapCustInfoModel suapCustInfoModel) {
		int row = 0;
		try {
			row = dao.insert(suapCustInfoModel);
		} catch (Exception e) {
			LOGGER.error("insert CustInfo fail: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.INSCSTINFERROR, "02",e.getMessage().toString());
		}
		if(row == 0) {
			LOGGER.error("insert CustInfo fail: no message has inserted!");
			throw new CommonRuntimeException(Errorcode.INSCSTINFFAILD);
		}
		
		return row;
	}
	
	
	/**
	 * 根据表名,id_type,id_no查询客户信息
	 * @param num
	 * @param idtype
	 * @param idno
	 * @return
	 */
	@CosttimeAnnotation(title = "selectCustInfo")
	public SuapCustInfoModel select(String num,String idtype,String idno) {
		SuapCustInfoModel selectCustInfo = null;
		try {
			selectCustInfo = dao.select(num, idtype, idno);
		} catch (Exception e) {
			LOGGER.error("select CustInfo fail: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.SECCSTINFERROR, "02",e.getMessage().toString());
		}
		
		return selectCustInfo;
	}
	
	
	/**
	 * 更新客户信息,若返回信息为0，则报错
	 * @param suapCustInfoModel
	 * @return
	 */
	@CosttimeAnnotation(title = "updateCustInfo")
	public int update(SuapCustInfoModel suapCustInfoModel) {
		int row = 0;
		try {
			row = dao.update(suapCustInfoModel);
		} catch (Exception e) {
			LOGGER.error("update CustInfo fail: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.UPDCSTINFERROR, "02",e.getMessage().toString());
		}
		if(row == 0) {
			LOGGER.error("update CustInfo fail: no message has updated!");
			throw new CommonRuntimeException(Errorcode.UPDCSTINFFAILD);
		}
		
		return row;
	}



	
	
	
	
	
	
	
	
	
}
