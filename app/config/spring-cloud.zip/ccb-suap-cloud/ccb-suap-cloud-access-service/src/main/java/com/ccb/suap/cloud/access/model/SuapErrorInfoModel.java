package com.ccb.suap.cloud.access.model;

import java.io.Serializable;

public class SuapErrorInfoModel implements Serializable{
	
	private static final long serialVersionUID = -7945235149351006731L;
	
	private String errorcode;			//错误代码
	private String errortype;			//错误类型
	private String errormsg;			//错误信息
	private String isconv;				//是否转译错误信息
	
	public String getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	public String getErrortype() {
		return errortype;
	}
	public void setErrortype(String errortype) {
		this.errortype = errortype;
	}
	public String getErrormsg() {
		return errormsg;
	}
	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}
	public String getIsconv() {
		return isconv;
	}
	public void setIsconv(String isconv) {
		this.isconv = isconv;
	}
	
	@Override
	public String toString() {
		return "SuapErrorinfo [errorcode=" + errorcode + ", errortype=" + errortype + ", errormsg=" + errormsg
				+ ", isconv=" + isconv + "]";
	}
	
	
	
	  
	
}
