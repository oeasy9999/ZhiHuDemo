package com.ccb.suap.outbound.ccvea.vo;

public class GatewayRequestMsg {

	private String sys_code;
	private String app_name;
	private String mp_code;
	private String sec_version;
	private String groupid;
	private String traceId;
	private String tx_code;
	private String ccb_param;
	
	public String getSys_code() {
		return sys_code;
	}
	public void setSys_code(String sys_code) {
		this.sys_code = sys_code;
	}
	public String getApp_name() {
		return app_name;
	}
	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}
	public String getMp_code() {
		return mp_code;
	}
	public void setMp_code(String mp_code) {
		this.mp_code = mp_code;
	}
	public String getSec_version() {
		return sec_version;
	}
	public void setSec_version(String sec_version) {
		this.sec_version = sec_version;
	}
	public String getGroupid() {
		return groupid;
	}
	public void setGroupid(String groupid) {
		this.groupid = groupid;
	}
	public String getTraceId() {
		return traceId;
	}
	public void setTraceId(String traceId) {
		this.traceId = traceId;
	}
	public String getTx_code() {
		return tx_code;
	}
	public void setTx_code(String tx_code) {
		this.tx_code = tx_code;
	}
	public String getCcb_param() {
		return ccb_param;
	}
	public void setCcb_param(String ccb_param) {
		this.ccb_param = ccb_param;
	}
	
	@Override
	public String toString() {
		int ccb_param_length=0;
		if(ccb_param!=null)
		{
			ccb_param_length=ccb_param.length();
		}
		return "MyRequestMsg [sys_code=" + sys_code + ", app_name=" + app_name + ", mp_code=" + mp_code
				+ ", sec_version=" + sec_version + ", ccb_param_length=" + ccb_param_length + "]";
	}

	
}
