package com.ccb.suap.cloud.access.beans;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1010ServiceInVo;
import com.ccb.suap.cloud.access.model.SuapCustBlackListModel;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustWhiteListModel;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.service.GPUMPService;
import com.ccb.suap.cloud.access.service.INRECBeansService;
import com.ccb.suap.cloud.access.service.RedisService;
import com.ccb.suap.cloud.access.service.SuapCustBlackListService;
import com.ccb.suap.cloud.access.service.SuapCustDeviceInfoService;
import com.ccb.suap.cloud.access.service.SuapCustInfoService;
import com.ccb.suap.cloud.access.service.SuapCustWhiteListService;
import com.ccb.suap.cloud.access.service.utils.PhotoUtil;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC1001ServiceInVo;
import com.ccb.suap.cloud.access.vo.INREC1001ServiceOutVo;
import com.ccb.suap.cloud.access.vo.INRECCustomerElements;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam1001;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

/**
 * 	人脸1:N采集
 * @author 86156
 *
 */
@Controller("INREC1001")
public class INREC1001_Bean extends INRECBean{
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC1001_Bean.class);
	
	@Autowired
	private SuapCustInfoService suapCustInfoService;
	
	@Autowired
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	
	@Autowired
	private GPUMPService gpumpService;
	
	@Autowired
	private INRECBeansService inrecBeansService;
	
	@Autowired
	private SuapCustBlackListService suapBlackNameListService;
	
	@Autowired
	private SuapCustWhiteListService suapWhiteNameListService;
	
	@Autowired
	private RedisService redisService;
	
//	private SuapCustInfoService suapCustInfoService = InrecDaoFactory.getDaoManager().getSuapCustInfoService();
//	private SuapCustDeviceInfoService suapCustDeviceInfoService = InrecDaoFactory.getDaoManager().getSuapCustDeviceInfoService();
//	private GPUMPService gpumpService = InrecDaoFactory.getDaoManager().getGPUMPService();
//	private INRECBeansService inrecBeansService = InrecDaoFactory.getDaoManager().getINRECBeansService();
//	private SuapCustBlackListService suapBlackNameListService = InrecDaoFactory.getDaoManager().getSuapBlackNameListService();
//	private SuapCustWhiteListService suapWhiteNameListService = InrecDaoFactory.getDaoManager().getSuapWhiteNameListService();
//	private RedisService redisService = InrecDaoFactory.getDaoManager().getRedisService();
	
	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg,TxRequestMsg reqMsg,TraceLog traceLog) throws Exception{
		LOGGER.debug("\n\n------------------调用INREC1001服务------------------");
		
		setFaceLogByReqEntity(reqMsg);
		
		//实例化响应报文entity域，默认未经过人脸核查
		INREC1001ServiceOutVo outVo = new INREC1001ServiceOutVo();
		rspMsg.getTx_body().setEntity(outVo);
		outVo.setIdverify("2");
		
		//实体域参数校验
		LOGGER.debug("check requestEntity: "+reqMsg.getTx_body().getEntity());
		checkParaByServerName(rspMsg, reqMsg);
		
		//流程参数，只存储部分参数，详情参考注释
		ServiceInVoParam1001 param = new ServiceInVoParam1001();
		setParam(reqMsg, param);
		if("2".equals(param.getFaceConfig().getIdverify())) {
			outVo.setIdverify("3");
			param.getCustInfo_reqMsg().setIdverify("2");
			param.getCustDeviceInfo_reqMsg().setIdverify("2");
		}
		
		String id_no = param.getInVo().getId_no();
		String channelid = reqMsg.getTx_body().getCom1().getSysChannelID();
		//获取黑名单策略参数
		String blackNameConfig = SuapSysParaUtil.getStrPara("BLACKNAMECONFIG", "0");
		if("1".equals(blackNameConfig)){
			SuapCustBlackListModel suapBlackNameListModel = suapBlackNameListService.selectOne(id_no, channelid);	
			if(suapBlackNameListModel != null){
				LOGGER.error("cust belong to blackList ");
				throw new CommonRuntimeException(Errorcode.SECBLANAMELSTExit, "01","id_no in blackList, id_no=: "+id_no + ", channelid = " + channelid);
			}
		}
		
		//获取白名单策略参数
		String whiteNameConfig = SuapSysParaUtil.getStrPara("WHITENAMECONFIG", "0");
		if("1".equals(whiteNameConfig)){
			SuapCustWhiteListModel suapWhiteNameListModel = suapWhiteNameListService.selectOne(id_no, channelid);	
			if(suapWhiteNameListModel == null){
				LOGGER.error("cust not belong to WhiteList ");
				throw new CommonRuntimeException(Errorcode.SECWHTNAMELSTNULL, "01", "id_no not exists in WhiteList, id_no = "+id_no + ", channelid = " + channelid);
			}
		}
		
		//保存请求图片
		String path = PhotoUtil.getPath(ServiceParaUtil.getBasePthBySyspara("FACEPICPATH", channelid, "faceRegImage"), param.getCustNo()+reqMsg.getTx_header().getSys_evt_trace_id() + ".jpg");
		SuapFaceLogModel faceLog = FaceLogThreadLocal.get();
		PhotoUtil.savePhotoWithTime(param.getInVo().getFace_image(), path, "saveTracePhoto");
		param.getCustInfo_reqMsg().setScenephoto_path(path);
		faceLog.setFacefilepath(path);
		LOGGER.debug("request photo path: "+path);
		
		//发往GMPMP1010进行图片质量审核
		checkPhotoByGMPMP1010(reqMsg);
		
		//新增/更新客户渠道注册信息表，发往GPUMP1001注册，这两流程须保持原子性
		inrecBeansService.insertCustDeviceAndSendGPUMP1001(rspMsg, reqMsg, param);
		
		//存储redis信息
		saveRedis(param);
		
		LOGGER.debug("success: "+rspMsg);
		return rspMsg;
	}
	
	
	/**
	 *	 设置流程参数
	 * @param reqMsg
	 */
	private void setParam(TxRequestMsg reqMsg, ServiceInVoParam1001 param) {
		//人脸参数配置表
		SuapFaceConfigModel faceConfig = SuapFaceConfigUtil.getFaceConfig(reqMsg);
		param.setFaceConfig(faceConfig);
		LOGGER.debug("faceConfig: "+faceConfig);
		
		//请求报文实体域
		INREC1001ServiceInVo inVo = (INREC1001ServiceInVo) reqMsg.getTx_body().getEntity();
		param.setInVo(inVo);
		
		//设置渠道客户号
		if("1".equals(faceConfig.getLocationindex()))
			param.setCustNo(inVo.getId_type() + inVo.getId_no());
		if("2".equals(faceConfig.getLocationindex()))
			param.setCustNo(inVo.getChannel_custno());
		
		//数据库中该客户的信息，不存在则为null
		SuapCustInfoModel custInfo_database = setCustInfo_Database(inVo);
		param.setCustInfo_database(custInfo_database);
		
		//根据请求报文封装客户信息
		SuapCustInfoModel custInfo_reqMsg = setSuapCustInfoModel(reqMsg,faceConfig);
		param.setCustInfo_reqMsg(custInfo_reqMsg);
		
		//填充客户信息
		ServiceParaUtil.fillCustInfo(custInfo_database, custInfo_reqMsg);
		
		//根据请求报文封装客户渠道注册信息
		SuapCustDeviceInfoModel custDeviceInfo_reqMsg = setSuapCustDeviceInfoModel(reqMsg);
		custDeviceInfo_reqMsg.setChannel_cstno(param.getCustNo());
		param.setCustDeviceInfo_reqMsg(custDeviceInfo_reqMsg);
		
		// 查询客户渠道注册信息是否已存在
		SuapCustDeviceInfoModel custDeviceInfo_database = setCustDeviceInfo_Database(custDeviceInfo_reqMsg);
		param.setCustDeviceInfo_database(custDeviceInfo_database);
		
		//填充渠道注册信息
		ServiceParaUtil.fillCustDeviceInfo(custDeviceInfo_database, custDeviceInfo_reqMsg);
		
	}


	/**
	 *	查询数据库中该客户信息
	 * @param entity
	 * @return
	 */
	private SuapCustInfoModel setCustInfo_Database(INREC1001ServiceInVo entity) {
		String idtype = entity.getId_type();
		String idno = entity.getId_no();
		String num = String.valueOf(StringUtils.getBiolInfoTableID(idtype+idno));
		
//		String json = redisService.get(idtype + "_" + idno);
//		if(StringUtils.isNotBlank(json))
//			return JSONObject.toJavaObject(JSONObject.parseObject(json), SuapCustInfoModel.class);
		
		LOGGER.debug("find custInfo: "+"{num: "+num+",id_tpye: "+idtype+",id_no: "+idno+"}");
		SuapCustInfoModel selectCustInfoModel = suapCustInfoService.selectWithRedis(num, idtype, idno);
		LOGGER.debug("find custInfo in database: "+selectCustInfoModel);
		
		return selectCustInfoModel;
	}

	
	/**
	 * 	把请求信息封装成客户渠道注册信息表
	 * @param txRequestMsg
	 * @return
	 */
	private SuapCustDeviceInfoModel setSuapCustDeviceInfoModel(TxRequestMsg txRequestMsg) {
		INREC1001ServiceInVo entity= (INREC1001ServiceInVo) txRequestMsg.getTx_body().getEntity();
		SuapCustDeviceInfoModel suapCustDeviceInfoModel = new SuapCustDeviceInfoModel();
		
		int num = StringUtils.getBiolInfoTableID(entity.getId_type()+entity.getId_no());
		suapCustDeviceInfoModel.setNum(String.valueOf(num));
		
		suapCustDeviceInfoModel.setIdtype(entity.getId_type());
		suapCustDeviceInfoModel.setIdnumber(entity.getId_no());
		suapCustDeviceInfoModel.setChannelid(txRequestMsg.getTx_body().getCom1().getSysChannelID());
		suapCustDeviceInfoModel.setCustname(entity.getName());
		suapCustDeviceInfoModel.setCellphome(entity.getMobile_no());
		suapCustDeviceInfoModel.setTitile(entity.getTitle());
		suapCustDeviceInfoModel.setIsvip(entity.getIs_vip());
		suapCustDeviceInfoModel.setCardno(entity.getChannel_cardno());
		suapCustDeviceInfoModel.setSiteno(entity.getDot_num());
		suapCustDeviceInfoModel.setLocation(entity.getLocation());
		suapCustDeviceInfoModel.setDevicetype(entity.getDevice_type());
		suapCustDeviceInfoModel.setDeviceauthcode(entity.getDevice_authcode());
		suapCustDeviceInfoModel.setDevicecode(entity.getDevice_code());
		suapCustDeviceInfoModel.setDeviceversion(entity.getDevice_version());
		suapCustDeviceInfoModel.setUpdatetime(new Date());
		suapCustDeviceInfoModel.setIsvalid("0");
		
		return suapCustDeviceInfoModel;
	}
	
	
	/**
	 *	 查询数据库中该客户渠道注册信息
	 * @param suapCustDeviceInfoModel
	 * @return
	 */
	private SuapCustDeviceInfoModel setCustDeviceInfo_Database(SuapCustDeviceInfoModel suapCustDeviceInfoModel) {
		String idtype = suapCustDeviceInfoModel.getIdtype();
		String idno = suapCustDeviceInfoModel.getIdnumber();
		String channelid = suapCustDeviceInfoModel.getChannelid();
		
//		String json = redisService.get(idtype + "_" + idno + "_" + channelid);
//		if(StringUtils.isNotBlank(json))
//			return JSONObject.toJavaObject(JSONObject.parseObject(json), SuapCustDeviceInfoModel.class);
		
		LOGGER.debug("select custDevInfo: " + "{num: " + suapCustDeviceInfoModel.getNum() + ", id_type: " + idtype + ", id_no: " + idno + ", channelId: " + channelid);
		SuapCustDeviceInfoModel selectSuapCustDeviceInfoModel = suapCustDeviceInfoService.selectWithRedis(suapCustDeviceInfoModel.getNum(), idtype, idno, channelid);
		return selectSuapCustDeviceInfoModel;
	}
	
	
	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		INREC1001ServiceInVo entity = (INREC1001ServiceInVo)reqMsg.getTx_body().getEntity();
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(reqMsg);
		
		String id_type = entity.getId_type();
		String id_no = entity.getId_no();
		String channel_custno = entity.getChannel_custno();
		String name = entity.getName();
		String face_image = entity.getFace_image();
		
		if(org.apache.commons.lang.StringUtils.isBlank(id_type)) {
			LOGGER.error("idtype is null : "+id_type);
			throw new CommonRuntimeException(Errorcode.ID_TYPENOTNULL);
		}
		if(org.apache.commons.lang.StringUtils.isBlank(id_no)) {
			LOGGER.error("id_no is null : "+id_no);
			throw new CommonRuntimeException(Errorcode.ID_NUMBNOTNULL);
		}
		if(locationIndex.equals("2") && (org.apache.commons.lang.StringUtils.isBlank(channel_custno))) {
			LOGGER.error("channel_custno is null : "+channel_custno);
			throw new CommonRuntimeException(Errorcode.CHANLCSTNONULL);
		}
		if(org.apache.commons.lang.StringUtils.isBlank(name)) {
			LOGGER.error("name is null : "+name);
			throw new CommonRuntimeException(Errorcode.CSTNAMENOTNULL);
		}
		if(org.apache.commons.lang.StringUtils.isBlank(face_image)) {
			LOGGER.error("face_image is null : "+face_image);
			throw new CommonRuntimeException(Errorcode.FACEIMGNOTNULL);
		}
		
		//从参数表获取图片大小限制，并对图片进行校验
		String sizeStr = SuapSysParaUtil.getStrPara("FACEPICSIZE", "0");
		if(org.apache.commons.lang.StringUtils.isBlank(sizeStr)) {
			LOGGER.error("FACEPICSIZE in SysPara is null : "+sizeStr);
			throw new CommonRuntimeException(Errorcode.PHSIZENOTFOUND);
		}
		
		int size = 0;
		try {
			size = Integer.parseInt(sizeStr);
		} catch (Exception e) {
			LOGGER.error("FACEPICSIZE in SysPara error: "+sizeStr);
			throw new CommonRuntimeException(Errorcode.PARAETYPEERROR,"01", "系统参数表: FACEPICSIZE参数格式错误");
		}
		
		boolean flag = PhotoUtil.judgeSizeByByte(face_image, size);
		if(!flag) {
			LOGGER.error("request photo size error: "+sizeStr);
			throw new CommonRuntimeException(Errorcode.PHOLARGEEERROR);
		}
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		SB.append("sendGPUMP1010(").append(sendGPUMP1010)
//		.append(")/saveTracePhoto(").append(saveTracePhoto)
//		.append(")/saveModelPhoto(").append(saveModelPhoto)
//		.append(")/selectCustInfo(").append(selectCustInfo);
//		
//		if(sendCCVEA1004 != 0) {
//			SB.append(")/sendCCVEA1004(").append(sendCCVEA1004)
//			.append(")/insertCustInfo(").append(insertCustInfo)
//			.append(")/insertCustDevInfo(").append(insertCustDevInfo);
//		}
//		if(sendCCVEA1004 == 0) {
//			SB.append(")/sendGPUMP1009(").append(sendGPUMP1009)
//			.append(")/updateCustInfo(").append(updateCustInfo)
//			.append(")/selectCustDevInfo(").append(selectCustDevInfo);
//			if(insertCustDevInfo != 0)
//				SB.append(")/insertCustDevInfo(").append(insertCustDevInfo);
//			if(updateCustDevInfo != 0)
//				SB.append(")/updateCustDevInfo(").append(updateCustDevInfo);
//		}
//		
//		SB.append(")/sendGPUMP1001(").append(sendGPUMP1001)
//		.append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	
	/**
	 * 添加日志信息
	 * @param reqMsg
	 */
	private void setFaceLogByReqEntity(TxRequestMsg reqMsg) {
		INREC1001ServiceInVo entity = (INREC1001ServiceInVo) reqMsg.getTx_body().getEntity();
		SuapFaceLogModel faceLog = FaceLogThreadLocal.get();
		faceLog.setBranchid(entity.getBranch_id());
		faceLog.setVendorcode(entity.getVender_code());
		faceLog.setIdtype(entity.getId_type());
		faceLog.setIdno(entity.getId_no());
		faceLog.setName(entity.getName());
		faceLog.setMobile(entity.getMobile_no());
		faceLog.setCustid(entity.getChannel_custno());
		
	}
	
	
	/**
	 * 发往GPUMP1010检查图片质量
	 * @param reqMsg
	 */
	private void checkPhotoByGMPMP1010(TxRequestMsg reqMsg) {
		TxRequestMsg gpump1010ReqMsg = getGPUMP1010ReqMsg(reqMsg);
		
		LOGGER.debug("send GPUMP1010 service: "+gpump1010ReqMsg);
		TxResponseMsg gpump1010Rsp = gpumpService.sendGPUMP1010(gpump1010ReqMsg);
		LOGGER.debug("return by GPUMP1010 service: "+gpump1010Rsp);
		
		if(!"000000000000".equals(gpump1010Rsp.getTx_header().getSys_resp_code())) {
			LOGGER.error("fail in gpump1010: "+gpump1010Rsp);
			throw new CommonRuntimeException(gpump1010Rsp);
		}
		
	}
	
	/**
	 * 封装GPUMP1010请求信息
	 * @param reqMsg
	 * @return
	 */
	private TxRequestMsg getGPUMP1010ReqMsg(TxRequestMsg reqMsg) {
		INREC1001ServiceInVo entity = (INREC1001ServiceInVo) reqMsg.getTx_body().getEntity();
		TxRequestMsg gpump1010RepMsg = ServiceParaUtil.parseGpuRequestMsg(reqMsg);
		
		GPUMP1010ServiceInVo gpump1010ReqEntity = new GPUMP1010ServiceInVo();
		gpump1010ReqEntity.setFace_image(entity.getFace_image());
		
		gpump1010RepMsg.getTx_header().setSys_tx_code("GPUMP1010");
		gpump1010RepMsg.getTx_body().setEntity(gpump1010ReqEntity);
		
		return gpump1010RepMsg;
	}
	
	
	/**
	 * 	把请求信息封装成客户信息
	 * @param entity
	 * @return
	 */
	private SuapCustInfoModel setSuapCustInfoModel(TxRequestMsg reqMsg, SuapFaceConfigModel faceConfig) {
		INREC1001ServiceInVo entity = (INREC1001ServiceInVo) reqMsg.getTx_body().getEntity();
		SuapCustInfoModel suapCustInfoModel = new SuapCustInfoModel();
		
		int num = StringUtils.getBiolInfoTableID(entity.getId_type()+entity.getId_no());
		suapCustInfoModel.setNum(String.valueOf(num));
		
		suapCustInfoModel.setCcbcustno(entity.getCcb_custno());
		suapCustInfoModel.setCustname(entity.getName());
		suapCustInfoModel.setIdtype(entity.getId_type());
		suapCustInfoModel.setIdnumber(entity.getId_no());
		suapCustInfoModel.setBranchid(entity.getBranch_id());
		suapCustInfoModel.setCellphome(entity.getMobile_no());
		suapCustInfoModel.setCreatetime(new Date());
		if("2".equals(faceConfig.getLeveltype()))
			suapCustInfoModel.setScenephoto_level(faceConfig.getLevelgrade());
		suapCustInfoModel.setScenephoto_date(new Date());
		suapCustInfoModel.setUpdatetime(new Date());
		
		return suapCustInfoModel;
	}
	
	
	/**
	 * Redis缓存客户三要素
	 * @param entity
	 */
	private void saveRedis(ServiceInVoParam1001 param) {
		
		//1.以手机号为key缓存客户三要素
		if(!org.apache.commons.lang.StringUtils.isBlank(param.getInVo().getMobile_no()))
			saveCustElement(param);
		
//		//2.以idtype_idno为key缓存客户信息
//		saveCustInfo(param.getCustInfo_reqMsg());
//		
//		//3.以idtype_idno_channelid为key缓存渠道注册信息
//		saveCustDeviceInfo(param.getCustDcviceInfo_reqMsg());
		
	}


	/**
	 * 	以手机号为key缓存客户三要素
	 * @param param
	 */
	private void saveCustElement(ServiceInVoParam1001 param) {
		INREC1001ServiceInVo inVo = param.getInVo();
		SuapCustInfoModel custInfo_database = param.getCustInfo_database();
		
		//客户信息已存在时，数据库中手机非空且与请求信息中不匹配时，删除旧数据
		if(custInfo_database !=  null) {
			if(org.apache.commons.lang.StringUtils.isNotEmpty(custInfo_database.getCellphome()) && !inVo.getMobile_no().equals(custInfo_database.getCellphome())) {
				LOGGER.debug("the mobile_no has change in request message: {entity.getMobile_no:"+inVo.getMobile_no()+",custInfoModel.getCellPhone: "+custInfo_database.getCellphome()+"}");
				deleteRedisMsg(custInfo_database);
			}
		}
		
		//redis保存客户三要素
		addRedisMsg(inVo);
	}


//	/**
//	 * 	以idtype_idno为key缓存客户信息
//	 * @param custInfo_reqMsg
//	 */
//	private void saveCustInfo(SuapCustInfoModel custInfo_reqMsg) {
//		String key = custInfo_reqMsg.getIdtype() + "_" + custInfo_reqMsg.getIdnumber();
//		
//		redisService.set(key, JSONObject.toJSONString(custInfo_reqMsg));
//		
//	}
//
//
//	/**
//	 * 	以idtype_idno_channelid为key缓存渠道注册信息
//	 * @param custDcviceInfo_reqMsg
//	 */
//	private void saveCustDeviceInfo(SuapCustDeviceInfoModel custDcviceInfo_reqMsg) {
//		String key = custDcviceInfo_reqMsg.getIdtype() + "_" + custDcviceInfo_reqMsg.getIdnumber() + "_" +custDcviceInfo_reqMsg.getChannelid();
//		
//		redisService.set(key, JSONObject.toJSONString(custDcviceInfo_reqMsg));
//		
//	}


	/**
	 * 	移除redis中变更的信息
	 * @param custInfoModel
	 */
	private void deleteRedisMsg(SuapCustInfoModel custInfoModel) {
		String custElementsJson = redisService.getNotNull(custInfoModel.getCellphome());
		LOGGER.debug("the custInfo is waited to delete in redis: "+custElementsJson);
		List<INRECCustomerElements> custElements = JSONObject.parseArray(custElementsJson, INRECCustomerElements.class);
		for (int i = 0; i < custElements.size(); i++) {
			if(custElements.get(i).getId_no().equals(custInfoModel.getIdnumber())) {
				custElements.remove(i);
				break;
			}
		}
		
		if(custElements.size() == 0) {
			redisService.delete(custInfoModel.getCellphome());
		}else {
			redisService.set(custInfoModel.getCellphome(), JSONObject.toJSONString(custElements));
		}
		
		
	}
	
	
	/**
	 * redis插入客户三要素
	 * @param entity
	 */
	private void addRedisMsg(INREC1001ServiceInVo entity) {
		String inrecCustElements = redisService.get(entity.getMobile_no());
		
		INRECCustomerElements reqCustElement = new INRECCustomerElements();
		reqCustElement.setId_type(entity.getId_type());
		reqCustElement.setId_no(entity.getId_no());
		reqCustElement.setName(entity.getName());
		
		if(inrecCustElements == null) {
			List<INRECCustomerElements> list = new ArrayList<>();
			list.add(reqCustElement);
			redisService.set(entity.getMobile_no(), JSONObject.toJSONString(list));
		}else {
			List<INRECCustomerElements> list = JSONObject.parseArray(inrecCustElements, INRECCustomerElements.class);
			boolean flag = true;
			for (INRECCustomerElements inrecCustElement : list) {
				if(inrecCustElement.getId_no().equals(entity.getId_no())) {
					flag = false;
					break;
				}
			}
			if(flag) {
				list.add(reqCustElement);
				redisService.set(entity.getMobile_no(), JSONObject.toJSONString(list));
			}
		}
		
	}


	
	
	
}
