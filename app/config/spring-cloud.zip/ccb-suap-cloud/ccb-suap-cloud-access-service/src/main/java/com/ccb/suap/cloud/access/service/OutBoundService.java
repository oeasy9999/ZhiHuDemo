package com.ccb.suap.cloud.access.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.annotation.CosttimeAnnotation;
import com.ccb.suap.cloud.access.annotation.TraceLogAnnotation;
import com.ccb.suap.cloud.access.client.OutBoundClient;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.service.utils.JSONObjectUtil;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1001ServiceOutVo;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1002ServiceOutVo;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1003ServiceOutVo;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1004ServiceOutVo;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1005ServiceOutVo;
import com.ccb.suap.outbound.ccvea.vo.SafeOutboundInVo;
import com.ccb.suap.outbound.ccvea.vo.SafeOutboundOutVo;
import com.ccb.suap.util.log.TraceLog;

@Service
public class OutBoundService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Autowired
	private OutBoundClient outbound;
	
	/**
	 * 	发送人行高清照(CCVEA1001)请求
	 * @param ccvea1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation
	@TraceLogAnnotation("CCVEA1001")
	public TxResponseMsg sendCCVEA1001(TxRequestMsg ccvea1001ReqMsg) {
		JSONObject ccvea1001RspJson = null;
		try {
			ccvea1001RspJson = outbound.CCVEAServer1001(ccvea1001ReqMsg);
		} catch (Exception e) {
			LOGGER.error("send CCVEA1001 error",e);
			throw new CommonRuntimeException(Errorcode.SENCC1001ERROR, "02",e.getMessage());
		}
		
		TxResponseMsg ccvea1001Rsp = JSONObjectUtil.toRspMsg(ccvea1001RspJson, CCVEA1001ServiceOutVo.class);
		
		return ccvea1001Rsp;
	}
	
	@CosttimeAnnotation
	public TxResponseMsg sendCCVEA1001(TxRequestMsg ccvea1001ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("CCVEA1001");
		traceLog.setRequestJsonString_CCVEA1001(JSONObject.toJSONString(ccvea1001ReqMsg));
		JSONObject ccvea1001RspJson = null;
		try {
			ccvea1001RspJson = outbound.CCVEAServer1001(ccvea1001ReqMsg);
		} catch (Exception e) {
			LOGGER.error("send CCVEA1001 error",e);
			throw new CommonRuntimeException(Errorcode.SENCC1001ERROR, "02",e.getMessage());
		}
		
		TxResponseMsg ccvea1001Rsp = JSONObjectUtil.toRspMsg(ccvea1001RspJson, CCVEA1001ServiceOutVo.class);
		traceLog.setResponseJsonString_CCVEA1001(JSONObject.toJSONString(ccvea1001Rsp));
		return ccvea1001Rsp;
	}
	
	
	/**
	 * 发送成开缓存照(CCVEA1002)请求
	 * @param ccvea1002ReqMsg
	 * @return
	 */
	@CosttimeAnnotation
	@TraceLogAnnotation("CCVEA1002")
	public TxResponseMsg sendCCVEA1002(TxRequestMsg ccvea1002ReqMsg) {
		JSONObject ccvea1002RspJson = null;
		try {
			ccvea1002RspJson = outbound.CCVEAServer1002(ccvea1002ReqMsg);
		} catch (Exception e) {
			LOGGER.error("send CCVEA1002 error",e);
			throw new CommonRuntimeException(Errorcode.SENCC1002ERROR, "02",e.getMessage());
		}
		
		TxResponseMsg ccvea1002Rsp = JSONObjectUtil.toRspMsg(ccvea1002RspJson, CCVEA1002ServiceOutVo.class);
		
		return ccvea1002Rsp;
	}
	
	@CosttimeAnnotation
	public TxResponseMsg sendCCVEA1002(TxRequestMsg ccvea1002ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("CCVEA1002");
		traceLog.setRequestJsonString_CCVEA1002(JSONObject.toJSONString(ccvea1002ReqMsg));
		JSONObject ccvea1002RspJson = null;
		try {
			ccvea1002RspJson = outbound.CCVEAServer1002(ccvea1002ReqMsg);
		} catch (Exception e) {
			LOGGER.error("send CCVEA1002 error",e);
			throw new CommonRuntimeException(Errorcode.SENCC1002ERROR, "02",e.getMessage());
		}
		
		TxResponseMsg ccvea1002Rsp = JSONObjectUtil.toRspMsg(ccvea1002RspJson, CCVEA1002ServiceOutVo.class);
		traceLog.setResponseJsonString_CCVEA1002(JSONObject.toJSONString(ccvea1002Rsp));
		return ccvea1002Rsp;
	}
	
	
	/**
	 * 发送公安一所联网核查(CCVEA1003)请求
	 * @param ccvea1003ReqMsg
	 * @return
	 */
	@CosttimeAnnotation
	@TraceLogAnnotation("CCVEA1003")
	public TxResponseMsg sendCCVEA1003(TxRequestMsg ccvea1003ReqMsg) {
		JSONObject ccvea1003RspJson = null;
		try {
			ccvea1003RspJson = outbound.CCVEAServer1003(ccvea1003ReqMsg);
		} catch (Exception e) {
			LOGGER.error("send CCVEA1003 error",e);
			throw new CommonRuntimeException(Errorcode.SENCC1003ERROR, "02",e.getMessage());
		}
		
		TxResponseMsg ccvea1003Rsp = JSONObjectUtil.toRspMsg(ccvea1003RspJson, CCVEA1003ServiceOutVo.class);
		
		return ccvea1003Rsp;
	}
	
	@CosttimeAnnotation
	public TxResponseMsg sendCCVEA1003(TxRequestMsg ccvea1003ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("CCVEA1003");
		traceLog.setRequestJsonString_CCVEA1003(JSONObject.toJSONString(ccvea1003ReqMsg));
		JSONObject ccvea1003RspJson = null;
		try {
			ccvea1003RspJson = outbound.CCVEAServer1003(ccvea1003ReqMsg);
		} catch (Exception e) {
			LOGGER.error("send CCVEA1003 error",e);
			throw new CommonRuntimeException(Errorcode.SENCC1003ERROR, "02",e.getMessage());
		}
		
		TxResponseMsg ccvea1003Rsp = JSONObjectUtil.toRspMsg(ccvea1003RspJson, CCVEA1003ServiceOutVo.class);
		traceLog.setResponseJsonString_CCVEA1003(JSONObject.toJSONString(ccvea1003Rsp));
		return ccvea1003Rsp;
	}
	
	/**
	 * 发送私有云总库注册(CCVEA1004)请求
	 * @param ccvea1003ReqMsg
	 * @return
	 */
	@CosttimeAnnotation
	@TraceLogAnnotation("CCVEA1004")
	public TxResponseMsg sendCCVEA1004(TxRequestMsg ccvea1004ReqMsg) {
		
		JSONObject ccvea1004RspJson = null;
		try {
			ccvea1004RspJson = outbound.CCVEAServer1004(ccvea1004ReqMsg);
		} catch (Exception e) {
			LOGGER.error("send CCVEA1004 error",e);
			throw new CommonRuntimeException(Errorcode.SENCC1004ERROR, "02",e.getMessage());
		}
		
		TxResponseMsg ccvea1004Rsp = JSONObjectUtil.toRspMsg(ccvea1004RspJson, CCVEA1004ServiceOutVo.class);
		
		return ccvea1004Rsp;
	}
	
	@CosttimeAnnotation
	public TxResponseMsg sendCCVEA1004(TxRequestMsg ccvea1004ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("CCVEA1004");
		traceLog.setRequestJsonString_CCVEA1004(JSONObject.toJSONString(ccvea1004ReqMsg));
		JSONObject ccvea1004RspJson = null;
		try {
			ccvea1004RspJson = outbound.CCVEAServer1004(ccvea1004ReqMsg);
		} catch (Exception e) {
			LOGGER.error("send CCVEA1004 error",e);
			throw new CommonRuntimeException(Errorcode.SENCC1004ERROR, "02",e.getMessage());
		}
		
		TxResponseMsg ccvea1004Rsp = JSONObjectUtil.toRspMsg(ccvea1004RspJson, CCVEA1004ServiceOutVo.class);
		traceLog.setResponseJsonString_CCVEA1004(JSONObject.toJSONString(ccvea1004Rsp));
		return ccvea1004Rsp;
	}
	
	
	/**
	 * 	发送流媒体识别(CCVEA1005)请求
	 * @param ccvea1005ReqMsg
	 * @return
	 */
	@CosttimeAnnotation
	@TraceLogAnnotation("CCVEA1005")
	public TxResponseMsg sendCCVEA1005(TxRequestMsg ccvea1005ReqMsg) {
		JSONObject ccvea1005RspJson = null;
		try {
			ccvea1005RspJson = outbound.CCVEAServer1005(ccvea1005ReqMsg);
		} catch (Exception e) {
			LOGGER.error("send CCVEA1005 error",e);
			throw new CommonRuntimeException(Errorcode.SENCC1005ERROR, "02",e.getMessage());
		}
		
		TxResponseMsg ccvea1005Rsp = JSONObjectUtil.toRspMsg(ccvea1005RspJson, CCVEA1005ServiceOutVo.class);
		
		return ccvea1005Rsp;
	}
	
	@CosttimeAnnotation
	public TxResponseMsg sendCCVEA1005(TxRequestMsg ccvea1005ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("CCVEA1005");
		traceLog.setRequestJsonString_CCVEA1005(JSONObject.toJSONString(ccvea1005ReqMsg));
		JSONObject ccvea1005RspJson = null;
		try {
			ccvea1005RspJson = outbound.CCVEAServer1005(ccvea1005ReqMsg);
		} catch (Exception e) {
			LOGGER.error("send CCVEA1005 error",e);
			throw new CommonRuntimeException(Errorcode.SENCC1005ERROR, "02",e.getMessage());
		}
		
		TxResponseMsg ccvea1005Rsp = JSONObjectUtil.toRspMsg(ccvea1005RspJson, CCVEA1005ServiceOutVo.class);
		traceLog.setResponseJsonString_CCVEA1005(JSONObject.toJSONString(ccvea1005Rsp));
		return ccvea1005Rsp;
	}
	
	
	/**
	 * 	发送到外呼透传(明文进出)
	 * @param safeOutboundInVo
	 * @return
	 */
	@CosttimeAnnotation
	@TraceLogAnnotation("SENDSAFEOUTBOUND")
	public SafeOutboundOutVo sendSafeOutbound(SafeOutboundInVo safeOutboundInVo) {
		JSONObject safeOutboundOutVo_json = null;
		try {
			safeOutboundOutVo_json = outbound.SafeOutbound(safeOutboundInVo);
		} catch (Exception e) {
			LOGGER.error("send SafeOutbound error",e);
			throw new CommonRuntimeException(Errorcode.SENSAFEBDERROR, "02",e.getMessage());
		}
		
		if(safeOutboundOutVo_json == null)
			throw new CommonRuntimeException(Errorcode.SENSAFEBDERROR, "02","SafeOutbound返回为空");
		
		SafeOutboundOutVo safeOutboundOutVo = JSONObject.toJavaObject(safeOutboundOutVo_json, SafeOutboundOutVo.class);
		
		return safeOutboundOutVo;
	}
	
	
	
	
	
}
