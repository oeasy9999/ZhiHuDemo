package com.ccb.suap.outbound.ccvea.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class CCVEA1002ServiceOutVo extends TxResponseMsgEntity{
	
	private String Cst_Nm;							//姓名
	private String Crdt_No;							//身份证号码
	private String Ftr_Col_Tm;						//发送时间
	private String CrdTp_Cd;						//证件状态
	private String Ftr_Col_TmnlInf;					//补发照片标志
	private String Aflt_Inf_Dsc;					//签发机关
	private String Mftr_Idr_CD;						//住址
	private String Ctf_Mnplt_Mode_ID;				//性别
	private String Ext_Stm_Safe_ModDsc;				//民族
	private String For_Ext_Stm_Svc_Tm;				//有效期-起始
	private String AlrdAhr_ID;						//有效期-结束
	private String base64_Ecrp_Txn_Inf;				//照片
	private String Smlr_Dgr_Cmnt;					//出生日期
	private String Eqmt_Modl_VNo;					//照片文件名
	private String Rsrv_1_Inf_Dsc;					//备注AWOKEINFO
	private String Rsrv_2_Inf_Dsc;					//备注COMMENT
	
	public String getCst_Nm() {
		return Cst_Nm;
	}
	public void setCst_Nm(String cst_Nm) {
		Cst_Nm = cst_Nm;
	}
	public String getCrdt_No() {
		return Crdt_No;
	}
	public void setCrdt_No(String crdt_No) {
		Crdt_No = crdt_No;
	}
	public String getFtr_Col_Tm() {
		return Ftr_Col_Tm;
	}
	public void setFtr_Col_Tm(String ftr_Col_Tm) {
		Ftr_Col_Tm = ftr_Col_Tm;
	}
	public String getCrdTp_Cd() {
		return CrdTp_Cd;
	}
	public void setCrdTp_Cd(String crdTp_Cd) {
		CrdTp_Cd = crdTp_Cd;
	}
	public String getFtr_Col_TmnlInf() {
		return Ftr_Col_TmnlInf;
	}
	public void setFtr_Col_TmnlInf(String ftr_Col_TmnlInf) {
		Ftr_Col_TmnlInf = ftr_Col_TmnlInf;
	}
	public String getAflt_Inf_Dsc() {
		return Aflt_Inf_Dsc;
	}
	public void setAflt_Inf_Dsc(String aflt_Inf_Dsc) {
		Aflt_Inf_Dsc = aflt_Inf_Dsc;
	}
	public String getMftr_Idr_CD() {
		return Mftr_Idr_CD;
	}
	public void setMftr_Idr_CD(String mftr_Idr_CD) {
		Mftr_Idr_CD = mftr_Idr_CD;
	}
	public String getCtf_Mnplt_Mode_ID() {
		return Ctf_Mnplt_Mode_ID;
	}
	public void setCtf_Mnplt_Mode_ID(String ctf_Mnplt_Mode_ID) {
		Ctf_Mnplt_Mode_ID = ctf_Mnplt_Mode_ID;
	}
	public String getExt_Stm_Safe_ModDsc() {
		return Ext_Stm_Safe_ModDsc;
	}
	public void setExt_Stm_Safe_ModDsc(String ext_Stm_Safe_ModDsc) {
		Ext_Stm_Safe_ModDsc = ext_Stm_Safe_ModDsc;
	}
	public String getFor_Ext_Stm_Svc_Tm() {
		return For_Ext_Stm_Svc_Tm;
	}
	public void setFor_Ext_Stm_Svc_Tm(String for_Ext_Stm_Svc_Tm) {
		For_Ext_Stm_Svc_Tm = for_Ext_Stm_Svc_Tm;
	}
	public String getAlrdAhr_ID() {
		return AlrdAhr_ID;
	}
	public void setAlrdAhr_ID(String alrdAhr_ID) {
		AlrdAhr_ID = alrdAhr_ID;
	}
	public String getBase64_Ecrp_Txn_Inf() {
		return base64_Ecrp_Txn_Inf;
	}
	public void setBase64_Ecrp_Txn_Inf(String base64_Ecrp_Txn_Inf) {
		this.base64_Ecrp_Txn_Inf = base64_Ecrp_Txn_Inf;
	}
	public String getSmlr_Dgr_Cmnt() {
		return Smlr_Dgr_Cmnt;
	}
	public void setSmlr_Dgr_Cmnt(String smlr_Dgr_Cmnt) {
		Smlr_Dgr_Cmnt = smlr_Dgr_Cmnt;
	}
	public String getEqmt_Modl_VNo() {
		return Eqmt_Modl_VNo;
	}
	public void setEqmt_Modl_VNo(String eqmt_Modl_VNo) {
		Eqmt_Modl_VNo = eqmt_Modl_VNo;
	}
	public String getRsrv_1_Inf_Dsc() {
		return Rsrv_1_Inf_Dsc;
	}
	public void setRsrv_1_Inf_Dsc(String rsrv_1_Inf_Dsc) {
		Rsrv_1_Inf_Dsc = rsrv_1_Inf_Dsc;
	}
	public String getRsrv_2_Inf_Dsc() {
		return Rsrv_2_Inf_Dsc;
	}
	public void setRsrv_2_Inf_Dsc(String rsrv_2_Inf_Dsc) {
		Rsrv_2_Inf_Dsc = rsrv_2_Inf_Dsc;
	}
	
	@Override
	public String toString() {
		return "CCVEA1002ServiceOutVo [Cst_Nm=" + Cst_Nm + ", Crdt_No=" + Crdt_No + ", Ftr_Col_Tm=" + Ftr_Col_Tm
				+ ", CrdTp_Cd=" + CrdTp_Cd + ", Ftr_Col_TmnlInf=" + Ftr_Col_TmnlInf + ", Aflt_Inf_Dsc=" + Aflt_Inf_Dsc
				+ ", Mftr_Idr_CD=" + Mftr_Idr_CD + ", Ctf_Mnplt_Mode_ID=" + Ctf_Mnplt_Mode_ID + ", Ext_Stm_Safe_ModDsc="
				+ Ext_Stm_Safe_ModDsc + ", For_Ext_Stm_Svc_Tm=" + For_Ext_Stm_Svc_Tm + ", AlrdAhr_ID=" + AlrdAhr_ID
				+ ", base64_Ecrp_Txn_Inf=" + base64_Ecrp_Txn_Inf + ", Smlr_Dgr_Cmnt=" + Smlr_Dgr_Cmnt
				+ ", Eqmt_Modl_VNo=" + Eqmt_Modl_VNo + ", Rsrv_1_Inf_Dsc=" + Rsrv_1_Inf_Dsc + ", Rsrv_2_Inf_Dsc="
				+ Rsrv_2_Inf_Dsc + "]";
	}
	
	

	
	
	
	
	
	
}
