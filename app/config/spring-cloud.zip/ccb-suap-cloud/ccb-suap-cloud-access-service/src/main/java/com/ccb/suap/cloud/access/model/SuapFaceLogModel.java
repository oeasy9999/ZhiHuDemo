package com.ccb.suap.cloud.access.model;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Date;

public class SuapFaceLogModel implements Serializable{
	
	private static final long serialVersionUID = -960778854351106016L;
	
	private String num;						//分表标识
	private String logid;					//日志流水号
	private String channelid;				//渠道编号
	private String channeltxcode;			//渠道交易码
	private String branchid;				//分行号
	private String transflow;				//交易流水号
	private String idtype;					//证件类型
	private String idno;					//证件号码
	private String name;					//客户名称
	private String mobile;					//手机号码
	private String custid;					//渠道客户号
	private String similarity;				//相似度
	private String facefilepath;			//照片存储路径
	private Date recvtime;					//交易请求时间
	private Date resptime;					//交易响应时间
	private String txcode;					//交易码
	private String transret;				//交易结果
	private String hostname;				//主机名称
	private String serverip;				//服务IP
	private String username;				//用户名称
	private String errorcode;				//错误码
	private String vendorcode;				//厂商标识
	private String vendorerrcode;			//厂商错误码
	private String errormsg;				//错误信息
	private String recvtimemillis;			//交易请求时间
	private String resptimemillis;			//交易响应时间
	private String costtimeinfo;			//交易各环节耗时信息
	private String remarks;					//备注
	
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getLogid() {
		return logid;
	}
	public void setLogid(String logid) {
		this.logid = logid;
	}
	public String getChannelid() {
		return channelid;
	}
	public void setChannelid(String channelid) {
		this.channelid = channelid;
	}
	public String getChanneltxcode() {
		return channeltxcode;
	}
	public void setChanneltxcode(String channeltxcode) {
		this.channeltxcode = channeltxcode;
	}
	public String getBranchid() {
		return branchid;
	}
	public void setBranchid(String branchid) {
		this.branchid = branchid;
	}
	public String getTransflow() {
		return transflow;
	}
	public void setTransflow(String transflow) {
		this.transflow = transflow;
	}
	public String getIdtype() {
		return idtype;
	}
	public void setIdtype(String idtype) {
		this.idtype = idtype;
	}
	public String getIdno() {
		return idno;
	}
	public void setIdno(String idno) {
		this.idno = idno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getCustid() {
		return custid;
	}
	public void setCustid(String custid) {
		this.custid = custid;
	}
	public String getSimilarity() {
		return similarity;
	}
	public void setSimilarity(String similarity) {
		this.similarity = similarity;
	}
	public String getFacefilepath() {
		return facefilepath;
	}
	public void setFacefilepath(String facefilepath) {
		this.facefilepath = facefilepath;
	}
	public Date getRecvtime() {
		return recvtime;
	}
	public void setRecvtime(Date recvtime) {
		this.recvtime = recvtime;
	}
	public Date getResptime() {
		return resptime;
	}
	public void setResptime(Date resptime) {
		this.resptime = resptime;
	}
	public String getTxcode() {
		return txcode;
	}
	public void setTxcode(String txcode) {
		this.txcode = txcode;
	}
	public String getTransret() {
		return transret;
	}
	public void setTransret(String transret) {
		this.transret = transret;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getServerip() {
		return serverip;
	}
	public void setServerip(String serverip) {
		this.serverip = serverip;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	public String getVendorcode() {
		return vendorcode;
	}
	public void setVendorcode(String vendorcode) {
		this.vendorcode = vendorcode;
	}
	public String getVendorerrcode() {
		return vendorerrcode;
	}
	public void setVendorerrcode(String vendorerrcode) {
		this.vendorerrcode = vendorerrcode;
	}
	public String getErrormsg() {
		return errormsg;
	}
	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}
	public String getRecvtimemillis() {
		return recvtimemillis;
	}
	public void setRecvtimemillis(String recvtimemillis) {
		this.recvtimemillis = recvtimemillis;
	}
	public String getResptimemillis() {
		return resptimemillis;
	}
	public void setResptimemillis(String resptimemillis) {
		this.resptimemillis = resptimemillis;
	}
	public String getCosttimeinfo() {
		return costtimeinfo;
	}
	public void setCosttimeinfo(String costtimeinfo) {
		this.costtimeinfo = costtimeinfo;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	@Override
	public String toString() {
		return "SuapFaceLogModel [logid=" + logid + ", channelid=" + channelid + ", channeltxcode=" + channeltxcode
				+ ", branchid=" + branchid + ", transflow=" + transflow + ", idtype=" + idtype + ", idno=" + idno
				+ ", name=" + name + ", mobile=" + mobile + ", custid=" + custid + ", similarity=" + similarity
				+ ", facefilepath=" + facefilepath + ", recvtime=" + recvtime + ", resptime=" + resptime + ", txcode="
				+ txcode + ", transret=" + transret + ", hostname=" + hostname + ", serverip=" + serverip
				+ ", username=" + username + ", errorcode=" + errorcode + ", vendorcode=" + vendorcode
				+ ", vendorerrcode=" + vendorerrcode + ", errormsg=" + errormsg + ", recvtimemillis=" + recvtimemillis
				+ ", resptimemillis=" + resptimemillis + ", costtimeinfo=" + costtimeinfo + ", remarks=" + remarks
				+ "]";
	}
	
	
//	public SuapFaceLogModel deepClone() throws IOException, ClassNotFoundException {    
//		//将对象写到流里    
//		ByteArrayOutputStream bo=new ByteArrayOutputStream();    
//		ObjectOutputStream oo=new ObjectOutputStream(bo);    
//		oo.writeObject(this);
//		//从流里读出来    
//		ByteArrayInputStream bi=new ByteArrayInputStream(bo.toByteArray());    
//		ObjectInputStream oi=new ObjectInputStream(bi);    
//		return (SuapFaceLogModel) (oi.readObject());    
//	} 
	
	
	
	
	
	
	
	
	
	
	
	
}
