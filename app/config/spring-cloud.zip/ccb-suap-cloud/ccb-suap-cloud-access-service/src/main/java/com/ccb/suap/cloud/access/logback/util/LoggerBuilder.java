package com.ccb.suap.cloud.access.logback.util;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.rolling.RollingFileAppender;
import org.slf4j.LoggerFactory;
 
import java.util.HashMap;
import java.util.Map;
public final class LoggerBuilder {
	private static final Map<String,Logger> container = new HashMap<>();
    public static Logger getLogger(String path,String name,String size,String level) {
        Logger logger = container.get(name);
        if(logger != null) {
            return logger;
        }
        synchronized (LoggerBuilder.class) {
            logger = container.get(name);
            if(logger != null) {
                return logger;
            }
            
            logger = build(path,name,size);
            container.put(name,logger);
        }
        Level Level=null;
        if("info".equals(level))
        {
        	Level=Level.INFO;
        }else if("debug".equals(level))
        {
        	Level=Level.DEBUG;
        }else if("warn".equals(level))
        {
        	Level=Level.WARN;
        }else if("error".equals(level))
        {
        	Level=Level.ERROR;
        }
        logger.setLevel(Level);
        return logger;
    }
 
 
 
 
    private static Logger build(String path,String name,String size) {
 //       RollingFileAppender errorAppender =new AppenderTest().getAppender(path,name,Level.ERROR,size);
        RollingFileAppender infoAppender =new AppenderTest().getAppender(path,name,size);
//        RollingFileAppender warnAppender =new AppenderTest().getAppender(path,name,Level.WARN,size);
//        RollingFileAppender debugAppender =new AppenderTest().getAppender(path,name,Level.DEBUG,size);
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        Logger logger = context.getLogger("FILE-" + name);
        //设置不向上级打印信息
        logger.setAdditive(false);
//        logger.addAppender(errorAppender);
        logger.addAppender(infoAppender);
//        logger.addAppender(warnAppender);
//        logger.addAppender(debugAppender);
 
        return logger;
    }
}
