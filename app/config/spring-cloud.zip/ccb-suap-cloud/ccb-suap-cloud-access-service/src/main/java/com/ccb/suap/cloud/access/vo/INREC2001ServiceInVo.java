package com.ccb.suap.cloud.access.vo;

public class INREC2001ServiceInVo extends INREC1001And2001ServiceInVo{
	
	
}
