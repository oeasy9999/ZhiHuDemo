package com.ccb.suap.cloud.access.model;

import java.io.Serializable;

public class SuapTxattrModel implements Serializable{
	
	private static final long serialVersionUID = 8499449692445221339L;
	
	private String txcode;			//交易代码
	private String txname;			//交易名称
	private String txpath;			//交易服务路径
	private String isoutbound;		//是否外呼
	private String ptxcode;			//外呼交易码
	private String ptxpath;			//外呼交易服务路径
	private String appcode;			//应用代码
	private String remark;			//交易描述
	
	public String getTxcode() {
		return txcode;
	}
	public void setTxcode(String txcode) {
		this.txcode = txcode;
	}
	public String getTxname() {
		return txname;
	}
	public void setTxname(String txname) {
		this.txname = txname;
	}
	public String getTxpath() {
		return txpath;
	}
	public void setTxpath(String txpath) {
		this.txpath = txpath;
	}
	public String getIsoutbound() {
		return isoutbound;
	}
	public void setIsoutbound(String isoutbound) {
		this.isoutbound = isoutbound;
	}
	public String getPtxcode() {
		return ptxcode;
	}
	public void setPtxcode(String ptxcode) {
		this.ptxcode = ptxcode;
	}
	public String getPtxpath() {
		return ptxpath;
	}
	public void setPtxpath(String ptxpath) {
		this.ptxpath = ptxpath;
	}
	public String getAppcode() {
		return appcode;
	}
	public void setAppcode(String appcode) {
		this.appcode = appcode;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	@Override
	public String toString() {
		return "Suap_txattrModel [txcode=" + txcode + ", txname=" + txname + ", txpath=" + txpath + ", isoutbound="
				+ isoutbound + ", ptxcode=" + ptxcode + ", ptxpath=" + ptxpath + ", appcode=" + appcode + ", remark="
				+ remark + "]";
	}
	
	
	
	
	
	
	
	
	
}
