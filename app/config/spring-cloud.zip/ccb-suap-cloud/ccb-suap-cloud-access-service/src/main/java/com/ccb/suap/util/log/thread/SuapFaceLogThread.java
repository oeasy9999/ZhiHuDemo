package com.ccb.suap.util.log.thread;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.dao.factory.InrecDaoFactory;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.service.SuapFaceLogService;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.util.LocalMessage;
import com.ccb.suap.util.date.DateUtils;

public class SuapFaceLogThread implements Runnable{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	SuapFaceLogService suapFaceLogService= InrecDaoFactory.getDaoManager().getSuapFaceLogService();
	
	private SuapFaceLogModel faceLog;
	
	public SuapFaceLogThread(SuapFaceLogModel faceLog) {
		super();
		this.faceLog = faceLog;
	}


	@Override
	public void run() {
		
		//获取ip列表
		List<String> ips = null;
		String serverIp = "";
		try {
			ips = LocalMessage.getLocalIP();
			LOGGER.debug("*************ips*************\n"+ips);
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (String ip : ips) {
			if(!"127.0.0.1".equals(ip)) {
				serverIp = serverIp+ip+"/";
			}
		}
		serverIp = serverIp.substring(0, serverIp.length()-1);
		
		faceLog.setHostname(LocalMessage.getHostName());
		faceLog.setServerip(serverIp);
		
		if(StringUtils.isNotBlank(faceLog.getRemarks()) && faceLog.getRemarks().length() > 150)
			faceLog.setRemarks(faceLog.getRemarks().substring(0, 150));
		
		String num = null;
		String patten = SuapSysParaUtil.getStrPara("FACELOGPATTEN", "yyMM");
		try {
			String timeMills = faceLog.getTransflow().substring(9,19)+"000";
			num = DateUtils.getTimeInMillis(patten, Long.parseLong(timeMills));
		} catch (Exception e1) {
			num = new SimpleDateFormat(patten).format(new Date());
			LOGGER.error("get table name fail, try to get table name by nowaday, table name = " + num + ", patten = " + patten,e1);
		}
		faceLog.setNum(num);
		
		try {
			long seq_logid_log = suapFaceLogService.seq_logid_log();
			faceLog.setLogid(String.valueOf(seq_logid_log));
			suapFaceLogService.insert(faceLog);
		} catch (Exception e) {
			LOGGER.error("insert faceLog error!",e);
			e.printStackTrace();
		}
		
		
	}
	
	
	
	
	
	
	
	
}
