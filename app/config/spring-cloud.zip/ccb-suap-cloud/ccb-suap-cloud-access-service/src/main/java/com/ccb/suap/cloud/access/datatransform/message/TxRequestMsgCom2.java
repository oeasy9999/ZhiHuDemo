package com.ccb.suap.cloud.access.datatransform.message;

public class TxRequestMsgCom2 {
	
	private String sysChannelID;			//系统渠道编号
	private String dotNumber;				//网点号
	private String groupName;				//N库分组名称
	private String sourceGroupName;			//N库源分组名称
	private String venderCode;				//算法厂商标识
	private String venderVersion;			//算法库版本号
	
	public String getSysChannelID() {
		return sysChannelID;
	}
	public void setSysChannelID(String sysChannelID) {
		this.sysChannelID = sysChannelID;
	}
	public String getDotNumber() {
		return dotNumber;
	}
	public void setDotNumber(String dotNumber) {
		this.dotNumber = dotNumber;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getSourceGroupName() {
		return sourceGroupName;
	}
	public void setSourceGroupName(String sourceGroupName) {
		this.sourceGroupName = sourceGroupName;
	}
	public String getVenderCode() {
		return venderCode;
	}
	public void setVenderCode(String venderCode) {
		this.venderCode = venderCode;
	}
	public String getVenderVersion() {
		return venderVersion;
	}
	public void setVenderVersion(String venderVersion) {
		this.venderVersion = venderVersion;
	}
	
	@Override
	public String toString() {
		return "TxRequestMsgCom2 [sysChannelID=" + sysChannelID + ", dotNumber=" + dotNumber + ", groupName="
				+ groupName + ", sourceGroupName=" + sourceGroupName + ", venderCode=" + venderCode + ", venderVersion="
				+ venderVersion + "]";
	}
	
	
	
	
	
	
	
	
	
}
