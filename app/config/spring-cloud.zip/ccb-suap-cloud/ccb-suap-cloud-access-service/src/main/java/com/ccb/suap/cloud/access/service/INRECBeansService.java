package com.ccb.suap.cloud.access.service;

import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.annotation.StatusAnnotation;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1001ServiceInVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1009ServiceInVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1009ServiceOutVo;
import com.ccb.suap.cloud.access.idverify.service.IDVerifyService;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.model.SuapWhiteListModel;
import com.ccb.suap.cloud.access.service.utils.PhotoUtil;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.cloud.access.vo.INREC1001And2001ServiceInVo;
import com.ccb.suap.cloud.access.vo.INREC1001ServiceInVo;
import com.ccb.suap.cloud.access.vo.INREC1001ServiceOutVo;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam1001;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam1001And2001;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam2001;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam6001;
import com.ccb.suap.util.date.DateUtils;
import com.ccb.suap.util.log.TraceLog;

@Service
@StatusAnnotation
public class INRECBeansService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Autowired
	private SuapCustInfoService suapCustInfoService;
	
	@Autowired
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	
	@Autowired
	private SuapFaceLogService suapFaceLogService;
	
	@Autowired
	private IDVerifyService IDVerifyService;
	
	@Autowired
	private SuapWhiteListService whiteListService;

	@Autowired
	private GPUMPService GPUMPService;
	
	@Autowired
	private RedisService redisService;

	
	@Transactional(rollbackFor = Exception.class)
	public TxResponseMsg insertCustDeviceAndSendGPUMP1001(TxResponseMsg rspMsg,TxRequestMsg reqMsg, ServiceInVoParam1001 param) {
		
		SuapCustInfoModel custInfo_database = param.getCustInfo_database();
		SuapCustInfoModel custInfo_reqMsg = param.getCustInfo_reqMsg();
		SuapCustDeviceInfoModel custDeviceInfo_reqMsg = param.getCustDeviceInfo_reqMsg();
		
		//处理人脸核查，客户信息和渠道注册信息
		handlerCustInfoAndCustDeviceInfo(rspMsg, reqMsg, param, param.getInVo());

		// 发往GPUMP1001接口注册
		TxRequestMsg gpump1001ReqMsg = setGPUMP1001ReqMsg(reqMsg);
		LOGGER.debug("send GPUMP1001: " + JSONObject.toJSONString(gpump1001ReqMsg));
		TxResponseMsg gpump1001Rsp = GPUMPService.sendGPUMP1001(gpump1001ReqMsg);
		LOGGER.debug("return by GPUMP1001: " + JSONObject.toJSONString(gpump1001Rsp));
		
		if (!"000000000000".equals(gpump1001Rsp.getTx_header().getSys_resp_code())) {
			LOGGER.error("registry in GPUMP1001 fail: " + gpump1001Rsp);
			throw new CommonRuntimeException(gpump1001Rsp);
		}
		
		
		//以idtype_idno为key缓存客户信息
		saveCustInfo(custInfo_reqMsg);
		
		//以idtype_idno_channelid为key缓存渠道注册信息
		try {
			saveCustDeviceInfo(custDeviceInfo_reqMsg);
		} catch (Exception e) {
			custInfoRollBack(custInfo_database, custInfo_reqMsg);
		}
		
		return rspMsg;
	}


	@Transactional(rollbackFor = Exception.class)
	public TxResponseMsg modifyCustInfoAndCustDevice(TxResponseMsg rspMsg,TxRequestMsg reqMsg,TraceLog traceLog, ServiceInVoParam2001 param) {
		
		SuapCustInfoModel custInfo_database = param.getCustInfo_database();
		SuapCustInfoModel custInfo_reqMsg = param.getCustInfo_reqMsg();
		SuapCustDeviceInfoModel custDeviceInfo_reqMsg = param.getCustDeviceInfo_reqMsg();
		
		//处理人脸核查，客户信息和渠道注册信息
		handlerCustInfoAndCustDeviceInfo(rspMsg, reqMsg, param, param.getInVo());
		
		//以idtype_idno为key缓存客户信息
		saveCustInfo(custInfo_reqMsg);
		
		//以idtype_idno_channelid为key缓存渠道注册信息
		try {
			saveCustDeviceInfo(custDeviceInfo_reqMsg);
		} catch (Exception e) {
			custInfoRollBack(custInfo_database, custInfo_reqMsg);
		}
		
		return rspMsg;
	}


	/**
	 * 1.渠道需要人脸核查且渠道注册信息不存在或者已关闭则进行人脸核查
	 * 2.新增/更新客户信息
	 * 3.新增/更新渠道注册信息
	 * @param rspMsg
	 * @param reqMsg
	 * @param param
	 * @param inVo
	 */
	private void handlerCustInfoAndCustDeviceInfo(TxResponseMsg rspMsg, TxRequestMsg reqMsg, ServiceInVoParam1001And2001 param, INREC1001And2001ServiceInVo inVo) {
		
		SuapFaceConfigModel faceConfig = param.getFaceConfig();
		SuapCustInfoModel custInfo_database = param.getCustInfo_database();
		SuapCustInfoModel custInfo_reqMsg = param.getCustInfo_reqMsg();
		SuapCustDeviceInfoModel custDeviceInfo_database = param.getCustDeviceInfo_database();
		SuapCustDeviceInfoModel custDeviceInfo_reqMsg = param.getCustDeviceInfo_reqMsg();
		
		//人脸核查开启则进行人脸核查
		if("1".equals(faceConfig.getIdverify()))
			if(!idverify(rspMsg, reqMsg, param, inVo))
				throw new CommonRuntimeException(Errorcode.IDVERIFY_FAILD);
		
//		if(custDeviceInfo_database == null || "1".equals(custDeviceInfo_database.getIsvalid())) {
////			Idverify:是否需要身份核查,1表示“是”，2是“否”
//			custInfo_reqMsg.setIdverify("2");
//			if("1".equals(faceConfig.getIdverify())) {
//				boolean flag = checkIsWHITELIST(custInfo_reqMsg);
//				if(!flag) {
//					IDVerifyService.verify(reqMsg,faceConfig,param);
//					custInfo_reqMsg.setIdverify("1");
//					((INREC1001ServiceOutVo)rspMsg.getTx_body().getEntity()).setIdverify("1");
//				}
//			}
//		} else {
//			if(faceConfig.getIdverify().equals("1"))
//				((INREC1001ServiceOutVo)rspMsg.getTx_body().getEntity()).setIdverify("1");
//		}
		
		
		if(custInfo_database == null) {
			//渠道注册信息存在则报错
			if(custDeviceInfo_database != null) {
				LOGGER.error("custInfo not exist but custDeviceInfo exists!");
				throw new CommonRuntimeException(Errorcode.CSTDEVEXIERROR, "01", "内部异常:客户信息缺失或渠道注册信息冗余");
			}
			
			//获取人脸核查照片路径
			String idPhoto_path = PhotoUtil.getPath(ServiceParaUtil.getBasePthBySyspara("FACEPICPATH", reqMsg.getTx_body().getCom1().getSysChannelID(), "faceModelImage"), inVo.getId_type()+"_"+inVo.getId_no()+"_A" + ".jpg");
			custInfo_reqMsg.setIdphoto_path(idPhoto_path);
			LOGGER.debug("idPhoto_path: "+idPhoto_path);
			
			//插入客户信息表
			LOGGER.debug("insert custInfo: "+custInfo_reqMsg);
			suapCustInfoService.insert(custInfo_reqMsg);
			
			//获取现场照保存路径
			String scene_path = PhotoUtil.getPath(ServiceParaUtil.getBasePthBySyspara("FACEPICPATH", reqMsg.getTx_body().getCom1().getSysChannelID(), "faceModelImage"), inVo.getId_type()+"_"+inVo.getId_no()+"_B" + ".jpg");
			custDeviceInfo_reqMsg.setPhoto_path(scene_path);
			LOGGER.debug("Scenephoto_path: "+scene_path);
			
			//新增渠道注册信息
			LOGGER.debug("insert custDevInfo: " + custDeviceInfo_reqMsg);
			suapCustDeviceInfoService.insert(custDeviceInfo_reqMsg);
			
			//保存人脸核查照片
			if(StringUtils.isNotBlank(param.getIdverify_image()))
				PhotoUtil.savePhotoWithTime(param.getIdverify_image(), idPhoto_path, "saveIdPhoto");
			
			//保存现场照
			PhotoUtil.savePhotoWithTime(inVo.getFace_image(), scene_path, "saveModelPhoto");
			
			return;
		}

		/**
		 *	客户已存在
		 * 	1.更新客户现场照
		 * 	2.更新客户信息
		 * 	3.查询客户渠道注册信息
		 * 		3.1.不存在则新增
		 * 		3.2.存在则更新 
		 */
//		//如果该渠道需要人脸核查，则判断姓名是否匹配
//		if("1".equals(faceConfig.getIdverify()) && "0".equals(custDeviceInfo_database.getIsvalid())) {
//			((INREC1001ServiceOutVo)rspMsg.getTx_body().getEntity()).setIdverify("1");
//			
//			if(!custInfo_database.getCustname().equals(inVo.getName())) {
//				LOGGER.error("request name error: "+"{entity.getName():"+inVo.getName()+",CustInfo.getName():"+custInfo_database.getCustname()+"}");
//				throw new CommonRuntimeException(Errorcode.CSTNAMNOTMATCH);
//			}
//			
//			//发送GPUMP1009校验图片合法性
//			String faceImage1 = ServiceParaUtil.getPhotoByCustDeviceInfo(reqMsg, custDeviceInfo_database);
//			String faceImage2 = inVo.getFace_image();
//			TxRequestMsg gpump1009ReqMsg = getGPUMP1009ReqMsg(reqMsg, faceImage1, faceImage2);
//			checkByGPUMP1009(reqMsg, gpump1009ReqMsg);
//		}
		
		//获取人脸核查照片路径
		String idphoto_path = custInfo_database.getIdphoto_path();
		if(StringUtils.isBlank(idphoto_path)) {
			idphoto_path = PhotoUtil.getPath(ServiceParaUtil.getBasePthBySyspara("FACEPICPATH", reqMsg.getTx_body().getCom1().getSysChannelID(), "faceModelImage"), inVo.getId_type()+"_"+inVo.getId_no()+"_A" + ".jpg");
			custInfo_reqMsg.setIdphoto_path(idphoto_path);
			LOGGER.debug("idPhoto_path: "+idphoto_path);
		}
		
		
		//更新客户信息表
		LOGGER.debug("update custInfo: "+custInfo_reqMsg);
		suapCustInfoService.update(custInfo_reqMsg);
		
		/*
		 * 1.渠道注册信息不存在则插入数据 
		 * 2.存在则判断渠道客户号是否一致，一致则更新，不一致则报错
		 */
		if (custDeviceInfo_database == null) {
			//获取图片保存路径
			String path = PhotoUtil.getPath(ServiceParaUtil.getBasePthBySyspara("FACEPICPATH", reqMsg.getTx_body().getCom1().getSysChannelID(), "faceModelImage"), inVo.getId_type()+"_"+inVo.getId_no()+"_B" + ".jpg");
			custDeviceInfo_reqMsg.setPhoto_path(path);
			
			//新增渠道注册信息
			LOGGER.debug("insert custDevInfo: " + custDeviceInfo_reqMsg);
			suapCustDeviceInfoService.insert(custDeviceInfo_reqMsg);
			
			//保存注册图片
			PhotoUtil.savePhotoWithTime(inVo.getFace_image(), path, "saveCustDevicePhoto");
			LOGGER.debug("Scenephoto_path: "+path);
		} else {
			if ("2".equals(faceConfig.getLocationindex())) {
				if (!inVo.getChannel_custno().equals(custDeviceInfo_database.getChannel_cstno())) {
					LOGGER.error("channel_custno not match: {entity.getChannel_custno: " + inVo.getChannel_custno() + ",selectSuapCustDeviceInfoModel.getChannel_cstno: " + custDeviceInfo_database.getChannel_cstno() + "}");
					throw new CommonRuntimeException(Errorcode.CHNCSNNOTMATCH);
				}
			}
			
			//更新渠道注册信息
			LOGGER.debug("update custDevInfo: " + custDeviceInfo_reqMsg);
			suapCustDeviceInfoService.update(custDeviceInfo_reqMsg);
			
			//保存客户图片
			String path = custDeviceInfo_database.getPhoto_path();
			PhotoUtil.savePhotoWithTime(inVo.getFace_image(), path, "saveCustDevicePhoto");
			LOGGER.debug("Scenephoto_path: "+path);
		}
		
		//保存人脸核查照片
		if(StringUtils.isNotBlank(param.getIdverify_image()))
			PhotoUtil.savePhotoWithTime(param.getIdverify_image(), idphoto_path, "saveIdPhoto");
		
	}
	
	
	/**
	 * 人脸核查
	 * @param rspMsg
	 * @param reqMsg
	 * @param param
	 */
	private boolean idverify(TxResponseMsg rspMsg, TxRequestMsg reqMsg, ServiceInVoParam1001And2001 param, INREC1001And2001ServiceInVo inVo) {
		SuapCustInfoModel custInfo_reqMsg = param.getCustInfo_reqMsg();
		SuapCustDeviceInfoModel custDcviceInfo_database = param.getCustDeviceInfo_database();
		SuapCustDeviceInfoModel custDcviceInfo_reqMsg = param.getCustDeviceInfo_reqMsg();
		
		if(custDcviceInfo_database != null && "0".equals(custDcviceInfo_database.getIsvalid()))
			return idverifyByGPUMP1009(reqMsg, param, inVo);
		
		boolean flag = idverifyByCCVEA(reqMsg,param);
		if(!flag)
			return false;
		
		if(StringUtils.isBlank(custDcviceInfo_reqMsg.getIdverify()))
			custDcviceInfo_reqMsg.setIdverify("1");
		if(StringUtils.isBlank(custInfo_reqMsg.getIdverify()))
			custInfo_reqMsg.setIdverify("1");
		((INREC1001ServiceOutVo)rspMsg.getTx_body().getEntity()).setIdverify("1");
		
		return flag;
	}


	/**
	 * 校验姓名及图片是否匹配
	 * @param reqMsg
	 * @param param
	 * @return
	 */
	private boolean idverifyByGPUMP1009(TxRequestMsg reqMsg, ServiceInVoParam1001And2001 param, INREC1001And2001ServiceInVo inVo) {
		SuapCustInfoModel custInfo_database = param.getCustInfo_database();
		SuapCustDeviceInfoModel custDeviceInfo_database = param.getCustDeviceInfo_database();
		
		if(!custInfo_database.getCustname().equals(inVo.getName())) {
			LOGGER.error("request name error: "+"{entity.getName():"+inVo.getName()+",CustInfo.getName():"+custInfo_database.getCustname()+"}");
			throw new CommonRuntimeException(Errorcode.CSTNAMNOTMATCH);
		}
		
		//发送GPUMP1009校验图片合法性
		String faceImage1 = ServiceParaUtil.getPhotoByCustDeviceInfo(reqMsg, custDeviceInfo_database);
		String faceImage2 = inVo.getFace_image();
		TxRequestMsg gpump1009ReqMsg = getGPUMP1009ReqMsg(reqMsg, faceImage1, faceImage2);
		checkByGPUMP1009(reqMsg, gpump1009ReqMsg);
		
		return true;
	}

	
	/**
	 * 发往私有云进行人脸核查
	 * @param reqMsg
	 * @param param
	 * @return
	 */
	private boolean idverifyByCCVEA(TxRequestMsg reqMsg, ServiceInVoParam1001And2001 param) {
		SuapCustInfoModel custInfo_reqMsg = param.getCustInfo_reqMsg();
		SuapFaceConfigModel faceConfig = param.getFaceConfig();
		
		if(checkIsWHITELIST(custInfo_reqMsg))
			return true;
		
		return IDVerifyService.verify(reqMsg,faceConfig,param);
	}
	
	
	/**
	 * 	当开启白名单且客户证件在其中时，返回true，否则返回false
	 * @param suapCustInfoModel
	 * @return
	 */
	private boolean checkIsWHITELIST(SuapCustInfoModel suapCustInfoModel) {
		String isWhiteList = SuapSysParaUtil.getStrPara("ISWHITELIST", null);
		if(!"1".equals(isWhiteList))
			return false;
		
		SuapWhiteListModel whiteListModel = whiteListService.selectOne(suapCustInfoModel.getIdnumber());
		LOGGER.debug("select WHITELIST: "+whiteListModel);
		if(whiteListModel == null) {
			
			LOGGER.warn("customer not in whiteList: "+whiteListModel);
			return false;
		}
		if(!suapCustInfoModel.getCustname().equals(whiteListModel.getCUSTNAME())) {
			LOGGER.warn("custName not match: {custInfoModel.getCustName:"+suapCustInfoModel.getCustname()+",whiteListModel.getCUSTNAME:"+whiteListModel.getCUSTNAME()+"}");
			return false;
		}
		
		return true;
	}
	
	
	/**
	 * GPUMP1009请求信息封装(需要传图片)
	 * @param reqMsg
	 * @param faceImage1
	 * @param faceImage2
	 * @return
	 */
	private TxRequestMsg getGPUMP1009ReqMsg(TxRequestMsg reqMsg, String faceImage1, String faceImage2) {
		TxRequestMsg gpump1009ReqMsg = ServiceParaUtil.parseGpuRequestMsg(reqMsg);
		GPUMP1009ServiceInVo gpump1009ReqEntity = new GPUMP1009ServiceInVo();
		
		gpump1009ReqMsg.getTx_header().setSys_tx_code("GPUMP1009");
		gpump1009ReqMsg.getTx_body().setEntity(gpump1009ReqEntity);
		
		gpump1009ReqEntity.setFace_image(faceImage1);
		gpump1009ReqEntity.setFace_refer_image(faceImage2);
		
		return gpump1009ReqMsg;
	}


	/**
	 * 1.发往GPUMP1009获取相似度
	 * 2.比较相似度，相似度不达标则抛异常
	 * @param gpump1009ReqMsg
	 */
	private boolean checkByGPUMP1009(TxRequestMsg reqMsg, TxRequestMsg gpump1009ReqMsg) {
		LOGGER.debug("send GPUMP1009: "+gpump1009ReqMsg);
		TxResponseMsg gpump1009Rsp = GPUMPService.sendGPUMP1009(gpump1009ReqMsg);
		LOGGER.debug("return by GPUMP1009: "+gpump1009Rsp);
		
		if(!"000000000000".equals(gpump1009Rsp.getTx_header().getSys_resp_code())) {
			LOGGER.error("check by GPUMP1009 service fail"+"{resp_code:"+gpump1009Rsp.getTx_header().getSys_resp_code()+",resp_desc:"+gpump1009Rsp.getTx_header().getSys_resp_desc()+"}");
			throw new CommonRuntimeException(gpump1009Rsp);
		}
		comparePhoto(reqMsg, gpump1009Rsp);
		
		return true;
	}

	
	/**
	 * 判断图片是否超过阈值
	 * @param reqMsg
	 * @param gpump1009Rsp
	 */
	private void comparePhoto(TxRequestMsg reqMsg, TxResponseMsg gpump1009Rsp) {
		SuapFaceConfigModel faceConfig = SuapFaceConfigUtil.getFaceConfig(reqMsg);
		double sourceSimilarity = 0;
		try {
			sourceSimilarity = Double.parseDouble(faceConfig.getSimilarity());
		} catch (NumberFormatException e) {
			throw new CommonRuntimeException(Errorcode.PARAETYPEERROR, "01", "parse similarity error! please reset faceConfig!");
		}
		
		GPUMP1009ServiceOutVo gpump1009RspEntity = (GPUMP1009ServiceOutVo) gpump1009Rsp.getTx_body().getEntity();
		double targetSimilarity = Double.parseDouble(gpump1009RspEntity.getSimilarity());
		
		LOGGER.debug("{系统指定阈值: "+sourceSimilarity+",图片相似度: "+targetSimilarity);
		if(targetSimilarity < sourceSimilarity) {
			LOGGER.error("the request photo do not reached the threshold"+"{系统指定阈值: "+sourceSimilarity+",图片相似度: "+targetSimilarity);
			throw new CommonRuntimeException(Errorcode.PHOCOMPAREFAIL);
		}
		
	}
	
	
	/**
	 * 	把请求信息封装成前置对应的请求报文
	 * @param reqMsg
	 * @return
	 */
	private TxRequestMsg setGPUMP1001ReqMsg(TxRequestMsg reqMsg) {
		TxRequestMsg gpuRequestMsg = ServiceParaUtil.parseGpuRequestMsg(reqMsg);
		
		INREC1001ServiceInVo entity = (INREC1001ServiceInVo) reqMsg.getTx_body().getEntity();
		
		GPUMP1001ServiceInVo gpump1001ServiceInVo = new GPUMP1001ServiceInVo();
		String image = entity.getFace_image();
		image = image.replaceAll("\r", "");
		image = image.replaceAll("\n", "");
		image = image.replaceAll(" ", "");
		gpump1001ServiceInVo.setFace_image(image);
		
		gpump1001ServiceInVo.setId_type(entity.getId_type());
		gpump1001ServiceInVo.setId_no(entity.getId_no());
		gpump1001ServiceInVo.setName(entity.getName());
		gpump1001ServiceInVo.setMobile_no(entity.getMobile_no());
		
		//根据字段索引封装请求报文的cust_id
		String sysChannelID = reqMsg.getTx_body().getCom1().getSysChannelID();
		String channelTxCode = reqMsg.getTx_body().getCom1().getChannelTxCode();
		String sys_tx_code = reqMsg.getTx_header().getSys_tx_code();
		SuapFaceConfigModel faceConfig = SuapFaceConfigUtil.getFaceConfig(sysChannelID+":"+channelTxCode+":"+sys_tx_code);
		gpump1001ServiceInVo.setThreshold(faceConfig.getSimilarity());
		
		String locationIndex = faceConfig.getLocationindex();
		if(locationIndex.equals("1"))
			gpump1001ServiceInVo.setCust_id(entity.getId_no());
		if(locationIndex.equals("2"))
			gpump1001ServiceInVo.setCust_id(entity.getChannel_custno());
		
		gpuRequestMsg.getTx_header().setSys_tx_code("GPUMP1001");
		gpuRequestMsg.getTx_body().setEntity(gpump1001ServiceInVo);
		
		return gpuRequestMsg;
	}


	/**
	 * 插入日志表并保存图片
	 * @param reqMsg
	 * @param arr
	 * @param param
	 */
	@Transactional(rollbackFor = Exception.class)
	public void insertFaceLogAndSavePhoto(TxRequestMsg reqMsg, ServiceInVoParam6001 param) {
		SuapFaceLogModel faceLog = param.getFaceLog();
		
//		String timeMills = faceLog.getTransflow().substring(9,22);
//		String num = DateUtils.getTimeInMillis("yyMM", Long.parseLong(timeMills));
		String num = getNum(faceLog);
		faceLog.setNum(num);
		
		//插入日志表
		int row = 0;
		try {
			long seq_logid_log = suapFaceLogService.seq_logid_log();
			faceLog.setLogid(String.valueOf(seq_logid_log));
			row = suapFaceLogService.insert(faceLog);
		} catch (Exception e) {
			LOGGER.error("insert FaceLog fail: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.INSFACLOGERROR, "02",e.getMessage());
		}
		if(row == 0) {
			LOGGER.error("insert FaceLog fail: no message has inserted!");
			throw new CommonRuntimeException(Errorcode.INSFACLOGFAILD);
		}
		
		//保存图片
		String face_image = param.getFace_image();
		String path = faceLog.getFacefilepath();
		if(StringUtils.isBlank(path))
			return;
		if(StringUtils.isBlank(face_image))
			throw new CommonRuntimeException(Errorcode.ENIMGPANOTNULL);
		
		PhotoUtil.savePhoto(face_image, path);
		
	}
	
	
	/**
	 * 	获取日志表分表名称
	 * @param faceLog
	 * @return
	 */
	private String getNum(SuapFaceLogModel faceLog) {
		String num = null;
		String patten = SuapSysParaUtil.getStrPara("FACELOGPATTEN", "yyMM");
		try {
			String timeMills = faceLog.getTransflow().substring(9,19)+"000";
			num = DateUtils.getTimeInMillis(patten, Long.parseLong(timeMills));
		} catch (Exception e1) {
			num = new SimpleDateFormat(patten).format(faceLog.getRecvtime());
			LOGGER.error("get table name fail, try to get table name by nowaday, traceflow = " + faceLog.getTransflow() + ", table name = " + num + ", patten = " + patten,e1);
		}
		
		return num;
	}


	/**
	 * 	以idtype_idno为key缓存客户信息
	 * @param custInfo_reqMsg
	 */
	private void saveCustInfo(SuapCustInfoModel custInfo_reqMsg) {
		String key = custInfo_reqMsg.getIdtype() + "_" + custInfo_reqMsg.getIdnumber();
		
		redisService.set(key, JSONObject.toJSONString(custInfo_reqMsg));
		
	}


	/**
	 * 	以idtype_idno_channelid为key缓存渠道注册信息
	 * @param custDcviceInfo_reqMsg
	 */
	private void saveCustDeviceInfo(SuapCustDeviceInfoModel custDcviceInfo_reqMsg) {
		String key = custDcviceInfo_reqMsg.getIdtype() + "_" + custDcviceInfo_reqMsg.getIdnumber() + "_" +custDcviceInfo_reqMsg.getChannelid();
		
		redisService.set(key, JSONObject.toJSONString(custDcviceInfo_reqMsg));
		
	}
	
	
	/**
	 * 手动回退redis中客户信息
	 * @param custInfo_database
	 */
	private void custInfoRollBack(SuapCustInfoModel custInfo_database, SuapCustInfoModel custInfo_reqMsg) {
		if(custInfo_database == null) {
			deleteCustInfo(custInfo_reqMsg);
		}else {
			String key = custInfo_database.getIdtype() + "_" + custInfo_database.getIdnumber();
			redisService.set(key, JSONObject.toJSONString(custInfo_database));
		}
	}
	
	
	/**
	 * 删除redis中客户信息
	 * @param custInfo_reqMsg
	 */
	private void deleteCustInfo(SuapCustInfoModel custInfo_reqMsg) {
		
		String key = custInfo_reqMsg.getIdtype() + "_" + custInfo_reqMsg.getIdnumber();
		
		redisService.delete(key);
		
	}
	

//	/**
//	 * 手动回退redis中渠道注册信息
//	 * @param custDeviceInfo_reqMsg
//	 */
//	private void custDeviceInfoRollBack(SuapCustDeviceInfoModel custDeviceInfo_database) {
//		if(custDeviceInfo_database == null) {
//			deleteCustDeviceInfo(custDeviceInfo_database);
//		}else {
//			String key = custDeviceInfo_database.getIdtype() + "_" + custDeviceInfo_database.getIdnumber() + "_" + custDeviceInfo_database.getChannelid();
//			
//			redisService.set(key, JSONObject.toJSONString(custDeviceInfo_database));
//		}
//		
//	}
	
	
//	/**
//	 * 删除redis中渠道注册信息
//	 * @param custDeviceInfo_database
//	 */
//	private void deleteCustDeviceInfo(SuapCustDeviceInfoModel custDeviceInfo_database) {
//		
//		String key = custDeviceInfo_database.getIdtype() + "_" + custDeviceInfo_database.getIdnumber() + "_" + custDeviceInfo_database.getChannelid();
//		
//		redisService.delete(key);
//		
//	}
	
	
	
	/**
	 * 新增/插入渠道注册信息，保存图片，此操作保持原子性
	 * @param custDeviceInfo
	 * @param image
	 * @param type
	 * @return
	 */
	@Transactional(rollbackFor = Exception.class)
	public boolean handlerCustDeviceInfoAndSavePhoto(SuapCustDeviceInfoModel custDeviceInfo, String image, String type) {
		String path = custDeviceInfo.getPhoto_path();
		
		switch (type.toUpperCase()) {
		case "INSERT":
			suapCustDeviceInfoService.insertWithRedis(custDeviceInfo);
			break;
		case "UPDATE":
			suapCustDeviceInfoService.updateWithRedis(custDeviceInfo);
			break;

		default:
			break;
		}
		
		PhotoUtil.savePhotoWithTime(image, path);
		
		return true;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
