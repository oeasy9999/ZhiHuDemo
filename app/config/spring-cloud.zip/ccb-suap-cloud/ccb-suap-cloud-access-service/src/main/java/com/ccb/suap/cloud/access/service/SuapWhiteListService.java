package com.ccb.suap.cloud.access.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccb.suap.cloud.access.annotation.CosttimeAnnotation;
import com.ccb.suap.cloud.access.annotation.StatusAnnotation;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.mapper.SuapWhiteListMapper;
import com.ccb.suap.cloud.access.model.SuapWhiteListModel;

@Service
@StatusAnnotation
public class SuapWhiteListService {
	
	@Autowired
	private SuapWhiteListMapper dao;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	
	/**
	 * 	根据证件号码查询指定白名单
	 * @param idnumber
	 * @return
	 */
	@CosttimeAnnotation(title = "selectWhiteList")
	public SuapWhiteListModel selectOne(String idnumber) {
		SuapWhiteListModel model = null;
		try {
			model = dao.selectOne(idnumber);
		} catch (Exception e) {
			LOGGER.error("insert CustInfo fail: "+e.getMessage(),e);
			throw new CommonRuntimeException(Errorcode.SECWHTLSTERROR, "02",e.getMessage().toString());
		}
		
		return model;
	}
	
	
	
	
	
	
	
}
