package com.ccb.suap.cloud.access.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;

@Service
public class RestTemplateService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	/**
	 * restTemplate发送post请求
	 * @param url
	 * @param requestMsg
	 * @param cl
	 * @return
	 */
	public <E> E postForEntity(String url, Object requestMsg, Class<E> cl) {
		
		ResponseEntity<E> aiaudioRsp = null;
		try {
			aiaudioRsp = restTemplate.postForEntity(url, requestMsg, cl);
		} catch (RestClientException e) {
			LOGGER.error("send aiaudio fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDRSTTPERROR, "02",e.getMessage().toString());
		}
		
		E aiaudioRspMsg = aiaudioRsp.getBody();
		
		return aiaudioRspMsg;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
