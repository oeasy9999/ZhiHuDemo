package com.ccb.suap.cloud.access.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ccb.suap.cloud.access.model.SuapOutboundConfigModel;

public interface SuapOutboundConfigMapper {
	
	@Select("select * from SUAP_OUTBOUND_CONFIG")
	List<SuapOutboundConfigModel> selectAll();
	
	
	@Select("select * from SUAP_OUTBOUND_CONFIG where CHANNELCODE=#{channelcode} AND TRADECODE=#{tradecode}")
	SuapOutboundConfigModel selectOne(@Param("channelcode")String channelcode,@Param("tradecode")String tradecode);
	
	
	
	
	
	
	
	
	
	
	
}
