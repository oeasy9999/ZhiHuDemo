package com.ccb.suap.cloud.access.beans;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.service.utils.PhotoUtil;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC6002ServiceInVo;
import com.ccb.suap.util.log.TraceLog;

/**
 * 	云端日志同步
 * @author 86156
 *
 */
@Controller("INREC6002")
public class INREC6002_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC6002_Bean.class);
	
	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg,TxRequestMsg reqMsg,TraceLog traceLog) throws Exception{
		LOGGER.debug("\n\n------------------调用INREC6002服务------------------");
		
		FaceLogThreadLocal.get().setRemarks("本地推送图片");
		
		INREC6002ServiceInVo inVo = (INREC6002ServiceInVo) reqMsg.getTx_body().getEntity();
		
		//实体域参数校验
		LOGGER.debug("check requestEntity: "+inVo);
		checkParaByServerName(rspMsg, reqMsg);
		
		String face_image = inVo.getFace_image();
		String image_name = inVo.getImage_name();
		
		String path = PhotoUtil.getPath(ServiceParaUtil.getBasePthBySyspara("FACEPICPATH", reqMsg.getTx_body().getCom1().getSysChannelID(), "LOCAL_TRANSFER"), image_name);
		PhotoUtil.savePhotoWithTime(face_image, path);
		
		LOGGER.debug("success: "+rspMsg);
		return rspMsg;
	}
	
	
	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		INREC6002ServiceInVo inVo = (INREC6002ServiceInVo)reqMsg.getTx_body().getEntity();
		
		if(StringUtils.isBlank(inVo.getImage_name()))
			throw new CommonRuntimeException(Errorcode.IMGNAMENOTNULL);
		if(StringUtils.isBlank(inVo.getFace_image()))
			throw new CommonRuntimeException(Errorcode.FACEIMGNOTNULL);
		
	}
	
	


	
	
	
}
