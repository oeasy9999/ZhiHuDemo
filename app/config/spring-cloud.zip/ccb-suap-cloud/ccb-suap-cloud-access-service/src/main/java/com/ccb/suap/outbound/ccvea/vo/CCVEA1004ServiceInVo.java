package com.ccb.suap.outbound.ccvea.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class CCVEA1004ServiceInVo extends TxRequestMsgEntity{
	
	private String SYSTEM_TIME;							//客户端当前时间
	private String Stm_Chnl_ID;							//系统渠道编号
	private String Stm_Chnl_Txn_CD;						//系统渠道交易码
	private String Cst_Nm;								//客户名称
	private String CrdTp_Cd;							//卡种代码
	private String Crdt_No;								//证件号码
	private String Br_ID;								//分行编号
	private String Rmrk_1_Rcrd_Cntnt;					//备注1记录内容
	private String base64_ECD_Txn_Inf;					//base64编码交易信息
	private String base64_Ecrp_Txn_Inf;					//base64加密交易信息
	private String Br_ID_Inf;							//网点编号信息
	private String Geo_Lo_ID;							//地理位置编号
	private String Mftr_Idr_CD;							//厂商标识码
	private String Mftr_Str_VNo;						//厂商库版本号
	private String Ftr_Col_TmnlInf;						//特征采集终端信息
	private String Tmnl_Eqmt_No;						//终端设备号
	private String Eqmt_Modl_VNo;						//设备型号版本号
	private String Eqmt_Ctfn_CD;						//设备认证码
	private String Usr_Inf_Dsc;							//用户信息描述
	private String Eqmt_Inf_Dsc;						//设备信息描述
	private String Aflt_Inf_Dsc;						//附属信息描述
	private String Rsrv_1_Inf_Dsc;						//备用1信息描述
	private String Rsrv_2_Inf_Dsc;						//备用2信息描述
	private String Rsrv_3_Inf_Dsc;						//备用3信息描述
	private String Rsrv_4_Inf_Dsc;						//备用4信息描述
	private String Rsrv_5_Inf_Dsc;						//备用5信息描述
	
	public String getSYSTEM_TIME() {
		return SYSTEM_TIME;
	}
	public void setSYSTEM_TIME(String sYSTEM_TIME) {
		SYSTEM_TIME = sYSTEM_TIME;
	}
	public String getStm_Chnl_ID() {
		return Stm_Chnl_ID;
	}
	public void setStm_Chnl_ID(String stm_Chnl_ID) {
		Stm_Chnl_ID = stm_Chnl_ID;
	}
	public String getStm_Chnl_Txn_CD() {
		return Stm_Chnl_Txn_CD;
	}
	public void setStm_Chnl_Txn_CD(String stm_Chnl_Txn_CD) {
		Stm_Chnl_Txn_CD = stm_Chnl_Txn_CD;
	}
	public String getCst_Nm() {
		return Cst_Nm;
	}
	public void setCst_Nm(String cst_Nm) {
		Cst_Nm = cst_Nm;
	}
	public String getCrdTp_Cd() {
		return CrdTp_Cd;
	}
	public void setCrdTp_Cd(String crdTp_Cd) {
		CrdTp_Cd = crdTp_Cd;
	}
	public String getCrdt_No() {
		return Crdt_No;
	}
	public void setCrdt_No(String crdt_No) {
		Crdt_No = crdt_No;
	}
	public String getBr_ID() {
		return Br_ID;
	}
	public void setBr_ID(String br_ID) {
		Br_ID = br_ID;
	}
	public String getRmrk_1_Rcrd_Cntnt() {
		return Rmrk_1_Rcrd_Cntnt;
	}
	public void setRmrk_1_Rcrd_Cntnt(String rmrk_1_Rcrd_Cntnt) {
		Rmrk_1_Rcrd_Cntnt = rmrk_1_Rcrd_Cntnt;
	}
	public String getBase64_ECD_Txn_Inf() {
		return base64_ECD_Txn_Inf;
	}
	public void setBase64_ECD_Txn_Inf(String base64_ECD_Txn_Inf) {
		this.base64_ECD_Txn_Inf = base64_ECD_Txn_Inf;
	}
	public String getBase64_Ecrp_Txn_Inf() {
		return base64_Ecrp_Txn_Inf;
	}
	public void setBase64_Ecrp_Txn_Inf(String base64_Ecrp_Txn_Inf) {
		this.base64_Ecrp_Txn_Inf = base64_Ecrp_Txn_Inf;
	}
	public String getBr_ID_Inf() {
		return Br_ID_Inf;
	}
	public void setBr_ID_Inf(String br_ID_Inf) {
		Br_ID_Inf = br_ID_Inf;
	}
	public String getGeo_Lo_ID() {
		return Geo_Lo_ID;
	}
	public void setGeo_Lo_ID(String geo_Lo_ID) {
		Geo_Lo_ID = geo_Lo_ID;
	}
	public String getMftr_Idr_CD() {
		return Mftr_Idr_CD;
	}
	public void setMftr_Idr_CD(String mftr_Idr_CD) {
		Mftr_Idr_CD = mftr_Idr_CD;
	}
	public String getMftr_Str_VNo() {
		return Mftr_Str_VNo;
	}
	public void setMftr_Str_VNo(String mftr_Str_VNo) {
		Mftr_Str_VNo = mftr_Str_VNo;
	}
	public String getFtr_Col_TmnlInf() {
		return Ftr_Col_TmnlInf;
	}
	public void setFtr_Col_TmnlInf(String ftr_Col_TmnlInf) {
		Ftr_Col_TmnlInf = ftr_Col_TmnlInf;
	}
	public String getTmnl_Eqmt_No() {
		return Tmnl_Eqmt_No;
	}
	public void setTmnl_Eqmt_No(String tmnl_Eqmt_No) {
		Tmnl_Eqmt_No = tmnl_Eqmt_No;
	}
	public String getEqmt_Modl_VNo() {
		return Eqmt_Modl_VNo;
	}
	public void setEqmt_Modl_VNo(String eqmt_Modl_VNo) {
		Eqmt_Modl_VNo = eqmt_Modl_VNo;
	}
	public String getEqmt_Ctfn_CD() {
		return Eqmt_Ctfn_CD;
	}
	public void setEqmt_Ctfn_CD(String eqmt_Ctfn_CD) {
		Eqmt_Ctfn_CD = eqmt_Ctfn_CD;
	}
	public String getUsr_Inf_Dsc() {
		return Usr_Inf_Dsc;
	}
	public void setUsr_Inf_Dsc(String usr_Inf_Dsc) {
		Usr_Inf_Dsc = usr_Inf_Dsc;
	}
	public String getEqmt_Inf_Dsc() {
		return Eqmt_Inf_Dsc;
	}
	public void setEqmt_Inf_Dsc(String eqmt_Inf_Dsc) {
		Eqmt_Inf_Dsc = eqmt_Inf_Dsc;
	}
	public String getAflt_Inf_Dsc() {
		return Aflt_Inf_Dsc;
	}
	public void setAflt_Inf_Dsc(String aflt_Inf_Dsc) {
		Aflt_Inf_Dsc = aflt_Inf_Dsc;
	}
	public String getRsrv_1_Inf_Dsc() {
		return Rsrv_1_Inf_Dsc;
	}
	public void setRsrv_1_Inf_Dsc(String rsrv_1_Inf_Dsc) {
		Rsrv_1_Inf_Dsc = rsrv_1_Inf_Dsc;
	}
	public String getRsrv_2_Inf_Dsc() {
		return Rsrv_2_Inf_Dsc;
	}
	public void setRsrv_2_Inf_Dsc(String rsrv_2_Inf_Dsc) {
		Rsrv_2_Inf_Dsc = rsrv_2_Inf_Dsc;
	}
	public String getRsrv_3_Inf_Dsc() {
		return Rsrv_3_Inf_Dsc;
	}
	public void setRsrv_3_Inf_Dsc(String rsrv_3_Inf_Dsc) {
		Rsrv_3_Inf_Dsc = rsrv_3_Inf_Dsc;
	}
	public String getRsrv_4_Inf_Dsc() {
		return Rsrv_4_Inf_Dsc;
	}
	public void setRsrv_4_Inf_Dsc(String rsrv_4_Inf_Dsc) {
		Rsrv_4_Inf_Dsc = rsrv_4_Inf_Dsc;
	}
	public String getRsrv_5_Inf_Dsc() {
		return Rsrv_5_Inf_Dsc;
	}
	public void setRsrv_5_Inf_Dsc(String rsrv_5_Inf_Dsc) {
		Rsrv_5_Inf_Dsc = rsrv_5_Inf_Dsc;
	}
	
	@Override
	public String toString() {
		return "CCVEA1004ServiceInVo [SYSTEM_TIME=" + SYSTEM_TIME + ", Stm_Chnl_ID=" + Stm_Chnl_ID
				+ ", Stm_Chnl_Txn_CD=" + Stm_Chnl_Txn_CD + ", Cst_Nm=" + Cst_Nm + ", CrdTp_Cd=" + CrdTp_Cd
				+ ", Crdt_No=" + Crdt_No + ", Br_ID=" + Br_ID + ", Rmrk_1_Rcrd_Cntnt=" + Rmrk_1_Rcrd_Cntnt
				+ ", base64_ECD_Txn_Inf=" + base64_ECD_Txn_Inf + ", base64_Ecrp_Txn_Inf=" + base64_Ecrp_Txn_Inf
				+ ", Br_ID_Inf=" + Br_ID_Inf + ", Geo_Lo_ID=" + Geo_Lo_ID + ", Mftr_Idr_CD=" + Mftr_Idr_CD
				+ ", Mftr_Str_VNo=" + Mftr_Str_VNo + ", Ftr_Col_TmnlInf=" + Ftr_Col_TmnlInf + ", Tmnl_Eqmt_No="
				+ Tmnl_Eqmt_No + ", Eqmt_Modl_VNo=" + Eqmt_Modl_VNo + ", Eqmt_Ctfn_CD=" + Eqmt_Ctfn_CD
				+ ", Usr_Inf_Dsc=" + Usr_Inf_Dsc + ", Eqmt_Inf_Dsc=" + Eqmt_Inf_Dsc + ", Aflt_Inf_Dsc=" + Aflt_Inf_Dsc
				+ ", Rsrv_1_Inf_Dsc=" + Rsrv_1_Inf_Dsc + ", Rsrv_2_Inf_Dsc=" + Rsrv_2_Inf_Dsc + ", Rsrv_3_Inf_Dsc="
				+ Rsrv_3_Inf_Dsc + ", Rsrv_4_Inf_Dsc=" + Rsrv_4_Inf_Dsc + ", Rsrv_5_Inf_Dsc=" + Rsrv_5_Inf_Dsc + "]";
	}
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
