package com.ccb.suap.cloud.access.model;

import java.io.Serializable;

public class SuapBranchModel implements Serializable{
	
	private static final long serialVersionUID = 2031345935532234141L;
	
	private String parentid;			//上级分行父节点
	private String branchid;			//分行ID
	private String branchcode;			//分行号
	private String branchname;			//分行名称
	private String branchtype;			//分行类型
	
	public String getParentid() {
		return parentid;
	}
	public void setParentid(String parentid) {
		this.parentid = parentid;
	}
	public String getBranchid() {
		return branchid;
	}
	public void setBranchid(String branchid) {
		this.branchid = branchid;
	}
	public String getBranchcode() {
		return branchcode;
	}
	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public String getBranchtype() {
		return branchtype;
	}
	public void setBranchtype(String branchtype) {
		this.branchtype = branchtype;
	}
	
	@Override
	public String toString() {
		return "SuapBranchModel [parentid=" + parentid + ", branchid=" + branchid + ", branchcode=" + branchcode
				+ ", branchname=" + branchname + ", branchtype=" + branchtype + "]";
	}
	
	
	
	
	
	
	
	
}
