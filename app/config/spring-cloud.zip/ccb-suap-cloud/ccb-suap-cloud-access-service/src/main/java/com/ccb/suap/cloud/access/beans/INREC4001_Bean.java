package com.ccb.suap.cloud.access.beans;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom2;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1008ServiceInVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1008ServiceOutVo;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.service.GPUMPService;
import com.ccb.suap.cloud.access.service.SuapCustDeviceInfoService;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapFaceConfigUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC4001ServiceInVo;
import com.ccb.suap.cloud.access.vo.INREC4001ServiceOutVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.string.StringUtils;

@Controller("INREC4001")
public class INREC4001_Bean extends INRECBean{

	private static final Logger LOGGER = LoggerFactory.getLogger(INREC4001_Bean.class);
	
	@Autowired
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	
	@Autowired
	private GPUMPService GPUMPService;
	
//	private SuapCustDeviceInfoService suapCustDeviceInfoService= InrecDaoFactory.getDaoManager().getSuapCustDeviceInfoService();
//	private GPUMPService GPUMPService=InrecDaoFactory.getDaoManager().getGPUMPService();
	
	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg, TxRequestMsg reqMsg,TraceLog traceLog) throws Exception {
		LOGGER.debug("\n------------------调用INREC4001服务------------------");
		ServiceParaUtil.setFaceLogByBaseEntity(reqMsg, FaceLogThreadLocal.get());
		
		setChannelCustNo(rspMsg,reqMsg);
		
		LOGGER.debug("check InVo: "+reqMsg);
		checkParaByServerName(rspMsg, reqMsg);
		
		TxRequestMsg gpump1008ReqMsg = getGPUMP1008ReqMsg(reqMsg);
		LOGGER.debug("send GPUMP1008");
		long beforeSelectCustInfo = System.currentTimeMillis();
		TxResponseMsg gpump1008Rsp = GPUMPService.sendGPUMP1008(gpump1008ReqMsg,traceLog);
		long sendGPUMP1008 = System.currentTimeMillis()-beforeSelectCustInfo;
		traceLog.setSendGpump1008Time(sendGPUMP1008);
		traceLog.setHttpcost(traceLog.getHttpcost()+traceLog.getSendGpump1008Time());
		
		LOGGER.debug("return by GPUMP1008: "+gpump1008Rsp);
		if(!"000000000000".equals(gpump1008Rsp.getTx_header().getSys_resp_code())) 
			throw new CommonRuntimeException(gpump1008Rsp);
		
		INREC4001ServiceOutVo inrec4001RspEntity = new INREC4001ServiceOutVo();
		GPUMP1008ServiceOutVo gpump1008RspEntity = (GPUMP1008ServiceOutVo) gpump1008Rsp.getTx_body().getEntity();
		inrec4001RspEntity.setSimilarity(gpump1008RspEntity.getSimilarity());
		
		rspMsg.getTx_body().setEntity(inrec4001RspEntity);
		
		return rspMsg;
	}
	
	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		
		INREC4001ServiceInVo inrec4001ReqEntity = (INREC4001ServiceInVo) reqMsg.getTx_body().getEntity();
		String name = inrec4001ReqEntity.getName();
		String face_image = inrec4001ReqEntity.getFace_image();
		
		if("".equals(name) || name == null)
			throw new CommonRuntimeException(Errorcode.CSTNAMENOTNULL);
		if("".equals(face_image) || face_image == null)
			throw new CommonRuntimeException(Errorcode.FACEIMGNOTNULL);
		
	}
	
	// TODO
//	@Override
//	public void setTime() {
//		StringBuilder SB = new StringBuilder();
//		
//		SB.append("selectCustDevInfo(").append(selectCustDevInfo)
//		.append(")/sendGPUMP1008(").append(sendGPUMP1008)
//		.append(")");
//		
//		SuapFaceLogModel faceLog = super.getFaceLog();
//		faceLog.setCosttimeinfo(SB.toString());
//		
//	}
	
	
	/**
	 * 	通过id_type,id_no,channelId查出渠道客户号
	 * @param rspMsg
	 * @param reqMsg
	 */
	private void setChannelCustNo(TxResponseMsg rspMsg, TxRequestMsg reqMsg) {
		INREC4001ServiceInVo inrec4001ReqEntity = (INREC4001ServiceInVo) reqMsg.getTx_body().getEntity();
		
		if(inrec4001ReqEntity.getChannel_custno() != null)
			return;
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		
		if("1".equals(locationIndex)) {
			inrec4001ReqEntity.setChannel_custno(inrec4001ReqEntity.getId_no());
			return;
		}
		
		String id_type = inrec4001ReqEntity.getId_type();
		if("".equals(id_type) || id_type == null)
			throw new CommonRuntimeException(Errorcode.ID_TYPENOTNULL);
		String id_no = inrec4001ReqEntity.getId_no();
		if("".equals(id_no) || id_no == null)
			throw new CommonRuntimeException(Errorcode.ID_NUMBNOTNULL);
		String num = String.valueOf(StringUtils.getBiolInfoTableID(id_type+id_no));
		SuapCustDeviceInfoModel suapCustDeviceInfoModel = suapCustDeviceInfoService.select(num, id_type, id_no, reqMsg.getTx_body().getCom1().getSysChannelID());
		
		if(suapCustDeviceInfoModel == null)
			throw new CommonRuntimeException(Errorcode.CHANLCSTNONULL);
		
		inrec4001ReqEntity.setChannel_custno(suapCustDeviceInfoModel.getChannel_cstno());
		
	}
	
	
	/**
	 * GPUMP1008请求信息封装
	 * @param reqMsg
	 * @return
	 */
	private TxRequestMsg getGPUMP1008ReqMsg(TxRequestMsg reqMsg) {
		TxRequestMsg gpump1008ReqMsg = ServiceParaUtil.newReqMsg(reqMsg);
		INREC4001ServiceInVo inrec4001ReqEntity = (INREC4001ServiceInVo) reqMsg.getTx_body().getEntity();
		GPUMP1008ServiceInVo gpump1008ReqEntity = new GPUMP1008ServiceInVo();
		
		TxRequestMsgCom1 com1 = reqMsg.getTx_body().getCom1();
		SuapFaceConfigModel faceConfig = SuapFaceConfigUtil.getFaceConfig(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		
		TxRequestMsgCom2 com2 = new TxRequestMsgCom2();
		com2.setSysChannelID(com1.getSysChannelID());
		com2.setGroupName(faceConfig.getLocation_source());
		
		String locationIndex = SuapFaceConfigUtil.getLocationIndex(com1.getSysChannelID()+":"+com1.getChannelTxCode()+":"+reqMsg.getTx_header().getSys_tx_code());
		if("1".equals(locationIndex)) 
			gpump1008ReqEntity.setCust_id(inrec4001ReqEntity.getId_no());
		if("2".equals(locationIndex)) 
			gpump1008ReqEntity.setCust_id(inrec4001ReqEntity.getChannel_custno());
		
		gpump1008ReqEntity.setFace_image(inrec4001ReqEntity.getFace_image());
		
		gpump1008ReqMsg.getTx_body().setCom2(com2);
		gpump1008ReqMsg.getTx_body().setEntity(gpump1008ReqEntity);
		
		return gpump1008ReqMsg;
	}

	
	
	
	
	

	
	
	
	
	
}
