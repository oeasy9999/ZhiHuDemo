package com.ccb.suap.cloud.access.gpump.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class GPUMP1002ServiceInVo extends TxRequestMsgEntity{
	
	private String face_image;			//人脸图片
	private String face_eigen;			//人脸特征值
	private String hit_size;			//命中数，默认为1
	private String threshold;			//人脸比对阈值
	
	public String getFace_image() {
		return face_image;
	}
	public void setFace_image(String face_image) {
		this.face_image = face_image;
	}
	public String getFace_eigen() {
		return face_eigen;
	}
	public void setFace_eigen(String face_eigen) {
		this.face_eigen = face_eigen;
	}
	public String getHit_size() {
		return hit_size;
	}
	public void setHit_size(String hit_size) {
		this.hit_size = hit_size;
	}
	public String getThreshold() {
		return threshold;
	}
	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}
	
	@Override
	public String toString() {
		return "GPUMP1002ServiceInVo [face_image=" + face_image + ", face_eigen=" + face_eigen + ", hit_size="
				+ hit_size + ", threshold=" + threshold + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
