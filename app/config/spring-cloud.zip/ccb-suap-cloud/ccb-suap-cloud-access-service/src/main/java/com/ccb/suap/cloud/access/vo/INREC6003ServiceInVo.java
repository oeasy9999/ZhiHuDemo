package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class INREC6003ServiceInVo extends TxRequestMsgEntity{
	
	private String ccbTraceId;				//
	private String deviceType;				//
	private String transId;					//
	private String msgContent;				//告警信息
	private String chanelId;				//
	private String channelTxCode;			//
	private String date;					//
	
	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getMsgContent() {
		return msgContent;
	}

	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}

	public String getChanelId() {
		return chanelId;
	}

	public void setChanelId(String chanelId) {
		this.chanelId = chanelId;
	}

	public String getChannelTxCode() {
		return channelTxCode;
	}

	public void setChannelTxCode(String channelTxCode) {
		this.channelTxCode = channelTxCode;
	}

	public String getCcbTraceId() {
		return ccbTraceId;
	}

	public void setCcbTraceId(String ccbTraceId) {
		this.ccbTraceId = ccbTraceId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "INREC6003ServiceInVo [ccbTraceId=" + ccbTraceId
				+ ", deviceType=" + deviceType + ", transId=" + transId
				+ ", msgContent=" + msgContent + ", chanelId=" + chanelId
				+ ", channelTxCode=" + channelTxCode + ", date=" + date + "]";
	}


	
}
