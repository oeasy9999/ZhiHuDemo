package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class INREC1005ServiceOutVo extends TxResponseMsgEntity{
	
	private String isexist;				//客户是否存在

	public String getIsexist() {
		return isexist;
	}

	public void setIsexist(String isexist) {
		this.isexist = isexist;
	}

	@Override
	public String toString() {
		return "INREC2005ServiceOutVo [isexist=" + isexist + "]";
	}
	
	
	
}
