package com.ccb.suap.cloud.access.vo;

public class INREC1005ServiceInVo extends INRECBaseServiceInVo{
	
	
	
	
	
	
	
}
