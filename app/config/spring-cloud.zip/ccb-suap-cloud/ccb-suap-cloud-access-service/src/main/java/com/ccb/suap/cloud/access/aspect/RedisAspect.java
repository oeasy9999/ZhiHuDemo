package com.ccb.suap.cloud.access.aspect;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.annotation.RedisAnnotation;
import com.ccb.suap.cloud.access.annotation.RedisAnnotation.actionType;
import com.ccb.suap.cloud.access.annotation.RedisAnnotation.dataType;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;
import com.ccb.suap.cloud.access.model.SuapCustInfoModel;
import com.ccb.suap.cloud.access.service.RedisService;

@Aspect
@Component
@Order(4)
public class RedisAspect {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Autowired
	private RedisService redisService;
	
	
	@Around("@annotation(redisAnnotation)")
	public Object redisEntity(ProceedingJoinPoint jp,RedisAnnotation redisAnnotation) throws Exception{
		
		Object obj = null;
		
		//执行方法前先用redis进行处理，如需继续执行目标方法请返回null
		obj = beforeExec(jp.getArgs(), redisAnnotation);
		if(obj != null)
			return obj;
		
		try {
			obj = jp.proceed();
		} catch (CommonRuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		} catch (Throwable e) {
			LOGGER.error("RedisAspect切面调用失败", e);
			throw new CommonRuntimeException(Errorcode.REDIS_ASPERROR, "02", "RedisAspect切面调用失败: "+e.getMessage());
		}
		
		afterExec(jp, redisAnnotation, obj);
		
		return obj;
	}


	/**
	 * 	方法执行前处理客户信息或者渠道注册信息
	 * 1.新增方法执行前暂不做任何操作
	 * 2.删除方法执行前删除redis中对应数据
	 * 3.修改方法执行前删除redis中对应数据
	 * 4.查询方法执行前查找redis中对应数据，非空则返回(跳过目标方法)
	 * @param args
	 * @param dataType
	 * @return
	 */
	private Object beforeExec(Object[] args, RedisAnnotation redisAnnotation) {
		
		actionType actionType = redisAnnotation.actionType();
		dataType dataType = redisAnnotation.dataType();
		
		switch (actionType) {
		case INSERT:
			// TODO 
			return null;
		case DELETE:
			return deleteBefore(args, dataType);
		case UPDATE:
			return updateBefore(args, dataType);
		case SELECT:
			return selectBefore(args, dataType);

		default:
			break;
		}
		
		return null;
	}


	/**
	 * 删除redis中客户及渠道信息
	 * @param args
	 * @param dataType
	 * @return
	 */
	private Object deleteBefore(Object[] args, dataType dataType) {
		switch (dataType) {
		case CUSTINFO:
			deleteCustInfo(args);
			break;
		case CUSTDEVICEINFO:
			deleteCustDeviceInfo(args);
			break;

		default:
			break;
		}
		
		return null;
	}


	/**
	 * 更新前删除redis中客户及渠道信息
	 * @param args
	 * @param dataType
	 * @return
	 */
	private Object updateBefore(Object[] args, dataType dataType) {
		
		switch (dataType) {
		case CUSTINFO:
			deleteCustInfoBefore(args);
			break;
		case CUSTDEVICEINFO:
			deleteCustDeviceInfoBefore(args);
			break;

		default:
			break;
		}
		
		return null;
	}


	/**
	 * 执行方法前删除redis中客户信息
	 * @param args
	 */
	private void deleteCustInfoBefore(Object[] args) {
		removeCustInfo((SuapCustInfoModel) args[0]);
	}


	/**
	 * 执行方法前删除redis中渠道注册信息
	 * @param args
	 */
	private void deleteCustDeviceInfoBefore(Object[] args) {
		removeCustDeviceInfo((SuapCustDeviceInfoModel) args[0]);
		
	}


	/**
	 * 从redis中读取客户信息
	 * @param args
	 * @param dataType
	 * @return
	 */
	private Object selectBefore(Object[] args, dataType dataType) {
		Object obj = null;
		
		switch (dataType) {
		case CUSTINFO:
			obj = selectCustInfoByArgs(args);
			break;
		case CUSTDEVICEINFO:
			obj = selectCustDeviceInfoByArgs(args);
			break;

		default:
			break;
		}
		
		return obj;
	}


	/**
	 * 	从redis中查找客户信息
	 * @param args
	 * @return
	 */
	private Object selectCustInfoByArgs(Object[] args) {
		
		String idtype = (String) args[1];
		String idno = (String) args[2];
		String key = idtype + "_" + idno;
		
		String json = redisService.get(key);
		
		SuapCustInfoModel custInfo = toJavaObject(json, key, SuapCustInfoModel.class);
		
		return custInfo;
	}


	/**
	 * 	从redis中查找渠道注册信息
	 * @param args
	 * @return
	 */
	private Object selectCustDeviceInfoByArgs(Object[] args) {

		String idtype = (String) args[1];
		String idno = (String) args[2];
		String channelid = (String) args[3];
		String key = idtype + "_" + idno + "_" + channelid;
		
		String json = redisService.get(key);
		
		SuapCustDeviceInfoModel custDeviceInfo = toJavaObject(json, key, SuapCustDeviceInfoModel.class);
		
		return custDeviceInfo;
	}


	/**
	 * 	方法执行后处理客户信息或者渠道注册信息
	 * 1.新增方法执行后将对应数据保存到redis中
	 * 2.删除方法执行后暂不做操作
	 * 3.修改方法执行后将对应数据保存到redis中
	 * 4.查找方法将查出来的数据存到redis中
	 * @param jp
	 * @param redisAnnotation
	 */
	private void afterExec(ProceedingJoinPoint jp, RedisAnnotation redisAnnotation, Object obj) {
		
		actionType actionType = redisAnnotation.actionType();
		dataType dataType = redisAnnotation.dataType();
		Object[] args = jp.getArgs();
		
		switch (actionType) {
		case INSERT:
			insertAfter(args, dataType);
			break;
		case DELETE:
//			deleteAfter(args, dataType);
			// TODO
			break;
		case UPDATE:
			updateAfter(args, dataType);
			break;
		case SELECT:
			insertRedis(dataType, obj);
			break;

		default:
			break;
		}
		
		
	}


	/**
	 * 	同步新增redis信息
	 * @param args
	 * @param dataType
	 */
	private void insertAfter(Object[] args, dataType dataType) {
		
		switch (dataType) {
		case CUSTINFO:
			insertCustInfoByArgs(args);
			break;
		case CUSTDEVICEINFO:
			insertCustDeviceInfoByArgs(args);
			break;

		default:
			break;
		}
		
	}


	/**
	 * redis保存客户信息
	 * @param args
	 */
	private void insertCustInfoByArgs(Object[] args) {
		insertCustInfo((SuapCustInfoModel) args[0]);
		
	}


	/**
	 * redis保存渠道注册信息
	 * @param args
	 */
	private void insertCustDeviceInfoByArgs(Object[] args) {
		insertCustDeviceInfo((SuapCustDeviceInfoModel) args[0]);
		
	}


//	/**
//	 * 	同步删除redis信息
//	 * @param args
//	 * @param dataType
//	 */
//	private void deleteAfter(Object[] args, dataType dataType) {
//		
//		switch (dataType) {
//		case CUSTINFO:
//			deleteCustInfo(args);
//			break;
//		case CUSTDEVICEINFO:
//			deleteCustDeviceInfo(args);
//			break;
//
//		default:
//			break;
//		}
//		
//	}


	/**
	 * 删除redis中客户信息
	 * @param args
	 */
	private void deleteCustInfo(Object[] args) {
		// TODO waitting to do
	}


	/**
	 * 删除redis中渠道注册信息
	 * @param args
	 */
	private void deleteCustDeviceInfo(Object[] args) {
		
		String idtype = (String) args[1];
		String idno = (String) args[2];
		String channelid = (String) args[3];
		String key = idtype + "_" + idno + "_" + channelid;
		
		redisService.delete(key);
		
	}


	/**
	 * 	同步修改redis信息
	 * @param args
	 * @param dataType
	 */
	private void updateAfter(Object[] args, dataType dataType) {
		
		switch (dataType) {
		case CUSTINFO:
			updateCustInfoByArgs(args);
			break;
		case CUSTDEVICEINFO:
			updateCustDeviceInfoByArgs(args);
			break;

		default:
			break;
		}
		
	}


	/**
	 * 更改redis中客户信息
	 * @param args
	 */
	private void updateCustInfoByArgs(Object[] args) {
		insertCustInfo((SuapCustInfoModel) args[0]);
		
	}


	/**
	 * 更改redis中渠道注册信息
	 * @param args
	 */
	private void updateCustDeviceInfoByArgs(Object[] args) {
		insertCustDeviceInfo((SuapCustDeviceInfoModel) args[0]);
		
	}
	
	
	/**
	 * 将数据库中查询出来的数据存到redis中
	 * @param args
	 * @param dataType
	 * @param obj
	 */
	private void insertRedis(dataType dataType, Object obj) {
		
		if(obj == null)
			return;
		
		switch (dataType) {
		case CUSTINFO:
			insertCustInfo((SuapCustInfoModel)obj);
			break;
		case CUSTDEVICEINFO:
			insertCustDeviceInfo((SuapCustDeviceInfoModel)obj);
			break;

		default:
			break;
		}
		
	}

	
	/**
	 * 将客户信息存储到redis中
	 * @param obj
	 */
	private void insertCustInfo(SuapCustInfoModel custInfo) {
		String key = custInfo.getIdtype() + "_" + custInfo.getIdnumber();
		
		try {
			redisService.set(key, toJson(custInfo));
		} catch (Exception e) {
		}
		
	}


	/**
	 * 将渠道注册信息存储到redis中
	 * @param obj
	 */
	private void insertCustDeviceInfo(SuapCustDeviceInfoModel custDeviceInfo) {
		String key = custDeviceInfo.getIdtype() + "_" + custDeviceInfo.getIdnumber() + "_" + custDeviceInfo.getChannelid();
		
		try {
			redisService.set(key, toJson(custDeviceInfo));
		} catch (Exception e) {
		}
		
	}

	
	/**
	 * 移除redis中客户信息
	 * @param custInfo
	 */
	private void removeCustInfo(SuapCustInfoModel custInfo) {
		String key = custInfo.getIdtype() + "_" + custInfo.getIdnumber();
		
		redisService.delete(key);
	}
	
	
	/**
	 * 移除redis中渠道注册信息
	 * @param custDeviceInfo
	 */
	private void removeCustDeviceInfo(SuapCustDeviceInfoModel custDeviceInfo) {
		String key = custDeviceInfo.getIdtype() + "_" + custDeviceInfo.getIdnumber() + "_" + custDeviceInfo.getChannelid();
		
		redisService.delete(key);
	}
	

	private <T> T toJavaObject(String json, String key, Class<T> T){
		
		if(StringUtils.isBlank(json))
			return null;
		
		T t = null;
		try {
			t = JSONObject.toJavaObject(JSONObject.parseObject(json), T);
		} catch (Exception e) {
			LOGGER.error("数据转换异常,key = " + key,e);
			throw new CommonRuntimeException(Errorcode.DATACHANGERROR, "02", "key = " + key + " " + e.getMessage());
		}
		
		return t;
	};


	private String toJson(Object obj) {
		String json = null;
		
		try {
			json = JSONObject.toJSONString(obj);
		} catch (Exception e) {
			LOGGER.error("数据转换异常,obj = " + obj,e);
			throw new CommonRuntimeException(Errorcode.DATACHANGERROR, "02", "obj = " + obj + " " + e.getMessage());
		}
		
		return json;
	}
	
	
	
	
	
	
}
