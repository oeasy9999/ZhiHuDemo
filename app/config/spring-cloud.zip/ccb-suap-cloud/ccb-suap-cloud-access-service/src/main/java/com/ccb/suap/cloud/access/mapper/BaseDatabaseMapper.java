package com.ccb.suap.cloud.access.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface BaseDatabaseMapper {
	
	
	@Select("select 1 from dual")
	public String heartBeat();
	
	
	
	
	
}
