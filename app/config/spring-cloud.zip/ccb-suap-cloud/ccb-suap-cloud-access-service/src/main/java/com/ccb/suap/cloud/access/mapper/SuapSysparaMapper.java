package com.ccb.suap.cloud.access.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.ccb.suap.cloud.access.model.SuapSysparaModel;

@Mapper
public interface SuapSysparaMapper {
	
	@Insert("insert into SUAP_SYSPARA(PARACODE,PARANAME,PARAVALUE,PARATYPE,REMARK) values(#{paracode},#{paraname},#{paravalue},#{paratype},#{remark})")
	int insert(SuapSysparaModel suapSysparaModel);
	
	@Select("select * from SUAP_SYSPARA")
	List<SuapSysparaModel> selectAll();
	
	@Select("SELECT * FROM SUAP_SYSPARA WHERE paracode=#{paracode} AND paratype='1' AND deployid=#{deployid}")
	SuapSysparaModel selectServerPara(@Param("paracode") String paracode, @Param("deployid") String deployid);
	
	@Select("SELECT * FROM SUAP_SYSPARA WHERE paracode=#{paracode} AND paratype=#{paratype}")
	SuapSysparaModel select(@Param("paracode") String paracode, @Param("paratype") String paratype);
	
	
	
}
