package com.ccb.suap.cloud.access.vo;

public class INREC3002ServiceInVo extends INRECBaseServiceInVo{
	
	
	
	
	
	
	
}
