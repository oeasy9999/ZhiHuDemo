package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class INRECBaseServiceInVo extends TxRequestMsgEntity{
	
	private String id_type;				//证件类型
	private String id_no;				//证件号码
	private String name;				//姓名
	private String channel_custno;		//渠道客户号
	private String ccb_custno;			//建行P6客户号码
	private String branch_id;			//分行号
	private String mobile_no;			//手机号码
	
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getChannel_custno() {
		return channel_custno;
	}
	public void setChannel_custno(String channel_custno) {
		this.channel_custno = channel_custno;
	}
	public String getCcb_custno() {
		return ccb_custno;
	}
	public void setCcb_custno(String ccb_custno) {
		this.ccb_custno = ccb_custno;
	}
	public String getBranch_id() {
		return branch_id;
	}
	public void setBranch_id(String branch_id) {
		this.branch_id = branch_id;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	
	@Override
	public String toString() {
		return "INREC2004ServiceInVo [id_type=" + id_type + ", id_no=" + id_no + ", name=" + name + ", channel_custno="
				+ channel_custno + ", ccb_custno=" + ccb_custno + ", branch_id=" + branch_id + ", mobile_no="
				+ mobile_no + "]";
	}
	
	
	
	
}
