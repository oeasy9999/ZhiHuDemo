package com.ccb.suap.cloud.access.dao.factory;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ccb.suap.cloud.access.client.GPUMPClient;
import com.ccb.suap.cloud.access.service.GPUMPService;
import com.ccb.suap.cloud.access.service.INRECBeansService;
import com.ccb.suap.cloud.access.service.OutBoundService;
import com.ccb.suap.cloud.access.service.RedisService;
import com.ccb.suap.cloud.access.service.RestTemplateService;
import com.ccb.suap.cloud.access.service.SuapBranchService;
import com.ccb.suap.cloud.access.service.SuapChannelInfoService;
import com.ccb.suap.cloud.access.service.SuapCustBlackListService;
import com.ccb.suap.cloud.access.service.SuapCustDeviceInfoService;
import com.ccb.suap.cloud.access.service.SuapCustInfoService;
import com.ccb.suap.cloud.access.service.SuapCustWhiteListService;
import com.ccb.suap.cloud.access.service.SuapErrorInfoService;
import com.ccb.suap.cloud.access.service.SuapFaceConfigService;
import com.ccb.suap.cloud.access.service.SuapFaceLogService;
import com.ccb.suap.cloud.access.service.SuapSysparaService;
import com.ccb.suap.cloud.access.service.SuapTxChannelAuthService;
import com.ccb.suap.cloud.access.service.SuapTxattrService;
import com.ccb.suap.cloud.access.service.SuapVendorInfoService;
import com.ccb.suap.cloud.access.service.SuapWhiteListService;


@Service(value="daoManager")
@Transactional
public class DaoManagerService {

	@Resource
	private SuapBranchService suapBranchService;
	@Resource
	private SuapChannelInfoService suapChannelInfoService;
	@Resource
	private SuapCustDeviceInfoService suapCustDeviceInfoService;
	@Resource
	private SuapCustInfoService suapCustInfoService;
	@Resource
	private SuapErrorInfoService suapErrorInfoService;
	@Resource
	private SuapFaceConfigService suapFaceConfigService;
	@Resource
	private SuapFaceLogService suapFaceLogService;
	@Resource
	private SuapSysparaService suapSysparaService;
	@Resource
	private SuapTxattrService suapTxattrService;
	@Resource
	private SuapTxChannelAuthService suapTxChannelAuthService;
	@Resource
	private SuapVendorInfoService suapVendorInfoService;
	@Resource
	private OutBoundService outBoundService;
	@Resource
	private GPUMPClient GPUMPClient;
	@Resource
	private GPUMPService GPUMPService;
	@Resource
	private SuapWhiteListService suapWhiteListService;
	@Resource
	private INRECBeansService INRECBeansService;
	@Resource
	private RestTemplateService restTemplateService;
	@Resource
	private SuapCustBlackListService suapBlackNameListService;
	@Resource
	private SuapCustWhiteListService suapWhiteNameListService;
	@Resource
	private RedisService redisService;
	
	public SuapBranchService getSuapBranchService() {
		return suapBranchService;
	}
	public void setSuapBranchService(SuapBranchService suapBranchService) {
		this.suapBranchService = suapBranchService;
	}
	public SuapChannelInfoService getSuapChannelInfoService() {
		return suapChannelInfoService;
	}
	public void setSuapChannelInfoService(SuapChannelInfoService suapChannelInfoService) {
		this.suapChannelInfoService = suapChannelInfoService;
	}
	public SuapCustDeviceInfoService getSuapCustDeviceInfoService() {
		return suapCustDeviceInfoService;
	}
	public void setSuapCustDeviceInfoService(SuapCustDeviceInfoService suapCustDeviceInfoService) {
		this.suapCustDeviceInfoService = suapCustDeviceInfoService;
	}
	public SuapCustInfoService getSuapCustInfoService() {
		return suapCustInfoService;
	}
	public void setSuapCustInfoService(SuapCustInfoService suapCustInfoService) {
		this.suapCustInfoService = suapCustInfoService;
	}
	public SuapErrorInfoService getSuapErrorInfoService() {
		return suapErrorInfoService;
	}
	public void setSuapErrorInfoService(SuapErrorInfoService suapErrorInfoService) {
		this.suapErrorInfoService = suapErrorInfoService;
	}
	public SuapFaceConfigService getSuapFaceConfigService() {
		return suapFaceConfigService;
	}
	public void setSuapFaceConfigService(SuapFaceConfigService suapFaceConfigService) {
		this.suapFaceConfigService = suapFaceConfigService;
	}
	public SuapFaceLogService getSuapFaceLogService() {
		return suapFaceLogService;
	}
	public void setSuapFaceLogService(SuapFaceLogService suapFaceLogService) {
		this.suapFaceLogService = suapFaceLogService;
	}
	public SuapSysparaService getSuapSysparaService() {
		return suapSysparaService;
	}
	public void setSuapSysparaService(SuapSysparaService suapSysparaService) {
		this.suapSysparaService = suapSysparaService;
	}
	public SuapTxattrService getSuapTxattrService() {
		return suapTxattrService;
	}
	public void setSuapTxattrService(SuapTxattrService suapTxattrService) {
		this.suapTxattrService = suapTxattrService;
	}
	public SuapTxChannelAuthService getSuapTxChannelAuthService() {
		return suapTxChannelAuthService;
	}
	public void setSuapTxChannelAuthService(SuapTxChannelAuthService suapTxChannelAuthService) {
		this.suapTxChannelAuthService = suapTxChannelAuthService;
	}
	public SuapVendorInfoService getSuapVendorInfoService() {
		return suapVendorInfoService;
	}
	public void setSuapVendorInfoService(SuapVendorInfoService suapVendorInfoService) {
		this.suapVendorInfoService = suapVendorInfoService;
	}
	public OutBoundService getOutBoundService() {
		return outBoundService;
	}
	public void setOutBoundService(OutBoundService outBoundService) {
		this.outBoundService = outBoundService;
	}
	public GPUMPClient getGPUMPClient() {
		return GPUMPClient;
	}
	public void setGPUMPClient(GPUMPClient gPUMPClient) {
		GPUMPClient = gPUMPClient;
	}
	public GPUMPService getGPUMPService() {
		return GPUMPService;
	}
	public void setGPUMPService(GPUMPService gPUMPService) {
		GPUMPService = gPUMPService;
	}
	public SuapWhiteListService getSuapWhiteListService() {
		return suapWhiteListService;
	}
	public void setSuapWhiteListService(SuapWhiteListService suapWhiteListService) {
		this.suapWhiteListService = suapWhiteListService;
	}
	public INRECBeansService getINRECBeansService() {
		return INRECBeansService;
	}
	public void setINRECBeansService(INRECBeansService iNRECBeansService) {
		INRECBeansService = iNRECBeansService;
	}
	public RestTemplateService getRestTemplateService() {
		return restTemplateService;
	}
	public void setRestTemplateService(RestTemplateService restTemplateService) {
		this.restTemplateService = restTemplateService;
	}
	public SuapCustBlackListService getSuapBlackNameListService() {
		return suapBlackNameListService;
	}
	public void setSuapBlackNameListService(SuapCustBlackListService suapBlackNameListService) {
		this.suapBlackNameListService = suapBlackNameListService;
	}
	public SuapCustWhiteListService getSuapWhiteNameListService() {
		return suapWhiteNameListService;
	}
	public void setSuapWhiteNameListService(SuapCustWhiteListService suapWhiteNameListService) {
		this.suapWhiteNameListService = suapWhiteNameListService;
	}
	public RedisService getRedisService() {
		return redisService;
	}
	public void setRedisService(RedisService redisService) {
		this.redisService = redisService;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
