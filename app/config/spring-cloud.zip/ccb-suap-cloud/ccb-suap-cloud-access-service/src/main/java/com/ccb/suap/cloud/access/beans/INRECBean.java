package com.ccb.suap.cloud.access.beans;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.inf.TrxInterface;
import com.ccb.suap.util.log.TraceLog;

public abstract class INRECBean implements TrxInterface{
	
	
	public INRECBean(){
		super();
	}
	
	public abstract TxResponseMsg  executeProcess(TxResponseMsg rspMsg,TxRequestMsg reqMsg,TraceLog traceLog)throws Exception;
	
	
	
	
	
	
}
