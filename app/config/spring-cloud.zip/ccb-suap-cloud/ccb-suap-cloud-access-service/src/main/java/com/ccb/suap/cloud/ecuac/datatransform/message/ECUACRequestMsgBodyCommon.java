package com.ccb.suap.cloud.ecuac.datatransform.message;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class ECUACRequestMsgBodyCommon implements Serializable {
	
	private static final long serialVersionUID = -703732272L;
	
	@XStreamAlias("COM1")
	private ECUACRequestMsgBodyCom1 com1;

	public ECUACRequestMsgBodyCom1 getCom1() {
		return com1;
	}

	public void setCom1(ECUACRequestMsgBodyCom1 com1) {
		this.com1 = com1;
	}

	@Override
	public String toString() {
		return "TxRequestMsgBodyCommon [com1=" + com1 + "]";
	}
	
	
	
	
	
}