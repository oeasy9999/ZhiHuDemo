package com.ccb.suap.cloud.access.aspect;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.annotation.TraceLogAnnotation;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.threadLocal.TraceLogThreadLocal;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.log.TraceLog_Entity;

@Aspect
@Component
@Order(2)
public class TraceLogAspect {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Around("@annotation(traceLogAnnotation)")
	public Object CacheEntity(ProceedingJoinPoint jp,TraceLogAnnotation traceLogAnnotation) throws Exception{
		TraceLog traceLog = TraceLogThreadLocal.get();
		TraceLog_Entity traceLog_Entity = new TraceLog_Entity();
		traceLog.getEntity_list().add(traceLog_Entity);
		
		String title = getTitle(jp, traceLogAnnotation);
		String reqMsg_trace = getReqMsg(jp);
		
		traceLog.setUrl(title);
		traceLog_Entity.setName(title);
		traceLog_Entity.setRequestMessage(reqMsg_trace);
		
		long start = System.currentTimeMillis();
		
		Object obj = null;
		try {
			obj = jp.proceed();
		} catch (CommonRuntimeException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		} catch (Throwable e) {
			LOGGER.error("CosttimeAspect切面调用失败", e);
			throw new CommonRuntimeException(Errorcode.COSTT_ASPERROR, "02", "CosttimeAspect切面调用失败: "+e.getMessage());
		}
		
		long costtime = System.currentTimeMillis() - start;
		traceLog_Entity.setCosttime(costtime);
		traceLog.setHttpcost(traceLog.getHttpcost() + costtime);
		
		if(obj instanceof String) {
			traceLog_Entity.setResponseMessage((String)obj);
		}else {
			traceLog_Entity.setResponseMessage(toJson(obj));
		}
		
		return obj;
	}


	/**
	 * 	获取交易名称
	 * @param jp
	 * @param traceLogAnnotation
	 * @return
	 */
	private String getTitle(ProceedingJoinPoint jp, TraceLogAnnotation traceLogAnnotation) {
		
		if(StringUtils.isNotBlank(traceLogAnnotation.title()))
			return traceLogAnnotation.title();
		
		if(StringUtils.isNotBlank(traceLogAnnotation.value()))
			return traceLogAnnotation.value();
		
		return jp.getSignature().getName();
	}
	
	
	/**
	 * 	获取请求报文
	 * @param jp
	 * @return
	 */
	private String getReqMsg(ProceedingJoinPoint jp) {
		Object[] args = jp.getArgs();
		Object reqMsg = args[0];
		
		if(reqMsg instanceof String)
			return (String) reqMsg;
		
		return toJson(reqMsg);
	}
	
	
	
	
	
	
	
	
	private String toJson(Object obj) {
		String json = null;
		
		try {
			json = JSONObject.toJSONString(obj);
		} catch (Exception e) {
			LOGGER.error("数据转换异常,obj = " + obj,e);
			throw new CommonRuntimeException(Errorcode.DATACHANGERROR, "02", "obj = " + obj + " " + e.getMessage());
		}
		
		return json;
	}
	
	
	
	
}
