package com.ccb.suap.cloud.access.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.config.SpringContextUtil;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgBody;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.inf.TrxInterface;
import com.ccb.suap.cloud.access.mapper.TraceLogger;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;
import com.ccb.suap.cloud.access.service.SuapFaceLogService;
import com.ccb.suap.cloud.access.service.utils.JSONObjectUtil;
import com.ccb.suap.cloud.access.service.utils.PhotoUtil;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SimpleDateFormatUtil;
import com.ccb.suap.cloud.access.service.utils.SuapErrorInfoUtil;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.threadLocal.TraceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC6002ServiceInVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.log.TraceLog_Entity;

@RefreshScope
@Controller
@RequestMapping("/")
public class FaceServiceController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
//	@Value("${image}")
//	private String image;
	
	@Autowired
	private TraceLogger traceLogger;
	
	@Autowired
	private SuapFaceLogService faceLogService;

	
	@RequestMapping(value = "/InrecService/{txcode}", produces = "application/json; charset=utf-8")
	@ResponseBody
	public TxResponseMsg inServer(@PathVariable("txcode") String txcode, @RequestBody JSONObject json) throws Exception {
		LOGGER.debug("\n\n\n------------------请求信息------------------\n"+json);
		
//		设置响应请求头和响应报文体
		TxResponseMsg rspMsg = new TxResponseMsg();
		TxResponseMsgHead rspHeader = new TxResponseMsgHead();
		rspMsg.setTx_header(rspHeader);
		TxResponseMsgBody rspBody = new TxResponseMsgBody();
		rspMsg.setTx_body(rspBody);

		SuapFaceLogModel faceLog = FaceLogThreadLocal.get();
		faceLog.setTxcode(txcode);
		
		TraceLog traceLog = TraceLogThreadLocal.get();
    	traceLog.setMaxValueLength(Integer.parseInt(SuapSysParaUtil.getStrPara("MaxValueLength","100")));
    	traceLog.setLevel(SuapSysParaUtil.getStrPara("LogLevel:1","DEBUG"));
    	traceLog.setRequestJsonString_client(json.toString());
    	traceLog.setLogName(txcode);
    	ArrayList<TraceLog_Entity> traceLog_entityList = new ArrayList<>();
    	traceLog.setEntity_list(traceLog_entityList);
    	
    	
//		设置响应报文头：setSys_recv_time（服务接收时间）
    	Date recv_time = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		rspHeader.setSys_recv_time(sdf.format(recv_time));
		faceLog.setRecvtime(recv_time);

		/*
		 * 处理请求报文信息
		 */
		TxRequestMsg reqMsg = null;
		
		try {
			reqMsg = JSONObjectUtil.toTxRequestMsg(rspMsg, json, txcode ,faceLog);
			traceLog.setTraceId(reqMsg.getTx_header().getSys_evt_trace_id());
		} catch (CommonRuntimeException e1) {
			LOGGER.error("error while parse the json: "+e1.getMessage(),e1);
			throw e1.newInstance(rspMsg, e1.getRspCode(), faceLog, traceLog);
		} catch (Exception e1) {
			faceLog.setRemarks("cause: "+e1.toString()+" \nlocation: "+e1.getStackTrace()[0].getFileName()+"."+e1.getStackTrace()[0].getMethodName()+"."+e1.getStackTrace()[0].getLineNumber());
			LOGGER.error("unknow error while parse the json: "+e1.getMessage(),e1);
			throw new CommonRuntimeException(rspMsg, Errorcode.UNKNOWMSGERROR, faceLog, traceLog);
		}
		LOGGER.debug("after parse the json: "+reqMsg);
		
//		Class<?> cl = TxcodeUtil.getServiceClassByTxcode(txcode);
//		TrxInterface inrecBean = (TrxInterface) cl.newInstance();
//		inrecBean=(TrxInterface) Utils.getInstance(txcode);
		
		TrxInterface inrecBean = (TrxInterface) SpringContextUtil.getBean(txcode);
		try {
//			rspMsg = inrecBean.executeProcess(rspMsg, reqMsg);
			rspMsg = inrecBean.executeProcess(rspMsg, reqMsg,traceLog);
		} catch (CommonRuntimeException e) {
			LOGGER.error("CommonException error: "+e.getMessage(),e);
			throw e.newInstance(rspMsg, e.getRspCode(), faceLog, traceLog);
		}catch (Exception e) {
			faceLog.setRemarks("cause: "+e.toString()+" \nlocation: "+e.getStackTrace()[0].getFileName()+"."+e.getStackTrace()[0].getMethodName()+"."+e.getStackTrace()[0].getLineNumber());
			LOGGER.error("Exception error: "+e.getMessage(),e);
			throw new CommonRuntimeException(rspMsg, Errorcode.UNKNOWMSGERROR, faceLog, traceLog);
		}
		
		rspHeader.setSys_tx_status("00");
		rspHeader.setSys_resp_code("000000000000");
		
		String errorMsg = SuapErrorInfoUtil.getErrorMsg(rspHeader.getSys_resp_code());
		rspHeader.setSys_resp_desc(errorMsg);
		traceLog.setErrormessage(errorMsg);
		
		Date resp_time = new Date();
		rspHeader.setSys_resp_time(sdf.format(resp_time));
		faceLog.setResptime(resp_time);
		LOGGER.debug("request success: " + rspMsg);
		
		LOGGER.debug("LogFlag: "+SuapSysParaUtil.getStrPara("LOGFLAG", null));
		if("1".equals(SuapSysParaUtil.getStrPara("LOGFLAG", null))) {
			ServiceParaUtil.setFaceLogFinally(rspMsg, faceLog);
//			SuapFaceLogThread suapFaceLogThread = new SuapFaceLogThread(faceLog);
//			MultithreadingLogExecutor.addLogTask(suapFaceLogThread);
			faceLogService.handlerFaceLog(faceLog);
		}
		
		traceLog.setEndTime(System.currentTimeMillis());
		traceLog.setResponseJsonString_client(JSONObject.toJSONString(rspMsg));
		
		traceLogger.dispose(traceLog);
		
		return rspMsg;
	}
	
	
	@RequestMapping(value = "/InrecService/INREC6002", produces = "application/json; charset=utf-8")
	@ResponseBody
	public Object imageTransfer(@RequestBody JSONObject json) {
		
		TxResponseMsg rspMsg = new TxResponseMsg();
		TxResponseMsgHead rsp_header = new TxResponseMsgHead();
		TxResponseMsgBody rsp_body = new TxResponseMsgBody();
		TxResponseMsgEntity rsp_entity = new TxResponseMsgEntity();
		
		rspMsg.setTx_header(rsp_header);
		rspMsg.setTx_body(rsp_body);
		rsp_body.setEntity(rsp_entity);
		
		TxRequestMsg reqMsg = getReqMsg(rspMsg, json);
		if(reqMsg == null)
			return rspMsg;
		
		INREC6002ServiceInVo inVo = (INREC6002ServiceInVo) reqMsg.getTx_body().getEntity();
		
		String channelid = reqMsg.getTx_body().getCom1().getSysChannelID();
		String image_name = inVo.getImage_name();
		String face_image = inVo.getImage_name();
		String image_tpye = inVo.getImage_tpye();
		
		if(StringUtils.isBlank(channelid)) {
			rsp_header.setSys_resp_code("channelid is NULL");
			rsp_header.setSys_resp_desc("channelid is NULL");
			return rspMsg;
		}
		if(StringUtils.isBlank(image_name)) {
			rsp_header.setSys_resp_code("image_name is NULL");
			rsp_header.setSys_resp_desc("image_name is NULL");
			return rspMsg;
		}
		if(StringUtils.isBlank(face_image)) {
			rsp_header.setSys_resp_code("face_image is NULL");
			rsp_header.setSys_resp_desc("face_image is NULL");
			return rspMsg;
		}
		if(StringUtils.isBlank(image_tpye)) {
			rsp_header.setSys_resp_code("image_tpye is NULL");
			rsp_header.setSys_resp_desc("image_tpye is NULL");
			return rspMsg;
		}
		
		String base_path = null;
		try {
			base_path = ServiceParaUtil.getBasePthBySyspara("FACEPICPATH", channelid, "LOCAL_TRANSFER");
		} catch (CommonRuntimeException e) {
			rsp_header.setSys_resp_code(e.getRspCode());
			rsp_header.setSys_resp_desc(SuapErrorInfoUtil.getErrorMsg(e.getRspCode()));
			return rspMsg;
		}
		
		String date_path = SimpleDateFormatUtil.getStrNow("yyyy-MM-dd") ;
		
		String path = base_path + "/" + image_tpye.toUpperCase() + "/" + date_path + "/" + image_name;
		PhotoUtil.savePhoto(face_image, path);
		
		rsp_header.setSys_resp_code("000000000000");
		rsp_header.setSys_resp_desc("success");
		
		return rspMsg;
	}


	private TxRequestMsg getReqMsg(TxResponseMsg rspMsg, JSONObject json) {
		TxResponseMsgHead rsp_header = rspMsg.getTx_header();
		
		TxRequestMsg reqMsg = JSONObject.toJavaObject(json, TxRequestMsg.class);
		if(reqMsg.getTx_header() == null)
			reqMsg.setTx_header(new TxRequestMsgHead());
		if(reqMsg.getTx_body() == null) {
			reqMsg.setTx_body(new TxRequestMsgBody());
			reqMsg.getTx_body().setCom1(new TxRequestMsgCom1());
		}
		
		JSONObject body_json = json.getJSONObject("tx_body");
		if(body_json == null) {
			rsp_header.setSys_resp_code("tx_body is null!");
			rsp_header.setSys_resp_desc("tx_body is null!");
			return null;
		}
		
		JSONObject entity_json = body_json.getJSONObject("entity");
		if(entity_json == null) {
			rsp_header.setSys_resp_code("entity is null!");
			rsp_header.setSys_resp_desc("entity is null!");
			return null;
		}
		
		INREC6002ServiceInVo entity = JSONObject.toJavaObject(entity_json, INREC6002ServiceInVo.class);
		reqMsg.getTx_body().setEntity(entity);
		
		return reqMsg;
	}
	
	
//	@RequestMapping("justTest")
//	@ResponseBody
//	public Object justTest() {
//		
//		RestTemplate restTemplate = new RestTemplate();
//		
//		System.out.println("\r\n\r\n\r\nimage: " + image);
//		
//		HashMap<String, String> map = new HashMap<>();
//		map.put("image_name", "test_name.jpg");
//		map.put("face_image", image);
//		map.put("channelid", "1800");
//		
//		System.out.println("map: " + map);
//		ResponseEntity<String> postForEntity = restTemplate.postForEntity("http://127.0.0.1:8079/imageTransfer", map, String.class);
//		System.out.println("result: " + postForEntity.getBody());
//		
//		
//		return "OK";
//	}
//	
//	
//	@RequestMapping("getPhoto")
//	@ResponseBody
//	public Object getPhoto(String path) {
//		
//		String image = PhotoUtil.loadPhoto(path);
//		
//		System.out.println("image: " + image);
//		
//		return image;
//	}
	
	
	

}
