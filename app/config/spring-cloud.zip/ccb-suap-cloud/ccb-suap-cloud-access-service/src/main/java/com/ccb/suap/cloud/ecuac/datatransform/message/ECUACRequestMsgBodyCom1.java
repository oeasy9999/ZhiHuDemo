package com.ccb.suap.cloud.ecuac.datatransform.message;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class ECUACRequestMsgBodyCom1 implements Serializable {
	
	private static final long serialVersionUID = -703015785L;
	
	@XStreamAlias("TXN_INSID")
	private String txn_insid;
	@XStreamAlias("TXN_ITT_CHNL_ID")
	private String txn_itt_chnl_id;
	@XStreamAlias("TXN_ITT_CHNL_CGY_CODE")
	private String txn_itt_chnl_cgy_code;
	@XStreamAlias("TXN_DT")
	private String txn_dt;
	@XStreamAlias("TXN_TM")
	private String txn_tm;
	@XStreamAlias("TXN_STFF_ID")
	private String txn_stff_id;
	@XStreamAlias("MULTI_TENANCY_ID")
	private String multi_tenancy_id;
	@XStreamAlias("LNG_ID")
	private String lng_id;
	
	public String getTxn_insid() {
		return txn_insid;
	}
	public void setTxn_insid(String txn_insid) {
		this.txn_insid = txn_insid;
	}
	public String getTxn_itt_chnl_id() {
		return txn_itt_chnl_id;
	}
	public void setTxn_itt_chnl_id(String txn_itt_chnl_id) {
		this.txn_itt_chnl_id = txn_itt_chnl_id;
	}
	public String getTxn_itt_chnl_cgy_code() {
		return txn_itt_chnl_cgy_code;
	}
	public void setTxn_itt_chnl_cgy_code(String txn_itt_chnl_cgy_code) {
		this.txn_itt_chnl_cgy_code = txn_itt_chnl_cgy_code;
	}
	public String getTxn_dt() {
		return txn_dt;
	}
	public void setTxn_dt(String txn_dt) {
		this.txn_dt = txn_dt;
	}
	public String getTxn_tm() {
		return txn_tm;
	}
	public void setTxn_tm(String txn_tm) {
		this.txn_tm = txn_tm;
	}
	public String getTxn_stff_id() {
		return txn_stff_id;
	}
	public void setTxn_stff_id(String txn_stff_id) {
		this.txn_stff_id = txn_stff_id;
	}
	public String getMulti_tenancy_id() {
		return multi_tenancy_id;
	}
	public void setMulti_tenancy_id(String multi_tenancy_id) {
		this.multi_tenancy_id = multi_tenancy_id;
	}
	public String getLng_id() {
		return lng_id;
	}
	public void setLng_id(String lng_id) {
		this.lng_id = lng_id;
	}
	
	@Override
	public String toString() {
		return "TxRequestMsgBodyCom1 [txn_insid=" + txn_insid + ", txn_itt_chnl_id=" + txn_itt_chnl_id
				+ ", txn_itt_chnl_cgy_code=" + txn_itt_chnl_cgy_code + ", txn_dt=" + txn_dt + ", txn_tm=" + txn_tm
				+ ", txn_stff_id=" + txn_stff_id + ", multi_tenancy_id=" + multi_tenancy_id + ", lng_id=" + lng_id
				+ "]";
	}
	
	
	
	
	
}