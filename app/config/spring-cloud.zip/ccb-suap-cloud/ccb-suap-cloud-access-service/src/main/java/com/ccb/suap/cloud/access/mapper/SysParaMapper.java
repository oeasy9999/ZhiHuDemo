package com.ccb.suap.cloud.access.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import com.ccb.suap.cloud.access.model.SysParaModel;

@Mapper
@Component
public interface SysParaMapper {

	// 根据 ID 查询
	@Select("SELECT * FROM inrec_sys_para WHERE id=#{id}")
    SysParaModel get(String id);
	
    @Select("SELECT * FROM inrec_sys_para WHERE paracode=#{paracode} AND paratype=#{paratype}")
    SysParaModel select(@Param("paracode") String paracode, @Param("paratype") String paratype);
    
    @Select("SELECT * FROM inrec_sys_para WHERE paracode=#{paracode} AND paratype='0'")
    SysParaModel selectCommPara(String paracode);
    
    @Select("SELECT * FROM inrec_sys_para WHERE paracode=#{paracode} AND paratype='1' AND deployid=#{deployid}")
    SysParaModel selectServerPara(@Param("paracode") String paracode, @Param("deployid") String deployid);

    // 查询全部
    @Select("SELECT * FROM inrec_sys_para")
    List<SysParaModel> selectAll();
    
    @Select("SELECT count(*) FROM inrec_sys_para")
    Integer count();
    
    // 插入
    @Insert("INSERT INTO inrec_sys_para(id,paracode,paraname,paravalue,paratype,deployid,remark,creator,createtime,version) "
    		+ " VALUES(seq_para_id.nextval, #{paracode}, #{paraname}, #{paravalue},#{paratype},#{deployid},#{remark},'admin',sysdate,1)")
    int insert(SysParaModel model);
    
    @Update("UPDATE inrec_sys_para SET paraname=#{paraname},paravalue=#{paravalue},remark=#{remark},operuserid='admin',opertime=sysdate WHERE id=#{id}")
    int update(SysParaModel model);
    
    @Delete("DELETE FROM inrec_sys_para WHERE id=#{id}")
    int delete(String id);
}
