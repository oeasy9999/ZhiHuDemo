package com.ccb.suap.cloud.access.datatransform.message;

public class TxResponseMsg {

	private TxResponseMsgHead tx_header;
	private TxResponseMsgBody tx_body;
	
	public TxResponseMsg() {
		super();
	}
	
	public TxResponseMsgHead getTx_header() {
		return tx_header;
	}
	public TxResponseMsgBody getTx_body() {
		return tx_body;
	}
	public void setTx_body(TxResponseMsgBody tx_body) {
		this.tx_body = tx_body;
	}
	public void setTx_header(TxResponseMsgHead tx_header) {
		this.tx_header = tx_header;
	}
	
	@Override
	public String toString() {
		return "TxResponseMsg [tx_header=" + tx_header + ", tx_body=" + tx_body + "]";
	}
	
	
	
}
