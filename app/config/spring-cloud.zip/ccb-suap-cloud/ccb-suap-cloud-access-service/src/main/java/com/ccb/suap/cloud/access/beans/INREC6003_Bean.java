package com.ccb.suap.cloud.access.beans;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.cloud.access.vo.INREC6003ServiceInVo;
import com.ccb.suap.util.log.TraceLog;
import com.ccb.suap.util.python.PythonUtil;

/**
 * 	云端日志同步
 * @author 86156
 *
 */
@Controller("INREC6003")
public class INREC6003_Bean extends INRECBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(INREC6003_Bean.class);
	
	
	@Override
	public TxResponseMsg executeProcess(TxResponseMsg rspMsg,TxRequestMsg reqMsg,TraceLog traceLog) throws Exception{
		LOGGER.debug("\n\n------------------调用INREC6003服务------------------");
		
		INREC6003ServiceInVo inVo = (INREC6003ServiceInVo) reqMsg.getTx_body().getEntity();
		
		//实体域参数校验
		LOGGER.debug("check requestEntity: "+inVo);
		checkParaByServerName(rspMsg, reqMsg);
		
		String pythonAddr = SuapSysParaUtil.getStrPara("MONITOR_PYTHON_ADDR", "/usr/local/qcloud/monitor/barad/client/cagent_tools");
		String alarmPerson = SuapSysParaUtil.getStrPara("MONITOR_PYTHON_ALARM_PERSON", "cm-py5x1tyi");
		
		LOGGER.debug("pythonAddr: " + pythonAddr + ", alarmPerson: " + alarmPerson);
		if(!PythonUtil.execPython(pythonAddr, inVo.getMsgContent(), alarmPerson)) {
			throw new CommonRuntimeException(Errorcode.PYTHONEXCFAILD, "01", "check para in table  suap_sys_para, MONITOR_PYTHON_ADDR :" + pythonAddr + ", MONITOR_PYTHON_ALARM_PERSON: " + alarmPerson);
		}
		
		LOGGER.debug("success: "+rspMsg);
		return rspMsg;
	}
	
	
	@Override
	public void checkParaByServerName(TxResponseMsg rspMsg, TxRequestMsg reqMsg) throws Exception {
		INREC6003ServiceInVo inVo = (INREC6003ServiceInVo)reqMsg.getTx_body().getEntity();
		
		String msgContent = inVo.getMsgContent();
		
		if(StringUtils.isBlank(msgContent)) {
			throw new CommonRuntimeException(Errorcode.MSGCONTNOTNULL);
		}
		
		
	}
	
	


	
	
	
}
