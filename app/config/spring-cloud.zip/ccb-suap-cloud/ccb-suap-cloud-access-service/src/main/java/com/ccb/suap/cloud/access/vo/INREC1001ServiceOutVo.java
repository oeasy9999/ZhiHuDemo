package com.ccb.suap.cloud.access.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;

public class INREC1001ServiceOutVo extends TxResponseMsgEntity {
	
	private String idverify;					//是否经过人脸核查

	public String getIdverify() {
		return idverify;
	}

	/**
	 * 1. 经过联网核查
	 * 2.未经过联网核查
	 * 3.不需要联网核查
	 * @param idverify
	 */
	public void setIdverify(String idverify) {
		this.idverify = idverify;
	}

	@Override
	public String toString() {
		return "INREC1001ServiceOutVo [idverify=" + idverify + "]";
	}
	
	
	
	
}
