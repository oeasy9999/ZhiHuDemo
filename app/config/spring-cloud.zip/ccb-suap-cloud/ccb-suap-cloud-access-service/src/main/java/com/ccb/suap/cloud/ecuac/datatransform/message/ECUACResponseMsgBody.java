package com.ccb.suap.cloud.ecuac.datatransform.message;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class ECUACResponseMsgBody implements Serializable {
	
	private static final long serialVersionUID = -543735659L;
	
	@XStreamAlias("COMMON")
	private ECUACResponseMsgBodyCommon common;
	@XStreamAlias("ENTITY")
	private ECUACResponseMsgBodyEntity entity;
	
	public ECUACResponseMsgBodyCommon getCommon() {
		return common;
	}
	public void setCommon(ECUACResponseMsgBodyCommon common) {
		this.common = common;
	}
	public ECUACResponseMsgBodyEntity getEntity() {
		return entity;
	}
	public void setEntity(ECUACResponseMsgBodyEntity entity) {
		this.entity = entity;
	}
	
	@Override
	public String toString() {
		return "TxResponseMsgBody [common=" + common + ", entity=" + entity + "]";
	}
	
	
	
	
	
	
	
	
	
	
}