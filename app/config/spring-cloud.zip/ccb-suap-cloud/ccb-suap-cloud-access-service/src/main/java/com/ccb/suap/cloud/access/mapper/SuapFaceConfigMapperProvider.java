package com.ccb.suap.cloud.access.mapper;

import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.jdbc.SQL;

import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;

public class SuapFaceConfigMapperProvider {
	
	public String update(SuapFaceConfigModel suapFaceConfigModel) {
		String sql = new SQL() {{
			UPDATE("SUAP_FACE_CONFIG");
			
			if(suapFaceConfigModel.getBranchno() != null) {
				SET("BRANCHNO=#{branchno}");
			}
			if(suapFaceConfigModel.getDestable() != null) {
				SET("DESTABLE=#{destable}");
			}
			if(suapFaceConfigModel.getIsseparate() != null) {
				SET("ISSEPARATE=#{isseparate}");
			}
			if(suapFaceConfigModel.getSeparatenum() != null) {
				SET("SEPARATENUM=#{separatenum}");
			}
			if(suapFaceConfigModel.getSeparateindex() != null) {
				SET("SEPARATEINDEX=#{separateindex}");
			}
			if(suapFaceConfigModel.getIshackcheck() != null) {
				SET("ISHACKCHECK=#{ishackcheck}");
			}
			if(suapFaceConfigModel.getHackthreshold() != null) {
				SET("HACKTHRESHOLD=#{hackthreshold}");
			}
			if(suapFaceConfigModel.getLeveltype() != null) {
				SET("LEVELTYPE=#{leveltype}");
			}
			if(suapFaceConfigModel.getLevelgrade() != null) {
				SET("LEVELGRADE=#{levelgrade}");
			}
			if(suapFaceConfigModel.getLocknum() != null) {
				SET("LOCKNUM=#{locknum}");
			}
			if(suapFaceConfigModel.getSimilarity() != null) {
				SET("SIMILARITY=#{similarity}");
			}
			if(suapFaceConfigModel.getIspicture() != null) {
				SET("ISPICTURE=#{ispicture}");
			}
			if(suapFaceConfigModel.getIdverify() != null) {
				SET("IDVERIFY=#{idverify}");
			}
			if(StringUtils.isNotBlank(suapFaceConfigModel.getIdverify_mode()))
				SET("IDVERIFY_MODE=#{idverify_mode}");
			if(StringUtils.isNotBlank(suapFaceConfigModel.getIdverify_mode()))
				SET("ECUAC0183_MODE=#{ecuac0183_mode}");
			if(StringUtils.isNotBlank(suapFaceConfigModel.getIdverify_mode()))
				SET("RHVERIFY=#{rhverify}");
			if(suapFaceConfigModel.getIsc00004() != null) {
				SET("ISC00004=#{isc00004}");
			}
			if(suapFaceConfigModel.getIspolice() != null) {
				SET("ISPOLICE=#{ispolice}");
			}
			if(suapFaceConfigModel.getRegpic() != null) {
				SET("REGPIC=#{regpic}");
			}
			if(suapFaceConfigModel.getHitnum() != null) {
				SET("HITNUM=#{hitnum}");
			}
			if(suapFaceConfigModel.getIssync1to1() != null) {
				SET("ISSYNC1TO1=#{issync1to1}");
			}
			if(suapFaceConfigModel.getLocation_source() != null) {
				SET("LOCATION_SOURCE=#{location_source}");
			}
			if(suapFaceConfigModel.getLocation() != null) {
				SET("LOCATION=#{location}");
			}
			if(suapFaceConfigModel.getLocationindex() != null) {
				SET("LOCATIONINDEX=#{locationindex}");
			}
			if(suapFaceConfigModel.getRemark() != null) {
				SET("REMARK=#{remark}");
			}
			if(suapFaceConfigModel.getDistpic() != null) {
				SET("DISTPIC=#{distpic}");
			}
			
//			if(suapFaceConfigModel.getChannelcode() != null) {
//				SET("CHANNELCODE=#{channelcode}");
//			}
//			if(suapFaceConfigModel.getTradecode() != null) {
//				SET("TRADECODE=#{tradecode}");
//			}
//			if(suapFaceConfigModel.getTxcode() != null) {
//				SET("TXCODE=#{txcode}");
//			}
			
			if(suapFaceConfigModel.getChannelcode() != null) {
				WHERE("CHANNELCODE=#{channelcode}");
			}
			if(suapFaceConfigModel.getTradecode() != null) {
				WHERE("TRADECODE=#{tradecode}");
			}
			if(suapFaceConfigModel.getTxcode() != null) {
				WHERE("TXCODE=#{txcode}");				
			}
			
		}}.toString();
		
//		System.out.println("------------sql------------\n"+sql);
		return sql;
	}
	
	
	
	
}
