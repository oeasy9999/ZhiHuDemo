package com.ccb.suap.cloud.access.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import com.ccb.suap.cloud.access.model.SuapVendorInfoModel;

@Mapper
public interface SuapVendorInfoMapper {
	
	@Insert("insert into SUAP_VENDOR_INFO(VENDORCODE,VENDORNAME,VENDORDESC,CREATETIME,CREATOR,MODIFYTIME,MODIFIER) values(#{vendorcode},#{vendorname},#{vendordesc},#{createtime},#{creator},#{modifytime},#{modifier})")
	int insert(SuapVendorInfoModel suapVendorInfoModel);
	
	
	
	
	
	
	
	
	
	
}
