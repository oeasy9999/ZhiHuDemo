package com.ccb.suap.cloud.access.service.utils;

/**
 * 本工具类主要用于JSONObject的封装等操作
 */
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgBody;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgCom1;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEquipmentInfo;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgHead;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgEntity;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsgHead;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.model.SuapFaceLogModel;

@Component
public class JSONObjectUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	/**
	 * 	将前端传过来的json,根据对应的Tx_code,封装到对应的TxRequestMsg中。 并对请求中的相关信息进行相应的校验
	 * 
	 * @param json 前端传过来的参数
	 * @return TxRequestMsg对象
	 * @throws Exception 
	 */
	public static TxRequestMsg toTxRequestMsg(TxResponseMsg rspMsg, JSONObject json, String txcode, SuapFaceLogModel faceLog) {
		//封装响应头信息
		TxResponseMsgHead rspHeader = rspMsg.getTx_header();
		rspHeader.setSys_tx_code(txcode);
		rspHeader.setSys_pkg_sts_type("01");
		TxRequestMsg reqMsg = new TxRequestMsg();
		TxRequestMsgBody reqBody = new TxRequestMsgBody();
		reqMsg.setTx_body(reqBody);
		
		//封装请求头
		JSONObject reqHeaderJSON = json.getJSONObject("tx_header");
		if(reqHeaderJSON == null) 
			throw new CommonRuntimeException(Errorcode.HEADMSGNOTNULL);
		
		TxRequestMsgHead reqHeader = JSONObject.toJavaObject(reqHeaderJSON, TxRequestMsgHead.class);
		reqHeader.setSys_tx_code(txcode);
		reqMsg.setTx_header(reqHeader);
		String rspCode = CheckParaUtil.checkTxRequestMsgHead(reqHeader);
		if(rspCode != null) {
			LOGGER.debug("check tx_header fail: "+reqHeaderJSON);
			throw new CommonRuntimeException(rspCode);
		}
		//tx_header校验正常则封装响应头信息,封装人脸交易日志信息
		rspHeader.setSys_evt_trace_id(reqHeader.getSys_evt_trace_id());
		faceLog.setTransflow(reqHeader.getSys_evt_trace_id());
		
		//封装tx_body
		JSONObject jsonBody = json.getJSONObject("tx_body");
		if(jsonBody == null) 
			throw new CommonRuntimeException(Errorcode.TX_BODYNOTNULL);
		
		//封装com1域
		JSONObject com1Json = jsonBody.getJSONObject("com1");
		if(com1Json == null) 
			throw new CommonRuntimeException(Errorcode.COM1ALLNOTNULL);
		
		TxRequestMsgCom1 reqCom1 = JSONObject.toJavaObject(com1Json, TxRequestMsgCom1.class);
		reqBody.setCom1(reqCom1);
		rspCode = CheckParaUtil.checkTxRequestMsgCom1(reqCom1);
		if(rspCode != null) {
			LOGGER.debug("------------------com1校验失败------------------\n"+com1Json);
			throw new CommonRuntimeException(rspCode);
		}
		//封装人脸交易日志信息
		faceLog.setChannelid(reqCom1.getSysChannelID());
		faceLog.setChanneltxcode(reqCom1.getChannelTxCode());
		
		//检查人脸识别参数配置表信息
		SuapFaceConfigModel suapFaceConfigModel = SuapFaceConfigUtil.getFaceConfig(reqCom1.getSysChannelID() + ":" + reqCom1.getChannelTxCode() + ":" + txcode);
		if (suapFaceConfigModel == null) 
			throw new CommonRuntimeException(Errorcode.FACECFGNOTNULL);
		rspCode = CheckParaUtil.checkFaceConfig(suapFaceConfigModel);
		if(rspCode != null) {
			LOGGER.debug("------------------suapFaceConfigModel------------------\n"+suapFaceConfigModel);
			throw new CommonRuntimeException(rspCode);
		}
		
		//封装实体域
		JSONObject entityJson = jsonBody.getJSONObject("entity");
		if(entityJson == null) 
			throw new CommonRuntimeException(Errorcode.ENTITY_NOTNULL);
		
		Class<?> entityClass = TxcodeUtil.getReqEntityClassByTxcode(txcode);
		if(entityClass == null)
			throw new CommonRuntimeException(Errorcode.NOSERVERSERROR);
		TxRequestMsgEntity entity = (TxRequestMsgEntity) JSONObject.toJavaObject(entityJson, entityClass);
		reqMsg.getTx_body().setEntity(entity);
		
		//封装设备信息域
		JSONObject equipmentInfoJson = jsonBody.getJSONObject("equipmentInfo");
		TxRequestMsgEquipmentInfo equipmentInfo = JSONObject.toJavaObject(equipmentInfoJson, TxRequestMsgEquipmentInfo.class);
		reqMsg.getTx_body().setEquipment_info(equipmentInfo);
		
		return reqMsg;
	}

	
	/**
	 * 将json封装成响应信息
	 * @param json
	 * @param cl
	 * @return
	 */
	public static <E extends TxResponseMsgEntity> TxResponseMsg toRspMsg(JSONObject json, Class<E> cl) {
		if(json == null)
			throw new CommonRuntimeException(Errorcode.RSPMSGNOTFOUND);
		TxResponseMsg rspMsg = JSONObject.toJavaObject(json, TxResponseMsg.class);
		if(rspMsg.getTx_header() == null)
			throw new CommonRuntimeException(Errorcode.HEADERNOTFOUND);
		
		if(json.getJSONObject("tx_body") != null) {
			JSONObject entityJson = json.getJSONObject("tx_body").getJSONObject("entity");
			E entity = (E) JSONObject.toJavaObject(entityJson, cl);
			rspMsg.getTx_body().setEntity(entity);
		}
		
		return rspMsg;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
