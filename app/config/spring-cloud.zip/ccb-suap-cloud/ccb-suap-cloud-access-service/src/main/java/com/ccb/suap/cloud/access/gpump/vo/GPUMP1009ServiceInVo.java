package com.ccb.suap.cloud.access.gpump.vo;

import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsgEntity;

public class GPUMP1009ServiceInVo extends TxRequestMsgEntity{
	
	private String face_image;						//人脸图片
	private String face_refer_image;				//人脸参考图片
	
	public String getFace_image() {
		return face_image;
	}
	public void setFace_image(String face_image) {
		this.face_image = face_image;
	}
	public String getFace_refer_image() {
		return face_refer_image;
	}
	public void setFace_refer_image(String face_refer_image) {
		this.face_refer_image = face_refer_image;
	}
	
	@Override
	public String toString() {
		return "GPUMP1009ServiceInVo [face_image=" + face_image + ", face_refer_image=" + face_refer_image + "]";
	}
	
	
	

	
	
	
}
