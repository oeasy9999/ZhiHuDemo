package com.ccb.suap.cloud.access.idverify.service;

/**
 * 	人行->成开->公安一所
 */

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.controller.FaceServiceController;


import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1009ServiceInVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1009ServiceOutVo;
import com.ccb.suap.cloud.access.model.SuapFaceConfigModel;
import com.ccb.suap.cloud.access.service.GPUMPService;
import com.ccb.suap.cloud.access.service.OutBoundService;
import com.ccb.suap.cloud.access.service.utils.ServiceParaUtil;
import com.ccb.suap.cloud.access.service.utils.SuapSysParaUtil;
import com.ccb.suap.cloud.access.threadLocal.FaceLogThreadLocal;
import com.ccb.suap.cloud.access.vo.INREC1001And2001ServiceInVo;
import com.ccb.suap.cloud.access.vo.ServiceInVoParam1001And2001;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1001ServiceInVo;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1001ServiceOutVo;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1002ServiceInVo;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1002ServiceOutVo;
import com.ccb.suap.outbound.ccvea.vo.CCVEA1003ServiceInVo;

@Service("IDVerify2")
public class IDVerifyModeB implements IDVerifyMode{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	@Autowired
	private OutBoundService outboundService;
	
	@Autowired
	private GPUMPService gpumpService;
	

	@Override
	public boolean verify(TxRequestMsg reqMsg, SuapFaceConfigModel faceConfig, ServiceInVoParam1001And2001 param) {
		
		//发往到CCVEA1001获取人行高清照
		TxResponseMsg rspFromCCVEA1001 = null;
		if("1".equals(faceConfig.getRhverify()))
			rspFromCCVEA1001 = sendCCVEA1001(reqMsg, param);
		
		//将拿到的图片发往GPUMP1009比对，相似度达标则返回true，相似度不达标则报错
		if(rspFromCCVEA1001 != null) {
			CCVEA1001ServiceOutVo ccvea1001OutVo= (CCVEA1001ServiceOutVo) rspFromCCVEA1001.getTx_body().getEntity();
			param.setIdverify_image(ccvea1001OutVo.getBase64_Ecrp_Txn_Inf());
			if("000000000000".equals(rspFromCCVEA1001.getTx_header().getSys_resp_code()))
				return checkByGPUMP1009(reqMsg, ccvea1001OutVo, faceConfig);
		}
		
		
		//发送到CCVEA1002获取成开缓存照
		TxResponseMsg rspFromCCVEA1002 = null;
		if("1".equals(faceConfig.getIsc00004()))
			rspFromCCVEA1002 = sendCCVEA1002(reqMsg, param);
		
		//将拿到的图片发往GPUMP1009比对，相似度达标则返回true，相似度不达标则报错
		if(rspFromCCVEA1002 != null) {
			CCVEA1002ServiceOutVo ccvea1002OutVo= (CCVEA1002ServiceOutVo) rspFromCCVEA1002.getTx_body().getEntity();
			param.setIdverify_image(ccvea1002OutVo.getBase64_Ecrp_Txn_Inf());
			if("000000000000".equals(rspFromCCVEA1002.getTx_header().getSys_resp_code()))
				return checkByGPUMP1009(reqMsg, ccvea1002OutVo, faceConfig);
		}
		
		//发往到CCVEA1003公安一所核查
		TxResponseMsg rspFromCCVEA1003 = null;
		if("1".equals(faceConfig.getIspolice())) {
			rspFromCCVEA1003 = sendCCVEA1003(reqMsg, param);
		}else {
			FaceLogThreadLocal.get().setRemarks("CCVEA1001: " + faceConfig.getRhverify() + ", CCVEA1002: " + faceConfig.getIsc00004() + ", CCVEA1003: " + faceConfig.getIspolice() + ", " + FaceLogThreadLocal.get().getRemarks());
			return false;
		}
		
		if(rspFromCCVEA1003 != null) {
			if(!"000000000000".equals(rspFromCCVEA1003.getTx_header().getSys_resp_code()))
				throw new CommonRuntimeException(rspFromCCVEA1003, "send CCVEA1003 fail, errorcode: " + rspFromCCVEA1003.getTx_header().getSys_resp_code() + ", errorMsg: " + rspFromCCVEA1003.getTx_header().getSys_resp_desc());
		}
		
		return true;
	}


	/**
	 * 	组装报文发往CCVEA1001
	 * @param reqMsg
	 * @param traceLog
	 * @param param
	 * @return
	 */
	private TxResponseMsg sendCCVEA1001(TxRequestMsg reqMsg, ServiceInVoParam1001And2001 param) {
		
		if(!checkIsOverTime())
			return null;
		
		TxRequestMsg ccvea1001ReqMsg = getCCVEA1001ReqMsg(reqMsg);
		
		LOGGER.debug("send CCVEA1001: " + JSONObject.toJSONString(ccvea1001ReqMsg));
		TxResponseMsg ccvea1001Rsp = null;
		try {
			ccvea1001Rsp = outboundService.sendCCVEA1001(ccvea1001ReqMsg);
		} catch (CommonRuntimeException e) {
			FaceLogThreadLocal.get().setRemarks(e.getRemarks());
		}
		LOGGER.debug("return by CCVEA1001: " + JSONObject.toJSONString(ccvea1001Rsp));
		
		if(ccvea1001Rsp != null && !"000000000000".equals(ccvea1001Rsp.getTx_header().getSys_resp_code()))
			FaceLogThreadLocal.get().setRemarks("send CCVEA1001 fail, errorcode: " + ccvea1001Rsp.getTx_header().getSys_resp_code() + ", errormsg: " + ccvea1001Rsp.getTx_header().getSys_resp_desc());
//			throw new CommonRuntimeException(ccvea1001Rsp, "send CCVEA1001 fail, errorcode: " + ccvea1001Rsp.getTx_header().getSys_resp_code() + ", errorMsg: " + ccvea1001Rsp.getTx_header().getSys_resp_desc());
		
		return ccvea1001Rsp;
	}
	
	
	/**
	 * 	封装CCVEA1001请求报文
	 * @param reqMsg
	 */
	private TxRequestMsg getCCVEA1001ReqMsg(TxRequestMsg reqMsg) {
		TxRequestMsg ccvea1001ReqMsg = ServiceParaUtil.newReqMsg(reqMsg);
		CCVEA1001ServiceInVo ccvea1001ReqEntity = new CCVEA1001ServiceInVo();
		ccvea1001ReqMsg.getTx_body().setEntity(ccvea1001ReqEntity);
		ccvea1001ReqMsg.getTx_header().setSys_tx_code("CCVEA1001");
		INREC1001And2001ServiceInVo entity = (INREC1001And2001ServiceInVo) reqMsg.getTx_body().getEntity();
		
		ccvea1001ReqEntity.setStm_Chnl_ID("1266");
		ccvea1001ReqEntity.setStm_Chnl_Txn_CD("FACE-ECUAC0167");
		ccvea1001ReqEntity.setCst_Nm(entity.getName());
		ccvea1001ReqEntity.setCrdt_No(entity.getId_no());
		ccvea1001ReqEntity.setMt_Apl_PD_ECD("");
		ccvea1001ReqEntity.setMftr_Str_VNo("");
		ccvea1001ReqEntity.setExt_Stm_Only1_Ind("");
		ccvea1001ReqEntity.setFtr_Col_Tm("");
		ccvea1001ReqEntity.setFor_Ext_Stm_Svc_Tm("");
		ccvea1001ReqEntity.setRsrv_1_Inf_Dsc("");
		
		return ccvea1001ReqMsg;
	}


	/**
	 * 	发往GPUMP1009校验图片是否达到相似度
	 * @param reqMsg
	 * @param ccvea1001OutVo
	 * @param faceConfig
	 * @param traceLog
	 * @return
	 */
	private boolean checkByGPUMP1009(TxRequestMsg reqMsg, CCVEA1001ServiceOutVo ccvea1001OutVo, SuapFaceConfigModel faceConfig) {
		TxRequestMsg gpump1009ReqMsg = getGPUMP1009ReqMsg(reqMsg, ccvea1001OutVo);
		
		return sendGPUMP1009AndCompare(gpump1009ReqMsg, faceConfig.getSimilarity());
	}


	/**
	 * 	组装报文发往CCVEA1002
	 * @param reqMsg
	 * @param param
	 * @param traceLog
	 * @return
	 */
	private TxResponseMsg sendCCVEA1002(TxRequestMsg reqMsg, ServiceInVoParam1001And2001 param) {
		
		TxRequestMsg ccvea1002ReqMsg = getCCVEA1002ReqMsg(reqMsg);
		
		LOGGER.debug("send CCVEA1002: " + JSONObject.toJSONString(ccvea1002ReqMsg));
		TxResponseMsg ccvea1002Rsp = null;
		try {
			ccvea1002Rsp = outboundService.sendCCVEA1002(ccvea1002ReqMsg);
		} catch (CommonRuntimeException e) {
			FaceLogThreadLocal.get().setRemarks(e.getRemarks());
		}
		LOGGER.debug("return by CCVEA1002: " + JSONObject.toJSONString(ccvea1002Rsp));
		
		if(ccvea1002Rsp != null && !"000000000000".equals(ccvea1002Rsp.getTx_header().getSys_resp_code()))
			FaceLogThreadLocal.get().setRemarks("send CCVEA1002 fail, errorcode: " + ccvea1002Rsp.getTx_header().getSys_resp_code() + ", errormsg: " + ccvea1002Rsp.getTx_header().getSys_resp_desc());
//			throw new CommonRuntimeException(ccvea1002Rsp, "send CCVEA1002 fail, errorcode: " + ccvea1002Rsp.getTx_header().getSys_resp_code() + ", errorMsg: " + ccvea1002Rsp.getTx_header().getSys_resp_desc());
		
		return ccvea1002Rsp;
	}


	/**
	 * 	校验是否处于成开缓存照服务时间
	 */
	private boolean checkIsOverTime() {
		
		String time_str = SuapSysParaUtil.getStrPara("IDVERIFY_TIME", "000000");
		LOGGER.debug("IDVERIFY_TIME in SysPara: " + time_str);
		String[] times = time_str.split("-");
		long startTime = Long.parseLong(times[0]);
		long endTime = Long.parseLong(times[1]);
		
		long now_time = Long.parseLong(new SimpleDateFormat("HHmmss").format(new Date()));
		
		LOGGER.debug("starttime: " + startTime + ", endtime: " + endTime +", now: " + now_time);
		if(now_time < startTime || now_time > endTime)
			return false;
		
		return true;
	}


	/**
	 * 	封装CCVEA1002请求报文
	 * @param reqMsg
	 * @return
	 */
	private TxRequestMsg getCCVEA1002ReqMsg(TxRequestMsg reqMsg) {
		TxRequestMsg ccvea1002ReqMsg = ServiceParaUtil.newReqMsg(reqMsg);
		CCVEA1002ServiceInVo ccvea1002ReqEntity = new CCVEA1002ServiceInVo();
		ccvea1002ReqMsg.getTx_body().setEntity(ccvea1002ReqEntity);
		ccvea1002ReqMsg.getTx_header().setSys_tx_code("CCVEA1002");
		INREC1001And2001ServiceInVo entity = (INREC1001And2001ServiceInVo) reqMsg.getTx_body().getEntity();
		
		ccvea1002ReqEntity.setStm_Chnl_ID("1266");
		ccvea1002ReqEntity.setStm_Chnl_Txn_CD("FACE-ECUAC0168");
		ccvea1002ReqEntity.setCst_Nm(entity.getName());
		ccvea1002ReqEntity.setCrdt_No(entity.getId_no());
		ccvea1002ReqEntity.setMt_Apl_PD_ECD("");
		ccvea1002ReqEntity.setMftr_Str_VNo("");
		ccvea1002ReqEntity.setExt_Stm_Only1_Ind("");
		ccvea1002ReqEntity.setFtr_Col_Tm("");
		ccvea1002ReqEntity.setCrdTp_Cd("");
		ccvea1002ReqEntity.setFtr_Col_TmnlInf("");
		ccvea1002ReqEntity.setAflt_Inf_Dsc("");
		ccvea1002ReqEntity.setMftr_Idr_CD("");
		ccvea1002ReqEntity.setCtf_Mnplt_Mode_ID("");
		ccvea1002ReqEntity.setExt_Stm_Safe_ModDsc("");
		ccvea1002ReqEntity.setFor_Ext_Stm_Svc_Tm("");
		ccvea1002ReqEntity.setAlrdAhr_ID("");
		ccvea1002ReqEntity.setBase64_Ecrp_Txn_Inf("");
		ccvea1002ReqEntity.setSmlr_Dgr_Cmnt("");
		
		return ccvea1002ReqMsg;
	}


	/**
	 * 	发往GPUMP1009校验图片是否达到相似度
	 * @param reqMsg
	 * @param ccvea1002OutVo
	 * @param faceConfig
	 * @param traceLog
	 * @return
	 */
	private boolean checkByGPUMP1009(TxRequestMsg reqMsg, CCVEA1002ServiceOutVo ccvea1002OutVo, SuapFaceConfigModel faceConfig) {
		TxRequestMsg gpump1009ReqMsg = getGPUMP1009ReqMsg(reqMsg, ccvea1002OutVo);
		
		return sendGPUMP1009AndCompare(gpump1009ReqMsg, faceConfig.getSimilarity());
	}


	/**
	 * 	封装GPUMP1009请求报文
	 * @param reqMsg
	 * @param ccvea1002OutVo
	 * @return
	 */
	private TxRequestMsg getGPUMP1009ReqMsg(TxRequestMsg reqMsg, CCVEA1002ServiceOutVo ccvea1002OutVo) {
		TxRequestMsg gpump1009ReqMsg = ServiceParaUtil.parseGpuRequestMsg(reqMsg);
		INREC1001And2001ServiceInVo entity = (INREC1001And2001ServiceInVo) reqMsg.getTx_body().getEntity();
		GPUMP1009ServiceInVo gpump1009ReqEntity = new GPUMP1009ServiceInVo();
		
		gpump1009ReqMsg.getTx_header().setSys_tx_code("GPUMP1009");
		gpump1009ReqMsg.getTx_body().setEntity(gpump1009ReqEntity);
		
		gpump1009ReqEntity.setFace_image(entity.getFace_image());
		gpump1009ReqEntity.setFace_refer_image(ccvea1002OutVo.getBase64_Ecrp_Txn_Inf());
		
		return gpump1009ReqMsg;
	}


	/**
	 * 	组装报文发往CCVEA1003
	 * @param reqMsg
	 * @param param
	 * @param traceLog
	 * @return
	 */
	private TxResponseMsg sendCCVEA1003(TxRequestMsg reqMsg, ServiceInVoParam1001And2001 param) {
		TxRequestMsg ccvea1003ReqMsg = getCCVEA1003ReqMsg(reqMsg);
		
		LOGGER.debug("send CCVEA1003: " + JSONObject.toJSONString(ccvea1003ReqMsg));
		TxResponseMsg ccvea1003Rsp = outboundService.sendCCVEA1003(ccvea1003ReqMsg);
		LOGGER.debug("return by CCVEA1003: " + JSONObject.toJSONString(ccvea1003Rsp));
		
//		if(!"000000000000".equals(ccvea1003Rsp.getTx_header().getSys_resp_code()))
//			throw new CommonRuntimeException(ccvea1003Rsp, "send CCVEA1003 fail, errorcode: " + ccvea1003Rsp.getTx_header().getSys_resp_code() + ", errorMsg: " + ccvea1003Rsp.getTx_header().getSys_resp_desc());
		
		return ccvea1003Rsp;
	}
	
	
	/**
	 * 	封装CCVEA1003请求报文
	 * @param reqMsg
	 * @return
	 */
	private TxRequestMsg getCCVEA1003ReqMsg(TxRequestMsg reqMsg) {
		TxRequestMsg ccvea1003ReqMsg = ServiceParaUtil.newReqMsg(reqMsg);
		CCVEA1003ServiceInVo ccvea1003ReqEntity = new CCVEA1003ServiceInVo();
		ccvea1003ReqMsg.getTx_body().setEntity(ccvea1003ReqEntity);
		ccvea1003ReqMsg.getTx_header().setSys_tx_code("CCVEA1003");
		INREC1001And2001ServiceInVo entity = (INREC1001And2001ServiceInVo) reqMsg.getTx_body().getEntity();
		
		ccvea1003ReqEntity.setSYSTEM_TIME(new SimpleDateFormat("yyyyMMddHHmm").format(new Date()));
		ccvea1003ReqEntity.setCst_ID("");
		ccvea1003ReqEntity.setApl_Exmp_ID("CIC");
		ccvea1003ReqEntity.setExtStmCtfn_Udt_MpltTm(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()));
		ccvea1003ReqEntity.setRmrk_1_Rcrd_Cntnt("1230");
		ccvea1003ReqEntity.setRmrk_2_Rcrd_Cntnt("1230");
		ccvea1003ReqEntity.setClntEndBaseSVrsnValSt("1230");
		ccvea1003ReqEntity.setBase64_Pic_Txn_Inf("");
		ccvea1003ReqEntity.setCtf_Mnplt_Mode_ID("8");
		ccvea1003ReqEntity.setBase64_ECD_Txn_Inf(entity.getName());
		ccvea1003ReqEntity.setBase64_Ecrp_Txn_Inf(entity.getId_no());
		ccvea1003ReqEntity.setRsrv_1_Inf_Dsc("");
		ccvea1003ReqEntity.setRsrv_2_Inf_Dsc("");
		ccvea1003ReqEntity.setRsrv_3_Inf_Dsc("");
		ccvea1003ReqEntity.setRsrv_4_Inf_Dsc("");
		ccvea1003ReqEntity.setRsrv_5_Inf_Dsc("");
		ccvea1003ReqEntity.setBase64_Rdm_Txn_Inf("");
		ccvea1003ReqEntity.setCtfn_Ahn_Stm_ID("");
		ccvea1003ReqEntity.setBLNG_INST_NM("");
		ccvea1003ReqEntity.setMt_Apl_PD_ECD("");
		ccvea1003ReqEntity.setTlr_Nm("");
		ccvea1003ReqEntity.setExt_Stm_Only1_Ind("");
		ccvea1003ReqEntity.setExt_Stm_NM("");
		ccvea1003ReqEntity.setBr_ID("");
		ccvea1003ReqEntity.setBr_Nm("");
		ccvea1003ReqEntity.setStm_Chnl_ID("");
		
		return ccvea1003ReqMsg;
	}


	/**
	 * 	封装GPUMP1009请求报文
	 * @param reqMsg
	 * @param ccvea1001OutVo
	 * @return
	 */
	private TxRequestMsg getGPUMP1009ReqMsg(TxRequestMsg reqMsg, CCVEA1001ServiceOutVo ccvea1001OutVo) {
		TxRequestMsg gpump1009ReqMsg = ServiceParaUtil.parseGpuRequestMsg(reqMsg);
		INREC1001And2001ServiceInVo entity = (INREC1001And2001ServiceInVo) reqMsg.getTx_body().getEntity();
		GPUMP1009ServiceInVo gpump1009ReqEntity = new GPUMP1009ServiceInVo();
		
		gpump1009ReqMsg.getTx_header().setSys_tx_code("GPUMP1009");
		gpump1009ReqMsg.getTx_body().setEntity(gpump1009ReqEntity);
		
		gpump1009ReqEntity.setFace_image(entity.getFace_image());
		gpump1009ReqEntity.setFace_refer_image(ccvea1001OutVo.getBase64_Ecrp_Txn_Inf());
		
		return gpump1009ReqMsg;
	}
	

	/**
	 * 	发往GPUMP1009并核验相似度是否达标
	 * @param gpump1009ReqMsg
	 * @param similarity
	 * @return
	 */
	private boolean sendGPUMP1009AndCompare(TxRequestMsg gpump1009ReqMsg, String similarity) {
		
		LOGGER.debug("send GPUMP1009: " + JSONObject.toJSONString(gpump1009ReqMsg));
		TxResponseMsg gpump1009Rsp = gpumpService.sendGPUMP1009(gpump1009ReqMsg);
		LOGGER.debug("return by GPUMP1009: " + JSONObject.toJSONString(gpump1009Rsp));
		
		if(!"000000000000".equals(gpump1009Rsp.getTx_header().getSys_resp_code()))
			throw new CommonRuntimeException(gpump1009Rsp, "send GPUMP1009 fail, errorCode: " + gpump1009Rsp.getTx_header().getSys_resp_code() + ", errorMsg: " + gpump1009Rsp.getTx_header().getSys_resp_desc());
		
		double sourceSimilarity = 0;
		try {
			sourceSimilarity = Double.parseDouble(similarity);
		} catch (NumberFormatException e) {
			throw new CommonRuntimeException(Errorcode.PARAETYPEERROR, "01", "parse similarity error! please reset faceConfig!");
		}
		GPUMP1009ServiceOutVo gpump1009OutVo = (GPUMP1009ServiceOutVo) gpump1009Rsp.getTx_body().getEntity();
		long targetSimilarity = Long.parseLong(gpump1009OutVo.getSimilarity());
		
		if(targetSimilarity < sourceSimilarity) {
			LOGGER.error("the request photo do not reached the threshold"+"{系统指定阈值: "+sourceSimilarity+",图片相似度: "+targetSimilarity);
			throw new CommonRuntimeException(Errorcode.PHOCOMPAREFAIL);
		}
		
		return true;
	}
	
	
	
	
}
