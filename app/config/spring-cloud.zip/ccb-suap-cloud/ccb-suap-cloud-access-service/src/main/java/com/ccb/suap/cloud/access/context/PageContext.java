package com.ccb.suap.cloud.access.context;
import java.util.UUID;

/**
 * 应用系统主界面级缓存
 */
public  class PageContext extends Context{
	
	private static final long serialVersionUID = 1L;
	
	private    String         fpageID;
	protected  SessionContext sessionContext;
	
	public PageContext(String pageID)
	{
		if (pageID != null && !pageID.equals(""))
			fpageID = GUID()+"-"+ System.currentTimeMillis();
		else
			fpageID = pageID;
		
	}
	
	/**
  	 * 获取GUID标示
  	 * @return　返回GUID标示号码
  	 */
	 public static final String GUID()
	 {   
		  UUID uuid = UUID.randomUUID(); 
		  return uuid.toString();        
	 } 
	/**
	 * 获取界面标识	
	 * @return
	 */
	public String getPageID()
	{
		return fpageID;
	}
	/**
	 * 获取当前会话缓存
	 * @return
	 */
	public SessionContext getSessionContext()
	{
		return sessionContext;
	}
	/**
	 * 获取当前应用级缓存
	 * @return
	 */
	public ApplicationContext getApplicationContext()throws Exception
	{
		if (sessionContext !=null)
			return sessionContext.getApplicationContext();
		else
			return null;
	}
	 /**
	  * 获取属性值 从当前主界面缓存、会话缓存、应用缓存逐级寻找
	  * @return 不存在则返回null
	  */
	public  Object getAttributes(String key)throws Exception
	{
		if (containsKey(key))
		{
			return get(key);
			
		}if (getSessionContext()!= null)
		{
			return getSessionContext().getAttributes(key);
				
		}else
		{
			return null;
		}
	}
}