package com.ccb.suap.cloud.access.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.ccb.suap.cloud.access.annotation.CosttimeAnnotation;
import com.ccb.suap.cloud.access.annotation.TraceLogAnnotation;
import com.ccb.suap.cloud.access.client.GPUMPClient;
import com.ccb.suap.cloud.access.controller.FaceServiceController;
import com.ccb.suap.cloud.access.datatransform.message.TxRequestMsg;
import com.ccb.suap.cloud.access.datatransform.message.TxResponseMsg;
import com.ccb.suap.cloud.access.exception.CommonRuntimeException;
import com.ccb.suap.cloud.access.exception.Errorcode;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1001ServiceOutVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1002ServiceOutVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1003ServiceOutVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1004ServiceOutVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1005ServiceOutVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1006ServiceOutVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1007ServiceOutVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1008ServiceOutVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1009ServiceOutVo;
import com.ccb.suap.cloud.access.gpump.vo.GPUMP1010ServiceOutVo;
import com.ccb.suap.cloud.access.service.utils.JSONObjectUtil;
import com.ccb.suap.util.log.TraceLog;

@Service
public class GPUMPService {
	
	@Autowired
	private GPUMPClient GPUMPClient;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FaceServiceController.class);
	
	
	/**
	 * 发送人脸1:N注册(GPUMP1001)请求
	 * @param gpump1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation(title = "sendGPUMP1001")
	@TraceLogAnnotation("GPUMP1001")
	public TxResponseMsg sendGPUMP1001(TxRequestMsg gpump1001ReqMsg) {
		JSONObject gpump1001RspJson = null;
		try {
//			gpump1001RspJson = GPUMPClient.GPUMPServer1001(gpump1001ReqMsg);
			gpump1001RspJson = GPUMPClient.GPUMPServer(gpump1001ReqMsg, "GPUMP1001");
			
			
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02",e.getMessage());
		}
		
		TxResponseMsg gpump1001Rsp = JSONObjectUtil.toRspMsg(gpump1001RspJson, GPUMP1001ServiceOutVo.class);
		
		return gpump1001Rsp;
	}
	
	@CosttimeAnnotation(title = "sendGPUMP1001")
	public TxResponseMsg sendGPUMP1001(TxRequestMsg gpump1001ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("GPUMP1001");
		traceLog.setRequestJsonString_gpump1001(JSONObject.toJSONString(gpump1001ReqMsg));
		JSONObject gpump1001RspJson = null;
		long beforeSendGpump1001reqMsg=System.currentTimeMillis();
		try {
//			gpump1001RspJson = GPUMPClient.GPUMPServer1001(gpump1001ReqMsg);
			gpump1001RspJson = GPUMPClient.GPUMPServer(gpump1001ReqMsg, "GPUMP1001");
			
			
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02",e.getMessage());
		}
		
		TxResponseMsg gpump1001Rsp = JSONObjectUtil.toRspMsg(gpump1001RspJson, GPUMP1001ServiceOutVo.class);
		traceLog.setResponseJsonString_gpump1001(JSONObject.toJSONString(gpump1001Rsp));
		long afterResponse=System.currentTimeMillis()-beforeSendGpump1001reqMsg;
		traceLog.setHttpcost(afterResponse);
		return gpump1001Rsp;
	}
	
	/**
	 * 发送人脸1:N识别(GPUMP1002)请求
	 * @param gpump1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation(title = "sendGPUMP1002")
	@TraceLogAnnotation("GPUMP1002")
	public TxResponseMsg sendGPUMP1002(TxRequestMsg gpump1002ReqMsg) {
		JSONObject gpump1002RspJson = null;
		try {
			gpump1002RspJson = GPUMPClient.GPUMPServer(gpump1002ReqMsg,"GPUMP1002");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1002Rsp = JSONObjectUtil.toRspMsg(gpump1002RspJson, GPUMP1002ServiceOutVo.class);
		
		return gpump1002Rsp;
	}
	
	@CosttimeAnnotation(title = "sendGPUMP1002")
	public TxResponseMsg sendGPUMP1002(TxRequestMsg gpump1002ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("GPUMP1002");
		traceLog.setRequestJsonString_gpump1002(JSONObject.toJSONString(gpump1002ReqMsg));
		JSONObject gpump1002RspJson = null;
		long beforeSendGpump1002reqMsg=System.currentTimeMillis();
		try {
			gpump1002RspJson = GPUMPClient.GPUMPServer(gpump1002ReqMsg,"GPUMP1002");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1002Rsp = JSONObjectUtil.toRspMsg(gpump1002RspJson, GPUMP1002ServiceOutVo.class);
		traceLog.setResponseJsonString_gpump1002(JSONObject.toJSONString(gpump1002Rsp));
		long afterResponse=System.currentTimeMillis()-beforeSendGpump1002reqMsg;
		traceLog.setHttpcost(afterResponse);
		return gpump1002Rsp;
	}
	
	/**
	 * 发送人脸1:N删除(GPUMP1003)请求
	 * @param gpump1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation(title = "sendGPUMP1003")
	public TxResponseMsg sendGPUMP1003(TxRequestMsg gpump1003ReqMsg) {
		JSONObject gpump1003RspJson = null;
		try {
			gpump1003RspJson = GPUMPClient.GPUMPServer(gpump1003ReqMsg,"GPUMP1003");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1003Rsp = JSONObjectUtil.toRspMsg(gpump1003RspJson, GPUMP1003ServiceOutVo.class);
		
		return gpump1003Rsp;
	}
	
	@CosttimeAnnotation(title = "sendGPUMP1003")
	public TxResponseMsg sendGPUMP1003(TxRequestMsg gpump1003ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("GPUMP1003");
		traceLog.setRequestJsonString_gpump1003(JSONObject.toJSONString(gpump1003ReqMsg));
		JSONObject gpump1003RspJson = null;
		long beforeSendGpump1003reqMsg=System.currentTimeMillis();
		try {
			gpump1003RspJson = GPUMPClient.GPUMPServer(gpump1003ReqMsg,"GPUMP1003");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1003Rsp = JSONObjectUtil.toRspMsg(gpump1003RspJson, GPUMP1003ServiceOutVo.class);
		long afterResponse=System.currentTimeMillis()-beforeSendGpump1003reqMsg;
		traceLog.setHttpcost(afterResponse);
		traceLog.setResponseJsonString_gpump1003(JSONObject.toJSONString(gpump1003Rsp));
		return gpump1003Rsp;
	}
	
	
	/**
	 * 发送人脸信息查询(GPUMP1004)请求
	 * @param gpump1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation(title = "sendGPUMP1004")
	public TxResponseMsg sendGPUMP1004(TxRequestMsg gpump1004ReqMsg) {
		JSONObject gpump1004RspJson = null;
		try {
			gpump1004RspJson = GPUMPClient.GPUMPServer(gpump1004ReqMsg,"GPUMP1004");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1004Rsp = JSONObjectUtil.toRspMsg(gpump1004RspJson, GPUMP1004ServiceOutVo.class);
		
		return gpump1004Rsp;
	}
	
	@CosttimeAnnotation(title = "sendGPUMP1004")
	public TxResponseMsg sendGPUMP1004(TxRequestMsg gpump1004ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("GPUMP1004");
		traceLog.setRequestJsonString_gpump1004(JSONObject.toJSONString(gpump1004ReqMsg));
		JSONObject gpump1004RspJson = null;
		try {
			gpump1004RspJson = GPUMPClient.GPUMPServer(gpump1004ReqMsg,"GPUMP1004");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1004Rsp = JSONObjectUtil.toRspMsg(gpump1004RspJson, GPUMP1004ServiceOutVo.class);
		traceLog.setResponseJsonString_gpump1004(JSONObject.toJSONString(gpump1004Rsp));
		return gpump1004Rsp;
	}
	
	
	/**
	 * 发送查询客户是否存在(GPUMP1005)请求
	 * @param gpump1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation(title = "sendGPUMP1005")
	public TxResponseMsg sendGPUMP1005(TxRequestMsg gpump1005ReqMsg) {
		JSONObject gpump1005RspJson = null;
		try {
			gpump1005RspJson = GPUMPClient.GPUMPServer(gpump1005ReqMsg,"GPUMP1005");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1005Rsp = JSONObjectUtil.toRspMsg(gpump1005RspJson, GPUMP1005ServiceOutVo.class);
		
		return gpump1005Rsp;
	}
	
	@CosttimeAnnotation(title = "sendGPUMP1005")
	public TxResponseMsg sendGPUMP1005(TxRequestMsg gpump1005ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("GPUMP1005");
		traceLog.setRequestJsonString_gpump1005(JSONObject.toJSONString(gpump1005ReqMsg));
		JSONObject gpump1005RspJson = null;
		try {
			gpump1005RspJson = GPUMPClient.GPUMPServer(gpump1005ReqMsg,"GPUMP1005");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1005Rsp = JSONObjectUtil.toRspMsg(gpump1005RspJson, GPUMP1005ServiceOutVo.class);
		traceLog.setResponseJsonString_gpump1005(JSONObject.toJSONString(gpump1005Rsp));
		return gpump1005Rsp;
	}
	
	
	/**
	 * 发送快速库入库(GPUMP1006)请求
	 * @param gpump1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation(title = "sendGPUMP1006")
	public TxResponseMsg sendGPUMP1006(TxRequestMsg gpump1006ReqMsg) {
		JSONObject gpump1006RspJson = null;
		try {
			gpump1006RspJson = GPUMPClient.GPUMPServer(gpump1006ReqMsg,"GPUMP1006");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1006Rsp = JSONObjectUtil.toRspMsg(gpump1006RspJson, GPUMP1006ServiceOutVo.class);
		
		return gpump1006Rsp;
	}
	
	@CosttimeAnnotation(title = "sendGPUMP1006")
	public TxResponseMsg sendGPUMP1006(TxRequestMsg gpump1006ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("GPUMP1006");
		traceLog.setRequestJsonString_gpump1006(JSONObject.toJSONString(gpump1006ReqMsg));
		JSONObject gpump1006RspJson = null;
		try {
			gpump1006RspJson = GPUMPClient.GPUMPServer(gpump1006ReqMsg,"GPUMP1006");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1006Rsp = JSONObjectUtil.toRspMsg(gpump1006RspJson, GPUMP1006ServiceOutVo.class);
		traceLog.setResponseJsonString_gpump1006(JSONObject.toJSONString(gpump1006Rsp));
		return gpump1006Rsp;
	}
	
	
	/**
	 * 发送快速库出库(GPUMP1007)请求
	 * @param gpump1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation(title = "sendGPUMP1007")
	public TxResponseMsg sendGPUMP1007(TxRequestMsg gpump1007ReqMsg) {
		JSONObject gpump1007RspJson = null;
		try {
			gpump1007RspJson = GPUMPClient.GPUMPServer(gpump1007ReqMsg,"GPUMP1007");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1007Rsp = JSONObjectUtil.toRspMsg(gpump1007RspJson, GPUMP1007ServiceOutVo.class);
		
		return gpump1007Rsp;
	}
	
	@CosttimeAnnotation(title = "sendGPUMP1007")
	public TxResponseMsg sendGPUMP1007(TxRequestMsg gpump1007ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("GPUMP1007");
		traceLog.setRequestJsonString_gpump1007(JSONObject.toJSONString(gpump1007ReqMsg));
		JSONObject gpump1007RspJson = null;
		try {
			gpump1007RspJson = GPUMPClient.GPUMPServer(gpump1007ReqMsg,"GPUMP1007");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1007Rsp = JSONObjectUtil.toRspMsg(gpump1007RspJson, GPUMP1007ServiceOutVo.class);
		traceLog.setResponseJsonString_gpump1007(JSONObject.toJSONString(gpump1007Rsp));
		return gpump1007Rsp;
	}
	
	
	/**
	 * 人脸1:1比对(GPUMP1008)请求
	 * @param gpump1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation(title = "sendGPUMP1008")
	public TxResponseMsg sendGPUMP1008(TxRequestMsg gpump1008ReqMsg) {
		JSONObject gpump1008RspJson = null;
		try {
			gpump1008RspJson = GPUMPClient.GPUMPServer(gpump1008ReqMsg,"GPUMP1008");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1008Rsp = JSONObjectUtil.toRspMsg(gpump1008RspJson, GPUMP1008ServiceOutVo.class);
		
		return gpump1008Rsp;
	}
	
	@CosttimeAnnotation(title = "sendGPUMP1008")
	public TxResponseMsg sendGPUMP1008(TxRequestMsg gpump1008ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("GPUMP1008");
		traceLog.setRequestJsonString_gpump1008(JSONObject.toJSONString(gpump1008ReqMsg));
		JSONObject gpump1008RspJson = null;
		try {
			gpump1008RspJson = GPUMPClient.GPUMPServer(gpump1008ReqMsg,"GPUMP1008");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1008Rsp = JSONObjectUtil.toRspMsg(gpump1008RspJson, GPUMP1008ServiceOutVo.class);
		traceLog.setResponseJsonString_gpump1008(JSONObject.toJSONString(gpump1008Rsp));
		return gpump1008Rsp;
	}
	
	
	/**
	 * 人脸图片比对(GPUMP1009)请求
	 * @param gpump1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation(title = "sendGPUMP1009")
	@TraceLogAnnotation("GPUMP1009")
	public TxResponseMsg sendGPUMP1009(TxRequestMsg gpump1009ReqMsg) {
		JSONObject gpump1009RspJson = null;
		try {
			gpump1009RspJson = GPUMPClient.GPUMPServer(gpump1009ReqMsg,"GPUMP1009");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1009Rsp = JSONObjectUtil.toRspMsg(gpump1009RspJson, GPUMP1009ServiceOutVo.class);
		
		return gpump1009Rsp;
	}
	
	@CosttimeAnnotation(title = "sendGPUMP1009")
	public TxResponseMsg sendGPUMP1009(TxRequestMsg gpump1009ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("GPUMP1009");
		traceLog.setRequestJsonString_gpump1009(JSONObject.toJSONString(gpump1009ReqMsg));
		JSONObject gpump1009RspJson = null;
		try {
			gpump1009RspJson = GPUMPClient.GPUMPServer(gpump1009ReqMsg,"GPUMP1009");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1009Rsp = JSONObjectUtil.toRspMsg(gpump1009RspJson, GPUMP1009ServiceOutVo.class);
		traceLog.setResponseJsonString_gpump1009(JSONObject.toJSONString(gpump1009Rsp));
		return gpump1009Rsp;
	}
	
	
	/**
	 * 人脸图片比对(GPUMP1010)请求
	 * @param gpump1001ReqMsg
	 * @return
	 */
	@CosttimeAnnotation("sendGPUMP1010")
	@TraceLogAnnotation("GPUMP1010")
	public TxResponseMsg sendGPUMP1010(TxRequestMsg gpump1010ReqMsg) {
		JSONObject gpump1010RspJson = null;
		try {
			gpump1010RspJson = GPUMPClient.GPUMPServer(gpump1010ReqMsg,"GPUMP1010");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1010Rsp = JSONObjectUtil.toRspMsg(gpump1010RspJson, GPUMP1010ServiceOutVo.class);
		
		return gpump1010Rsp;
	}
	
	@CosttimeAnnotation(title = "sendGPUMP1010")
	public TxResponseMsg sendGPUMP1010(TxRequestMsg gpump1010ReqMsg,TraceLog traceLog) {
		traceLog.setUrl("GPUMP1010");
		traceLog.setRequestJsonString_gpump1010(JSONObject.toJSONString(gpump1010ReqMsg));
		JSONObject gpump1010RspJson = null;
		try {
			gpump1010RspJson = GPUMPClient.GPUMPServer(gpump1010ReqMsg,"GPUMP1010");
		} catch (Exception e) {
			LOGGER.error("send GPUMPService fail: "+e.toString(),e);
			throw new CommonRuntimeException(Errorcode.SENDGPUMPERROR, "02", e.getMessage());
		}
		
		TxResponseMsg gpump1010Rsp = JSONObjectUtil.toRspMsg(gpump1010RspJson, GPUMP1010ServiceOutVo.class);
		traceLog.setResponseJsonString_gpump1010(JSONObject.toJSONString(gpump1010Rsp));
		return gpump1010Rsp;
	}
	
	
	
	
	
	
	
	
}
