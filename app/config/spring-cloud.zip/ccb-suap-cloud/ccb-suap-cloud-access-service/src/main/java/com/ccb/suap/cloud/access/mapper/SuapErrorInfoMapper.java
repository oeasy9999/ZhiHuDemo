package com.ccb.suap.cloud.access.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.ccb.suap.cloud.access.model.SuapErrorInfoModel;

@Mapper
public interface SuapErrorInfoMapper {
	
	@Insert("insert into SUAP_ERROR_INFO(ERRORCODE,ERRORTYPE,ERRORMSG,ISCONV) values(#{errorcode},#{errortype},#{errormsg},#{isconv})")
	int insert(SuapErrorInfoModel suapErrorInfoModel);
	
	@Select("select * from SUAP_ERROR_INFO")
	List<SuapErrorInfoModel> selectAll();
	
	
	
	
	
	
	
	
	
}
