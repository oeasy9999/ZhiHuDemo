package com.ccb.suap.cloud.access.vo;

public class INREC2003ServiceInVo extends INRECBaseServiceInVo{
	
	private String channel_cardno;					//渠道绑定卡号
	private String title;							//尊称
	private String is_vip;							//是否VIP客户
	private String reserve_info1;					//预留信息1
	private String reserve_info2;					//预留信息2
	private String reserve_info3;					//预留信息3
	
	public String getChannel_cardno() {
		return channel_cardno;
	}
	public void setChannel_cardno(String channel_cardno) {
		this.channel_cardno = channel_cardno;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getIs_vip() {
		return is_vip;
	}
	public void setIs_vip(String is_vip) {
		this.is_vip = is_vip;
	}
	public String getReserve_info1() {
		return reserve_info1;
	}
	public void setReserve_info1(String reserve_info1) {
		this.reserve_info1 = reserve_info1;
	}
	public String getReserve_info2() {
		return reserve_info2;
	}
	public void setReserve_info2(String reserve_info2) {
		this.reserve_info2 = reserve_info2;
	}
	public String getReserve_info3() {
		return reserve_info3;
	}
	public void setReserve_info3(String reserve_info3) {
		this.reserve_info3 = reserve_info3;
	}
	
	@Override
	public String toString() {
		return "INREC2003ServiceInVo [channel_cardno=" + channel_cardno + ", title=" + title + ", is_vip=" + is_vip
				+ ", reserve_info1=" + reserve_info1 + ", reserve_info2=" + reserve_info2 + ", reserve_info3="
				+ reserve_info3 + "]";
	}
	
	
	

	
	
	
}
