package com.ccb.suap.cloud.access.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;

import com.ccb.suap.cloud.access.model.SuapCustDeviceInfoModel;

@Mapper
public interface SuapCustDeviceInfoMapper {
	
	@Insert("insert into SUAP_CUST_DEVICE_INFO_${num}(IDTYPE,IDNUMBER,CHANNELID,CUSTNAME,CELLPHOME,CHANNEL_CSTNO,PHOTO_PATH,TITILE,ISVIP,CARDNO,IDVERIFY,SITENO,LOCATION,DEVICETYPE,DEVICEAUTHCODE,DEVICECODE,DEVICEVERSION,UPDATETIME,ISVALID) values(#{idtype},db_encrypt(#{idnumber}),#{channelid},#{custname},#{cellphome},db_encrypt(#{channel_cstno}),#{photo_path},#{titile},#{isvip},#{cardno},#{idverify},#{siteno},#{location},#{devicetype},#{deviceauthcode},#{devicecode},#{deviceversion},#{updatetime},#{isvalid})")
	int insert(SuapCustDeviceInfoModel suapCustDeviceInfoModel);
	
	@Delete("DELETE FROM SUAP_CUST_DEVICE_INFO_${num} WHERE IDTYPE=#{idtype} and IDNUMBER=db_encrypt(#{idno}) and CHANNELID=#{channelid}")
	int delete(@Param("num")String num,@Param("idtype")String idtype,@Param("idno")String idno,@Param("channelid")String channelid);
	
	@Select("select IDTYPE,db_decrypt(IDNUMBER) IDNUMBER,CHANNELID,CUSTNAME,CELLPHOME,db_decrypt(CHANNEL_CSTNO) CHANNEL_CSTNO,PHOTO_PATH,TITILE,ISVIP,CARDNO,IDVERIFY,SITENO,LOCATION,DEVICETYPE,DEVICEAUTHCODE,DEVICECODE,DEVICEVERSION,UPDATETIME,ISVALID from SUAP_CUST_DEVICE_INFO_${num} WHERE IDTYPE=#{idtype} and IDNUMBER=db_encrypt(#{idno}) and CHANNELID=#{channelid}")
	SuapCustDeviceInfoModel select(@Param("num")String num,@Param("idtype")String idtype,@Param("idno")String idno,@Param("channelid")String channelid);
	
	@UpdateProvider(type=SuapCustDeviceInfoDynaProveider.class,method="update")
	int update(SuapCustDeviceInfoModel suapCustDeviceInfoModel);
	
	@Update("update SUAP_CUST_DEVICE_INFO_${num} SET ISVALID='1' WHERE IDTYPE=#{idtype} and IDNUMBER=db_encrypt(#{idno}) and CHANNELID=#{channelid}")
	int close(@Param("num")String num,@Param("idtype")String idtype,@Param("idno")String idno,@Param("channelid")String channelid);
	
	
	
}
