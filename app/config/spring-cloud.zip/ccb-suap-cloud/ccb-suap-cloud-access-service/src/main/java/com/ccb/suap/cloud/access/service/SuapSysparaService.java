package com.ccb.suap.cloud.access.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ccb.suap.cloud.access.annotation.StatusAnnotation;
import com.ccb.suap.cloud.access.controller.ConfigRefreshContoller;
import com.ccb.suap.cloud.access.mapper.SuapSysparaMapper;

@Service
@StatusAnnotation
public class SuapSysparaService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigRefreshContoller.class);
	
	@Autowired
	SuapSysparaMapper dao;
	
	
	
	
	
	
}
